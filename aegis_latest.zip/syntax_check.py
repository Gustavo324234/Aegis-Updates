import sys


print("--- SYNTAX CHECK ---")
modules = [
    "modules.browser_tools",
    "modules.project_oracle",
    "modules.skill_builder",
    "modules.life_manager",
    "modules.codex",
    "modules.notifier",
    "modules.bridge_browser",
    "modules.vault_manager",
    "modules.beacon",
    "modules.updater",
    "modules.validator",
    "modules.web_search",
    "modules.web_reader",
    "modules.ide_bridge",
    "modules.unifier",
    "modules.resource_monitor",
    "modules.file_writer",
    "modules.nexus_gateway",
    "process_watchdog",
    "setup",
    "tools.build_installer",
    "aegis_limb",
    "app_telegram",
]

failed = []
for m in modules:
    try:
        if m in sys.modules:
            sys.modules.pop(m)  # Force reload
        __import__(m)
        print(f"[OK] {m}")
    except Exception as e:
        print(f"[FAIL] {m}: {e}")
        failed.append(m)

if failed:
    sys.exit(1)
else:
    print("All modules imported successfully.")
