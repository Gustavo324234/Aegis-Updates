import sys
import os

# Add project root to path
sys.path.append(os.getcwd())

from core_engine import llm_drivers, router


def test_exceptions():
    print("--- Testing Specialized Exceptions ---")
    try:
        # Simulate an Auth Error
        llm_drivers.query_gemini("sys", "hello", [], "INVALID_KEY")
    except llm_drivers.LLMAuthError as e:
        print(f"✅ Caught LLMAuthError: {e}")
    except Exception as e:
        print(f"❌ Failed to catch LLMAuthError, got {type(e).__name__}: {e}")


def test_model_health():
    print("\n--- Testing Model Health Registry ---")
    provider = "gemini"
    print(f"Initial health of {provider}: {router.ModelHealth.is_healthy(provider)}")

    router.ModelHealth.report_error(provider)
    print(
        f"Health after error: {router.ModelHealth.is_healthy(provider)} (Expected: False)"
    )

    router.ModelHealth.report_success(provider)
    print(
        f"Health after success: {router.ModelHealth.is_healthy(provider)} (Expected: True)"
    )


def test_brain_failover_logic():
    print("\n--- Testing Brain Failover Logic ---")
    # This is a bit harder to test without mocking the network,
    # but we can check if it skips unhealthy providers.
    provider = "gemini"
    router.ModelHealth.report_error(provider)

    # We'll just check if ModelHealth works as integrated in Brain (logical check)
    if not router.ModelHealth.is_healthy(provider):
        print(f"✅ Brain will skip {provider} correctly.")
    else:
        print(f"❌ Brain would NOT skip {provider}.")


if __name__ == "__main__":
    test_exceptions()
    test_model_health()
    test_brain_failover_logic()
