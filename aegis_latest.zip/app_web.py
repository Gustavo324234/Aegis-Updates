import streamlit as st
import os
import database
import json
import time
from core import AegisBrain
from modules.auth_vault import auth
from gtts import gTTS
import io
import requests
import datetime


import modules.studio_exporter

try:
    from streamlit_mic_recorder import speech_to_text
except ImportError:
    speech_to_text = None

# Logic removed to fix duplication


# Initialize database
database.init_db()

# --- HUGGING FACE AUTHENTICATION & SILENCER ---
# Critical Path: Inject Token before any ML library loads
try:
    hf_token = database.get_setting("hf_token")
    if hf_token:
        os.environ["HF_TOKEN"] = hf_token.strip()
        # print("[INIT] Hugging Face Token Injected.")

    # Silence HF Hub Warnings (Unauthenticated requests spam)
    import logging
    logging.getLogger("huggingface_hub").setLevel(logging.ERROR)
except Exception:
    pass

# --- SRE DEPENDENCY CHECK ---
@st.cache_resource
def get_daemon_manager():
    """Singleton for DaemonManager to prevent zombie threads."""
    from modules.daemon_manager import DaemonManager
    manager = DaemonManager()
    manager.start()
    return manager

# Ensure critical modules are present on runtime.
def check_dependencies():
    """Ensures critical modules are present on runtime."""
    required = ["cryptography", "google.generativeai", "pyngrok", "requests"]
    missing = []
    
    # Check imports
    try: import cryptography
    except ImportError: missing.append("cryptography")
    
    try: import google.generativeai
    except ImportError: missing.append("google-generativeai")
    
    try: import pyngrok
    except ImportError: missing.append("pyngrok")
    
    try: import requests
    except ImportError: missing.append("requests")
    
    if missing:
        st.error(f"⚠️ MISSING DEPENDENCIES: {', '.join(missing)}")
        st.info("Attempting auto-repair...")
        import subprocess
        import sys
        import os
        
        # Debian 12 Check
        import platform
        use_break = False
        try:
            # Quick check file presence
            if os.path.exists("/etc/debian_version"):
                 with open("/etc/debian_version") as f:
                     if float(f.read().strip()) >= 12: use_break = True
        except: pass
        
        cmd = [sys.executable, "-m", "pip", "install"] + missing
        if use_break and sys.prefix == sys.base_prefix:
            cmd.append("--break-system-packages")
            
        try:
            subprocess.check_call(cmd)
            st.success("Repaired! Please refresh the page.")
            time.sleep(2)
            st.rerun()
        except:
            st.error("Auto-repair failed. Please run 'python setup.py' manually.")
            st.stop()

check_dependencies()

# --- REALTIME LOGGING (AUDIT HOOK) ---
from modules.db_logger import setup_db_logger
setup_db_logger()
print("[INIT] Database Logger System Activated.")

# --- AUTHENTICATION & ONBOARDING ---
if 'authenticated' not in st.session_state:
    st.session_state.authenticated = False

def render_login():
    st.markdown("""
    <style>
        .login-box {
            max-width: 400px;
            margin: 100px auto;
            padding: 40px;
            background: rgba(22, 27, 34, 0.9);
            border: 1px solid #30363d;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 0 20px rgba(0, 242, 255, 0.1);
        }
    </style>
    """, unsafe_allow_html=True)
    
    col1, col2, col3 = st.columns([1,2,1])
    with col2:
        st.title("🛡️ AEGIS-IA")
        st.caption("SYSTEM ACCESS LOCKED")
        
        with st.form("main_login_form"):
            password = st.text_input("IDENTITY VERIFICATION", type="password", placeholder="Enter Master Password")
            submit_auth = st.form_submit_button("AUTHENTICATE SYSTEM")
            
            if submit_auth:
                if auth.verify_password(password):
                    st.session_state.authenticated = True
                    st.session_state.master_password = password
                    
                    # Derive Session Encryption Key (Fernet)
                    try:
                        st.session_state.enc_key = auth.derive_key(password)
                    except Exception as e:
                        st.error(f"Crypto Init Failed: {e}")
                        
                    st.success("ACCESS GRANTED")
                    
                    # Load API Key Ring
                    keys = database.get_api_keys()
                    key_ring = {}
                    if keys:
                        for k in keys:
                            try:
                                decrypted = auth.decrypt_content(k['api_key'], st.session_state.enc_key)
                                key_ring[k['provider']] = decrypted
                            except Exception as e:
                                print(f"Key Decrypt Fail for {k['provider']}: {e}")
                    
                    st.session_state.api_key_ring = key_ring
                    
                    time.sleep(1)
                    st.rerun()
                else:
                    st.error("ACCESS DENIED: INVALID CREDENTIALS")

def render_onboarding():
    st.markdown("""
    <style>
        .onboarding-card {
            background-color: #161b22;
            padding: 30px;
            border-radius: 10px;
            border: 1px solid #30363d;
            text-align: center;
            margin-bottom: 20px;
        }
        .pillar {
            display: inline-block;
            width: 30%;
            margin: 1%;
            padding: 10px;
            background: rgba(0, 242, 255, 0.05);
            border-radius: 8px;
        }
    </style>
    """, unsafe_allow_html=True)

    step = st.session_state.get('onboarding_step', 0)
    
    # --- STEP 0: WELCOME ---
    if step == 0:
        st.title("🛡️ Aegis-IA Workspace")
        st.markdown("### Bienvenido a su entorno privado.")
        st.write("Este sistema opera de manera aislada. Su base de datos y archivos son exclusivos de esta instancia.")
        
        st.divider()
        
        ai_name = st.text_input("Nombre para su Asistente", placeholder="Ej: Aegis, Jarvis, Cortana...", value="Aegis")
        
        if st.button("Comenzar Configuración", type="primary"):
            if ai_name.strip():
                database.set_setting('ai_name', ai_name.strip())
                # Implicitly set a default master password for tenant mode to simplify UX
                # In a real SaaS, this would be the user's login password.
                # Here we set a discrete default to enable the crypto vault.
                auth.set_master_password("tenant_default_secure")
                st.session_state.master_password = "tenant_default_secure"
                st.session_state.onboarding_step = 1
                st.rerun()
            else:
                st.warning("Por favor, elija un nombre.")

    # --- STEP 1: API KEY (THE BRAIN) ---
    elif step == 1:
        st.subheader("🔑 Activación Neuronal")
        st.markdown("""
        Para que **Aegis** pueda razonar, necesita conectarse a un modelo de lenguaje.
        
        Opción A: **Google Gemini (Recomendado)** - Rápido, Gratuito y Potente.
        Opción B: **Modo Local (Ollama)** - Privacidad total, requiere hardware potente.
        """)
        
        st.markdown("[Obtener Gemini API Key Gratis](https://aistudio.google.com/app/apikey)")
        
        api_key = st.text_input("Ingrese su Google Gemini API Key", type="password", placeholder="AIzaSy...")
        
        col1, col2 = st.columns(2)
        with col1:
            if st.button("Guardar y Activar", type="primary"):
                if api_key and str(api_key).startswith("AI"):
                    auth.set_api_key(api_key, st.session_state.master_password)
                    st.success("API Key Guardada en Bóveda Segura.")
                    time.sleep(1)
                    st.session_state.onboarding_step = 2
                    st.rerun()
                else:
                    st.error("API Key inválida (Debe comenzar con 'AI').")
        
        with col2:
            if st.button("Usar Modo Local (Ollama)"):
                st.info("Configurando Modo Soberano...")
                database.set_setting("active_model", "ollama-llama3.1")
                database.set_setting("api_key_gemini", "local_mode_active")
                time.sleep(1)
                st.session_state.onboarding_step = 2
                st.rerun()

    # --- STEP 2: FINALIZATION ---
    elif step == 2:
        st.subheader("✅ Todo Listo")
        st.write("Su espacio de trabajo está configurado y aislado.")
        st.info("Todos los datos generados se guardarán en su carpeta personal.")
        
        if st.button("LAUNCH SYSTEM", type="primary"):
            database.set_setting('setup_complete', 'true')
            st.session_state.authenticated = True
            
            # Init Session Key
            try:
                st.session_state.enc_key = auth.derive_key(st.session_state.master_password)
            except: pass
            
            st.balloons()
            time.sleep(1)
            st.rerun()

# prepare_studio_context moved to modules/studio_exporter.py

# Logic: STRICT ENFORCEMENT
# Determine if setup is complete: Checked via Database Settings
setup_complete = database.get_setting('setup_complete') == 'true'

if not setup_complete:
    render_onboarding()
    st.stop() # HALT execution if not set up
    
if not st.session_state.authenticated:
    render_login()
    st.stop() # HALT execution if not logged in
    
# --- MAIN APP ---
# Initialize Brain
brain = AegisBrain()

st.set_page_config(page_title="Aegis-IA V10", layout="wide", page_icon="🛡️")

# --- PROTOCOL DAWN (Audio Briefing) ---
briefing_file = "briefing_today.mp3"
if os.path.exists(briefing_file) and "briefing_played" not in st.session_state:
    st.audio(briefing_file, format="audio/mp3", autoplay=True)
    st.session_state.briefing_played = True
    st.toast("☀️ Protocol Dawn: Briefing Active")

# --- CUSTOM CSS (Hades V2: Cyber-Dark Professional + Mobile) ---
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;700&display=swap');
    
    /* GLOBAL RESET */
    .stApp { 
        background-color: #050505 !important; 
        color: #e0e0e0; 
        font-family: 'JetBrains Mono', monospace !important; 
    }
    
    /* SIDEBAR */
    section[data-testid="stSidebar"] { 
        background-color: #000000 !important; 
        border-right: 1px solid #1f1f1f; 
    }
    
    /* CHAT BUBBLES - NEON GLOW */
    .stChatMessage { 
        background: #0a0a0a !important;
        border: 1px solid #1f1f1f;
        border-radius: 4px !important;
        padding: 15px;
        margin-bottom: 10px;
        transition: all 0.3s ease;
        box-shadow: 0 0 5px rgba(0,0,0,0.5);
    }
    
    /* USER BUBBLE (Right/Different color?) - Standardizing to left but specific accent */
    div[data-testid="stChatMessage"]:nth-child(even) {
        border-left: 2px solid #00ff41 !important; /* Matrix Green */
        box-shadow: -2px 0 10px rgba(0, 255, 65, 0.1);
    }
    
    /* AI BUBBLE */
    div[data-testid="stChatMessage"]:nth-child(odd) {
        border-left: 2px solid #00f2ff !important; /* Cyan */
        box-shadow: -2px 0 10px rgba(0, 242, 255, 0.1);
    }
    
    .stChatMessage:hover {
        transform: translateX(2px);
        box-shadow: 0 0 15px rgba(0, 242, 255, 0.2);
        border-color: #333;
    }

    /* INPUT FIELD */
    .stTextInput input, .stChatInput textarea {
        background-color: #0a0a0a !important;
        color: #00f2ff !important;
        border: 1px solid #333 !important;
        font-family: 'JetBrains Mono', monospace !important;
    }
    .stTextInput input:focus, .stChatInput textarea:focus {
        border-color: #00f2ff !important;
        box-shadow: 0 0 10px rgba(0, 242, 255, 0.3) !important;
    }
    
    /* BUTTONS */
    .stButton button {
        background-color: #111 !important;
        color: #00f2ff !important;
        border: 1px solid #333 !important;
    }
    .stButton button:hover {
        background-color: #00f2ff !important;
        color: #000 !important;
    }

     /* SPINNER */
    .stSpinner > div {
        border-color: #00f2ff transparent #00f2ff transparent !important;
        opacity: 0.8;
    }
    
    /* CUSTOM STATUS BAR */
    .sys-log {
        font-size: 0.75rem;
        color: #666;
        border-top: 1px solid #222;
        padding-top: 5px;
        margin-top: 5px;
        font-family: 'JetBrains Mono', monospace;
    }
    
    /* MOBILE OPTIMIZATIONS */
    @media (max-width: 600px) {
        .stButton button { width: 100% !important; margin-bottom: 5px; }
        .stChatMessage { margin-left: 0 !important; margin-right: 0 !important; }
        /* Keep header minimal */
        [data-testid="stHeader"] { visibility: hidden; }
        .block-container { padding-top: 2rem !important; }
    }
</style>
<!-- Mobile PWA Meta -->
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover" />
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="theme-color" content="#0e1117">
<link rel="manifest" href="data:application/json;base64,eyJuYW1lIjogIkFlZ2lzLUlBIiwgInNob3J0X25hbWUiOiAiQWVnaXMiLCAic3RhcnRfdXJsIjogIi8iLCAiZGlzcGxheSI6ICJzdGFuZGFsb25lIiwgImJhY2tncm91bmRfY29xvciI6ICIjMGUxMTE3IiwgInRoZW1lX2NvbG9yIjogIiMwZTExMTcifQ==">
""", unsafe_allow_html=True)

# --- SIDEBAR & CONTEXT ---
with st.sidebar:
    ai_name = database.get_setting("ai_name") or "Aegis-IA"
    st.title(f"🛡️ {ai_name}")
    st.caption("The Singularity Edition")
    
    # PROJECT NEXUS INDICATOR
    active_projects = database.get_active_projects()
    if active_projects:
        st.success(f"🟢 NEXUS ACTIVE: {', '.join(active_projects)}")

    # System Health Indicator
    from modules.resource_monitor import monitor
    # Note: check_health() triggers cleanup if RED
    health_status = monitor.check_health()
    
    color = "green" if health_status == "GREEN" else "orange" if health_status == "YELLOW" else "red"
    st.markdown(f"**STATUS:** :{color}[●] {health_status} | **RAM:** {monitor.get_metrics()['app_ram_usage_mb']}MB")
    
    st.divider()

    # --- 🌐 NETWORK MESH ---
    with st.expander("🌐 Network Mesh", expanded=True):
        nodes = database.get_all_nodes()
        if nodes:
            for node in nodes:
                # Calculate basic latency/status
                last_seen_str = node.get('last_seen', '')
                status = node.get('status', 'offline')
                latency_disp = "N/A"
                
                status_color = "🔴" # Offline
                swarming = False
                
                if status == 'online':
                    status_color = "🟢" # Online Standard
                    if node.get('contribution_mode'):
                        status_color = "⚡" # Swarm Contributor
                        swarming = True
                        
                    # Mock Latency
                    try:
                        dt = datetime.datetime.fromisoformat(last_seen_str)
                        diff = (datetime.datetime.now() - dt).total_seconds()
                        if diff < 60:
                             latency_disp = f"{int(diff * 1000) % 50 + 10}ms"
                        else:
                             latency_disp = "High Latency"
                    except:
                        pass
                else:
                    status_color = "⚫" # Dead

                c1, c2 = st.columns([3, 1])
                with c1:
                    st.markdown(f"**{node['node_id']}**")
                    caption_text = f"{status_color} {latency_disp} | {node.get('last_ip')}"
                    if swarming: caption_text += " | **Swarm Ready**"
                    st.caption(caption_text)
                    
                    # Display Remote Index Status
                    last_idx = node.get('last_indexed')
                    if last_idx:
                        try:
                            # Parse ISO format
                            ts = datetime.datetime.fromisoformat(last_idx)
                            nice_time = ts.strftime("%b %d, %H:%M:%S")
                            st.caption(f"📂 **Remote Index:** {nice_time}")
                        except:
                            st.caption(f"📂 Remote Index: {last_idx}")
                    
                with c2:
                    if swarming:
                        if st.button("🚀 Task", key=f"del_{node['node_id']}"):
                             st.toast(f"Delegating tasks to {node['node_id']}...")
                             
                             # 1. Prepare Command
                             cmd_data = {
                                 "cmd": "delegate_task", # Match Limb CommandHandler
                                 "task_type": "index_folder",
                                 "payload": {"path": "."}
                             }
                             
                             # 2. Get Key and Encrypt
                             node_key = database.get_node_key(node['node_id'])
                             if node_key:
                                 try:
                                     # auth.encrypt_content expects string content and key_token (bytes or string)
                                     # Ensure json string
                                     json_str = json.dumps(cmd_data)
                                     enc_token = auth.encrypt_content(json_str, node_key)
                                     
                                     payload = {
                                         "target_node": node['node_id'],
                                         "content": {"encrypted_data": enc_token}
                                     }
                                     resp = requests.post("http://localhost:8000/send_message", json=payload)
                                     if resp.status_code == 200:
                                         st.success("Task Sent (Encrypted).")
                                     else:
                                         st.error(f"Gateway Error: {resp.text}")
                                 except Exception as e:
                                     st.error(f"Encryption/Send Failed: {e}")
                             else:
                                 st.error("Missing Fernet Key for Node. Re-pair device.")
                    else:
                        if st.button("⚙️", key=f"conf_{node['node_id']}"):
                            st.toast(f"Configuring {node['node_id']}...")
                st.divider()
        else:
            st.info("No nodes linked. Start a Limb.")

        # NEXUS PAIRING
        st.subheader("🔗 Device Pairing")
        if st.button("Generate Pairing Code"):
            # Generate random 6-digit code
            import random
            import string
            code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))
            
            # Save to DB (valid 10 mins)
            database.create_pairing_code(code)
            
            # Generate QR (Clean JSON for mobile app/Satellite)
            config_payload = json.dumps({
                "gateway": "ws://REPLACE_WITH_IP:8000/ws", 
                "code": code
            })
            
            from modules.beacon import beacon
            local_url = beacon.get_local_ip(port=8000) # Get Gateway Port
            final_payload = config_payload.replace("REPLACE_WITH_IP", local_url.replace("http://", ""))
            
            qr_img = beacon.generate_qr(final_payload)
            
            st.session_state.pairing_code = code
            st.session_state.pairing_qr = qr_img
        
        if "pairing_code" in st.session_state:
            c1, c2 = st.columns([1, 1])
            with c1:
                st.metric("Pairing Code", st.session_state.pairing_code, "Expires in 10m")
                st.caption("Enter this code in your Aegis Limb (Satellite).")
            with c2:
                st.image(st.session_state.pairing_qr, width=150, caption="Scan to Auto-Configure")


    # TELEMETRY CONSOLE (Hades V2)
    st.caption("📟 **SYSTEM TELEMETRY**")
    
    # Fetch recent logs for display
    # We query DB for last 3 actions
    recent_audits = database.get_audit_logs(limit=5)
    log_lines = []
    
    # Mocking some "system" logs if audits are empty to show the UI
    if not recent_audits:
        log_lines.append("[SYS] CORE: Online")
        log_lines.append("[SYS] LINK: Secure")
        
    for log in recent_audits:
        # log structure: (timestamp, module, action, status, approved)
        # format timestamp to HH:MM:SS
        try:
            ts = log[0].split("T")[1][:8]
        except:
            ts = "00:00:00"
        log_lines.append(f"[{ts}] {str(log[1]).upper()}: {log[2]}")
        
    # Join with breaks
    log_html = f"<div class='sys-log'>{'<br>'.join(log_lines[:5])}</div>"
    st.markdown(log_html, unsafe_allow_html=True)
    
    st.divider()
    st.subheader("📡 The Beacon")
    if st.button("Generate Mobile Access"):
        from modules.beacon import beacon
        with st.spinner("Establishing Secure Tunnel..."):
            public_url = beacon.start_tunnel()
            if "http" in public_url:
                st.success("Beacon Lit!")
                st.code(public_url)
                qr_img = beacon.generate_qr(public_url)
                st.image(qr_img, caption="Scan to Connect", width=200)
            else:
                st.error(public_url)
    
    st.divider()
    st.subheader("Memory Operations")
    if st.button("PURGE MEMORY"):
        conn = database.sqlite3.connect("aegis_memory.db")
        c = conn.cursor()
        c.execute("DELETE FROM history")
        conn.commit()
        conn.close()
        st.success("Memory Purged.")
        st.rerun()
    
    if st.button("♻️ SYSTEM RESET (Reload Core)"):
        st.cache_resource.clear()
        st.success("Core Reloaded.")
        time.sleep(1)
        st.rerun()

# --- NAVIGATION & SIDEBAR CONTENT ---
with st.sidebar:
    st.divider()
    
    # 1. Dashboard Expander
    with st.expander("📊 Stats & Data"):
        st.subheader("Nexus Dashboard")
        st.markdown("**💰 Finance Stream**")
        expenses = database.get_expenses(limit=50)
        total_monthly = sum(e[1] for e in expenses) if expenses else 0
        st.metric("Total Stream", f"${total_monthly:,.2f}")
        
        st.divider()
        st.markdown("**📝 Tasks**")
        pending_tasks = database.get_tasks(status='pending')
        st.metric("Pending", len(pending_tasks))
        
        st.divider()
        from modules.env_probe import probe
        st.markdown("**🖥️ System**")
        st.code(probe.get_system_context())

    # 2. Missions Expander
    with st.expander("🛰️ Mission Control"):
        st.info("Sentinel Status: ACTIVE")
        from modules.vault_manager import vault
        if st.button("🔄 Index Vault (New)"):
            files = vault.scan_vault()
            st.success(f"Indexed {len(files)} docs.")
        
        if st.button("🔄 Sincronizar Bóveda Antigua"):
            status = vault.rebuild_index()
            st.info(status)

    # 3. Unify / Bridge Expander
    with st.expander("🔄 Unify / Bridge"):
        st.info("Use the 'Synapse' module to sync with external AIs.")
        from modules.unifier import unifier
        st.markdown("### 📥 Import Memories")
        st.caption("Upload ChatGPT exports, Documents (PDF/Excel), or Audio logs.")
        uploaded_file = st.file_uploader("Choose a file", type=['json', 'zip', 'txt', 'pdf', 'csv', 'xlsx', 'xls', 'mp3', 'wav'])
        
        if uploaded_file is not None:
            if st.button("Start Ingestion"):
                with st.spinner("Processing & Indexing..."):
                    file_type = uploaded_file.name.split('.')[-1].lower()
                    result = "Unknown file type"
                    try:
                        if file_type == 'json':
                            result = unifier.ingest_json_export(uploaded_file)
                        elif file_type == 'zip':
                            result = unifier.ingest_zip_export(uploaded_file)
                        elif file_type == 'txt':
                            text = uploaded_file.read().decode('utf-8', errors='ignore')
                            result = unifier.ingest_text(text, source="Upload")
                        elif file_type in ['pdf', 'csv', 'xlsx', 'xls', 'mp3', 'wav']:
                            import os
                            # Save binary content
                            safe_name = os.path.basename(uploaded_file.name)
                            if not os.path.exists("vault"): os.makedirs("vault")
                            
                            with open(os.path.join("vault", safe_name), "wb") as f:
                                f.write(uploaded_file.getbuffer())
                            
                            # Index via Vault (Universal Bridge)
                            from modules.vault_manager import vault
                            result = vault.index_file(safe_name)
                            
                        st.success(result)
                    except Exception as e:
                        st.error(f"Import Error: {str(e)}")
        
        st.divider()
        st.markdown("**Imported Contexts**")
        imports = unifier.get_imported_contexts()
        if imports:
            for fname, date in imports[:5]:
                st.text(f"{date[:10]} - {fname[:20]}...")
                
        # --- EXPORT FOR AI STUDIO ---
        st.divider()
        st.markdown("### 📤 Export for AI Studio")
        st.caption("Includes Remote Workspace Maps.")
        
        if st.checkbox("Generate Context File"):
             current_history = database.get_history(limit=50) 
             context_txt = modules.studio_exporter.prepare_studio_context(current_history)
             st.download_button("💾 Download .txt", context_txt, f"aegis_ctx_{datetime.datetime.now().strftime('%H%M')}.txt")

    # 4. Active Daemons Expander (Overseer Engine)
    with st.expander("📡 Active Daemons"):
        daemon_manager = get_daemon_manager()
        import os
        
        # Quick Launchers
        col1, col2 = st.columns(2)
        with col1:
            if st.button("Start MemoryGuard"):
                res = daemon_manager.register_daemon("MemoryGuard", "resource_watcher", {"min_ram_mb": 500}, interval=60)
                st.toast(res)
                st.rerun()
        with col2:
            if st.button("Start DL Organizer"):
                try:
                    dl_path = os.path.join(os.path.expanduser("~"), "Downloads")
                except:
                    dl_path = "C:/Downloads" # Fallback
                res = daemon_manager.register_daemon("DownloadGuard", "folder_guard", {"path": dl_path}, interval=300) 
                st.toast(res)
                st.rerun()

        st.divider()
        st.markdown("**Overseer Control**")
        
        active_daemons = daemon_manager.list_daemons()
        if not active_daemons:
            st.info("No active daemons.")
        
        for d in active_daemons:
            status_icon = "🟢" if d['status'] == 'RUNNING' else "🔴"
            st.markdown(f"**{d['name']}**")
            st.caption(f"{status_icon} {d['status']} | Type: {d['type']}")
            st.caption(f"Last Run: {d['last_run']}")
            
            if d['status'] == 'RUNNING':
                if st.button(f"Stop {d['name']}", key=f"stop_{d['id']}"):
                    daemon_manager.stop_daemon(d['name'])
                    st.rerun()
            else:
                if st.button(f"Restart {d['name']}", key=f"start_{d['id']}"):
                    daemon_manager.start_daemon(d['name'])
                    st.rerun()
             
            st.divider()

    # 5. Audit Log Expander (Enhanced)
    with st.expander("🛡️ Audit Log"):
        # Clear Button
        c_clear, c_space = st.columns([2, 3])
        if c_clear.button("🗑️ Limpiar Logs", key="clear_audit_logs"):
             try:
                 conn = database.get_connection()
                 conn.execute("DELETE FROM audit_log")
                 conn.commit()
                 conn.close()
                 st.success("Audit Log Cleared")
                 time.sleep(1)
                 st.rerun()
             except Exception as e:
                 st.error(f"Failed to clear logs: {e}")

        logs = database.get_audit_logs(limit=50) # Increased limit
        if logs:
            # logs structure: [(timestamp, module, action, status, approved), ...]
            
            log_html_accum = ""
            for log in logs:
                # log: 0=ts, 1=mod, 2=act, 3=stat, 4=appr
                ts_raw = log[0]
                ts_display = ts_raw.split("T")[1][:8] if "T" in ts_raw else str(ts_raw)[-8:]
                
                module = str(log[1])
                msg = str(log[2])
                status = str(log[3]).upper()
                
                # Color match
                color = "#888888" # Default text (INFO)
                border_color = "#333"
                icon = "ℹ️"
                
                if status in ["FAILURE", "ERROR", "CRITICAL"]:
                    color = "#ff4b4b" # Red
                    border_color = "#990000"
                    icon = "❌"
                elif status in ["WARNING", "WARN"]:
                    color = "#ffa500" # Orange
                    border_color = "#aa6600"
                    icon = "⚠️"
                elif status == "SUCCESS":
                    color = "#00ff41" # Green
                    border_color = "#005500"
                    icon = "✅"
                
                # Use simplified HTML for streamlit markdown safety
                log_html_accum += f"""
                <div style='
                    border-left: 3px solid {border_color}; 
                    background: rgba(0,0,0,0.2);
                    padding: 8px; 
                    margin-bottom: 4px; 
                    font-size: 0.8rem;
                    border-radius: 4px;'>
                    <div style='color: #666; font-size: 0.7em;'>{ts_display} | {module}</div>
                    <div style='color: {color}; font-weight: bold;'>{icon} {status}</div>
                    <div style='color: #ddd; word-wrap: break-word;'>{msg}</div>
                </div>
                """
            
            # Wrap in scrollable container
            final_html = f"<div style='max-height: 400px; overflow-y: auto; padding-right: 5px;'>{log_html_accum}</div>"
            st.markdown(final_html, unsafe_allow_html=True)
            
        else:
            st.caption("No audit records found.")

    # 5. Settings Expander (Enriched V14)
    with st.expander("⚙️ Settings"):
        
        tab_ai, tab_keys, tab_sys, tab_store = st.tabs(["🧠 AI Brain", "🔐 API Vault", "🔄 System", "🛒 Store"])
        
        with tab_ai:
            st.caption("Architecture Configuration")
            
            # --- 0. OPERATION MODE SELECTOR ---
            current_mode = database.get_setting("operation_mode") or "Hybrid (Smart)"
            op_mode = st.radio("Source of Intelligence", ["Cloud Only", "Local Only (Sovereign)", "Hybrid (Smart)"], 
                               index=["Cloud Only", "Local Only (Sovereign)", "Hybrid (Smart)"].index(current_mode),
                               horizontal=True)
            
            if op_mode != current_mode:
                database.set_setting("operation_mode", op_mode)
                st.rerun()

            st.divider()

            # --- 1. OLLAMA CONFIGURATION (Local & Hybrid) ---
            local_models = []
            if op_mode in ["Local Only (Sovereign)", "Hybrid (Smart)"]:
                st.markdown("**🤖 Local Brain (Ollama)**")
                current_ollama_url = database.get_setting("ollama_url") or "http://localhost:11434"
                
                c_url, c_test = st.columns([3, 1])
                with c_url:
                    ollama_url = st.text_input("Connection URL", value=current_ollama_url, label_visibility="collapsed")
                with c_test:
                    if st.button("Test Link"):
                         try:
                             tags_url = f"{ollama_url}/api/tags" if not ollama_url.endswith("/") else f"{ollama_url}api/tags"
                             resp = requests.get(tags_url, timeout=3)
                             if resp.status_code == 200:
                                 st.success("Online!")
                             else:
                                 st.error(f"Error: {resp.status_code}")
                         except Exception as e:
                             st.error("Unreachable")

                if ollama_url != current_ollama_url:
                    database.set_setting("ollama_url", ollama_url.strip())
                    st.rerun()

                # Fetch Local Models
                try:
                    tags_url = f"{ollama_url}/api/tags" if not ollama_url.endswith("/") else f"{ollama_url}api/tags"
                    tags_resp = requests.get(tags_url, timeout=2)
                    if tags_resp.status_code == 200:
                        data = tags_resp.json()
                        local_models = [m['name'] for m in data.get('models', [])]
                except:
                    if op_mode == "Local Only (Sovereign)":
                         st.error(f"⚠️ Sovereignty Lost: Cannot connect to {ollama_url}")
                    else:
                         st.warning(f"Ollama disconnected at {ollama_url}")

                st.divider()

            # --- 2. ACTIVE MODEL SELECTOR ---
            
            # Base Cloud Models
            cloud_models = [
                "gemini-1.5-flash", "gemini-1.5-pro", 
                "gpt-4o-mini", "gpt-4o", 
                "claude-3-haiku-20240307", "claude-3-opus-20240229",
                "llama3-70b-8192", "mixtral-8x7b-32768", # Groq
                "google/gemini-2.0-flash-exp:free" # OpenRouter
            ]
            
            # Determine Available Options based on Mode
            model_options = []
            if op_mode == "Cloud Only":
                model_options = cloud_models
            elif op_mode == "Local Only (Sovereign)":
                model_options = local_models if local_models else ["No Local Models Found"]
            else: # Hybrid
                model_options = local_models + cloud_models

            current_model = database.get_setting("active_model") or "gemini-1.5-flash"
            
            # Safeguard if current model not in available options (e.g. switched mode)
            if model_options and current_model not in model_options:
                current_model = model_options[0]
                # Auto-update setting to avoid mismatch
                database.set_setting("active_model", current_model)
            
            if model_options:
                selected_model = st.selectbox("Active Model (Base)", model_options, index=model_options.index(current_model) if current_model in model_options else 0)
                if selected_model != current_model:
                    database.set_setting("active_model", selected_model)
                    st.rerun()
            else:
                st.error("No models available in this mode.")

            st.divider()
            
            # --- HUGGING FACE AUTH ---
            st.markdown("### 🤗 Hugging Face Token")
            curr_hf = database.get_setting("hf_token") or ""
            new_hf = st.text_input("HF_TOKEN (Optional - For Gated Models)", value=curr_hf, type="password", help="Needed to download restricted models without warnings.")
            if new_hf != curr_hf:
                database.set_setting("hf_token", new_hf)
                st.toast("HF Token Updated. Restart required.")
            
            # --- SATELLITE CONFIG ---
            st.divider()

            # --- 3. SMART MODE (Hybrid Only) ---
            if op_mode == "Hybrid (Smart)":
                st.divider()
                current_smart = database.get_setting("smart_mode") == "true"
                smart_mode = st.toggle("🧠 Enable Smart Mode (AI Tiering)", value=current_smart)
                if smart_mode != current_smart:
                    database.set_setting("smart_mode", "true" if smart_mode else "false")
                    st.rerun()

            st.divider()
            
            # --- 4. SPECIALIST ROLES (Local/Hybrid) ---
            if op_mode in ["Local Only (Sovereign)", "Hybrid (Smart)"] and local_models:
                st.markdown("**🦾 Specialist Roles (Ollama)**")
                
                col_spec1, col_spec2 = st.columns(2)
                
                # Defaults
                def_chat = database.get_setting("local_chat_model") or local_models[0]
                def_logic = database.get_setting("local_logic_model") or local_models[0]
                def_coder = database.get_setting("local_coder_model") or local_models[0]
                def_heavy = database.get_setting("local_heavy_model") or local_models[0]
                
                # Ensure defaults exist
                if def_chat not in local_models: def_chat = local_models[0]

                with col_spec1:
                    s_chat = st.selectbox("💬 Chat (Default)", local_models, index=local_models.index(def_chat) if def_chat in local_models else 0)
                    if s_chat != def_chat: database.set_setting("local_chat_model", s_chat)
                    
                    s_coder = st.selectbox("💻 Code Specialist", local_models, index=local_models.index(def_coder) if def_coder in local_models else 0)
                    if s_coder != def_coder: database.set_setting("local_coder_model", s_coder)

                with col_spec2:
                    s_logic = st.selectbox("🧠 Logic/Reasoning", local_models, index=local_models.index(def_logic) if def_logic in local_models else 0)
                    if s_logic != def_logic: database.set_setting("local_logic_model", s_logic)
                    
                    s_heavy = st.selectbox("📚 Heavy Context", local_models, index=local_models.index(def_heavy) if def_heavy in local_models else 0)
                    if s_heavy != def_heavy: database.set_setting("local_heavy_model", s_heavy)
            
            st.divider()
            st.markdown("**🔊 Voice Interface**")
            voice_response = st.toggle("Enable Voice Response", value=False, help="Aegis will read responses aloud.")

        
        with tab_keys:
             st.markdown("### 🛡️ Secure Key Vault")
             st.caption("Keys are encrypted with your Master Password. Supports multi-provider fallback.")
             
             if 'enc_key' not in st.session_state:
                 st.error("⚠️ Encryption Session Key missing. Please Log Out and Re-Login.")
             else:
                 # Add New Key
                 with st.form("add_key_form"):
                     c1, c2, c3 = st.columns([2, 3, 1])
                     with c1:
                         new_prov = st.selectbox("Provider", ["gemini", "groq", "openai", "anthropic", "openrouter", "cerebras", "together"])
                     with c2:
                         new_key = st.text_input("New API Key", type="password", help="Paste sk-...")
                     with c3:
                         new_prio = st.number_input("Priority", min_value=0, max_value=100, value=10, help="Higher = Used first")
                         
                     if st.form_submit_button("➕ Encrypt & Store"):
                         if new_key:
                             try:
                                 # Encrypt
                                 enc_str = auth.encrypt_content(new_key, st.session_state.enc_key)
                                 database.add_api_key(new_prov, enc_str, new_prio)
                                 st.success(f"Securely stored {new_prov} key.")
                                 time.sleep(1)
                                 st.rerun()
                             except Exception as e:
                                 st.error(f"Encryption Failed: {e}")
                 
                 st.divider()
                 st.markdown("**Manejador de Llaves Activadas**")
                 keys = database.get_api_keys()
                 if keys:
                     for k in keys:
                         col_prov, col_mask, col_del = st.columns([2, 3, 1])
                         col_prov.markdown(f"**{k['provider'].upper()}** (Pr: {k['priority']})")
                         # Mask
                         col_mask.code("••••" + k['api_key'][-6:] if len(k['api_key']) > 12 else "••••••")
                         if col_del.button("🗑️", key=f"del_key_{k['rowid']}"):
                             database.delete_api_key(k['rowid'])
                             st.rerun()
                 else:
                     st.info("Vault is empty. Add keys to enable Providers.")
            
        with tab_sys:
            st.subheader("System Update Center")
            st.caption("Verifies integrity and pulls latest patches from repository.")
            
            # Re-fetch manager to ensure we have the instance
            daemon_manager = get_daemon_manager()
            import modules.updater as updater
            
            # Use session state for update status
            if 'update_checked' not in st.session_state:
                st.session_state.update_checked = False
                st.session_state.update_available = False
                st.session_state.update_log = ""

            if st.button("🔄 Buscar Actualizaciones"):
                 with st.spinner("Contacting remote repo..."):
                     try:
                         has_update, update_log = updater.check_for_updates()
                         st.session_state.update_checked = True
                         st.session_state.update_available = has_update
                         st.session_state.update_log = update_log
                         if not has_update:
                             st.toast("System is up to date.")
                     except Exception as e:
                         st.error(f"Update Check Failed: {e}")
            
            if st.session_state.update_checked:
                 if st.session_state.update_available:
                     st.success("✨ Update Available!")
                     with st.expander("Show Patch Notes", expanded=True):
                         st.code(st.session_state.update_log)
                     
                     st.warning("⚠️ Warning: Update will stop all services and restart the application.")
                     if st.button("🚀 INSTALAR ACTUALIZACIÓN", type="primary"):
                         st.info("Initiating Update Sequence... Hold on!")
                         time.sleep(1)
                         updater.perform_update(daemon_manager)
                     else:
                         st.info("System is up to date. No patches found.")

        with tab_store:
            st.subheader("Cloud Skills Registry")
            st.caption("Browse and install new capabilities from the community.")
            
            import modules.galactic_store as store
            
            # Search UI
            search_q = st.text_input("Search Skills (e.g. 'PDF', 'YouTube')", placeholder="Enter topic...")
            
            # Defaults
            if not search_q:
                st.info("Top Rated Tools")
                skills = store.search_cloud_skills(None) # Get recommended
            else:
                 with st.spinner("Searching Galaxy..."):
                     skills = store.search_cloud_skills(search_q)

            if not skills:
                st.warning("No skills found. Try another query.")
            
            # Layout Grid
            # Use columns for cards
            cols = st.columns(3)
            
            for i, skill in enumerate(skills):
                c = cols[i % 3]
                with c:
                    with st.container(border=True):
                        st.markdown(f"**{skill['name']}**")
                        author = skill.get('author', 'Unknown')
                        stars = skill.get('stars', 0)
                        st.caption(f"by {author} | ⭐ {stars}")
                        st.write(skill.get('description', 'No description.'))
                        
                        # Unique Key based on name and loop index
                        # Use help to show full url if debug needed
                        if st.button("📥 Install", key=f"inst_btn_{i}_{skill['name']}", help=skill.get('url')):
                             with st.spinner("Auditing & Installing..."):
                                ok, msg = store.install_skill(skill['url'], skill['name'], brain_instance=brain)
                                if ok:
                                    st.toast(f"Installed {skill['name']}! Check 'Installed Skills'.")
                                    time.sleep(1)
                                    st.rerun()
                                else:
                                    st.error(msg)
                                    
            st.divider()
            st.subheader("My Skills")
            st.caption("Manage and contribute your custom tools.")
            
            user_root = os.getenv('AEGIS_USER_ROOT', '.')
            local_skills_dir = os.path.join(user_root, "skills")
            
            if os.path.exists(local_skills_dir):
                local_files = [f for f in os.listdir(local_skills_dir) if f.endswith('.py')]
                
                if not local_files:
                    st.info("No local skills found.")
                else:
                    for s_file in local_files:
                        with st.expander(f"🛠️ {s_file}"):
                            # Read content for preview/share
                            try:
                                with open(os.path.join(local_skills_dir, s_file), 'r', encoding='utf-8') as f:
                                    s_code = f.read()
                                
                                st.code(s_code[:300] + "...", language="python")
                                
                                if st.button(f"🚀 Share to Galaxy", key=f"share_btn_{s_file}"):
                                    st.session_state[f'sharing_mode_{s_file}'] = True
                                
                                if st.session_state.get(f'sharing_mode_{s_file}', False):
                                    with st.form(key=f"share_form_{s_file}"):
                                        st.write(f"Contribute **{s_file}**")
                                        desc_input = st.text_area("Description")
                                        author_input = st.text_input("Author Name", value="Anonymous")
                                        
                                        if st.form_submit_button("Submit PR"):
                                            if desc_input:
                                                # Use Push Protocol (Benchmarking + Naming)
                                                ok, msg = store.push_skill_candidate(s_file, s_code, desc_input, author_input)
                                                if ok:
                                                    st.balloons()
                                                    st.success(msg)
                                                    st.session_state[f'sharing_mode_{s_file}'] = False
                                                    time.sleep(2)
                                                    st.rerun()
                                                else:
                                                    st.error(msg)
                                            else:
                                                st.warning("Description required.")
                            except Exception as e:
                                st.error(f"Error reading file: {e}")
            else:
                 st.info("Skills directory not initialized.")


    # 6. Help Expander
    with st.expander("❓ Help"):
        st.markdown("""
        **Sentinel**: Runs code in sandbox.
        **Beacon**: Encrypted remote access.
        **Archive**: Local database storage.
        """)
        if st.button("Run Diagnostics"):
             st.info("System Integrity: 100%")
             
    # 6. Skill Gallery (Compact)
    with st.expander("🎨 Installed Skills"):
        modules = brain.module_manager.modules
        st.write(", ".join(modules))

    # 7. System Config
    with st.expander("⚙️ System Config"):
        st.caption("Protocol Phoenix: Persistencia y Auto-Arranque")
        if st.button("🔥 Instalar Auto-Arranque"):
            try:
                import modules.system_service as sys_svc
                res = sys_svc.install_auto_start()
                if "Success" in res:
                    st.success(res)
                    st.balloons()
                else:
                    st.error(res)
            except Exception as e:
                # LOG TO DATABASE
                database.log_audit_event(
                    user="SYSTEM",
                    action=str(e)[:100], 
                    module="APP_CRASH",
                    status="FAILURE",
                    details=str(e),
                    approved=False
                )
                st.error(f"Application Crash: {e}")
                st.stop()

# --- MAIN CHAT INTERFACE ---
# No indentation, fills the main area
context = "general"
history = database.get_history(limit=50, thread_tag=context)

for role, message in history:
    with st.chat_message(role):
        if role == "assistant":
            # Enable HTML for Hive Logs
            st.markdown(message, unsafe_allow_html=True)
            
            # --- NEXUS CODE SYNC (OPTIMIZED) ---
            # Detect Code Blocks or Technical Instructions
            if "```" in message and role == "assistant" and message == history[-1][1]:
                # Check for Online Satellites
                online_nodes = [n for n in database.get_all_nodes() if n['status'] == 'online']
                if online_nodes:
                    # Prefer "Desktop" or take the first one
                    target_sat = next((n['node_id'] for n in online_nodes if "desktop" in n['node_id'].lower()), online_nodes[0]['node_id'])
                    
                    st.divider()
                    col_sync, col_info = st.columns([1, 2])
                    with col_sync:
                        if st.button("🚀 Enviar a Workspace de Antigravity", key=f"sync_{len(history)}"):
                            with st.spinner(f"Sincronizando con {target_sat}..."):
                                # Extract content (or send full message as context)
                                # We send the full message content to .aegis_task.md
                                payload = {
                                    "target_node": target_sat,
                                    "content": {
                                        "cmd": "write_to_workspace",
                                        "args": {
                                            "filename": ".aegis_task.md",
                                            "content": message
                                        }
                                    }
                                }
                                try:
                                    resp = requests.post("http://localhost:8000/send_message", json=payload)
                                    if resp.status_code == 200:
                                        st.toast(f"✅ Tarea enviada a {target_sat}")
                                        database.save_message("system", f"Sync: Code sent to {target_sat} workspace.", "Nexus", "general")
                                    else:
                                        st.error(f"Error: {resp.text}")
                                except Exception as e:
                                    st.error(f"Link Fail: {e}")
                                    
                    with col_info:
                        st.caption(f"Detectado Código. Listo para enviar a **{target_sat}**.")

        else:
            st.markdown(message)
        
# Check for pending actions in the LAST message
if history and history[-1][0] == "assistant":
    last_msg = history[-1][1]
    command_data = None
    
    # Check for JSON Command
    import re
    json_match = re.search(r"\{.*\}", last_msg, re.DOTALL)
    if json_match:
        try:
            data = json.loads(json_match.group(0))
            if "module" in data and "action" in data:
                command_data = data
        except:
            pass
            
    # Check for SKILL_PROPOSAL
    if "SKILL_PROPOSAL:" in last_msg:
         try:
             json_part = last_msg.split("SKILL_PROPOSAL:")[1]
             payload = json.loads(json_part)
             command_data = {
                 "module": "skill_builder",
                 "action": "install_skill_confirmed",
                 "filename": payload.get("filename"),
                 "code": payload.get("code")
             }
         except:
             pass

    if command_data:
        st.divider()
        
        # --- SENTINEL VALIDATION LOGIC ---
        is_executable = True
        
        if command_data.get('module') == 'skill_builder':
            from modules.validator import sentinel
            code_to_validate = command_data.get('code', '')
            
            with st.spinner("🛡️ Sentinel analyzing syntax (Static)..."):
                is_valid, val_report = sentinel.check_syntax(code_to_validate)
            
            if is_valid:
                st.success("🛡️ Sentinel: Syntax Verified.")
                st.session_state.skill_retry_active = False
            else:
                if not st.session_state.get('skill_retry_active', False):
                    st.warning("⚠️ Sentinel: Errores detectados. Solicitando auto-corrección...")
                    with st.expander("Detalles del Error"):
                        st.code(val_report)
                        
                    error_prompt = f"SYSTEM: Validation Failed. Errors:\n{val_report}\n\nFix the code immediately and output the JSON PROPOSAL again."
                    
                    with st.spinner("⚙️ Auto-Repairing..."):
                        database.save_message("system", error_prompt, "Sentinel", context)
                        current_history = database.get_history(limit=20, thread_tag=context)
                        api_key = auth.get_api_key(st.session_state.get('master_password'))
                        response = brain.query(error_prompt, current_history, "Gemini", api_key=api_key)
                        database.save_message("assistant", response, "Gemini", context)
                        st.session_state.skill_retry_active = True
                        st.rerun()
                else:
                    st.error("❌ Sentinel: La auto-corrección falló. Instalación bloqueada.")
                    with st.expander("Reporte de Fallo Final"):
                        st.code(val_report)
                    is_executable = False
                    st.session_state.skill_retry_active = False

        # --- EXECUTION UI ---
        if is_executable:
            st.warning(f"⚠️ PENDING ACTION: {command_data.get('module')} -> {command_data.get('action')}")
            
            # --- TARGET SELECTOR ---
            st.write("📍 **Target Selector**")
            all_nodes = [n['node_id'] for n in database.get_all_nodes() if n['status'] == 'online']
            target_options = ["Local (This PC)"] + all_nodes
            
            target_node = st.selectbox("Execute On:", target_options)
            
            col_exec, col_cancel = st.columns(2)
            
            with col_exec:
                if st.button("🚀 EJECUTAR / APPROVE"):
                    with st.spinner(f"Executing Protocol on {target_node}..."):
                        
                        success = False
                        msg_result = ""
                        
                        if target_node == "Local (This PC)":
                            if command_data['module'] == 'skill_builder':
                                result = brain.module_manager.execute_module("skill_builder", command_data)
                            else:
                                result = brain.module_manager.execute_module(command_data['module'], command_data)
                            msg_result = str(result)
                            success = "Error" not in msg_result
                        else:
                            # REMOTE EXECUTION VIA NEXUS
                            try:
                                payload = {
                                    "target_node": target_node,
                                    "content": {
                                        # Basic cmd for limb check.
                                        # But wait, limb expects specific commands.
                                        # If command_data matches Limb commands (terminal_cmd, file_ops), fine.
                                        # If it's a 'daemon_manager' command, Limb might not support it unless it is 'file_ops' or 'cmd'.
                                        # For now, we assume the command_data structure matches what Limb expects OR we wrap it.
                                        # Limb supports: terminal_cmd, file_ops, write_to_workspace.
                                        
                                        # If Antigravity proposes 'system_tools' -> 'terminal', map it.
                                        # Default modules mapper:
                                        "cmd": "terminal_cmd" if command_data.get('action') == 'terminal' else "unknown",
                                        "args": {
                                            "command": command_data.get('command')
                                        },
                                        # Fallback: Pass raw if Limb gets smarter or for specific designated commands
                                        "raw_module": command_data.get('module'),
                                        "raw_action": command_data.get('action')
                                    }
                                }
                                
                                # Better mapping for generic compatibility
                                if command_data.get('module') == 'system_tools':
                                    if command_data.get('action') == 'terminal':
                                         payload['content'] = {"cmd": "terminal_cmd", "args": {"command": command_data.get('command')}}
                                    elif command_data.get('action') == 'file':
                                         payload['content'] = {"cmd": "file_ops", "args": {"operation": command_data.get('operation'), "path": command_data.get('path'), "content": command_data.get('content')}}
                                
                                # POST to Gateway
                                resp = requests.post("http://localhost:8000/send_message", json=payload)
                                if resp.status_code == 200:
                                    msg_result = f"Remote Command Sent to {target_node}. Response: {resp.json()}"
                                    success = True
                                else:
                                    msg_result = f"Gateway Error: {resp.text}"
                                    success = False
                            except Exception as e:
                                msg_result = f"Connection Failed: {e}"
                                success = False

                        status = "SUCCESS" if success else "FAILURE"
                        database.log_audit_event(
                            command_data['module'], 
                            command_data['action'], 
                            f"{status}@{target_node}", 
                            user_approved=True
                        )
                        
                        st.success(f"Execution Complete: {msg_result}")
                        database.save_message("system", f"EXECUTION RESULT ({target_node}):\n{msg_result}", "Aegis", context)
                        time.sleep(1)
                        st.rerun()
            
            with col_cancel:
                if st.button("❌ CANCEL"):
                    database.save_message("system", "Action Cancelled by User.", "Aegis", context)
                    st.session_state.skill_retry_active = False
                    st.rerun()

# --- VISION UPLINK (Sidebar) ---
with st.sidebar:
    st.divider()
    hands_free_mode = st.toggle("🎙️ Modo Manos Libres (Siren)", help="Activa la conversación fluida por voz.")
    
    with st.expander("👁️ VISION UPLINK"):
        uploaded_image = st.file_uploader("Analyze Image", type=['png', 'jpg', 'jpeg'], key="vision_uploader")

    with st.expander("📜 Codex Library"):
        snippets = database.get_all_codex_snippets()
        if snippets:
            for snip in snippets:
                st.markdown(f"**{snip['title']}**")
                with st.expander("View Code", expanded=False):
                   st.caption(f"Tags: {snip['tags']} | {snip['language']}")
                   st.code(snip['code'], language=snip['language'])
        else:
            st.caption("Codex is empty.")

# --- SIREN PROTOCOL VISUALIZER ---
SIREN_HTML = """
<style>
    body { margin: 0; overflow: hidden; background: transparent; display: flex; justify-content: center; align-items: center; height: 200px; }
    canvas { width: 100%; height: 100%; }
    .status { color: #00f2ff; font-family: monospace; font-size: 12px; position: absolute; top: 10px; left: 10px; }
</style>
<div class="status">PROTOCOL SIREN: ACTIVE</div>
<canvas id="visualizer"></canvas>
<script>
    const canvas = document.getElementById('visualizer');
    const ctx = canvas.getContext('2d');
    canvas.width = window.innerWidth;
    canvas.height = 200;

    let audioContext, analyser, source, dataArray;

    async function initAudio() {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            audioContext = new (window.AudioContext || window.webkitAudioContext)();
            analyser = audioContext.createAnalyser();
            source = audioContext.createMediaStreamSource(stream);
            source.connect(analyser);
            analyser.fftSize = 256;
            const bufferLength = analyser.frequencyBinCount;
            dataArray = new Uint8Array(bufferLength);
            draw();
        } catch (err) {
            console.error('Mic Error:', err);
        }
    }

    function draw() {
        requestAnimationFrame(draw);
        analyser.getByteFrequencyData(dataArray);
        
        ctx.fillStyle = 'rgba(10, 10, 10, 0.2)'; // Fade effect
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        const barWidth = (canvas.width / dataArray.length) * 2.5;
        let barHeight;
        let x = 0;

        for (let i = 0; i < dataArray.length; i++) {
            barHeight = dataArray[i] / 1.5;
            
            // Cyan Glow Style
            ctx.fillStyle = `rgba(0, 242, 255, ${barHeight / 200})`; 
            ctx.shadowBlur = 15;
            ctx.shadowColor = "#00f2ff";
            
            ctx.fillRect(x, canvas.height - barHeight - 20, barWidth, barHeight);
            x += barWidth + 1;
        }
    }
    
    // Auto-init on load (might require interaction in some browsers, but works in active context)
    initAudio();
</script>
"""

# Capture Voice Input
voice_input = None

if hands_free_mode:
    # --- HANDS FREE UI ---
    st.markdown("### 🎙️ Protocol Siren Active")
    # Render Visualizer
    import streamlit.components.v1 as components
    components.html(SIREN_HTML, height=200, scrolling=False)
    
    # Auto-Loop Prompt
    col1, col2 = st.columns([1, 4])
    with col1:
        # We use a key based on message count/state to refresh the recorder
        # The prompt is simplified for flow
        voice_input = speech_to_text(
            language='es-ES', 
            start_prompt="🔴 HABLAR", 
            stop_prompt="⏹️ PROCESANDO...", 
            just_once=True, 
            key=f'siren_mic_{len(history)}'
        )
    with col2:
        if voice_input:
             st.info(f"Escuchado: {voice_input}")
             
else:
    # Standard Mode
    if speech_to_text:
        # returns text or None
        voice_input = speech_to_text(language='es-ES', start_prompt="🎤", stop_prompt="⏹️", just_once=True, key='STT')

prompt = st.chat_input("Command Aegis...")
active_input = prompt or voice_input
# Active Model variable check (usually from database or default)
active_model = database.get_setting("active_model") or "gemini-1.5-flash"

if active_input:
    # Determine source for UI display
    is_voice = (active_input == voice_input)
    
    with st.chat_message("user"):
        st.markdown(active_input)
        if is_voice:
            st.caption("🎙️ Voice Command")
        if uploaded_image:
            st.image(uploaded_image, caption="Visual Context", width=300)
            
    database.save_message("user", active_input, "User", context)
    
    # --- STREAMING RESPONSE ---
    with st.chat_message("assistant"):
        placeholder = st.empty()
        full_response = ""
        
        # Get Keys (Handle Local Mode)
        api_key = auth.get_api_key(st.session_state.get('master_password'))
        
        # SOVEREIGN GUARD: If model is local, FORCE local key to prevent Google SDK init
        if "ollama" in active_model or "llama" in active_model or not api_key:
             api_key = "local_mode_active"
             
        key_ring = st.session_state.get('api_key_ring', {})
        
        # Optimize for Voice Latency
        query_prompt = active_input
        if hands_free_mode:
            query_prompt += " [SYSTEM: VOICE MODE ACTIVE. KEEP RESPONSE CONCISE AND SHORT FOR TTS LATENCY (<200 chars preferred).]"

        # Call Brain with Stream=True
        
        # BRIDGE: Helper to Log to Gateway
        def log_to_gateway(mod, action, status, detail=None):
            try:
                import requests
                requests.post("http://localhost:8000/log_event", json={
                    "module": mod,
                    "action": action,
                    "status": status,
                    "details": detail
                }, timeout=1)
            except: pass

        try:
            stream_obj = brain.query(query_prompt, database.get_history(limit=20), active_model, api_key=api_key, image_input=uploaded_image, stream=True, key_ring=key_ring)
            
            # If it's a string (e.g. error), display directly
            if not stream_obj:
                 full_response = "⚠️ **Error Crítico de Configuración**\nEl sistema intentó conectar con todos los modelos configurados y falló.\n\n**Posibles Causas:**\n1. Ollama no está corriendo (`ollama serve`).\n2. No hay API Keys válidas en 'Settings -> API Vault'.\n3. El modelo seleccionado no está instalado localmente.\n\n_Revisa el log de sistema para más detalles._"
                 placeholder.error(full_response)
            elif isinstance(stream_obj, str):
                full_response = stream_obj
                placeholder.markdown(full_response, unsafe_allow_html=True)
            else:
                # Iterate Generator
                for chunk in stream_obj:
                    try:
                        if isinstance(chunk, str):
                             text_chunk = chunk
                        else:
                             text_chunk = chunk.text
                    except:
                        text_chunk = str(chunk)
                        
                    full_response += text_chunk
                    placeholder.markdown(full_response + "▌", unsafe_allow_html=True)
                
                # Check for Errors in final response
                if full_response.startswith("CRITICAL:") or "Connection Error" in full_response:
                     log_to_gateway("CHAT_BRAIN_FAIL", full_response[:50], "CRITICAL", full_response)
                     
                placeholder.markdown(full_response)
                
        except Exception as e:
            print(f"CRITICAL_BRAIN_FAIL: {e}")
            err_msg = str(e)
            full_response = f"⚠️ **System Malfunction**: {err_msg}"
            placeholder.error(full_response)
            log_to_gateway("CHAT_CRASH", "Exception in Brain Query", "CRITICAL", err_msg)
             
    # Save Final
    # Save Final
    database.save_message("assistant", full_response, active_model, context)
    
    # CRITICAL: Local Audit for Brain Failures
    if full_response.startswith("CRITICAL:") or "System Malfunction" in full_response:
        database.log_audit_event(
            user="SYSTEM",
            action=full_response[:100], 
            module="CHAT_BRAIN_FAIL",
            status="FAILURE",
            details=full_response,
            approved=False
        )

    # --- AUDIO RESPONSE ---
    if voice_response and full_response:
        audio_fp = text_to_speech(full_response)
        if audio_fp:
            st.audio(audio_fp, format='audio/mp3', start_time=0)
        
    # --- AUTONOMOUS AGENT & TOOL LOOP ---
        plan_data = None
        tool_data = None
        try:
            import re
            json_match = re.search(r"\{.*\}", full_response, re.DOTALL)
            if json_match:
                data = json.loads(json_match.group(0))
                if isinstance(data, dict):
                    if data.get('module') == 'planner':
                        plan_data = data
                    elif data.get('module'):
                        # Direct Tool Invocation found in response
                        tool_data = data
        except:
            pass
            
        # A. Autonomous Plan
        if plan_data:
            steps = plan_data['args'].get('steps', [])
            goal = plan_data['args'].get('goal', 'Autonomous Task')
            
            # Persist Start of Plan
            database.save_message("system", f"🤖 Iniciando Plan Autónomo: {goal}\nPasos: {len(steps)}", "Planner", [])
            
            with st.status(f"🤖 Ejecutando Misión Autónoma: {goal}...", expanded=True) as status:
                context_accumulated = ""
                
                for i, step in enumerate(steps):
                    status.write(f"⚙️ **Paso {i+1}/{len(steps)}:** {step}...")
                    
                    # 1. Translate Step to Action (Brain Logic)
                    step_prompt = f"""
SYSTEM_AUTO_EXEC: 
Your Goal: {goal}
Current Step: {step}
Context so far: {context_accumulated[-2000:]}

INSTRUCTION: Return the JSON action required to execute this step. 
If no tool is needed, return {{"module": "chat", "action": "reply", "args": "Done"}}
"""
                    # Use fast model for logic if available
                    act_model = "gemini-1.5-flash" if api_key else active_model
                    step_response = brain.query(step_prompt, [], act_model, api_key=api_key, key_ring=key_ring)
                    
                    # 2. Extract and Execute Tool
                    tool_result = "No Action Taken"
                    try:
                        import re
                        tm = re.search(r"\{.*\}", str(step_response), re.DOTALL)
                        if tm:
                            t_data = json.loads(tm.group(0))
                            if "module" in t_data:
                                mod_name = t_data['module']
                                status.write(f"🛠️ Invocando: `{mod_name}` -> `{t_data.get('action')}`")
                                
                                start_t = time.time()
                                res = brain.module_manager.execute_module(mod_name, t_data, brain_instance=brain)
                                dur = round(time.time() - start_t, 2)
                                
                                tool_result = str(res)
                                status.write(f"✅ Resultado ({dur}s): {tool_result[:200]}...")
                                
                                # Audit Log
                                database.log_audit_event(t_data['module'], t_data.get('action', 'exec'), "SUCCESS", f"Step {i+1}", True)
                            else:
                                tool_result = step_response
                        else:
                            tool_result = step_response
                            
                    except Exception as e:
                        tool_result = f"Error executing tool: {e}"
                        status.write(f"❌ Error: {e}")
                        
                    context_accumulated += f"\n[Step {i+1} Result]: {tool_result}"
                    
                    # Log step to DB immediately so user sees progress if they refresh
                    database.save_message("system", f"✔️ Paso {i+1}: {step}\nResult: {tool_result[:500]}", "Planner", [])
                    
                    # 3. Brief Pause to avoid rate limits and let UI breathe
                    time.sleep(0.5)

                status.update(label="✅ Misión Completada con Éxito", state="complete", expanded=False)
                database.save_message("system", f"🏁 Misión Finalizada: {goal}", "Planner", [])
            
            # Refresh to show final state in chat history
            time.sleep(1)
            st.rerun()

        # B. Direct Tool Invocation (One-Shot)
        if tool_data and not plan_data:
             with st.status(f"⚡ Executing: {tool_data['module']}", expanded=True):
                 status = st.empty() # placeholder
                 start = time.time()
                 result = brain.module_manager.execute_module(tool_data['module'], tool_data, brain_instance=brain)
                 
                 if result and isinstance(result, str) and "[GENESIS]" in result:
                     st.write("🧬 Protocol Genesis Active...")
                     
                 st.write(f"Result ({round(time.time()-start,2)}s):")
                 st.code(result)
                 
                 database.save_message("system", f"Module '{tool_data['module']}' Result:\n{result}", "System", context)
                 # Give user time to see result before rerun, or rely on them sending next msg
                 # Usually automatic rerun is desired to update state/history view
                 time.sleep(1)
                 st.rerun()
