import streamlit as st
import warnings
import os
import database
from core import AegisBrain
from modules.daemon_manager import DaemonManager
from modules.db_logger import setup_db_logger
from modules.auth_vault import auth

# UI Components
from ui.styles import apply_custom_styles
from ui.auth_manager import render_login, render_onboarding
from ui.sidebar_manager import render_sidebar
from ui.chat_manager import render_chat_interface

warnings.filterwarnings("ignore", category=FutureWarning)

# --- 1. CONFIGURACIÓN DE PÁGINA ---
st.set_page_config(page_title="Aegis-IA V10", layout="wide", page_icon="🛡️")

# --- 2. ESTILOS Y SYSTEM CHECK ---
apply_custom_styles()

# Initialize Database & Logger
database.init_db()
setup_db_logger()


# Dependency Check (Simplified)
def check_dependencies():
    import importlib.util

    required = ["cryptography", "google.generativeai", "requests"]
    missing = [req for req in required if importlib.util.find_spec(req) is None]
    if missing:
        st.error(f"⚠️ MISSING DEPENDENCIES: {', '.join(missing)}")
        st.stop()


check_dependencies()


# --- 3. CORE INITIALIZATION ---
@st.cache_resource
def get_daemon_manager():
    manager = DaemonManager()
    manager.start()  # Ensure thread starts
    return manager


@st.cache_resource
def load_brain():
    return AegisBrain()


daemon_manager = get_daemon_manager()
brain = load_brain()

# --- 4. AUTHENTICATION FLOW ---
if "authenticated" not in st.session_state:
    st.session_state.authenticated = False

# Setup Check (SRE Cache Bypass)
setup_complete = database.get_setting("setup_complete") == "true"
if not setup_complete:
    # If the system was factory-reset, we must clear the session state
    # to avoid showing ghosts of previous chats/sessions.
    if "purge_done" not in st.session_state:
        # Clear everything except the purge flag to avoid loops
        for key in list(st.session_state.keys()):
            del st.session_state[key]
        st.session_state.purge_done = True
        st.rerun()

    render_onboarding()
    st.stop()

# Login Check
if not st.session_state.authenticated:
    render_login()
    st.stop()

# Re-sync internal vault key on every rerun if authenticated

if st.session_state.get("authenticated") and st.session_state.get("master_password"):
    if not auth.get_session_key():
        # Only attempt if the vault is actually setup to avoid KeyError on 'salt'
        if auth.is_setup():
            auth.set_session_key(st.session_state.master_password)

# --- 5. MAIN APPLICATION (ORCHESTRATOR) ---

# Protocol Dawn (Briefing) - Optional, kept for continuity
briefing_file = os.path.join(
    os.getenv("AEGIS_USER_ROOT", "."), "tmp", "briefing_today.mp3"
)
if os.path.exists(briefing_file) and "briefing_played" not in st.session_state:
    st.audio(briefing_file, format="audio/mp3", autoplay=True)
    st.session_state.briefing_played = True
    st.toast("☀️ Protocol Dawn: Briefing Active")

# Render Sidebar & Get Modes
hands_free_mode, zen_mode = render_sidebar(brain, daemon_manager)

# Render Chat Interface
# We pass the modes returned by sidebar
render_chat_interface(brain, hands_free_mode, zen_mode)
