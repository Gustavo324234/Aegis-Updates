import asyncio
from mcp import ClientSession
from mcp.client.sse import sse_client


async def test_aegis_mcp():
    # Primero probamos localhost para asegurar que el servidor responde
    urls = ["http://127.0.0.1:7000/mcp/sse", "http://192.168.1.8:7000/mcp/sse"]

    for url in urls:
        print(f"\n--- Probando conexion con: {url} ---")
        try:
            async with sse_client(url) as (read, write):
                async with ClientSession(read, write) as session:
                    print("Conexion establecida. Inicializando sesion...")
                    await session.initialize()

                    print("Listando herramientas...")
                    tools = await session.list_tools()
                    print(f"Encontradas {len(tools.tools)} herramientas.")

                    print("Probando 'get_system_status'...")
                    await session.call_tool("get_system_status")
                    print("Resultado: OK")

                    print("Revision completada con exito.")
                    return  # Si funciona una, estamos bien

        except Exception as e:
            print(f"Fallo en {url}: {e}")


if __name__ == "__main__":
    asyncio.run(test_aegis_mcp())
