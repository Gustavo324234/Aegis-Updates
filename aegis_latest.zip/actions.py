import subprocess
import os
import shutil
import psutil
import platform

def execute_command(command):
    """Executes a system command in the shell."""
    try:
        # Use shell=True to allow complex commands like pipes or redirects
        # Capture output and error
        result = subprocess.run(command, shell=True, capture_output=True, text=True)
        if result.returncode == 0:
            return f"Success:\n{result.stdout}"
        else:
            return f"Error (Code {result.returncode}):\n{result.stderr}"
    except Exception as e:
        return f"Execution Failed: {str(e)}"

def manage_files(action, path, content=None):
    """Manages files: read, write, delete."""
    try:
        if action == "read":
            if os.path.exists(path):
                with open(path, 'r', encoding='utf-8') as f:
                    return f.read()
            else:
                return "Error: File not found."
        
        elif action == "write":
            # Ensure directory exists
            os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
            with open(path, 'w', encoding='utf-8') as f:
                f.write(content or "")
            return f"Success: File '{path}' written."
        
        elif action == "delete":
            if os.path.exists(path):
                os.remove(path)
                return f"Success: File '{path}' deleted."
            else:
                return "Error: File not found."
        
        else:
            return "Error: Unknown file action. Use 'read', 'write', or 'delete'."

    except Exception as e:
        return f"File Operation Failed: {str(e)}"

from pathlib import Path

def get_system_info():
    """Returns basic system information (Cross-Platform)."""
    try:
        info = {
            "OS": platform.system(),
            "Release": platform.release(),
            "Machine": platform.machine(),
            "CPU Logic Cores": psutil.cpu_count(),
            "RAM Total (GB)": round(psutil.virtual_memory().total / (1024**3), 2),
            "RAM Available (GB)": round(psutil.virtual_memory().available / (1024**3), 2),
            "Current Directory": str(Path.cwd()),
            "Files in Dir": [f.name for f in Path.cwd().iterdir()]
        }
        return str(info)
    except Exception as e:
        return f"System Info Failed: {str(e)}"

def execute_command(command):
    """Executes a system command in the shell (Universal)."""
    try:
        # Use shell=True for flexibility. 
        # On Windows, this uses cmd.exe by default. On Linux, /bin/sh.
        result = subprocess.run(command, shell=True, capture_output=True, text=True)
        if result.returncode == 0:
            return f"Success:\n{result.stdout}"
        else:
            return f"Error (Code {result.returncode}):\n{result.stderr}"
    except Exception as e:
        return f"Execution Failed: {str(e)}"
