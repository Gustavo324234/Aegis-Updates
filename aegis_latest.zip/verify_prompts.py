import sys
import os

# Add project root to path
sys.path.append(os.getcwd())

try:
    from core_engine import prompts

    print("Prompts module loaded successfully.")

    # Test get_system_instruction with dummy data
    s = prompts.get_system_instruction(
        ai_name="TestAI",
        user_name="TestUser",
        silent_report="All systems nominal.",
        module_descriptions="None",
    )
    print("get_system_instruction executes successfully.")
    if "TestUser" in s:
        print("User name correctly injected.")
    else:
        print("ERROR: User name not found in prompt.")

    if "TestAI" in s:
        print("AI name correctly injected.")
    else:
        print("ERROR: AI name not found in prompt.")

except Exception as e:
    print(f"Error loading prompts: {e}")
