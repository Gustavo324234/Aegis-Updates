import google.generativeai as genai
import database
from modules.auth_vault import auth


def list_gemini_models():
    # Simulate Aegis environment
    # We need a session key. Usually stored in st.session_state or handled by auth.
    # Since this is a CLI script, we might need to prompt or assumes something if it's not in vault.

    enc_key = database.get_api_key_by_provider("gemini")
    if not enc_key:
        # Legacy fallback
        api_key = database.get_setting("api_key_gemini")
    else:
        # Need to decrypt. For this internal debug, let's try to find if there's a cached session key
        # or just fail gracefully.
        print("Encrypted key found. Attempting decryption...")
        session_key = auth.get_session_key()
        if not session_key:
            print(
                "No active session key. Run this while the UI is active and logged in?"
            )
            return
        api_key = auth.decrypt_content(enc_key, session_key)

    if not api_key:
        print("Final API Key is empty.")
        return

    genai.configure(api_key=api_key)
    try:
        print(f"Checking models for key: {api_key[:5]}...")
        for m in genai.list_models():
            if "generateContent" in m.supported_generation_methods:
                print(f"- {m.name} ({m.display_name})")
    except Exception as e:
        print(f"Error listing models: {e}")


if __name__ == "__main__":
    list_gemini_models()
