# marketing.py


HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aegis-IA | The Singularity</title>
    <style>
        :root {
            --neon-blue: #00f2ff;
            --dark-bg: #0e1117;
            --card-bg: #161b22;
        }
        body {
            background-color: var(--dark-bg);
            color: #e0e0e0;
            font-family: 'Courier New', monospace;
            margin: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            overflow-x: hidden;
        }
        h1 {
            font-size: 4rem;
            text-shadow: 0 0 20px var(--neon-blue);
            margin-bottom: 0.5rem;
        }
        h2 { color: var(--neon-blue); }
        .hero {
            text-align: center;
            padding: 50px;
            animation: fadeIn 2s ease-in;
        }
        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            max-width: 1200px;
            width: 100%;
            padding: 20px;
        }
        .card {
            background: var(--card-bg);
            border: 1px solid #30363d;
            padding: 20px;
            border-radius: 10px;
            transition: transform 0.3s, border-color 0.3s;
        }
        .card:hover {
            transform: translateY(-5px);
            border-color: var(--neon-blue);
            box-shadow: 0 0 15px rgba(0, 242, 255, 0.2);
        }
        .btn {
            background: transparent;
            color: var(--neon-blue);
            border: 2px solid var(--neon-blue);
            padding: 15px 30px;
            font-size: 1.2rem;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            margin-top: 20px;
            transition: all 0.3s;
        }
        .btn:hover {
            background: var(--neon-blue);
            color: var(--dark-bg);
            box-shadow: 0 0 20px var(--neon-blue);
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>
    <div class="hero">
        <h1>AEGIS-IA</h1>
        <p>VERSION 10: THE SINGULARITY</p>
        <p>Private. Secure. Limitless.</p>
        <a href="#" class="btn">INITIALIZE SYSTEM</a>
    </div>

    <div class="grid">
        <div class="card">
            <h2>🛡️ The Sentinel</h2>
            <p>Military-grade code validation and sandboxing. No rogue AI actions allowed.</p>
        </div>
        <div class="card">
            <h2>📡 The Beacon</h2>
            <p>Secure, encrypted remote access from any device in the world.</p>
        </div>
        <div class="card">
            <h2>⚡ The Synapse</h2>
            <p>Direct neural link to external minds (ChatGPT, Claude). Unify your knowledge.</p>
        </div>
        <div class="card">
            <h2>🏛️ The Archive</h2>
            <p>Total Data Sovereignty. You own every byte. One-click encryption backups.</p>
        </div>
    </div>

    <footer style="margin-top: 50px; opacity: 0.5;">
        <p>&copy; 2026 Aegis Systems. Built for the Architect.</p>
    </footer>
</body>
</html>
"""


def generate_landing():
    with open("index.html", "w", encoding="utf-8") as f:
        f.write(HTML_TEMPLATE)
    print("Landing Page Generated: index.html")


if __name__ == "__main__":
    generate_landing()
