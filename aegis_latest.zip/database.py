import os
import sqlite3
import json
import datetime
import time

# --- CONFIGURATION & MULTI-TENANCY ---
# Support for multi-user environments (e.g., Linux server with multiple users)
AEGIS_USER_ROOT = os.getenv('AEGIS_USER_ROOT')

if AEGIS_USER_ROOT:
    # Tenant Mode: Strict isolation
    USER_ROOT = AEGIS_USER_ROOT
    if not os.path.exists(USER_ROOT):
        print(f"[DATABASE] Zero-Config: Initializing Data Root at {USER_ROOT}")
        try:
            os.makedirs(USER_ROOT, exist_ok=True)
            # Pre-provision core structure immediately
            for sub in ["users", "vault", "config", "backups"]:
                 os.makedirs(os.path.join(USER_ROOT, sub), exist_ok=True)
        except Exception as e:
            print(f"[DATABASE] CRITICAL: Failed to create Data Vault at {USER_ROOT}: {e}")
            # Fallback to local to prevent crash, but warn heavily
            USER_ROOT = "."
else:
    # System/Global Mode: Default behavior (Dev/Local)
    USER_ROOT = "."
    # print("[DATABASE] System Mode Active (Global).") # Optional: reduce noise

# Ensure core folders exist for this tenant (or global)
# These are MANDATORY for the system to function
REQUIRED_DIRS = ["vault", "backups", "quarantine", "config", "global_config", "users"]
for d in REQUIRED_DIRS:
    target = os.path.join(USER_ROOT, d)
    if not os.path.exists(target):
        try: 
            os.makedirs(target, exist_ok=True)
        except Exception: 
            pass

DB_NAME = os.path.join(USER_ROOT, "aegis_memory.db")

def get_connection():
    """Establishes a connection to the SQLite database with WAL mode enabled."""
    conn = sqlite3.connect(DB_NAME, check_same_thread=False)
    # Enable Write-Ahead Logging for concurrency
    conn.execute("PRAGMA journal_mode=WAL;")
    return conn

def init_db():
    conn = get_connection()
    c = conn.cursor()

    # 1. Chat History
    c.execute('''CREATE TABLE IF NOT EXISTS history
                 (timestamp TEXT, role TEXT, content TEXT, model TEXT, thread_tag TEXT)''')
    
    # 2. Key-Value Settings (The Configuration Cortex)
    c.execute('''CREATE TABLE IF NOT EXISTS settings
                 (key TEXT PRIMARY KEY, value TEXT)''')
    
    # 3. User Metadata (Long-Term Memory / Facts)
    c.execute('''CREATE TABLE IF NOT EXISTS user_metadata
                 (key TEXT, value TEXT, category TEXT, confidence REAL, timestamp TEXT)''')

    # 4. Expenses (Finance Stream)
    c.execute('''CREATE TABLE IF NOT EXISTS expenses
                 (timestamp TEXT, amount REAL, category TEXT, description TEXT, currency TEXT)''')

    # 5. Tasks (Mission Control)
    c.execute('''CREATE TABLE IF NOT EXISTS tasks
                 (id INTEGER PRIMARY KEY AUTOINCREMENT, task TEXT, status TEXT, due_date TEXT, priority TEXT)''')

    # 6. Nexus Mesh (Network Nodes)
    c.execute('''CREATE TABLE IF NOT EXISTS network_nodes
                 (node_id TEXT PRIMARY KEY, 
                  ip_address TEXT, 
                  public_key TEXT, 
                  status TEXT, 
                  last_seen TEXT,
                  capabilities TEXT,
                  shared_key TEXT,
                  last_indexed TEXT)''')
    
    # Migration for existing table
    try:
        c.execute("ALTER TABLE network_nodes ADD COLUMN last_indexed TEXT")
    except:
        pass

    # 7. Pairing Codes (Security)
    c.execute('''CREATE TABLE IF NOT EXISTS pairing_codes
                 (code TEXT PRIMARY KEY, created_at TEXT)''')
    
    # 8. API Vault (The Swarm)
    c.execute('''CREATE TABLE IF NOT EXISTS api_vault
                 (id INTEGER PRIMARY KEY AUTOINCREMENT, provider TEXT, api_key TEXT, priority INTEGER)''')
    
    # 9. Codex Snippets (Code Library)
    c.execute('''CREATE TABLE IF NOT EXISTS codex_snippets
                 (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, code TEXT, tags TEXT, language TEXT, created_at TEXT)''')

    # 10. Audit Log (Security)
    c.execute('''CREATE TABLE IF NOT EXISTS audit_log
                 (timestamp TEXT, module TEXT, action TEXT, status TEXT, user_approved BOOLEAN)''')
    
    # 11. Daemons (The Overseer)
    c.execute('''CREATE TABLE IF NOT EXISTS daemons
                 (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, type TEXT, config TEXT, status TEXT, last_run TEXT)''')

    # 12. Message Queue (Offline Persistence)
    c.execute('''CREATE TABLE IF NOT EXISTS message_queue
                 (id INTEGER PRIMARY KEY AUTOINCREMENT, 
                  target_node TEXT, 
                  sender_id TEXT, 
                  content TEXT, 
                  timestamp TEXT, 
                  status TEXT)''')

    conn.commit()
    conn.close()

# --- MESSAGE QUEUE ---
def queue_message(target_node, sender_id, content):
    """Enqueues a message for later delivery."""
    conn = get_connection()
    c = conn.cursor()
    ts = datetime.datetime.now().isoformat()
    # Content is expected to be a JSON string
    c.execute("INSERT INTO message_queue (target_node, sender_id, content, timestamp, status) VALUES (?, ?, ?, ?, 'pending')", 
              (target_node, sender_id, content, ts))
    conn.commit()
    conn.close()

def get_and_clear_queued_messages(target_node):
    """Retrieves pending messages and marks them as delivered/deleted."""
    conn = get_connection()
    c = conn.cursor()
    
    # Select pending messages
    c.execute("SELECT id, sender_id, content, timestamp FROM message_queue WHERE target_node=? AND status='pending' ORDER BY timestamp ASC", (target_node,))
    rows = c.fetchall()
    
    messages = []
    ids_to_delete = []
    
    for r in rows:
        messages.append({
            "id": r[0],
            "sender": r[1],
            "content": r[2], # JSON string
            "timestamp": r[3]
        })
        ids_to_delete.append(r[0])
        
    # Delete retrieved messages (Simple queue semantics)
    if ids_to_delete:
        c.executemany("DELETE FROM message_queue WHERE id=?", [(i,) for i in ids_to_delete])
        conn.commit()
        
    conn.close()
    return messages

# --- SETTINGS MANAGEMENT ---
def set_setting(key, value):
    conn = get_connection()
    c = conn.cursor()
    c.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (key, value))
    conn.commit()
    conn.close()

def get_setting(key):
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT value FROM settings WHERE key=?", (key,))
    result = c.fetchone()
    conn.close()
    return result[0] if result else None

# --- CHAT HISTORY ---
def save_message(role, content, model="unknown", thread_tag="general"):
    conn = get_connection()
    c = conn.cursor()
    timestamp = datetime.datetime.now().isoformat()
    c.execute("INSERT INTO history VALUES (?, ?, ?, ?, ?)", (timestamp, role, content, model, thread_tag))
    conn.commit()
    conn.close()

def get_history(limit=50, thread_tag="general"):
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT role, content FROM history WHERE thread_tag=? ORDER BY timestamp DESC LIMIT ?", (thread_tag, limit))
    rows = c.fetchall()
    conn.close()
    return rows[::-1]

def get_history_count():
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM history")
    count = c.fetchone()[0]
    conn.close()
    return count

# --- USER MEMORY (FACTS) ---
def add_user_fact(key, value, category="general", confidence=1.0):
    conn = get_connection()
    c = conn.cursor()
    timestamp = datetime.datetime.now().isoformat()
    # Check uniqueness for key/value pair to avoid spam
    c.execute("SELECT rowid FROM user_metadata WHERE key=? AND value=?", (key, value))
    if not c.fetchone():
        c.execute("INSERT INTO user_metadata VALUES (?, ?, ?, ?, ?)", (key, value, category, confidence, timestamp))
    conn.commit()
    conn.close()

def get_user_facts(limit=20):
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT key, value, confidence FROM user_metadata ORDER BY timestamp DESC LIMIT ?", (limit,))
    rows = c.fetchall()
    conn.close()
    return rows

def get_latest_context_summary():
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT value FROM user_metadata WHERE key='chronos_summary' ORDER BY timestamp DESC LIMIT 1")
    res = c.fetchone()
    conn.close()
    return res[0] if res else None

# --- FINANCE STREAM ---
def add_expense(amount, category, description, currency="USD"):
    conn = get_connection()
    c = conn.cursor()
    timestamp = datetime.datetime.now().isoformat()
    c.execute("INSERT INTO expenses VALUES (?, ?, ?, ?, ?)", (timestamp, amount, category, description, currency))
    conn.commit()
    conn.close()
    return f"Expense Logged: {currency} {amount} for {category}"

def get_expenses(limit=10):
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM expenses ORDER BY timestamp DESC LIMIT ?", (limit,))
    res = c.fetchall()
    conn.close()
    return res

# --- TASKS (MISSION CONTROL) ---
def add_task(task, due_date=None, priority="Medium"):
    conn = get_connection()
    c = conn.cursor()
    c.execute("INSERT INTO tasks (task, status, due_date, priority) VALUES (?, ?, ?, ?)", (task, "pending", due_date, priority))
    conn.commit()
    conn.close()
    return f"Task Added: {task}"

def get_tasks(status="pending"):
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT id, task, due_date, priority FROM tasks WHERE status=?", (status,))
    res = c.fetchall()
    conn.close()
    return res

def complete_task(task_id):
    conn = get_connection()
    c = conn.cursor()
    c.execute("UPDATE tasks SET status='completed' WHERE id=?", (task_id,))
    conn.commit()
    conn.close()

# --- NEXUS MESH (P2P NETWORK) ---
def register_node(node_id, ip, public_key, capabilities, shared_key=None, contribution_mode=False):
    # Updated signature to match usage
    conn = get_connection()
    c = conn.cursor()
    now = datetime.datetime.now().isoformat()
    # Handle optional shared_key and contribution_mode via capabilities json or separate fields if schema evolved
    # For now, simplistic update or insert
    
    # We need to be careful with existing columns.
    # The original schema had: node_id, ip_address, public_key, status, last_seen, capabilities, shared_key
    # And we just added last_indexed.
    
    c.execute("SELECT node_id FROM network_nodes WHERE node_id=?", (node_id,))
    exists = c.fetchone()
    
    if exists:
        # Update
        c.execute("""UPDATE network_nodes SET 
                     ip_address=?, public_key=?, status='online', last_seen=?, capabilities=? 
                     WHERE node_id=?""", 
                  (ip, public_key, now, json.dumps(capabilities), node_id))
    else:
        # Insert
        c.execute("""INSERT INTO network_nodes 
                     (node_id, ip_address, public_key, status, last_seen, capabilities, shared_key, last_indexed) 
                     VALUES (?, ?, ?, 'online', ?, ?, ?, NULL)""", 
                  (node_id, ip, public_key, now, json.dumps(capabilities), shared_key))
                  
    conn.commit()
    conn.close()

def update_node_status(node_id, status):
    conn = get_connection()
    c = conn.cursor()
    c.execute("UPDATE network_nodes SET status=? WHERE node_id=?", (status, node_id))
    conn.commit()
    conn.close()

def update_node_heartbeat(node_id, ip=None):
    conn = get_connection()
    c = conn.cursor()
    now = datetime.datetime.now().isoformat()
    if ip:
        c.execute("UPDATE network_nodes SET last_seen=?, status='online', ip_address=? WHERE node_id=?", (now, ip, node_id))
    else:
        c.execute("UPDATE network_nodes SET last_seen=?, status='online' WHERE node_id=?", (now, node_id))
    conn.commit()
    conn.close()

def update_node_last_indexed(node_id):
    conn = get_connection()
    c = conn.cursor()
    now = datetime.datetime.now().isoformat()
    c.execute("UPDATE network_nodes SET last_indexed=? WHERE node_id=?", (now, node_id))
    conn.commit()
    conn.close()

def get_all_nodes():
    conn = get_connection()
    c = conn.cursor()
    # Check if last_indexed exists in schema (it should after init)
    try:
        c.execute("SELECT node_id, status, last_seen, ip_address, capabilities, last_indexed FROM network_nodes")
        rows = c.fetchall()
        return [{"node_id": r[0], "status": r[1], "last_seen": r[2], "last_ip": r[3], "caps": r[4], "last_indexed": r[5]} for r in rows]
    except:
        # Fallback if migration hasn't run or something
        c.execute("SELECT node_id, status, last_seen, ip_address, capabilities FROM network_nodes")
        rows = c.fetchall()
        return [{"node_id": r[0], "status": r[1], "last_seen": r[2], "last_ip": r[3], "caps": r[4], "last_indexed": None} for r in rows]

def get_contributors():
    """Get nodes with contribution_mode=True"""
    # This logic was missing in original file, inferring implementation
    # Assuming 'contribution_mode' is in capabilities JSON
    nodes = get_all_nodes()
    contributors = []
    for n in nodes:
        try:
            caps = json.loads(n['caps'])
            if caps.get('contribution_mode', False) or caps.get('brain_power', False):
                contributors.append(n)
        except: pass
    return contributors
    
def get_node_key(node_id):
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT shared_key FROM network_nodes WHERE node_id=?", (node_id,))
    res = c.fetchone()
    conn.close()
    return res[0] if res else None

def set_node_key(node_id, key):
    conn = get_connection()
    c = conn.cursor()
    c.execute("UPDATE network_nodes SET shared_key=? WHERE node_id=?", (key, node_id))
    conn.commit()
    conn.close()

# --- PAIRING CODES ---
def create_pairing_code(code):
    conn = get_connection()
    c = conn.cursor()
    now = datetime.datetime.now().isoformat()
    # Expire old codes first (older than 10 mins)
    # Simple cleanup, assume logic handled elsewhere, just insert for now
    c.execute("INSERT OR REPLACE INTO pairing_codes VALUES (?, ?)", (code, now))
    conn.commit()
    conn.close()

def validate_pairing_code(code):
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT created_at FROM pairing_codes WHERE code=?", (code,))
    res = c.fetchone()
    if res:
        created_at = datetime.datetime.fromisoformat(res[0])
        if (datetime.datetime.now() - created_at).total_seconds() < 600: # 10 mins
            c.execute("DELETE FROM pairing_codes WHERE code=?", (code,))
            conn.commit()
            conn.close()
            return True
    conn.close()
    return False

# --- API VAULT (THE SWARM) ---
def add_api_key(provider, enc_key, priority=10):
    conn = get_connection()
    c = conn.cursor()
    c.execute("INSERT INTO api_vault (provider, api_key, priority) VALUES (?, ?, ?)", (provider, enc_key, priority))
    conn.commit()
    conn.close()

def get_api_keys():
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT rowid, provider, api_key, priority FROM api_vault ORDER BY priority DESC")
    rows = c.fetchall()
    conn.close()
    return [{"rowid": r[0], "provider": r[1], "api_key": r[2], "priority": r[3]} for r in rows]

def delete_api_key(rowid):
    conn = get_connection()
    c = conn.cursor()
    c.execute("DELETE FROM api_vault WHERE rowid=?", (rowid,))
    conn.commit()
    conn.close()

# --- THE CODEX (CODE SNIPPETS) ---
def save_codex_snippet(title, code, tags, language="python"):
    conn = get_connection()
    c = conn.cursor()
    ts = datetime.datetime.now().isoformat()
    c.execute("INSERT INTO codex_snippets (title, code, tags, language, created_at) VALUES (?, ?, ?, ?, ?)", 
              (title, code, tags, language, ts))
    conn.commit()
    conn.close()

def get_all_codex_snippets():
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT title, code, tags, language FROM codex_snippets ORDER BY created_at DESC")
    rows = c.fetchall()
    conn.close()
    return [{"title": r[0], "code": r[1], "tags": r[2], "language": r[3]} for r in rows]

def search_codex(query):
    conn = get_connection()
    c = conn.cursor()
    # Simple text search
    c.execute("SELECT title, code, language FROM codex_snippets WHERE title LIKE ? OR tags LIKE ?", (f"%{query}%", f"%{query}%"))
    rows = c.fetchall()
    conn.close()
    return [{"title": r[0], "code": r[1], "language": r[2]} for r in rows]

# --- AUDIT & DAEMONS (THE OVERSEER) ---
def log_audit_event(module, action, status, user_approved=False):
    conn = get_connection()
    c = conn.cursor()
    ts = datetime.datetime.now().isoformat()
    c.execute("INSERT INTO audit_log VALUES (?, ?, ?, ?, ?)", (ts, module, action, status, user_approved))
    conn.commit()
    conn.close()

def get_audit_logs(limit=50):
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM audit_log ORDER BY timestamp DESC LIMIT ?", (limit,))
    rows = c.fetchall()
    conn.close()
    return rows

def register_daemon(name, dtype, config):
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT id FROM daemons WHERE name=?", (name,))
    if c.fetchone():
        c.execute("UPDATE daemons SET config=?, status='RUNNING' WHERE name=?", (json.dumps(config), name))
    else:
        c.execute("INSERT INTO daemons (name, type, config, status) VALUES (?, ?, ?, ?)", (name, dtype, json.dumps(config), 'RUNNING'))
    conn.commit()
    conn.close()

def update_daemon_status(name, status, last_run=None):
    conn = get_connection()
    c = conn.cursor()
    if last_run:
        c.execute("UPDATE daemons SET status=?, last_run=? WHERE name=?", (status, last_run, name))
    else:
        c.execute("UPDATE daemons SET status=? WHERE name=?", (status, name))
    conn.commit()
    conn.close()

def get_all_daemons():
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT id, name, type, config, status, last_run FROM daemons")
    rows = c.fetchall()
    conn.close()
    return [{"id": r[0], "name": r[1], "type": r[2], "config": json.loads(r[3]), "status": r[4], "last_run": r[5]} for r in rows]

# --- DAEMON MANAGER COMPATIBILITY LAYER ---
def get_daemons():
    """Returns raw rows for DaemonManager loop."""
    conn = get_connection()
    c = conn.cursor()
    # Schema: id, name, type, status, interval (missing in DB?), config, last_run
    # Note: DB schema is (id, name, type, config, status, last_run).
    # DaemonManager expects: id, name, type, status, interval, config, last_run
    # We must adapt. Interval is likely inside config or missing from DB schema v1.
    # Let's mock interval as 60 if missing.
    c.execute("SELECT id, name, type, status, config, last_run FROM daemons")
    rows = c.fetchall()
    conn.close()
    
    adapted = []
    for r in rows:
        # r: (id, name, type, status, config_str, last_run)
        # construct: (id, name, type, status, interval, config, last_run)
        # extract interval from config
        interval = 60
        try:
            cfg = json.loads(r[4])
            interval = cfg.get("interval", 60)
        except: pass
        
        adapted.append((r[0], r[1], r[2], r[3], interval, r[4], r[5]))
        
    return adapted

def get_daemon(daemon_id):
    """Get single daemon tuple for run_loop."""
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT id, name, type, status, config, last_run FROM daemons WHERE id=?", (daemon_id,))
    r = c.fetchone()
    conn.close()
    if not r: return None
    
    interval = 60
    try:
        cfg = json.loads(r[4])
        interval = cfg.get("interval", 60)
    except: pass
    
    return (r[0], r[1], r[2], r[3], interval, r[4], r[5])

def update_daemon_last_run(daemon_id):
    conn = get_connection()
    c = conn.cursor()
    ts = datetime.datetime.now().isoformat()
    c.execute("UPDATE daemons SET last_run=? WHERE id=?", (ts, daemon_id))
    conn.commit()
    conn.close()
    
def register_daemon_db(name, task_type, interval, config_str):
    # Adapter for DaemonManager.register_daemon
    # Inject interval into config since DB has no column
    try:
        cfg = json.loads(config_str)
        cfg['interval'] = interval
        new_conf = json.dumps(cfg)
        
        register_daemon(name, task_type, cfg) # Reuse existing
        return "Daemon Registered"
    except Exception as e:
        return str(e)

def set_daemon_status(name, status):
    update_daemon_status(name, status)

# --- PROJECT NEXUS HELPERS ---
def get_active_projects():
    # Retrieve active projects from User Facts
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT value FROM user_metadata WHERE category='project_active'")
    rows = c.fetchall()
    conn.close()
    return [r[0] for r in rows]
