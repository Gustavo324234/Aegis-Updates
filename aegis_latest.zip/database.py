import os
import sqlite3
import json
import datetime

# Multi-Tenancy Support
USER_ROOT = os.getenv('AEGIS_USER_ROOT', '.')
if USER_ROOT != '.' and not os.path.exists(USER_ROOT):
    try:
        os.makedirs(USER_ROOT)
    except Exception as e:
        print(f"Error creating user root {USER_ROOT}: {e}")

# --- SYSTEM SKELETON (DEEP CLEAN PROTOCOL) ---
# Ensure core folders exist regardless of entry point
for d in ["vault", "backups", "quarantine", "config", "global_config"]:
    target = os.path.join(USER_ROOT, d)
    if not os.path.exists(target):
        try: os.makedirs(target)
        except: pass

DB_NAME = os.path.join(USER_ROOT, "aegis_memory.db")

def init_db():
    """Initializes the SQLite database and creates tables if they don't exist."""
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute('PRAGMA journal_mode=WAL;') # WAL Mode for concurrencia
    
    # History Table (Enhanced)
    c.execute('''
        CREATE TABLE IF NOT EXISTS history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT,
            role TEXT,
            message TEXT,
            model_name TEXT,
            thread_tag TEXT DEFAULT 'general'
        )
    ''')
    
    # Migration: Add thread_tag if not exists
    try:
        c.execute("SELECT thread_tag FROM history LIMIT 1")
    except sqlite3.OperationalError:
        c.execute("ALTER TABLE history ADD COLUMN thread_tag TEXT DEFAULT 'general'")

    # Expenses Table (V5: Added currency)
    c.execute('''
        CREATE TABLE IF NOT EXISTS expenses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT,
            amount REAL,
            currency TEXT DEFAULT 'USD',
            category TEXT,
            description TEXT
        )
    ''')
    try:
        c.execute("SELECT currency FROM expenses LIMIT 1")
    except sqlite3.OperationalError:
        c.execute("ALTER TABLE expenses ADD COLUMN currency TEXT DEFAULT 'USD'")

    # Reminders/Tasks Table (V5: Added priority)
    c.execute('''
        CREATE TABLE IF NOT EXISTS reminders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            task TEXT,
            due_date TEXT,
            priority TEXT DEFAULT 'Medium',
            status TEXT DEFAULT 'pending'
        )
    ''')
    try:
        c.execute("SELECT priority FROM reminders LIMIT 1")
    except sqlite3.OperationalError:
        c.execute("ALTER TABLE reminders ADD COLUMN priority TEXT DEFAULT 'Medium'")

    # Projects Table (V5: Added description)
    c.execute('''
        CREATE TABLE IF NOT EXISTS projects (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE,
            description TEXT,
            content TEXT,
            last_update TEXT
        )
    ''')
    try:
        c.execute("SELECT description FROM projects LIMIT 1")
    except sqlite3.OperationalError:
        c.execute("ALTER TABLE projects ADD COLUMN description TEXT DEFAULT ''")

    # Events Table (Orchestrator)
    c.execute('''
        CREATE TABLE IF NOT EXISTS events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            type TEXT,
            trigger_time TEXT,
            payload TEXT,
            status TEXT DEFAULT 'pending'
        )
    ''')
    
    # Vault Content Table (V6: The Vault)
    c.execute('''
        CREATE TABLE IF NOT EXISTS vault_content (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            filename TEXT UNIQUE,
            content TEXT,
            last_indexed TEXT
        )
    ''')

    # Vault FTS5 Virtual Table (V7: Full Text Search)
    # Allows efficient searching without loading all content into RAM
    try:
        c.execute('''
            CREATE VIRTUAL TABLE IF NOT EXISTS vault_fts USING fts5(filename, content, content='vault_content', content_rowid='id');
        ''')

        # Triggers to keep FTS index in sync with main table
        c.execute('''
            CREATE TRIGGER IF NOT EXISTS vault_ai AFTER INSERT ON vault_content BEGIN
                INSERT INTO vault_fts(rowid, filename, content) VALUES (new.id, new.filename, new.content);
            END;
        ''')
        c.execute('''
            CREATE TRIGGER IF NOT EXISTS vault_ad AFTER DELETE ON vault_content BEGIN
                INSERT INTO vault_fts(vault_fts, rowid, filename, content) VALUES('delete', old.id, old.filename, old.content);
            END;
        ''')
        c.execute('''
            CREATE TRIGGER IF NOT EXISTS vault_au AFTER UPDATE ON vault_content BEGIN
                INSERT INTO vault_fts(vault_fts, rowid, filename, content) VALUES('delete', old.id, old.filename, old.content);
                INSERT INTO vault_fts(rowid, filename, content) VALUES (new.id, new.filename, new.content);
            END;
        ''')
    except sqlite3.OperationalError as e:
        print(f"Warning: FTS5 not supported or error creating virtual table: {e}")

    # Settings Table (V11: Configuration persistency)
    c.execute('''
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT
        )
    ''')

    # Audit Log Table (V12: Security Auditing)
    c.execute('''
        CREATE TABLE IF NOT EXISTS audit_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT,
            module TEXT,
            action TEXT,
            status TEXT,
            user_approved BOOLEAN
        )
    ''')

    c.execute('''
        CREATE TABLE IF NOT EXISTS daemons (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE,
            task_type TEXT,
            status TEXT DEFAULT 'STOPPED',
            interval_seconds INTEGER DEFAULT 60,
            last_run TEXT,
            config TEXT DEFAULT '{}'
        )
    ''')
    
    # Initialize Default Daemons if empty
    c.execute("SELECT count(*) FROM daemons")
    if c.fetchone()[0] == 0:
        c.execute("INSERT INTO daemons (name, task_type, status, interval_seconds) VALUES ('System Watcher', 'resource_watcher', 'STOPPED', 300)")
        c.execute("INSERT INTO daemons (name, task_type, status, interval_seconds) VALUES ('Downloads Guard', 'folder_guard', 'STOPPED', 600)")

    # User Metadata Table (Human Long-Term Memory)
    c.execute('''
        CREATE TABLE IF NOT EXISTS user_metadata (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            key TEXT,
            value TEXT,
            category TEXT,
            confidence_score REAL,
            timestamp TEXT
        )
    ''')

    # Pairing Codes Table (Transient)
    c.execute('''
        CREATE TABLE IF NOT EXISTS pairing_codes (
            code TEXT PRIMARY KEY,
            created_at TEXT,
            expires_at TEXT,
            status TEXT DEFAULT 'active'
        )
    ''')

    # Network Nodes Table (Nexus Gateway)
    c.execute('''
        CREATE TABLE IF NOT EXISTS network_nodes (
            node_id TEXT PRIMARY KEY,
            public_key TEXT,
            fernet_key TEXT,
            last_ip TEXT,
            status TEXT,
            last_seen TEXT,
            contribution_mode BOOLEAN DEFAULT 0
        )
    ''')
    
    # Migration: Add contribution_mode if not exists
    try:
        c.execute("SELECT contribution_mode FROM network_nodes LIMIT 1")
    except sqlite3.OperationalError:
        c.execute("ALTER TABLE network_nodes ADD COLUMN contribution_mode BOOLEAN DEFAULT 0")

    # API Keys Vault (V14: Multi-provider support)
    c.execute('''
        CREATE TABLE IF NOT EXISTS api_vault (
            provider TEXT,
            api_key TEXT,
            priority INTEGER DEFAULT 0,
            active BOOLEAN DEFAULT 1
        )
    ''')

    # Codex Snippets Table (V15: The Codex)
    c.execute('''
        CREATE TABLE IF NOT EXISTS codex_snippets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT,
            language TEXT,
            code TEXT,
            tags TEXT,
            usage_count INTEGER DEFAULT 0,
            created_at TEXT
        )
    ''')

    conn.commit()
    conn.close()

def get_history_count():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("SELECT count(*) FROM history")
    count = c.fetchone()[0]
    conn.close()
    return count

def add_user_fact(key, value, category, confidence_score):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    timestamp = datetime.datetime.now().isoformat()
    # Check if key exists to update or insert? Or just append?
    # Request says "extract permanent data". Duplicate keys might exist if preferences change.
    # Let's insert new rows for now.
    c.execute("INSERT INTO user_metadata (key, value, category, confidence_score, timestamp) VALUES (?, ?, ?, ?, ?)",
              (key, value, category, confidence_score, timestamp))
    conn.commit()
    conn.close()

def get_user_facts(limit=5):
    """Retrieves the most recent high-confidence user facts."""
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    # Prioritize high confidence and recency
    c.execute("SELECT key, value, category FROM user_metadata WHERE confidence_score > 0.6 ORDER BY id DESC LIMIT ?", (limit,))
    rows = c.fetchall()
    conn.close()
    return rows

# --- Daemon Functions ---
def get_daemons():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    # Migration: Add task_type if not exists
    try:
        c.execute("SELECT task_type FROM daemons LIMIT 1")
    except sqlite3.OperationalError:
        c.execute("ALTER TABLE daemons ADD COLUMN task_type TEXT DEFAULT 'resource_watcher'")

    c.execute("SELECT id, name, task_type, status, interval_seconds, config, last_run FROM daemons")
    rows = c.fetchall()
    conn.close()
    return rows

def get_daemon(daemon_id):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("SELECT id, name, task_type, status, interval_seconds, config FROM daemons WHERE id = ?", (daemon_id,))
    row = c.fetchone()
    conn.close()
    return row

def update_daemon_last_run(daemon_id):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    now = datetime.datetime.now().isoformat()
    c.execute("UPDATE daemons SET last_run = ? WHERE id = ?", (now, daemon_id))
    conn.commit()
    conn.close()

def register_daemon_db(name, task_type, interval, config_str):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    try:
        c.execute("INSERT INTO daemons (name, task_type, interval_seconds, config, status) VALUES (?, ?, ?, ?, 'RUNNING')", 
                  (name, task_type, interval, config_str))
        conn.commit()
        return "Daemon registered successfully."
    except sqlite3.IntegrityError:
        return "Daemon name already exists."
    finally:
        conn.close()

def set_daemon_status(name, status):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("UPDATE daemons SET status = ? WHERE name = ?", (status, name))
    conn.commit()
    conn.close()

def get_latest_context_summary():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("SELECT value FROM user_metadata WHERE category = 'context_summary' ORDER BY id DESC LIMIT 1")
    row = c.fetchone()
    conn.close()
    if row:
        return row[0]
    return None

def get_active_projects():
    """Retrieves list of active project names from Nexus."""
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute("SELECT key, value FROM user_metadata WHERE category = 'project_sheet'")
    rows = c.fetchall()
    conn.close()
    
    projects = []
    # Key is project_{name}
    for row in rows:
        key = row['key']
        name = key.replace('project_', '').replace('_', ' ').title()
        projects.append(name)
    return projects

def register_node(node_id, public_key, ip_address, fernet_key=None, contribution_mode=None):
    """Registers or updates a network node."""
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    now = datetime.datetime.now().isoformat()
    
    # Check existence and preserves mode
    c.execute("SELECT contribution_mode FROM network_nodes WHERE node_id = ?", (node_id,))
    row = c.fetchone()
    
    current_mode = row[0] if (row and row[0] is not None) else 0
    final_mode = contribution_mode if contribution_mode is not None else current_mode

    if row:
        if fernet_key:
             c.execute("UPDATE network_nodes SET public_key = ?, fernet_key = ?, last_ip = ?, status = 'online', last_seen = ?, contribution_mode = ? WHERE node_id = ?",
                       (public_key, fernet_key, ip_address, now, final_mode, node_id))
        else:
             c.execute("UPDATE network_nodes SET public_key = ?, last_ip = ?, status = 'online', last_seen = ?, contribution_mode = ? WHERE node_id = ?",
                       (public_key, ip_address, now, final_mode, node_id))
    else:
        if fernet_key:
            c.execute("INSERT INTO network_nodes (node_id, public_key, fernet_key, last_ip, status, last_seen, contribution_mode) VALUES (?, ?, ?, ?, 'online', ?, ?)",
                      (node_id, public_key, fernet_key, ip_address, now, final_mode))
        else:
            c.execute("INSERT INTO network_nodes (node_id, public_key, last_ip, status, last_seen, contribution_mode) VALUES (?, ?, ?, 'online', ?, ?)",
                      (node_id, public_key, ip_address, now, final_mode))
    conn.commit()
    conn.close()

def get_contributors():
    """Retrieves all online nodes with contribution_mode enabled."""
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute("SELECT node_id, last_ip, status FROM network_nodes WHERE status = 'online' AND contribution_mode = 1")
    rows = c.fetchall()
    conn.close()
    return [dict(row) for row in rows]

def update_node_status(node_id, status, ip_address=None):
    """Updates the status and optionally IP of a node."""
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    now = datetime.datetime.now().isoformat()
    
    if ip_address:
        c.execute("UPDATE network_nodes SET status = ?, last_seen = ?, last_ip = ? WHERE node_id = ?", 
                  (status, now, ip_address, node_id))
    else:
        c.execute("UPDATE network_nodes SET status = ?, last_seen = ? WHERE node_id = ?", 
                  (status, now, node_id))
    conn.commit()
    conn.close()

def get_node_public_key(node_id):
    """Retrieves the public key for a given node ID."""
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("SELECT public_key FROM network_nodes WHERE node_id = ?", (node_id,))
    row = c.fetchone()
    conn.close()
    if row:
        return row[0]
    return None

def get_all_nodes():
    """Retrieves all network nodes."""
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute("SELECT node_id, status, last_seen, last_ip, contribution_mode FROM network_nodes")
    rows = c.fetchall()
    conn.close()
    return [dict(row) for row in rows]

def create_pairing_code(code, duration_minutes=10):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    now = datetime.datetime.now()
    expires = now + datetime.timedelta(minutes=duration_minutes)
    c.execute("INSERT INTO pairing_codes (code, created_at, expires_at) VALUES (?, ?, ?)", 
              (code, now.isoformat(), expires.isoformat()))
    conn.commit()
    conn.close()

def validate_pairing_code(code):
    """Checks if a code exists and is not expired."""
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    # Check expiry first
    c.execute("SELECT expires_at FROM pairing_codes WHERE code = ? AND status = 'active'", (code,))
    row = c.fetchone()
    
    if row:
        expires_str = row[0]
        try:
            expires = datetime.datetime.fromisoformat(expires_str)
            if datetime.datetime.now() < expires:
                # Code is valid. Mark as used?
                # User might want to pair multiple devices with same code?
                # Let's keep it active for the duration, safer to just rely on expiry for user UX
                conn.close()
                return True
        except:
            pass
            
    conn.close()
    return False

def get_node_key(node_id):
    """Retrieves the Fernet Key for a given node ID."""
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("SELECT fernet_key FROM network_nodes WHERE node_id = ?", (node_id,))
    row = c.fetchone()
    conn.close()
    return row[0] if row else None

    return row[0] if row else None


# --- API Vault Functions ---

def add_api_key(provider, api_key, priority=0, active=True):
    """Adds an encrypted API key to the vault."""
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("INSERT INTO api_vault (provider, api_key, priority, active) VALUES (?, ?, ?, ?)",
              (provider, api_key, priority, active))
    conn.commit()
    conn.close()

def get_api_keys(provider=None):
    """Retrieves API keys, optionally filtered by provider."""
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    if provider:
         c.execute("SELECT rowid, provider, api_key, priority, active FROM api_vault WHERE provider = ? AND active = 1 ORDER BY priority DESC", (provider,))
    else:
         c.execute("SELECT rowid, provider, api_key, priority, active FROM api_vault WHERE active = 1 ORDER BY priority DESC")
    rows = c.fetchall()
    conn.close()
    return [dict(row) for row in rows]

def delete_api_key(rowid):
    """Deletes an API key by its rowid."""
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("DELETE FROM api_vault WHERE rowid = ?", (rowid,))
    conn.commit()
    conn.close()

# --- Codex Functions (The Codex) ---
def add_codex_snippet(title, language, code, tags):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    created_at = datetime.datetime.now().isoformat()
    c.execute("INSERT INTO codex_snippets (title, language, code, tags, created_at) VALUES (?, ?, ?, ?, ?)",
              (title, language, code, tags, created_at))
    conn.commit()
    conn.close()

def search_codex(query):
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    wild = f"%{query}%"
    c.execute("SELECT * FROM codex_snippets WHERE title LIKE ? OR tags LIKE ? OR code LIKE ? ORDER BY usage_count DESC", (wild, wild, wild))
    rows = c.fetchall()
    conn.close()
    return [dict(row) for row in rows]

def get_all_codex_snippets():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute("SELECT * FROM codex_snippets ORDER BY created_at DESC")
    rows = c.fetchall()
    conn.close()
    return [dict(row) for row in rows]

def increment_codex_usage(snippet_id):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("UPDATE codex_snippets SET usage_count = usage_count + 1 WHERE id = ?", (snippet_id,))
    conn.commit()
    conn.close()

def get_pending_tasks(limit=10):
    """Retrieves pending tasks ordered by priority."""
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute("SELECT task, due_date, priority FROM reminders WHERE status = 'pending' ORDER BY CASE priority WHEN 'High' THEN 1 WHEN 'Medium' THEN 2 ELSE 3 END, due_date ASC LIMIT ?", (limit,))
    rows = c.fetchall()
    conn.close()
    return [dict(row) for row in rows]
