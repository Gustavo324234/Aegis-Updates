import os
import sqlite3
import json
import datetime
import time

# --- CONFIGURATION & MULTI-TENANCY ---
# Support for multi-user environments (e.g., Linux server with multiple users)
AEGIS_USER_ROOT = os.getenv('AEGIS_USER_ROOT')

if AEGIS_USER_ROOT:
    # Tenant Mode: Strict isolation
    USER_ROOT = AEGIS_USER_ROOT
    if not os.path.exists(USER_ROOT):
        print(f"[DATABASE] Zero-Config: Initializing Data Root at {USER_ROOT}")
        try:
            os.makedirs(USER_ROOT, exist_ok=True)
            # Pre-provision core structure immediately
            for sub in ["users", "vault", "config", "backups"]:
                 os.makedirs(os.path.join(USER_ROOT, sub), exist_ok=True)
        except Exception as e:
            print(f"[DATABASE] CRITICAL: Failed to create Data Vault at {USER_ROOT}: {e}")
            # Fallback to local to prevent crash, but warn heavily
            USER_ROOT = "."
else:
    # System/Global Mode: Default behavior (Dev/Local)
    USER_ROOT = "."
    # print("[DATABASE] System Mode Active (Global).") # Optional: reduce noise

# Ensure core folders exist for this tenant (or global)
# These are MANDATORY for the system to function
REQUIRED_DIRS = ["vault", "backups", "quarantine", "config", "global_config", "users"]
for d in REQUIRED_DIRS:
    target = os.path.join(USER_ROOT, d)
    if not os.path.exists(target):
        try: 
            os.makedirs(target, exist_ok=True)
        except Exception: 
            pass

DB_NAME = os.path.join(USER_ROOT, "aegis_memory.db")

def get_connection():
    """Establishes a connection to the SQLite database with WAL mode enabled."""
    conn = sqlite3.connect(DB_NAME, check_same_thread=False)
    # Enable Write-Ahead Logging for concurrency
    conn.execute("PRAGMA journal_mode=WAL;")
    return conn

def init_db():
    conn = get_connection()
    c = conn.cursor()

    # 1. Chat History
    c.execute('''CREATE TABLE IF NOT EXISTS history
                 (timestamp TEXT, role TEXT, content TEXT, model TEXT, thread_tag TEXT)''')
    
    # 2. Key-Value Settings (The Configuration Cortex)
    c.execute('''CREATE TABLE IF NOT EXISTS settings
                 (key TEXT PRIMARY KEY, value TEXT)''')
    
    # 3. User Metadata (Long-Term Memory / Facts)
    c.execute('''CREATE TABLE IF NOT EXISTS user_metadata
                 (key TEXT, value TEXT, category TEXT, confidence REAL, timestamp TEXT)''')

    # 4. Expenses (Finance Stream)
    c.execute('''CREATE TABLE IF NOT EXISTS expenses
                 (timestamp TEXT, amount REAL, category TEXT, description TEXT, currency TEXT)''')

    # 5. Tasks (Mission Control)
    c.execute('''CREATE TABLE IF NOT EXISTS tasks
                 (id INTEGER PRIMARY KEY AUTOINCREMENT, task TEXT, status TEXT, due_date TEXT, priority TEXT)''')

    # 6. Nexus Mesh (Network Nodes)
    c.execute('''CREATE TABLE IF NOT EXISTS network_nodes
                 (node_id TEXT PRIMARY KEY, 
                  ip_address TEXT, 
                  public_key TEXT, 
                  status TEXT, 
                  last_seen TEXT,
                  capabilities TEXT,
                  shared_key TEXT,
                  last_indexed TEXT)''')
    
    # Migration for existing table
    try:
        c.execute("ALTER TABLE network_nodes ADD COLUMN last_indexed TEXT")
    except:
        pass

    # 7. Pairing Codes (Security)
    c.execute('''CREATE TABLE IF NOT EXISTS pairing_codes
                 (code TEXT PRIMARY KEY, created_at TEXT)''')
    
    # 8. API Vault (The Swarm)
    c.execute('''CREATE TABLE IF NOT EXISTS api_vault
                 (id INTEGER PRIMARY KEY AUTOINCREMENT, provider TEXT, api_key TEXT, priority INTEGER)''')
    
    # 9. Codex Snippets (Code Library)
    c.execute('''CREATE TABLE IF NOT EXISTS codex_snippets
                 (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, code TEXT, tags TEXT, language TEXT, created_at TEXT)''')

    # 10. Audit Log (Security)
    c.execute('''CREATE TABLE IF NOT EXISTS audit_log
                 (timestamp TEXT, module TEXT, action TEXT, status TEXT, approved BOOLEAN, details TEXT, user TEXT)''')
    
    # Audit Log Migration (Robust)
    try:
        # Check if columns exist (simple try/except approach)
        c.execute("SELECT details FROM audit_log LIMIT 1")
    except:
        try:
            c.execute("ALTER TABLE audit_log ADD COLUMN details TEXT")
        except: pass
        
    try:
        c.execute("SELECT user FROM audit_log LIMIT 1")
    except:
        try:
            c.execute("ALTER TABLE audit_log ADD COLUMN user TEXT")
        except: pass
        
    try:
        c.execute("SELECT approved FROM audit_log LIMIT 1")
    except:
        # Migrate user_approved -> approved if needed, or just add approved
        try:
            c.execute("ALTER TABLE audit_log ADD COLUMN approved BOOLEAN")
        except: pass

    # 11. Daemons (The Overseer)
    c.execute('''CREATE TABLE IF NOT EXISTS daemons
                 (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, type TEXT, config TEXT, status TEXT, last_run TEXT)''')

    # 12. Message Queue (Offline Persistence)
    c.execute('''CREATE TABLE IF NOT EXISTS message_queue
                 (id INTEGER PRIMARY KEY AUTOINCREMENT, 
                  target_node TEXT, 
                  sender_id TEXT, 
                  content TEXT, 
                  timestamp TEXT, 
                  status TEXT)''')

    conn.commit()
    conn.close()

# ... (Existing Message Queue functions) ...

# --- AUDIT & DAEMONS (THE OVERSEER) ---
def log_audit_event(module, action, status, details=None, user="SYSTEM", approved=False):
    conn = get_connection()
    c = conn.cursor()
    ts = datetime.datetime.now().isoformat()
    try:
        # Try new schema
        c.execute("INSERT INTO audit_log (timestamp, module, action, status, approved, details, user) VALUES (?, ?, ?, ?, ?, ?, ?)", 
                  (ts, module, action, status, approved, details, user))
    except Exception as e:
        # Fallback for critical schema failure
        print(f"[DATABASE] Audit Log Failed: {e}")
        try:
            # Attempt legacy insert (user_approved?)
            c.execute("INSERT INTO audit_log (timestamp, module, action, status, user_approved) VALUES (?, ?, ?, ?, ?)", 
                      (ts, module, action, status, approved))
        except:
            pass
        
    conn.commit()
    conn.close()

def get_audit_logs(limit=50):
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM audit_log ORDER BY timestamp DESC LIMIT ?", (limit,))
    rows = c.fetchall()
    conn.close()
    return rows

def register_daemon(name, dtype, config):
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT id FROM daemons WHERE name=?", (name,))
    if c.fetchone():
        c.execute("UPDATE daemons SET config=?, status='RUNNING' WHERE name=?", (json.dumps(config), name))
    else:
        c.execute("INSERT INTO daemons (name, type, config, status) VALUES (?, ?, ?, ?)", (name, dtype, json.dumps(config), 'RUNNING'))
    conn.commit()
    conn.close()

def update_daemon_status(name, status, last_run=None):
    conn = get_connection()
    c = conn.cursor()
    if last_run:
        c.execute("UPDATE daemons SET status=?, last_run=? WHERE name=?", (status, last_run, name))
    else:
        c.execute("UPDATE daemons SET status=? WHERE name=?", (status, name))
    conn.commit()
    conn.close()

def get_all_daemons():
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT id, name, type, config, status, last_run FROM daemons")
    rows = c.fetchall()
    conn.close()
    return [{"id": r[0], "name": r[1], "type": r[2], "config": json.loads(r[3]), "status": r[4], "last_run": r[5]} for r in rows]

# --- DAEMON MANAGER COMPATIBILITY LAYER ---
def get_daemons():
    """Returns raw rows for DaemonManager loop."""
    conn = get_connection()
    c = conn.cursor()
    # Schema: id, name, type, status, interval (missing in DB?), config, last_run
    # Note: DB schema is (id, name, type, config, status, last_run).
    # DaemonManager expects: id, name, type, status, interval, config, last_run
    # We must adapt. Interval is likely inside config or missing from DB schema v1.
    # Let's mock interval as 60 if missing.
    c.execute("SELECT id, name, type, status, config, last_run FROM daemons")
    rows = c.fetchall()
    conn.close()
    
    adapted = []
    for r in rows:
        # r: (id, name, type, status, config_str, last_run)
        # construct: (id, name, type, status, interval, config, last_run)
        # extract interval from config
        interval = 60
        try:
            cfg = json.loads(r[4])
            interval = cfg.get("interval", 60)
        except: pass
        
        adapted.append((r[0], r[1], r[2], r[3], interval, r[4], r[5]))
        
    return adapted

def get_daemon(daemon_id):
    """Get single daemon tuple for run_loop."""
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT id, name, type, status, config, last_run FROM daemons WHERE id=?", (daemon_id,))
    r = c.fetchone()
    conn.close()
    if not r: return None
    
    interval = 60
    try:
        cfg = json.loads(r[4])
        interval = cfg.get("interval", 60)
    except: pass
    
    return (r[0], r[1], r[2], r[3], interval, r[4], r[5])

def update_daemon_last_run(daemon_id):
    conn = get_connection()
    c = conn.cursor()
    ts = datetime.datetime.now().isoformat()
    c.execute("UPDATE daemons SET last_run=? WHERE id=?", (ts, daemon_id))
    conn.commit()
    conn.close()
    
def register_daemon_db(name, task_type, interval, config_str):
    # Adapter for DaemonManager.register_daemon
    # Inject interval into config since DB has no column
    try:
        cfg = json.loads(config_str)
        cfg['interval'] = interval
        new_conf = json.dumps(cfg)
        
        register_daemon(name, task_type, cfg) # Reuse existing
        return "Daemon Registered"
    except Exception as e:
        return str(e)

def set_daemon_status(name, status):
    update_daemon_status(name, status)

# --- PROJECT NEXUS HELPERS ---
def get_active_projects():
    # Retrieve active projects from User Facts
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT value FROM user_metadata WHERE category='project_active'")
    rows = c.fetchall()
    conn.close()
    return [r[0] for r in rows]
