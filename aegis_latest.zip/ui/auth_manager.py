import streamlit as st
import time
import database
import requests
from modules.auth_vault import auth


def render_login():
    st.markdown(
        """
    <style>
        .login-box {
            max-width: 400px;
            margin: 100px auto;
            padding: 40px;
            background: rgba(22, 27, 34, 0.9);
            border: 1px solid #30363d;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 0 20px rgba(0, 242, 255, 0.1);
        }
    </style>
    """,
        unsafe_allow_html=True,
    )

    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        st.title("🛡️ AEGIS-IA")
        st.caption("SYSTEM ACCESS LOCKED")

        with st.form("main_login_form"):
            password = st.text_input(
                "IDENTITY VERIFICATION",
                type="password",
                placeholder="Enter Master Password",
            )
            submit_auth = st.form_submit_button("AUTHENTICATE SYSTEM")

            if submit_auth:
                if auth.verify_password(password):
                    st.session_state.authenticated = True
                    st.session_state.master_password = password

                    # Derive Session Encryption Key (Fernet)
                    try:
                        st.session_state.enc_key = auth.derive_key(password)
                    except Exception as e:
                        st.error(f"Crypto Init Failed: {e}")

                    st.success("ACCESS GRANTED")

                    # Load API Key Ring
                    keys = database.get_api_keys()
                    key_ring = {}
                    if keys:
                        for k in keys:
                            try:
                                decrypted = auth.decrypt_content(
                                    k["api_key"], st.session_state.enc_key
                                )
                                key_ring[k["provider"]] = decrypted
                            except Exception as e:
                                print(f"Key Decrypt Fail for {k['provider']}: {e}")

                    st.session_state.api_key_ring = key_ring

                    time.sleep(1)
                    st.rerun()
                else:
                    st.error("ACCESS DENIED: INVALID CREDENTIALS")


def render_onboarding():
    st.markdown(
        """
    <style>
        .onboarding-card {
            background-color: #161b22;
            padding: 30px;
            border-radius: 10px;
            border: 1px solid #30363d;
            text-align: left;
            margin-bottom: 20px;
        }
        .step-indicator {
            font-size: 0.8em;
            color: #8b949e;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 5px;
        }
        .highlight {
            color: #00f2ff;
        }
    </style>
    """,
        unsafe_allow_html=True,
    )

    if "onboarding_step" not in st.session_state:
        st.session_state.onboarding_step = 1

    step = st.session_state.onboarding_step

    container = st.container()

    with container:
        # Header
        st.caption("PROTOCOL: EL DESPERTAR // ONBOARDING V2")
        progress = (step - 1) / 3
        st.progress(progress)

        # --- STEP 1: IDENTITY & SECURITY ---
        if step == 1:
            st.subheader("1. Identidad y Seguridad")
            st.markdown(
                "Defina la identidad de este nodo y asegure su bóveda de datos."
            )

            with st.form("step1_form"):
                col1, col2 = st.columns(2)
                with col1:
                    user_name = st.text_input("Su Nombre", placeholder="Ej: Neo")
                with col2:
                    ai_name = st.text_input("Nombre de la IA", value="Aegis")

                st.divider()
                st.markdown("🔐 **Contraseña Maestra**")
                st.caption(
                    "Esta contraseña encriptará sus claves API y datos sensibles. ¡No la olvide!"
                )
                master_pass = st.text_input(
                    "Master Password", type="password", placeholder="********"
                )
                confirm_pass = st.text_input(
                    "Confirm Password", type="password", placeholder="********"
                )

                if st.form_submit_button("Siguiente: Conexión Neuronal ➡️"):
                    if not user_name or not ai_name:
                        st.error("Por favor, complete los nombres.")
                    elif len(master_pass) < 4:
                        st.error("La contraseña debe tener al menos 4 caracteres.")
                    elif master_pass != confirm_pass:
                        st.error("Las contraseñas no coinciden.")
                    else:
                        # Logic
                        auth.set_master_password(master_pass)
                        st.session_state.master_password = master_pass
                        try:
                            st.session_state.enc_key = auth.derive_key(master_pass)
                        except Exception as e:
                            st.error(f"Error Crypto: {e}")
                            st.stop()

                        # Save Identity
                        database.add_user_fact("user_name", user_name, "identity")
                        database.set_setting("ai_name", ai_name)

                        st.session_state.onboarding_step = 2
                        st.rerun()

        # --- STEP 2: NEURAL CONNECTION ---
        elif step == 2:
            st.subheader("2. Conexión Neuronal")
            st.markdown("Configure el cerebro digital de su asistente.")

            mode = st.radio(
                "Modo de Operación",
                ["Solo Nube (Gemini/OpenAI)", "Solo Local (Ollama)", "Híbrido"],
                index=0,
                horizontal=True,
            )

            st.divider()

            # LOCAL CONFIG
            if "Local" in mode or "Híbrido" in mode:
                st.markdown("🦙 **Configuración Local (Ollama)**")
                ollama_url = st.text_input("Ollama URL", value="http://localhost:11434")

                c1, c2 = st.columns([1, 3])
                with c1:
                    if st.button("🔍 Detectar Modelos"):
                        try:
                            r = requests.get(f"{ollama_url}/api/tags", timeout=3)
                            if r.status_code == 200:
                                models = [m["name"] for m in r.json().get("models", [])]
                                st.session_state.detected_models = models
                                st.success(f"{len(models)} modelos detectados.")
                            else:
                                st.error("Error al conectar con Ollama.")
                        except Exception as e:
                            st.error(f"Error: {e}")

                detected = st.session_state.get("detected_models", [])
                selected_local = None
                if detected:
                    selected_local = st.selectbox("Modelo Principal", detected)
                else:
                    st.info("Detecte modelos para seleccionar.")

                # Test Connection
                if selected_local:
                    if st.button("🧪 Probar Conexión (Ping)"):
                        try:
                            payload = {
                                "model": selected_local,
                                "prompt": "Hola",
                                "stream": False,
                            }
                            with st.spinner("Enviando señal..."):
                                r = requests.post(
                                    f"{ollama_url}/api/generate",
                                    json=payload,
                                    timeout=10,
                                )
                                if r.status_code == 200:
                                    resp = r.json().get("response", "")
                                    st.success(f"Respuesta recibida: '{resp}'")
                                else:
                                    st.error(f"Error {r.status_code}: {r.text}")
                        except Exception as e:
                            st.error(f"Connection Exception: {e}")

            # CLOUD CONFIG
            if "Nube" in mode or "Híbrido" in mode:
                st.markdown("☁️ **Configuración Nube**")
                gemini_key = st.text_input(
                    "Gemini API Key", type="password", placeholder="AIza..."
                )
                openai_key = st.text_input(
                    "OpenAI API Key (Opcional)", type="password", placeholder="sk-..."
                )

                if st.button("💾 Guardar Keys en Bóveda"):
                    if not st.session_state.get("enc_key"):
                        st.error("Error de sesión: Clave de encriptación perdida.")
                    else:
                        saved_count = 0
                        if gemini_key:
                            enc = auth.encrypt_content(
                                gemini_key, st.session_state.enc_key
                            )
                            database.add_api_key("gemini", enc)
                            saved_count += 1
                        if openai_key:
                            enc = auth.encrypt_content(
                                openai_key, st.session_state.enc_key
                            )
                            database.add_api_key("openai", enc)
                            saved_count += 1
                        st.success(f"{saved_count} API Keys encriptadas y guardadas.")

            st.divider()
            c_back, c_next = st.columns([1, 1])
            with c_back:
                if st.button("⬅️ Atrás"):
                    st.session_state.onboarding_step = 1
                    st.rerun()
            with c_next:
                if st.button("Siguiente: Definir Alma ➡️"):
                    # Save Configs
                    database.set_setting("operation_mode", mode)
                    if "Local" in mode or "Híbrido" in mode:
                        database.set_setting("ollama_url", ollama_url)
                        if st.session_state.get("detected_models"):
                            # Auto-set active model if user selected one, else logic defaults
                            pass  # Logic handled in Brain usually, or set 'active_model' setting
                        # We can set default active model to selected local if acceptable
                        if (
                            "detected_models" in st.session_state
                            and st.session_state.detected_models
                        ):
                            # Assuming query of selectbox is persistent if not re-rendered, but safer to trust user config later
                            pass

                    st.session_state.onboarding_step = 3
                    st.rerun()

        # --- STEP 3: PERSONALITY & SOUL ---
        elif step == 3:
            st.subheader("3. Definición del Alma")
            st.markdown("Elija la personalidad base de su compañero.")

            archetypes = {
                "Mayordomo Formal": "Respetuoso, preciso, conciso. Usa 'Señor/a'. Estilo Jarvis.",
                "Ingeniero Sarcástico": "Técnico, directo, con humor seco y cínico. Estilo Silicon Valley.",
                "Amigo Empático": "Cálido, comprensivo, emocionalmente inteligente. Estilo Samantha (Her).",
                "Maestro Zen": "Calmado, filosófico, profundo. Enfocado en el equilibrio.",
            }

            selection = st.radio("Arquetipo de Personalidad", list(archetypes.keys()))
            st.info(f"🎭 **Estilo:** {archetypes[selection]}")

            st.divider()

            if st.button("✨ FINALIZAR EL DESPERTAR ✨", type="primary"):
                # Save Personality
                database.add_user_fact("assistant_personality", selection, "identity")

                # Finalize
                database.set_setting("setup_complete", "true")
                st.session_state.authenticated = True
                st.session_state.first_run_trigger = True

                st.balloons()
                time.sleep(1)
                st.rerun()
