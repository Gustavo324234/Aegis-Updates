import streamlit as st
import time
import database
import requests
from modules.auth_vault import auth


def render_login():
    st.markdown(
        """
    <style>
        .login-box {
            max-width: 400px;
            margin: 100px auto;
            padding: 40px;
            background: rgba(22, 27, 34, 0.9);
            border: 1px solid #30363d;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 0 20px rgba(0, 242, 255, 0.1);
        }
    </style>
    """,
        unsafe_allow_html=True,
    )

    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        st.title("🛡️ AEGIS-IA")
        st.caption("SYSTEM ACCESS LOCKED")

        with st.form("main_login_form"):
            password = st.text_input(
                "IDENTITY VERIFICATION",
                type="password",
                placeholder="Enter Master Password",
            )
            submit_auth = st.form_submit_button("AUTHENTICATE SYSTEM")

            if submit_auth:
                if auth.verify_password(password):
                    st.session_state.authenticated = True
                    st.session_state.master_password = password

                    # Derive Session Encryption Key (Fernet)
                    try:
                        st.session_state.enc_key = auth.derive_key(password)
                    except Exception as e:
                        st.error(f"Crypto Init Failed: {e}")

                    st.success("ACCESS GRANTED")

                    # Load API Key Ring
                    keys = database.get_api_keys()
                    key_ring = {}
                    if keys:
                        for k in keys:
                            try:
                                decrypted = auth.decrypt_content(
                                    k["api_key"], st.session_state.enc_key
                                )
                                key_ring[k["provider"]] = decrypted
                            except Exception as e:
                                print(f"Key Decrypt Fail for {k['provider']}: {e}")

                    st.session_state.api_key_ring = key_ring

                    time.sleep(1)
                    st.rerun()
                else:
                    st.error("ACCESS DENIED: INVALID CREDENTIALS")


def render_onboarding():
    st.markdown(
        """
    <style>
        .bootloader-card {
            background-color: #0d1117;
            padding: 30px;
            border-radius: 4px;
            border: 1px solid #30363d;
            font-family: 'Courier New', monospace;
            color: #00f2ff;
        }
        .boot-header {
            border-bottom: 2px solid #00f2ff;
            margin-bottom: 20px;
            padding-bottom: 5px;
            text-transform: uppercase;
            letter-spacing: 2px;
        }
        .stTextInput input {
            background-color: #000 !important;
            color: #0f0 !important;
            border: 1px solid #333 !important;
        }
    </style>
    """,
        unsafe_allow_html=True,
    )

    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        st.markdown(
            """
        <div class="bootloader-card">
            <div class="boot-header">/// SYSTEM BOOTLOADER v1.0 ///</div>
            <div>STATUS: UNINITIALIZED</div>
            <div>KERNEL: WAITING FOR AUTHORIZATION</div>
        </div>
        """,
            unsafe_allow_html=True,
        )

        with st.form("bootloader"):
            # 1. Master Key
            st.markdown("### 1. SECURITY PROTOCOL")
            master_pass = st.text_input(
                "ROOT PASSWORD", type="password", placeholder="Set Master Key..."
            )

            st.divider()

            # 2. Neural Connection
            st.markdown("### 2. NEURAL LINK")
            mode = st.radio(
                "PROCESSOR ARCHITECTURE",
                ["Local (Ollama)", "Cloud (Gemini/OpenAI)", "Hybrid"],
                index=0,
                horizontal=True,
            )

            api_input_container = st.container()
            ollama_url = "http://localhost:11434"
            gemini_key = ""

            if "Local" in mode or "Hybrid" in mode:
                ollama_url = st.text_input(
                    "LOCAL HOST ADDRESS", value="http://localhost:11434"
                )

            if "Cloud" in mode or "Hybrid" in mode:
                gemini_key = st.text_input(
                    "GEMINI API KEY", type="password", placeholder="AIza..."
                )

            st.markdown("<br>", unsafe_allow_html=True)

            # Action
            submitted = st.form_submit_button(">>> INITIATE GENESIS SEQUENCE <<<")

            if submitted:
                if len(master_pass) < 4:
                    st.error("ERROR: PASSWORD_TOO_SHORT (MIN 4 CHARS)")
                    st.stop()

                # --- EXECUTE BOOT SEQUENCE ---
                with st.spinner("CRYPTOSYSTEM ENGAGED..."):
                    # 1. Security Setup
                    auth.set_master_password(master_pass)
                    st.session_state.master_password = master_pass
                    try:
                        st.session_state.enc_key = auth.derive_key(master_pass)
                    except Exception as e:
                        st.error(f"FATAL: CRYPTO_FAIL: {e}")
                        st.stop()

                    # 2. Processor Config
                    database.set_setting("operation_mode", mode)
                    if "Local" in mode or "Hybrid" in mode:
                        database.set_setting("ollama_url", ollama_url)

                    if gemini_key:
                        enc = auth.encrypt_content(gemini_key, st.session_state.enc_key)
                        database.add_api_key("gemini", enc)

                    # 3. Mark as Complete (BUT GENESIS MODE WILL TRIGGER IN CHAT)
                    database.set_setting("setup_complete", "true")
                    st.session_state.authenticated = True
                    # Let chat manager handle the 'first run' message based on empty history

                    st.success("SYSTEM INITIALIZED. NEURAL LINK ESTABLISHED.")
                    time.sleep(1.5)
                    st.rerun()
