import streamlit as st
import time
import database
import requests
from modules.auth_vault import auth


def render_login():
    st.markdown(
        """
    <style>
        .login-box {
            max-width: 400px;
            margin: 100px auto;
            padding: 40px;
            background: rgba(22, 27, 34, 0.9);
            border: 1px solid #30363d;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 0 20px rgba(0, 242, 255, 0.1);
        }
    </style>
    """,
        unsafe_allow_html=True,
    )

    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        st.title("🛡️ AEGIS-IA")
        st.caption("SYSTEM ACCESS LOCKED")

        with st.form("main_login_form"):
            password = st.text_input(
                "IDENTITY VERIFICATION",
                type="password",
                placeholder="Enter Master Password",
            )
            submit_auth = st.form_submit_button("AUTHENTICATE SYSTEM")

            if submit_auth:
                if auth.verify_password(password):
                    st.session_state.authenticated = True
                    st.session_state.master_password = password

                    # Derive Session Encryption Key (Fernet)
                    try:
                        st.session_state.enc_key = auth.derive_key(password)
                    except Exception as e:
                        st.error(f"Crypto Init Failed: {e}")

                    st.success("ACCESS GRANTED")

                    # Load API Key Ring
                    keys = database.get_api_keys()
                    key_ring = {}
                    if keys:
                        for k in keys:
                            try:
                                decrypted = auth.decrypt_content(
                                    k["api_key"], st.session_state.enc_key
                                )
                                key_ring[k["provider"]] = decrypted
                            except Exception as e:
                                print(f"Key Decrypt Fail for {k['provider']}: {e}")

                    st.session_state.api_key_ring = key_ring

                    time.sleep(1)
                    st.rerun()
                else:
                    st.error("ACCESS DENIED: INVALID CREDENTIALS")


def render_onboarding():
    st.markdown(
        """
    <style>
        .bootloader-card {
            background-color: #0d1117;
            padding: 30px;
            border-radius: 4px;
            border: 1px solid #30363d;
            font-family: 'Courier New', monospace;
            color: #00f2ff;
        }
        .boot-header {
            border-bottom: 2px solid #00f2ff;
            margin-bottom: 20px;
            padding-bottom: 5px;
            text-transform: uppercase;
            letter-spacing: 2px;
        }
    </style>
    """,
        unsafe_allow_html=True,
    )

    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        st.markdown(
            """
        <div class="bootloader-card">
            <div class="boot-header">/// SYSTEM BOOTLOADER v1.1 ///</div>
            <div>STATUS: UNINITIALIZED</div>
            <div>KERNEL: WAITING FOR AUTHORIZATION</div>
        </div>
        """,
            unsafe_allow_html=True,
        )

        # 1. Master Key
        st.markdown("### 1. SECURITY PROTOCOL")
        master_pass = st.text_input(
            "MASTER PASSWORD", type="password", placeholder="Set Master Key..."
        )

        st.divider()

        # 2. Neural Connection
        st.markdown("### 2. NEURAL LINK")
        # Updated to match settings_manager.py exactly
        mode = st.radio(
            "PROCESSOR ARCHITECTURE",
            ["Local Only (Sovereign)", "Cloud Only", "Hybrid (Smart)"],
            index=0,
            horizontal=True,
        )

        ollama_url = "http://127.0.0.1:11434"
        gemini_key = ""

        # Local model selection variables (default to None)
        sel_chat = None
        sel_coder = None
        sel_logic = None
        sel_heavy = None

        if "Local" in mode or "Hybrid" in mode:
            c_ollama, c_test = st.columns([3, 1])
            with c_ollama:
                ollama_url = st.text_input(
                    "LOCAL HOST ADDRESS", value="http://127.0.0.1:11434"
                )
            with c_test:
                st.write("")  # Spacer
                st.write("")
                if st.button("PING & SCAN", help="Test Link & Fetch Models"):
                    try:
                        resp = requests.get(f"{ollama_url}/api/tags", timeout=3)
                        if resp.status_code == 200:
                            data = resp.json()
                            models = [m["name"] for m in data.get("models", [])]
                            st.session_state.onboard_models = models
                            st.toast(f"✅ FOUND {len(models)} MODELS", icon="🟢")
                        else:
                            st.toast(f"❌ ERROR: {resp.status_code}", icon="🔴")
                    except Exception:
                        st.session_state.onboard_models = []
                        st.toast("❌ UNREACHABLE", icon="🔴")

            # Show selectors if models found
            if "onboard_models" in st.session_state and st.session_state.onboard_models:
                avail_models = st.session_state.onboard_models
                st.markdown("###### 🧠 ASSIGN NEURAL ROLES")
                c_r1, c_r2 = st.columns(2)
                with c_r1:
                    sel_chat = st.selectbox("💬 Chat / General", avail_models, index=0)
                    sel_coder = st.selectbox(
                        "💻 Code Specialist", avail_models, index=0
                    )
                with c_r2:
                    sel_logic = st.selectbox(
                        "🤔 Logic / Reasoning", avail_models, index=0
                    )
                    sel_heavy = st.selectbox("📚 Heavy Context", avail_models, index=0)
            elif "onboard_models" in st.session_state:
                st.warning(
                    "⚠️ No models found. Install models in Ollama first (e.g. `ollama run llama3`)."
                )

        if "Cloud" in mode or "Hybrid" in mode:
            gemini_key = st.text_input(
                "GEMINI API KEY", type="password", placeholder="AIza..."
            )

        st.markdown("<br>", unsafe_allow_html=True)

        # Action
        if st.button(
            ">>> INITIATE GENESIS SEQUENCE <<<",
            type="primary",
            use_container_width=True,
        ):
            if len(master_pass) < 4:
                st.error("ERROR: PASSWORD_TOO_SHORT (MIN 4 CHARS)")
                st.stop()

            # --- EXECUTE BOOT SEQUENCE ---
            with st.spinner("CRYPTOSYSTEM ENGAGED..."):
                # 1. Security Setup
                auth.set_master_password(master_pass)
                st.session_state.master_password = master_pass
                try:
                    st.session_state.enc_key = auth.derive_key(master_pass)
                except Exception as e:
                    st.error(f"FATAL: CRYPTO_FAIL: {e}")
                    st.stop()

                # 2. Processor Config
                database.set_setting("operation_mode", mode)
                if "Local" in mode or "Hybrid" in mode:
                    database.set_setting("ollama_url", ollama_url)
                    # Save selected roles if available
                    if sel_chat:
                        database.set_setting("local_chat_model", sel_chat)
                    if sel_coder:
                        database.set_setting("local_coder_model", sel_coder)
                    if sel_logic:
                        database.set_setting("local_logic_model", sel_logic)
                    if sel_heavy:
                        database.set_setting("local_heavy_model", sel_heavy)

                if gemini_key:
                    enc = auth.encrypt_content(gemini_key, st.session_state.enc_key)
                    database.add_api_key("gemini", enc)

                # 3. Mark as Complete
                database.set_setting("setup_complete", "true")
                st.session_state.authenticated = True

                st.success("SYSTEM INITIALIZED. NEURAL LINK ESTABLISHED.")
                time.sleep(1.5)
                st.rerun()
