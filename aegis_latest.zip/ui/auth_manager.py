import streamlit as st
import time
import database
from modules.auth_vault import auth


def render_login():
    st.markdown(
        """
    <style>
        .login-box {
            max-width: 400px;
            margin: 100px auto;
            padding: 40px;
            background: rgba(22, 27, 34, 0.9);
            border: 1px solid #30363d;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 0 20px rgba(0, 242, 255, 0.1);
        }
    </style>
    """,
        unsafe_allow_html=True,
    )

    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        st.title("🛡️ AEGIS-IA")
        st.caption("SYSTEM ACCESS LOCKED")

        with st.form("main_login_form"):
            password = st.text_input(
                "IDENTITY VERIFICATION",
                type="password",
                placeholder="Enter Master Password",
            )
            submit_auth = st.form_submit_button("AUTHENTICATE SYSTEM")

            if submit_auth:
                if auth.verify_password(password):
                    st.session_state.authenticated = True
                    st.session_state.master_password = password

                    # Derive Session Encryption Key (Fernet)
                    try:
                        st.session_state.enc_key = auth.derive_key(password)
                    except Exception as e:
                        st.error(f"Crypto Init Failed: {e}")

                    st.success("ACCESS GRANTED")

                    # Load API Key Ring
                    keys = database.get_api_keys()
                    key_ring = {}
                    if keys:
                        for k in keys:
                            try:
                                decrypted = auth.decrypt_content(
                                    k["api_key"], st.session_state.enc_key
                                )
                                key_ring[k["provider"]] = decrypted
                            except Exception as e:
                                print(f"Key Decrypt Fail for {k['provider']}: {e}")

                    st.session_state.api_key_ring = key_ring

                    time.sleep(1)
                    st.rerun()
                else:
                    st.error("ACCESS DENIED: INVALID CREDENTIALS")


def render_onboarding():
    st.markdown(
        """
    <style>
        .onboarding-card {
            background-color: #161b22;
            padding: 30px;
            border-radius: 10px;
            border: 1px solid #30363d;
            text-align: center;
            margin-bottom: 20px;
        }
        .pillar {
            display: inline-block;
            width: 30%;
            margin: 1%;
            padding: 10px;
            background: rgba(0, 242, 255, 0.05);
            border-radius: 8px;
        }
    </style>
    """,
        unsafe_allow_html=True,
    )

    step = st.session_state.get("onboarding_step", 0)

    # --- STEP 0: WELCOME ---
    if step == 0:
        st.title("🛡️ Aegis-IA Workspace")
        st.markdown("### Bienvenido a su entorno privado.")
        st.write(
            "Este sistema opera de manera aislada. Su base de datos y archivos son exclusivos de esta instancia."
        )

        st.divider()

        ai_name = st.text_input(
            "Nombre para su Asistente",
            placeholder="Ej: Aegis, Jarvis, Cortana...",
            value="Aegis",
        )

        if st.button("Comenzar Configuración", type="primary"):
            if ai_name.strip():
                database.set_setting("ai_name", ai_name.strip())
                # Implicitly set a default master password for tenant mode to simplify UX
                # In a real SaaS, this would be the user's login password.
                # Here we set a discrete default to enable the crypto vault.
                auth.set_master_password("tenant_default_secure")
                st.session_state.master_password = "tenant_default_secure"
                st.session_state.onboarding_step = 1
                st.rerun()
            else:
                st.warning("Por favor, elija un nombre.")

    # --- STEP 1: API KEY (THE BRAIN) ---
    elif step == 1:
        st.subheader("🔑 Activación Neuronal")
        st.markdown("""
        Para que **Aegis** pueda razonar, necesita conectarse a un modelo de lenguaje.
        
        Opción A: **Google Gemini (Recomendado)** - Rápido, Gratuito y Potente.
        Opción B: **Modo Local (Ollama)** - Privacidad total, requiere hardware potente.
        """)

        st.markdown(
            "[Obtener Gemini API Key Gratis](https://aistudio.google.com/app/apikey)"
        )

        api_key = st.text_input(
            "Ingrese su Google Gemini API Key", type="password", placeholder="AIzaSy..."
        )

        col1, col2 = st.columns(2)
        with col1:
            if st.button("Guardar y Activar", type="primary"):
                if api_key and str(api_key).startswith("AI"):
                    auth.set_api_key(api_key, st.session_state.master_password)
                    st.success("API Key Guardada en Bóveda Segura.")
                    time.sleep(1)
                    st.session_state.onboarding_step = 2
                    st.rerun()
                else:
                    st.error("API Key inválida (Debe comenzar con 'AI').")

        with col2:
            if st.button("Usar Modo Local (Ollama)"):
                st.info("Configurando Modo Soberano...")
                database.set_setting("active_model", "ollama-llama3.1")
                database.set_setting("api_key_gemini", "local_mode_active")
                time.sleep(1)
                st.session_state.onboarding_step = 2
                st.rerun()

    # --- STEP 2: FINALIZATION ---
    elif step == 2:
        st.subheader("✅ Todo Listo")
        st.write("Su espacio de trabajo está configurado y aislado.")
        st.info("Todos los datos generados se guardarán en su carpeta personal.")

        if st.button("LAUNCH SYSTEM", type="primary"):
            database.set_setting("setup_complete", "true")
            st.session_state.authenticated = True

            # Init Session Key
            try:
                st.session_state.enc_key = auth.derive_key(
                    st.session_state.master_password
                )
            except Exception:
                pass

            st.balloons()
            time.sleep(1)
            st.rerun()
