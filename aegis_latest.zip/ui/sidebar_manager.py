import streamlit as st
import database
import json
import os
import datetime
import requests
import time

# Module Imports
from modules.resource_monitor import monitor
import modules.ide_bridge
from modules.beacon import beacon
from modules.utils import get_user_root
from modules.env_probe import probe
from modules.vault_manager import vault
from modules.unifier import unifier
import modules.studio_exporter
from modules.auth_vault import auth
from modules.daemon_manager import DaemonManager

# Local Imports
from .settings_manager import render_settings_tabs


def render_sidebar(brain_instance, daemon_manager):
    """
    Renders the complete Sidebar interface.
    Args:
        brain_instance: The initialized AegisBrain.
        daemon_manager: The active DaemonManager instance.
    """
    with st.sidebar:
        ai_name = database.get_setting("ai_name") or "Aegis-IA"
        st.title(f"🛡️ {ai_name}")
        st.caption("The Singularity Edition")

        # --- PROJECT NEXUS INDICATOR ---
        active_projects = database.get_active_projects()
        if active_projects:
            st.success(f"🟢 NEXUS ACTIVE: {', '.join(active_projects)}")

        # --- SYSTEM HEALTH ---
        health_status = monitor.check_health()
        color = (
            "green"
            if health_status == "GREEN"
            else "orange"
            if health_status == "YELLOW"
            else "red"
        )
        metrics = monitor.get_metrics()
        st.markdown(
            f"**STATUS:** :{color}[●] {health_status} | **RAM:** {metrics.get('app_ram_usage_mb', 0)}MB"
        )

        st.divider()

        # --- FORGE UPLINK STATUS ---
        forge_conf = modules.ide_bridge.get_config_path()
        if forge_conf and os.path.exists(forge_conf):
            st.markdown("🛠️ **Forge Uplink:** :green[ACTIVE]")
        else:
            st.markdown("🛠️ **Forge Uplink:** :red[OFFLINE]")

        # --- 🛠️ THE FORGE (IDE) ---
        with st.expander("🛠️ The Forge (IDE)", expanded=False):
            if st.button(
                "🚀 Launch & Sync",
                use_container_width=True,
                help="Sync AI Config & Open IDE (Port 8080)",
            ):
                with st.spinner("Syncing Neural Pathways..."):
                    try:
                        res = modules.ide_bridge.sync_ai_config()
                        if res.get("status") == "success":
                            st.toast(f"Synced: {res['model']}")
                        else:
                            st.warning(f"Sync: {res.get('message')}")
                    except Exception:
                        st.warning("Sync failed (Check connection)")

                    # Auto-Start (Linux Only - skipping complex logic here relying on user manual start or simple subprocess)
                    # Open via JS
                    ws_root = get_user_root().replace("\\", "/")
                    st.markdown(
                        f"""
                     <script>
                        const protocol = window.location.protocol;
                        const host = window.location.hostname;
                        const target = protocol + "//" + host + ":8080/?folder={ws_root}";
                        window.open(target, '_blank').focus();
                     </script>
                     """,
                        unsafe_allow_html=True,
                    )
                    st.info("Opening Forge...")
            st.caption("⚠️ Ensure port **8080** is open")

        # --- 🌐 NETWORK MESH ---
        with st.expander("🌐 Network Mesh", expanded=True):
            nodes = database.get_all_nodes()
            if nodes:
                for node in nodes:
                    last_seen_str = node.get("last_seen", "")
                    status = node.get("status", "offline")
                    latency_disp = "N/A"
                    status_color = "🔴"
                    swarming = False

                    if status == "online":
                        status_color = "🟢"
                        if node.get("contribution_mode"):
                            status_color = "⚡"
                            swarming = True
                        try:
                            dt = datetime.datetime.fromisoformat(last_seen_str)
                            diff = (datetime.datetime.now() - dt).total_seconds()
                            if diff < 60:
                                latency_disp = f"{int(diff * 1000) % 50 + 10}ms"
                        except Exception:
                            pass
                    else:
                        status_color = "⚫"

                    c1, c2 = st.columns([3, 1])
                    with c1:
                        st.markdown(f"**{node['node_id']}**")
                        caption_text = (
                            f"{status_color} {latency_disp} | {node.get('last_ip')}"
                        )
                        if swarming:
                            caption_text += " | **Swarm Ready**"
                        st.caption(caption_text)

                    with c2:
                        if st.button("⚙️", key=f"conf_{node['node_id']}"):
                            st.toast(f"Configuring {node['node_id']}...")
                    st.divider()
            else:
                st.info("No nodes linked. Start a Limb.")

            # Pairing
            st.subheader("🔗 Device Pairing")
            if st.button("Generate Pairing Code"):
                import random
                import string

                code = "".join(
                    random.choices(string.ascii_uppercase + string.digits, k=6)
                )
                database.create_pairing_code(code)

                # QR Logic simplified
                config_payload = json.dumps(
                    {"gateway": "ws://REPLACE_WITH_IP:8000/ws", "code": code}
                )
                local_url = beacon.get_local_ip(port=8000)
                final_payload = config_payload.replace(
                    "REPLACE_WITH_IP", local_url.replace("http://", "")
                )
                qr_img = beacon.generate_qr(final_payload)

                st.session_state.pairing_code = code
                st.session_state.pairing_qr = qr_img

            if "pairing_code" in st.session_state:
                c1, c2 = st.columns([1, 1])
                with c1:
                    st.metric("Pairing Code", st.session_state.pairing_code)
                with c2:
                    st.image(st.session_state.pairing_qr, width=150)

        # --- 📊 STATS & DATA ---
        with st.expander("📊 Stats & Data"):
            st.subheader("Nexus Dashboard")
            st.markdown("**💰 Finance Stream**")
            expenses = database.get_expenses(limit=50)
            total_monthly = sum(e[1] for e in expenses) if expenses else 0
            st.metric("Total Stream", f"${total_monthly:,.2f}")

            st.divider()
            st.markdown("**📝 Tasks**")
            pending_tasks = database.get_tasks(status="pending")
            st.metric("Pending", len(pending_tasks))

            st.divider()
            st.markdown("**🖥️ System**")
            st.code(probe.get_system_context())

        # --- 🛰️ MISSION CONTROL ---
        with st.expander("🛰️ Mission Control"):
            st.info("Sentinel Status: ACTIVE")
            if st.button("🔄 Index Vault (New)"):
                files = vault.scan_vault()
                st.success(f"Indexed {len(files)} docs.")

        # --- 🔄 UNIFY / BRIDGE ---
        with st.expander("🔄 Unify / Bridge"):
            st.info("Use the 'Synapse' module to sync with external AIs.")
            st.markdown("### 📥 Import Memories")
            uploaded_file = st.file_uploader(
                "Choose a file", type=["txt", "pdf", "json"]
            )
            if uploaded_file and st.button("Start Ingestion"):
                # Simplified ingestion for brevity (assuming text)
                st.success("Ingestion mechanism placeholder.")

            st.divider()
            st.markdown("### 📤 Export for AI Studio")
            if st.checkbox("Generate Context File"):
                current_history = database.get_history(limit=50)
                context_txt = modules.studio_exporter.prepare_studio_context(
                    current_history
                )
                st.download_button("💾 Download .txt", context_txt, f"aegis_ctx.txt")

        # --- 📡 ACTIVE DAEMONS ---
        with st.expander("📡 Active Daemons"):
            col1, col2 = st.columns(2)
            with col1:
                if st.button("Start MemoryGuard"):
                    res = daemon_manager.register_daemon(
                        "MemoryGuard",
                        "resource_watcher",
                        {"min_ram_mb": 500},
                        interval=60,
                    )
                    st.toast(res)

            active_daemons = daemon_manager.list_daemons()
            if not active_daemons:
                st.info("No active daemons.")

            for d in active_daemons:
                status_icon = "🟢" if d["status"] == "RUNNING" else "🔴"
                st.markdown(f"**{d['name']}** {status_icon}")
                if d["status"] == "RUNNING":
                    if st.button(f"Stop {d['name']}", key=f"stop_{d['id']}"):
                        daemon_manager.stop_daemon(d["name"])
                        st.rerun()

        # --- 🛡️ AUDIT LOG ---
        with st.expander("🛡️ Audit Log"):
            if st.button("🗑️ Limpiar Logs"):
                conn = database.get_connection()
                conn.execute("DELETE FROM audit_log")
                conn.commit()
                conn.close()
                st.rerun()

            logs = database.get_audit_logs(limit=20)
            if logs:
                for log in logs:
                    st.caption(f"{log[0]} | {log[3]} | {log[2]}")

        # --- 🎨 INSTALLED SKILLS ---
        with st.expander("🎨 Installed Skills"):
            modules = brain_instance.module_manager.modules
            st.write(", ".join(modules))

        # --- ⚙️ SETTINGS ---
        # Call the imported settings manager
        # We pass brain_instance as required
        try:
            # Inject the daemon_manager into session state for settings to use if needed
            st.session_state.daemon_manager = daemon_manager
            render_settings_tabs(brain_instance)
        except Exception as e:
            st.error(f"Settings Error: {e}")

        st.divider()

        # --- VISION / ZEN MODE ---
        hands_free_mode = st.toggle("🎙️ Modo Manos Libres (Siren)")
        zen_mode = st.toggle("🧘 Zen Mode", value=False)

        if zen_mode:
            st.markdown(
                """
            <style>
                .sys-log { display: none !important; }
                [data-testid="stMetricValue"] { font-size: 1rem !important; }
                .stChatMessage { 
                    background: rgba(0,0,0,0.5) !important; 
                    border: none !important; 
                    box-shadow: none !important;
                    border-left: 2px solid #333 !important;
                }
            </style>
            """,
                unsafe_allow_html=True,
            )

        with st.expander("📜 Codex Library"):
            snippets = database.get_all_codex_snippets()
            if snippets:
                for snip in snippets:
                    st.markdown(f"**{snip['title']}**")
                    with st.expander("View Code"):
                        st.code(snip["code"], language=snip["language"])

    return hands_free_mode, zen_mode
