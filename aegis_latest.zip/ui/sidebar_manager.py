import streamlit as st
import database
import json
import os
import datetime

# Module Imports
from modules.resource_monitor import monitor
import modules.ide_bridge
from modules.beacon import beacon
from modules.env_probe import probe
from modules.vault_manager import vault
import modules.studio_exporter

# Local Imports
from .settings_manager import render_settings_tabs


def render_daily_snapshot():
    """
    Renders the 'Executive Glance' Daily Snapshot.
    """
    # Check for global sync status
    online_nodes = [n for n in database.get_all_nodes() if n["status"] == "online"]
    global_tag = " 🌐 Global" if online_nodes else ""

    st.markdown(f"### 📅 Resumen de Guardia{global_tag}")

    # Financial
    daily_spent = database.get_daily_spend()

    # Next Task
    next_task_obj = database.get_next_task()
    next_task_str = (
        f"🕒 {next_task_obj['time']} - {next_task_obj['task']}"
        if next_task_obj
        else "Agenda Libre"
    )

    # Active Project
    active_proj = database.get_latest_project()
    proj_str = active_proj or "Ninguno"

    col1, col2 = st.columns(2)
    with col1:
        st.metric("Hoy (Gastos)", f"${daily_spent:,.2f}")
    with col2:
        st.metric("Proyecto", proj_str)

    st.caption(f"**Próximo:** {next_task_str}")

    # --- PROTOCOLO CHRONOS: PENDIENTES DE LARGA DURACIÓN ---
    st.markdown("---")
    st.markdown("🕒 **Pendientes de Larga Duración**")
    try:
        # Buscamos en el Vault conceptos de objetivos antiguos o "algún día"
        long_term = vault.search_semantic(
            "objetivos, metas y proyectos pendientes a largo plazo",
            collection="vault",
            top_k=2,
        )
        if long_term:
            for item in long_term:
                clean_text = (
                    item["snippet"].replace("[Match:", "").split("]")[-1].strip()
                )
                if len(clean_text) > 80:
                    clean_text = clean_text[:77] + "..."
                st.caption(f"• {clean_text}")
        else:
            st.caption("No se detectan metas antiguas.")
    except Exception:
        st.caption("Protocolo Chronos: Standby")

    st.divider()


def render_sidebar(brain_instance, daemon_manager):
    """
    Renders the complete Sidebar interface.
    Args:
        brain_instance: The initialized AegisBrain.
        daemon_manager: The active DaemonManager instance.
    """
    with st.sidebar:
        ai_name = database.get_setting("ai_name") or "Aegis-IA"
        st.title(f"🛡️ {ai_name}")
        st.caption("The Singularity Edition")

        # --- SEMANTIC ENGINE STATUS ---
        from core_engine.router import IntentEngine

        if not IntentEngine.ensure_semantic_engine(brain_instance.ollama_host):
            with st.status("🛰️ Calibrando Sensores Semánticos", expanded=False):
                st.write("Descargando motor de alta precisión...")
                st.caption("Aegis usará lógica de texto mientras calibra.")

        # --- EXECUTIVE GLANCE ---
        render_daily_snapshot()

        # --- PROJECT NEXUS INDICATOR ---
        active_projects = database.get_active_projects()
        if active_projects:
            st.success(f"🟢 NEXUS ACTIVE: {', '.join(active_projects)}")

        # --- SYSTEM HEALTH ---
        health_status = monitor.check_health()
        color = (
            "green"
            if health_status == "GREEN"
            else "orange"
            if health_status == "YELLOW"
            else "red"
        )
        metrics = monitor.get_metrics()
        st.markdown(
            f"**STATUS:** :{color}[●] {health_status} | **RAM:** {metrics.get('app_ram_usage_mb', 0)}MB"
        )

        st.divider()

        # --- FORGE UPLINK STATUS ---
        forge_conf = modules.ide_bridge.get_config_path()
        if forge_conf and os.path.exists(forge_conf):
            st.markdown("🛠️ **Forge Uplink:** :green[ACTIVE]")
        else:
            st.markdown("🛠️ **Forge Uplink:** :red[OFFLINE]")

        # --- 📁 MY PROJECTS ---
        with st.expander("📁 Mis Proyectos", expanded=True):
            my_projects = database.get_active_projects()
            if my_projects:
                for proj in my_projects:
                    st.markdown(f"**{proj}**")
                    col_p1, col_p2 = st.columns(2)
                    with col_p1:
                        if st.button("🚀 Run", key=f"run_{proj}"):
                            st.session_state["last_project_launch"] = proj
                            st.rerun()
                    with col_p2:
                        # Placeholder for edit/open in IDE
                        st.caption("Active")
                    st.divider()
            else:
                st.info("No projects found.")

        # --- 🛠️ THE FORGE (IDE) ---
        with st.expander("🛠️ The Forge (IDE)", expanded=False):
            if st.button(
                "🚀 Launch & Sync",
                use_container_width=True,
                help="Sync AI Config & Open IDE (Port 8080)",
            ):
                with st.spinner("Syncing Neural Pathways..."):
                    try:
                        res = modules.ide_bridge.sync_ai_config()
                        if res.get("status") == "success":
                            st.toast(f"Synced: {res['model']}")
                        else:
                            st.warning(f"Sync: {res.get('message')}")
                    except Exception:
                        st.warning("Sync failed (Check connection)")

                    # Auto-Start (Linux Only)
                    # Open via JS - Pointing to Aegis Core Root (Sovereignty Protocol)
                    aegis_root = os.getcwd().replace("\\", "/")
                    st.markdown(
                        f"""
                     <script>
                        const protocol = window.location.protocol;
                        const host = window.location.hostname;
                        const target = protocol + "//" + host + ":8080/?folder={aegis_root}";
                        window.open(target, '_blank').focus();
                     </script>
                     """,
                        unsafe_allow_html=True,
                    )
                    st.info("Opening Forge...")
            st.caption("⚠️ Ensure port **8080** is open")

        # --- 🌐 NETWORK MESH ---
        with st.expander("🌐 Network Mesh", expanded=True):
            nodes = database.get_all_nodes()
            if nodes:
                for node in nodes:
                    last_seen_str = node.get("last_seen", "")
                    status = node.get("status", "offline")
                    latency_disp = "N/A"
                    status_color = "🔴"
                    swarming = False

                    if status == "online":
                        status_color = "🟢"
                        if node.get("contribution_mode"):
                            status_color = "⚡"
                            swarming = True
                        try:
                            dt = datetime.datetime.fromisoformat(last_seen_str)
                            diff = (datetime.datetime.now() - dt).total_seconds()
                            if diff < 60:
                                latency_disp = f"{int(diff * 1000) % 50 + 10}ms"
                        except Exception:
                            pass
                    else:
                        status_color = "⚫"

                    c1, c2 = st.columns([3, 1])
                    with c1:
                        st.markdown(f"**{node['node_id']}**")
                        caption_text = (
                            f"{status_color} {latency_disp} | {node.get('last_ip')}"
                        )
                        if swarming:
                            caption_text += " | **Swarm Ready**"
                        st.caption(caption_text)

                    with c2:
                        if st.button("⚙️", key=f"conf_{node['node_id']}"):
                            st.toast(f"Configuring {node['node_id']}...")
                    st.divider()
            else:
                st.info("No nodes linked. Start a Limb.")

            # Pairing
            st.subheader("🔗 Device Pairing")
            if st.button("Generate Pairing Code"):
                import random
                import string

                code = "".join(
                    random.choices(string.ascii_uppercase + string.digits, k=6)
                )
                database.create_pairing_code(code)

                # QR Logic simplified
                config_payload = json.dumps(
                    {"gateway": "ws://REPLACE_WITH_IP:8000/ws", "code": code}
                )
                local_url = beacon.get_local_ip(port=8000)
                final_payload = config_payload.replace(
                    "REPLACE_WITH_IP", local_url.replace("http://", "")
                )
                qr_img = beacon.generate_qr(final_payload)

                st.session_state.pairing_code = code
                st.session_state.pairing_qr = qr_img

            if "pairing_code" in st.session_state:
                c1, c2 = st.columns([1, 1])
                with c1:
                    st.metric("Pairing Code", st.session_state.pairing_code)
                with c2:
                    st.image(st.session_state.pairing_qr, width=150)

        # --- 📊 STATS & DATA ---
        with st.expander("📊 Stats & Data"):
            st.subheader("Nexus Dashboard")
            st.markdown("**💰 Finance Stream**")
            expenses = database.get_expenses(limit=50)
            total_monthly = sum(e[1] for e in expenses) if expenses else 0
            st.metric("Total Stream", f"${total_monthly:,.2f}")

            st.divider()
            st.markdown("**📝 Tasks**")
            pending_tasks = database.get_tasks(status="pending")
            st.metric("Pending", len(pending_tasks))

            st.divider()
            st.markdown("**🖥️ System**")
            st.code(probe.get_system_context())

        # --- 🛰️ MISSION CONTROL ---
        with st.expander("🛰️ Mission Control"):
            st.info("Sentinel Status: ACTIVE")
            if st.button("🔄 Index Vault (New)"):
                files = vault.scan_vault()
                st.success(f"Indexed {len(files)} docs.")

        # --- 🔄 UNIFY / BRIDGE ---
        with st.expander("🔄 Unify / Bridge"):
            st.info("Use the 'Synapse' module to sync with external AIs.")
            st.markdown("### 📥 Import Memories")
            uploaded_file = st.file_uploader(
                "Choose a file", type=["txt", "pdf", "json"]
            )
            if uploaded_file and st.button("Start Ingestion"):
                # Simplified ingestion for brevity (assuming text)
                st.success("Ingestion mechanism placeholder.")

            st.divider()
            st.markdown("### 📤 Export for AI Studio")
            if st.checkbox("Generate Context File"):
                current_history = database.get_history(limit=50)
                context_txt = modules.studio_exporter.prepare_studio_context(
                    current_history
                )
                st.download_button("💾 Download .txt", context_txt, "aegis_ctx.txt")

        # --- 📡 ACTIVE DAEMONS ---
        with st.expander("📡 Active Daemons"):
            col1, col2 = st.columns(2)
            with col1:
                if st.button("Start MemoryGuard"):
                    res = daemon_manager.register_daemon(
                        "MemoryGuard",
                        "resource_watcher",
                        {"min_ram_mb": 500},
                        interval=60,
                    )
                    st.toast(res)

            active_daemons = daemon_manager.list_daemons()
            if not active_daemons:
                st.info("No active daemons.")

            for d in active_daemons:
                status_icon = "🟢" if d["status"] == "RUNNING" else "🔴"
                st.markdown(f"**{d['name']}** {status_icon}")
                if d["status"] == "RUNNING":
                    if st.button(f"Stop {d['name']}", key=f"stop_{d['id']}"):
                        daemon_manager.stop_daemon(d["name"])
                        st.rerun()

        # --- 🛡️ AUDIT LOG ---
        with st.expander("🛡️ Audit Log"):
            if st.button("🗑️ Limpiar Logs"):
                conn = database.get_connection()
                conn.execute("DELETE FROM audit_log")
                conn.commit()
                conn.close()
                st.rerun()

            logs = database.get_audit_logs(limit=20)
            if logs:
                for log in logs:
                    st.caption(f"{log[0]} | {log[3]} | {log[2]}")

        # --- 🎨 INSTALLED SKILLS ---
        with st.expander("🎨 Installed Skills"):
            installed_modules = brain_instance.module_manager.modules
            st.write(", ".join(installed_modules))

        # --- ⚙️ SETTINGS ---
        # Call the imported settings manager
        # We pass brain_instance as required
        try:
            # Inject the daemon_manager into session state for settings to use if needed
            st.session_state.daemon_manager = daemon_manager
            render_settings_tabs(brain_instance)
        except Exception as e:
            st.error(f"Settings Error: {e}")

        st.divider()

        # --- VISION / ZEN MODE ---
        hands_free_mode = st.toggle("🎙️ Modo Manos Libres (Siren)")
        zen_mode = st.toggle("🧘 Zen Mode", value=False)

        if zen_mode:
            st.markdown(
                """
            <style>
                .sys-log { display: none !important; }
                [data-testid="stMetricValue"] { font-size: 1rem !important; }
                .stChatMessage { 
                    background: rgba(0,0,0,0.5) !important; 
                    border: none !important; 
                    box-shadow: none !important;
                    border-left: 2px solid #333 !important;
                }
            </style>
            """,
                unsafe_allow_html=True,
            )

        with st.expander("📜 Codex Library"):
            snippets = database.get_all_codex_snippets()
            if snippets:
                for snip in snippets:
                    st.markdown(f"**{snip['title']}**")
                    with st.expander("View Code"):
                        st.code(snip["code"], language=snip["language"])

    return hands_free_mode, zen_mode
