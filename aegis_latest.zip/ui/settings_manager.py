import streamlit as st
import database
import requests
import time
import os
from modules.auth_vault import auth
import modules.updater as updater
import modules.galactic_store as store
import modules.resource_monitor as resource_monitor
import core_engine.llm_drivers as llm_drivers


# ---------------------------------------------------------------------------
# MOTOR DE RECOMENDACIÓN PROACTIVA
# ---------------------------------------------------------------------------
def get_optimal_model_recommendation(
    local_models: list, tier: int, tier_name: str
) -> dict | None:
    """
    Cruza el hardware Tier detectado con los modelos disponibles en Ollama y devuelve
    la mejor recomendación de instalación.  Retorna None si no hay acción necesaria.

    Returns:
        dict with keys: 'model' (str), 'reason' (str), 'ram_gb' (int)
        or None if no recommendation.
    """
    from core_engine.router import TIER_CONFIGS

    try:
        metrics = resource_monitor.monitor.get_metrics()
        ram_gb = int(metrics.get("ram_total_gb", 8))
    except Exception:
        ram_gb = 8

    tier_config = TIER_CONFIGS.get(tier, TIER_CONFIGS[2])

    # Modelos ideales para el tier, en orden de prioridad (logic > coder > chat)
    priority_roles = ["logic", "coder", "chat", "heavy"]
    target_models = [tier_config.get(r) for r in priority_roles if tier_config.get(r)]

    # ¿Cuál de ellos NO está instalado aún?
    missing = [
        m
        for m in target_models
        if m not in local_models and f"{m}:latest" not in local_models
    ]

    if not missing:
        return None  # Todo instalado, sin recomendación

    best = missing[0]  # El de mayor prioridad
    return {
        "model": best,
        "ram_gb": ram_gb,
        "reason": (
            f"Basado en tus {ram_gb}GB de RAM ({tier_name}), "
            f"te recomendamos activar el modelo **{best}** para mejor razonamiento."
        ),
    }


def render_settings_tabs(brain_instance):
    """
    Renders the Settings expander with tabs for AI Brain, API Vault, System Ops, and Galactic Store.
    Args:
        brain_instance: The initialized AegisBrain instance (needed for installing skills).
    """
    with st.expander("⚙️ Settings"):
        tab_ai, tab_keys, tab_sys, tab_store = st.tabs(
            ["🧠 AI Brain", "🔐 API Vault", "🔄 System", "🛒 Store"]
        )

        with tab_ai:
            st.caption("Architecture Configuration")

            # --- 0. OPERATION MODE SELECTOR ---
            current_mode = database.get_setting("operation_mode") or "Hybrid (Smart)"

            # Legacy Mapping
            mapping = {
                "Local (Ollama)": "Local Only (Sovereign)",
                "Cloud (Gemini/OpenAI)": "Cloud Only",
                "Hybrid": "Hybrid (Smart)",
            }
            if current_mode in mapping:
                current_mode = mapping[current_mode]
                database.set_setting("operation_mode", current_mode)

            valid_modes = ["Cloud Only", "Local Only (Sovereign)", "Hybrid (Smart)"]
            if current_mode not in valid_modes:
                current_mode = "Hybrid (Smart)"

            op_mode = st.radio(
                "Source of Intelligence",
                valid_modes,
                index=valid_modes.index(current_mode),
                horizontal=True,
            )

            if op_mode != current_mode:
                database.set_setting("operation_mode", op_mode)
                st.rerun()

            st.divider()

            # --- 1. OLLAMA CONFIGURATION (Local & Hybrid) ---
            local_models = []
            if op_mode in ["Local Only (Sovereign)", "Hybrid (Smart)"]:
                st.markdown("**🤖 Local Brain (Ollama)**")
                current_ollama_url = (
                    database.get_setting("ollama_url") or "http://127.0.0.1:11434"
                )

                c_url, c_test = st.columns([3, 1])
                with c_url:
                    ollama_url = st.text_input(
                        "Connection URL",
                        value=current_ollama_url,
                        label_visibility="collapsed",
                    )
                with c_test:
                    if st.button("Test Link"):
                        try:
                            tags_url = (
                                f"{ollama_url}/api/tags"
                                if not ollama_url.endswith("/")
                                else f"{ollama_url}api/tags"
                            )
                            resp = requests.get(tags_url, timeout=3)
                            if resp.status_code == 200:
                                st.success("Online!")
                            else:
                                st.error(f"Error: {resp.status_code}")
                        except Exception as e:
                            st.error(f"Unreachable: {e}")

                if ollama_url != current_ollama_url:
                    database.set_setting("ollama_url", ollama_url.strip())
                    st.rerun()

                # Fetch Local Models
                try:
                    tags_url = (
                        f"{ollama_url}/api/tags"
                        if not ollama_url.endswith("/")
                        else f"{ollama_url}api/tags"
                    )
                    tags_resp = requests.get(tags_url, timeout=2)
                    if tags_resp.status_code == 200:
                        data = tags_resp.json()
                        local_models = [m["name"] for m in data.get("models", [])]
                except Exception:
                    if op_mode == "Local Only (Sovereign)":
                        st.error(f"⚠️ Sovereignty Lost: Cannot connect to {ollama_url}")
                    else:
                        st.warning(f"Ollama disconnected at {ollama_url}")

                st.divider()

            # --- 2. ACTIVE MODEL SELECTOR ---
            tier, tier_name, model_range, _ = (
                resource_monitor.monitor.get_hardware_tier()
            )
            st.info(f"💾 Hardware Detectado: **{tier_name}** (Sugerido: {model_range})")

            # Determine Recommended Models from Master Map
            from core_engine.router import TIER_CONFIGS

            tier_config = TIER_CONFIGS.get(tier, TIER_CONFIGS[2])

            # Extract recommended model names (base)
            rec_models = [
                v
                for k, v in tier_config.items()
                if k not in ["ctx", "keep_alive", "name"]
            ]

            # --- Cloud Discovery Protocol ---
            if "discovered_cloud_models" not in st.session_state:
                st.session_state.discovered_cloud_models = []

            # Auto-discovery if empty
            if not st.session_state.discovered_cloud_models:
                p_key = auth.get_api_key(st.session_state.get("master_password"))
                if p_key:
                    with st.spinner("Buscando motores disponibles..."):
                        gemini_list = llm_drivers.get_available_gemini_models(p_key)
                        if gemini_list:
                            st.session_state.discovered_cloud_models = gemini_list

            # Base Standard Cloud Models
            base_cloud = [
                "gpt-4o",
                "gpt-4o-mini",
                "o1-preview",
                "claude-3-5-sonnet-latest",
                "claude-3-5-haiku-latest",
                "groq-llama-3.3-70b-versatile",
                "groq-deepseek-r1-distill-llama-70b",
                "google/gemini-2.0-flash-exp:free",
                "✍️ Custom Model Name...",
            ]

            # Essential Frontier Models (Always check these)
            essential_models = [
                "gemini-3.1-flash",
                "gemini-3.1-pro",
                "gemini-3.0-flash-preview",
                "gemini-3.0-pro-preview",
                "gemini-2.5-flash",
                "gemini-2.5-pro",
                "gemini-2.0-flash",
                "gemini-1.5-flash-latest",
            ]

            # Final List Construction
            all_discovered = st.session_state.discovered_cloud_models

            # Combine Discoveries with Essentials and Base (Unique set)
            # Prioritize discovered items if any
            cloud_models = list(
                dict.fromkeys(all_discovered + essential_models + base_cloud)
            )

            # Refresh Button
            if st.button("🔄 Refrescar Motores en Nube"):
                p_key = auth.get_api_key(st.session_state.get("master_password"))
                if p_key:
                    st.session_state.discovered_cloud_models = (
                        llm_drivers.get_available_gemini_models(p_key)
                    )
                    st.rerun()

            st.info(
                "💡 **Protocolo de Economía:** Recomendamos usar modelos **Flash** para el uso diario (Plan Gratuito). "
                "Aegis detectará automáticamente tareas complejas (como programar) y realizará un **Force Upgrade** "
                "a versiones Pro solo cuando sea necesario para garantizar precisión."
            )

            # Determine Available Options based on Mode
            raw_options = []
            if op_mode == "Cloud Only":
                raw_options = cloud_models
            elif op_mode == "Local Only (Sovereign)":
                raw_options = (
                    local_models if local_models else ["No Local Models Found"]
                )
            else:  # Hybrid
                raw_options = local_models + cloud_models

            # Apply Recommendation Tags
            model_options = []
            for m in raw_options:
                # Si el modelo está en el Tier actual, es recomendado
                is_rec = any(rm in m.lower() for rm in rec_models)
                model_options.append(f"{m} ⭐ Recomendado" if is_rec else m)

            current_model = (
                database.get_setting("active_model") or "gemini-3.1-flash"
            ).strip()

            # Find current in mapped options
            current_display = current_model
            for opt in model_options:
                if opt.startswith(current_model):
                    current_display = opt
                    break

            if model_options:
                selected_display = st.selectbox(
                    "Active Model (Base)",
                    model_options,
                    index=model_options.index(current_display)
                    if current_display in model_options
                    else 0,
                    help="Select the default brain for general conversation and lightweight tasks.",
                )

                if "✍️ Custom" in selected_display:
                    selected_model = st.text_input(
                        "Custom Model ID",
                        value=current_model if current_model not in raw_options else "",
                        placeholder="e.g. gpt-4-turbo-preview",
                    ).strip()
                else:
                    selected_model = selected_display.split(" ⭐")[0]
                if selected_model != current_model:
                    database.set_setting("active_model", selected_model)

                    # --- NOTIFICACIÓN DE OPTIMIZACIÓN ---
                    user_name = (
                        database.get_user_fact("user_name", "identity") or "Usuario"
                    )
                    tier, tier_name, _, auto_num_ctx = (
                        resource_monitor.monitor.get_hardware_tier()
                    )
                    metrics = resource_monitor.monitor.get_metrics()
                    ram_total = int(metrics["ram_total_gb"])
                    ctx_kb = auto_num_ctx // 1024

                    st.session_state["optimization_notify"] = (
                        f"{user_name}, he detectado que tienes {ram_total}GB de RAM. "
                        f"He optimizado el motor {selected_model} con una ventana de {ctx_kb}k "
                        f"para que tengamos una memoria de trabajo más amplia."
                    )
                    st.rerun()
            else:
                st.error("No models available in this mode.")

            # --- MOTOR DE RECOMENDACIÓN PROACTIVA ---
            user_name = database.get_user_fact("user_name", "identity") or "Usuario"

            recommendation = get_optimal_model_recommendation(
                local_models, tier, tier_name
            )

            if recommendation is None:
                st.success("✅ Motores de Élite Listos para tu hardware")
            else:
                rec_model = recommendation["model"]
                ram_gb = recommendation["ram_gb"]

                # Aviso de Optimización Disponible
                st.info(
                    f"⚡ **Optimización disponible:** "
                    f"Basado en tus {ram_gb}GB de RAM ({tier_name}), "
                    f"te recomendamos activar el modelo **{rec_model}** "
                    f"para mejor razonamiento."
                )

                if st.button(
                    f"✨ Instalar Recomendado: {rec_model}",
                    type="primary",
                    use_container_width=True,
                    key="install_recommended_btn",
                ):
                    st.info(f"Descargando {rec_model} en segundo plano...")
                    try:
                        _ollama_url = locals().get(
                            "ollama_url",
                            database.get_setting("ollama_url")
                            or "http://127.0.0.1:11434",
                        )
                        requests.post(
                            f"{_ollama_url}/api/pull",
                            json={"name": rec_model},
                            timeout=1,
                        )
                        st.toast(
                            f"✅ Instalación de {rec_model} iniciada. Refresca en unos minutos."
                        )
                    except Exception as e:
                        st.error(f"Error al iniciar descarga: {e}")
                    st.rerun()

            st.divider()

            # --- 3. VISION PERCEPTION (El Ojo) ---
            st.markdown("### 👁️ Percepción Visual (El Ojo)")
            vision_models = [
                m
                for m in local_models
                if any(
                    v in m.lower()
                    for v in ["moondream", "llava", "vision", "internvl", "minicpm"]
                )
            ]
            if not vision_models:
                vision_models = local_models if local_models else ["moondream"]

            # Rec-tagged local models for vision
            tagged_vision = []
            for m in vision_models:
                is_rec = any(
                    rm in m.lower()
                    for rm in rec_models
                    if "moondream" in rm or "llava" in rm
                )
                tagged_vision.append(f"{m} ⭐ Recomendado" if is_rec else m)

            def_vision = database.get_setting("local_vision_model") or "moondream"

            def get_v_display(model_name):
                for opt in tagged_vision:
                    if opt.startswith(model_name):
                        return opt
                return model_name

            current_v_display = get_v_display(def_vision)
            if current_v_display not in tagged_vision:
                tagged_vision.append(current_v_display)

            selected_vision_display = st.selectbox(
                "Modelo de Visión Local",
                tagged_vision,
                index=tagged_vision.index(current_v_display)
                if current_v_display in tagged_vision
                else 0,
                help="Selecciona el motor que Aegis usará para analizar oficialmente tus capturas y fotos.",
            )
            selected_vision = selected_vision_display.split(" ⭐")[0]

            if selected_vision != def_vision:
                database.set_setting("local_vision_model", selected_vision)
                st.toast(f"Ojo calibrado con {selected_vision}")
                st.rerun()

            st.divider()

            # --- 4. HUGGING FACE AUTH ---
            st.markdown("### 🤗 Hugging Face Token")
            curr_hf = database.get_setting("hf_token") or ""
            new_hf = st.text_input(
                "HF_TOKEN (Optional - For Gated Models)",
                value=curr_hf,
                type="password",
                help="Needed to download restricted models without warnings.",
            )
            if new_hf != curr_hf:
                database.set_setting("hf_token", new_hf)
                st.toast("HF Token Updated. Restart required.")

            st.divider()

            # --- 3. SMART MODE (Hybrid Only) ---
            if op_mode == "Hybrid (Smart)":
                st.divider()
                current_smart = database.get_setting("smart_mode") == "true"
                smart_mode = st.toggle(
                    "🧠 Enable Smart Mode (AI Tiering)", value=current_smart
                )
                if smart_mode != current_smart:
                    database.set_setting(
                        "smart_mode", "true" if smart_mode else "false"
                    )
                    st.rerun()

            st.divider()

            # --- 4. MATRIZ DE ESPECIALISTAS (Model Assignment Protocol) ---
            if op_mode in ["Local Only (Sovereign)", "Hybrid (Smart)"] and local_models:
                st.markdown("**🦾 Matriz de Especialistas (Protocolo Aegis)**")

                col_spec1, col_spec2 = st.columns(2)

                # Fetch configs with updated defaults from Master Map
                def_chat = (
                    database.get_setting("local_chat_model") or tier_config["chat"]
                )
                def_logic = (
                    database.get_setting("local_logic_model") or tier_config["logic"]
                )
                def_coder = (
                    database.get_setting("local_coder_model") or tier_config["coder"]
                )
                def_heavy = (
                    database.get_setting("local_heavy_model") or tier_config["heavy"]
                )
                def_vision = (
                    database.get_setting("local_vision_model") or tier_config["vision"]
                )

                # Rec-tagged local models for specialists
                tagged_locals = []
                for m in local_models:
                    is_rec = any(rm in m.lower() for rm in rec_models)
                    tagged_locals.append(f"{m} ⭐ Recomendado" if is_rec else m)

                # Add missing defaults if not in tagged_locals to avoid crashes
                for d in [def_chat, def_logic, def_coder, def_heavy, def_vision]:
                    if d not in local_models and f"{d}:latest" not in local_models:
                        # If not installed, we still show but warn
                        if d not in tagged_locals:
                            tagged_locals.append(f"{d} (Not Found)")

                with col_spec1:

                    def get_display(model_name):
                        for opt in tagged_locals:
                            if opt.startswith(model_name):
                                return opt
                        return model_name

                    s_chat_display = st.selectbox(
                        "💬 CHAT (Bridge)",
                        tagged_locals,
                        index=tagged_locals.index(get_display(def_chat))
                        if get_display(def_chat) in tagged_locals
                        else 0,
                        help="Interfaz conversacional y protocolo de respuesta.",
                    )
                    s_chat = s_chat_display.split(" ⭐")[0].split(" (")[0]
                    if s_chat != def_chat:
                        database.set_setting("local_chat_model", s_chat)
                        resource_monitor.flush_ollama_cache()
                        st.rerun()

                    s_coder_display = st.selectbox(
                        "💻 CODER (Forge)",
                        tagged_locals,
                        index=tagged_locals.index(get_display(def_coder))
                        if get_display(def_coder) in tagged_locals
                        else 0,
                        help="Especialista en desarrollo. SRE NOTE: Se requiere 7B+ para evitar alucinaciones.",
                    )
                    s_coder = s_coder_display.split(" ⭐")[0].split(" (")[0]
                    # Forced 7B+ for Coder role (SRE Level Fix)
                    if any(
                        small in s_coder.lower() for small in [":1b", ":1.5b", ":3b"]
                    ):
                        st.warning(
                            "⚠️ El modelo seleccionado es < 7B. Aegis forzará 7B+ para tareas de Misión."
                        )

                    if s_coder != def_coder:
                        database.set_setting("local_coder_model", s_coder)
                        resource_monitor.flush_ollama_cache()
                        st.rerun()

                with col_spec2:
                    s_logic_display = st.selectbox(
                        "🧠 LOGIC (Reasoning)",
                        tagged_locals,
                        index=tagged_locals.index(get_display(def_logic))
                        if get_display(def_logic) in tagged_locals
                        else 0,
                        help="Razonamiento lógico. SRE NOTE: Se requiere 7B+ para Misión.",
                    )
                    s_logic = s_logic_display.split(" ⭐")[0].split(" (")[0]
                    if s_logic != def_logic:
                        database.set_setting("local_logic_model", s_logic)
                        resource_monitor.flush_ollama_cache()
                        st.rerun()

                    s_heavy_display = st.selectbox(
                        "📚 HEAVY (Oracle)",
                        tagged_locals,
                        index=tagged_locals.index(get_display(def_heavy))
                        if get_display(def_heavy) in tagged_locals
                        else 0,
                        help="Procesamiento masivo de documentos y contexto largo.",
                    )
                    s_heavy = s_heavy_display.split(" ⭐")[0].split(" (")[0]
                    if s_heavy != def_heavy:
                        database.set_setting("local_heavy_model", s_heavy)
                        resource_monitor.flush_ollama_cache()
                        st.rerun()

                    # Embedding Specialist
                    embed_models = [m for m in local_models if "embed" in m.lower()]
                    if not embed_models:
                        embed_models = ["mxbai-embed-large"] + local_models

                    def_embed = (
                        database.get_setting("router_embedding_model")
                        or "mxbai-embed-large"
                    )

                    s_embed = st.selectbox(
                        "🔗 EMBEDDING (Neural)",
                        embed_models,
                        index=embed_models.index(def_embed)
                        if def_embed in embed_models
                        else 0,
                        help="Motor de vectores para clasificación semántica.",
                    )
                    if s_embed != def_embed:
                        database.set_setting("router_embedding_model", s_embed)
                        resource_monitor.flush_ollama_cache()
                        st.rerun()

                st.divider()
                st.markdown("**🔊 Voice Interface**")
            # Voice Interface Toggle
            if "voice_response_enabled" not in st.session_state:
                st.session_state.voice_response_enabled = False

            st.toggle(
                "Enable Voice Response",
                help="Aegis will read responses aloud.",
                key="voice_response_enabled",
            )

        with tab_keys:
            st.markdown("### 🛡️ Secure Key Vault")
            st.caption(
                "Keys are encrypted with your Master Password. Supports multi-provider fallback."
            )

            if "enc_key" not in st.session_state:
                st.error(
                    "⚠️ Encryption Session Key missing. Please Log Out and Re-Login."
                )
            else:
                # Add New Key
                with st.form("add_key_form"):
                    c1, c2, c3 = st.columns([2, 3, 1])
                    with c1:
                        new_prov = st.selectbox(
                            "Provider",
                            [
                                "gemini",
                                "groq",
                                "openai",
                                "anthropic",
                                "openrouter",
                                "cerebras",
                                "together",
                            ],
                        )
                    with c2:
                        new_key = st.text_input(
                            "New API Key", type="password", help="Paste sk-..."
                        )
                    with c3:
                        new_prio = st.number_input(
                            "Priority",
                            min_value=0,
                            max_value=100,
                            value=10,
                            help="Higher = Used first",
                        )

                    if st.form_submit_button("➕ Encrypt & Store"):
                        if new_key:
                            try:
                                # Encrypt
                                enc_str = auth.encrypt_content(
                                    new_key, st.session_state.enc_key
                                )
                                database.add_api_key(new_prov, enc_str, new_prio)
                                st.success(f"Securely stored {new_prov} key.")
                                time.sleep(1)
                                st.rerun()
                            except Exception as e:
                                st.error(f"Encryption Failed: {e}")

                st.divider()
                st.markdown("**Manejador de Llaves Activadas**")
                keys = database.get_api_keys()
                if keys:
                    for k in keys:
                        col_prov, col_mask, col_del = st.columns([2, 3, 1])
                        col_prov.markdown(
                            f"**{k['provider'].upper()}** (Pr: {k['priority']})"
                        )
                        # Mask
                        col_mask.code(
                            "••••" + k["api_key"][-6:]
                            if len(k["api_key"]) > 12
                            else "••••••"
                        )
                        if col_del.button("🗑️", key=f"del_key_{k['rowid']}"):
                            database.delete_api_key(k["rowid"])
                            st.rerun()
                else:
                    st.info("Vault is empty. Add keys to enable Providers.")

                st.divider()
                st.markdown("### 🔌 Synapse (External App Secrets)")
                st.caption(
                    "Store tokens for Notion, GitHub, and other APIs accessed via Markdown Skills."
                )

                with st.form("add_external_secret"):
                    ec1, ec2 = st.columns([1, 2])
                    with ec1:
                        new_svc = st.text_input(
                            "Service Variable Name", placeholder="NOTION_API_KEY"
                        )
                    with ec2:
                        new_secret = st.text_input("Secret Token", type="password")

                    if st.form_submit_button("➕ Store External Secret"):
                        if new_svc and new_secret:
                            # To use store_secret we need the master password which might not be in memory explicitly
                            # but we can try to use session_state.master_password if available
                            pwd = st.session_state.get("master_password")
                            if pwd:
                                if auth.store_secret(new_svc, new_secret, pwd):
                                    st.success(f"Secret '{new_svc}' stored securely.")
                                    time.sleep(1)
                                    st.rerun()
                                else:
                                    st.error(
                                        "Failed to store secret. Invalid password or crypto error."
                                    )
                            else:
                                st.warning(
                                    "Session Locked. Require explicit master password re-entry to store secrets."
                                )

                # List keys (redacted)
                ext_secrets = auth.config.get("external_secrets", {})
                if ext_secrets:
                    for svc in ext_secrets.keys():
                        st.markdown(f"**{svc}** `••••••••`")

                st.divider()
                st.markdown("### 🏰 Protocolo Ciudadela (MFA / 2FA)")
                st.caption(
                    "Añade un segundo factor de autenticación (TOTP) al acceso del sistema."
                )

                mfa_enabled = database.get_setting("mfa_enabled") == "true"
                if mfa_enabled:
                    st.success("✅ Citadel MFA is ENABLED.")
                    if st.button("Disable MFA (Risk)"):
                        database.set_setting("mfa_enabled", "false")
                        # Clear secret securely
                        if "mfa_secret" in auth.config:
                            del auth.config["mfa_secret"]
                        if "mfa_recovery_codes" in auth.config:
                            del auth.config["mfa_recovery_codes"]
                        auth._save_config()
                        st.rerun()
                else:
                    pwd = st.session_state.get("master_password")
                    if pwd:
                        if st.button("Enable Citadel MFA"):
                            qr_bytes, recovery_codes = auth.generate_mfa_qr(pwd)
                            if qr_bytes:
                                st.image(
                                    qr_bytes, caption="Scan with Google Auth/Authy"
                                )
                                st.warning(
                                    "⚠️ GUARDA ESTOS CÓDIGOS DE RESCATE. SE MOSTRARÁN UNA SOLA VEZ."
                                )
                                st.code("\n".join(recovery_codes))

                                if st.button("I have scanned the QR & Saved Codes"):
                                    database.set_setting("mfa_enabled", "true")
                                    st.rerun()
                            else:
                                st.error("MFA Generation Failed.")
                    else:
                        st.warning(
                            "Session Locked. Require explicit master password re-entry to configure MFA."
                        )

        with tab_sys:
            st.subheader("System Update Center")
            st.caption("Verifies integrity and pulls latest patches from repository.")

            # Re-fetch manager to ensure we have the instance
            # We don't have get_daemon_manager here.
            # Ideally we pass it in, or we just rely on logic that runs the update.
            # Updater requires manager only for `perform_update(daemon_manager)`.
            # I should import `get_daemon_manager` from `app_web`? No, circular import.
            # I should probably pass daemon_manager as arg or move get_daemon_manager to a shared utility?
            # Or define a local helper since it's a Singleton.
            pass
            # I will assume daemon_manager is passed or obtained via cached resource if I could import it.
            # But simplified: `updater.perform_update` usually needs to stop daemons.
            # Let's import DaemonManager from modules and instantiate/get it.

            from modules.daemon_manager import DaemonManager
            # Since it's a singleton in practice (or uses lock), we can get an instance or handle it.
            # The original app_web.py cached it.
            # I'll just use the class or create a new instance which should attach to existing if shared state,
            # but standard DaemonManager isn't a singleton class by default in Python unless implemented as such.
            # app_web.py uses `@st.cache_resource` for `get_daemon_manager`.
            # I can't easily access the cached resource from another file without passing it.
            # I'll assume we pass `daemon_manager` to this function as well.

            # NOTE: Adding daemon_manager to arguments.

            # Use session state for update status
            if "update_checked" not in st.session_state:
                st.session_state.update_checked = False
                st.session_state.update_available = False
                st.session_state.update_log = ""

            if st.button("🔄 Buscar Actualizaciones"):
                with st.spinner("Contacting remote repo..."):
                    try:
                        has_update, update_log = updater.check_for_updates()
                        st.session_state.update_checked = True
                        st.session_state.update_available = has_update
                        st.session_state.update_log = update_log
                        if not has_update:
                            st.toast("System is up to date.")
                    except Exception as e:
                        st.error(f"Update Check Failed: {e}")

            if st.session_state.update_checked:
                if st.session_state.update_available:
                    st.success("✨ Update Available!")
                    with st.expander("Show Patch Notes", expanded=True):
                        st.code(st.session_state.update_log)

                    st.warning(
                        "⚠️ Warning: Update will stop all services and restart the application."
                    )
                    if st.button("🚀 INSTALAR ACTUALIZACIÓN", type="primary"):
                        st.info("Initiating Update Sequence... Hold on!")
                        time.sleep(1)
                        # We need daemon_manager here.
                        # I'll rely on it being passed in `kwargs` or `daemon_manager` arg.
                        if (
                            "daemon_manager" in st.session_state
                        ):  # Fallback or pass explicit
                            updater.perform_update(st.session_state.daemon_manager)
                        else:
                            # Try to get it
                            dm = DaemonManager()
                            updater.perform_update(dm)
                    else:
                        st.info("System is up to date. No patches found.")

        with tab_store:
            st.subheader("Cloud Skills Registry")
            st.caption("Browse and install new capabilities from the community.")

            # Search UI
            search_q = st.text_input(
                "Search Skills (e.g. 'PDF', 'YouTube')", placeholder="Enter topic..."
            )

            # Defaults
            if not search_q:
                st.info("Top Rated Tools")
                skills = store.search_cloud_skills(None)  # Get recommended
            else:
                with st.spinner("Searching Galaxy..."):
                    skills = store.search_cloud_skills(search_q)

            if not skills:
                st.warning("No skills found. Try another query.")

            # Layout Grid
            # Use columns for cards
            cols = st.columns(3)

            for i, skill in enumerate(skills):
                c = cols[i % 3]
                with c:
                    with st.container(border=True):
                        st.markdown(f"**{skill['name']}**")
                        author = skill.get("author", "Unknown")
                        stars = skill.get("stars", 0)
                        st.caption(f"by {author} | ⭐ {stars}")
                        st.write(skill.get("description", "No description."))

                        if st.button(
                            "📥 Install",
                            key=f"inst_btn_{i}_{skill['name']}",
                            help=skill.get("url"),
                        ):
                            with st.spinner("Auditing & Installing..."):
                                ok, msg = store.install_skill(
                                    skill["url"],
                                    skill["name"],
                                    brain_instance=brain_instance,
                                )
                                if ok:
                                    st.toast(
                                        f"Installed {skill['name']}! Check 'Installed Skills'."
                                    )
                                    time.sleep(1)
                                    st.rerun()
                                else:
                                    st.error(msg)

            st.divider()
            st.subheader("My Skills")
            st.caption("Manage and contribute your custom tools.")

            user_root = os.getenv("AEGIS_USER_ROOT", ".")
            local_skills_dir = os.path.join(user_root, "skills")

            if os.path.exists(local_skills_dir):
                local_files = [
                    f for f in os.listdir(local_skills_dir) if f.endswith(".py")
                ]

                if not local_files:
                    st.info("No local skills found.")
                else:
                    for s_file in local_files:
                        with st.expander(f"🛠️ {s_file}"):
                            # Read content for preview/share
                            try:
                                with open(
                                    os.path.join(local_skills_dir, s_file),
                                    "r",
                                    encoding="utf-8",
                                ) as f:
                                    s_code = f.read()

                                st.code(s_code[:300] + "...", language="python")

                                if st.button(
                                    "🚀 Share to Galaxy", key=f"share_btn_{s_file}"
                                ):
                                    st.session_state[f"sharing_mode_{s_file}"] = True

                                if st.session_state.get(
                                    f"sharing_mode_{s_file}", False
                                ):
                                    with st.form(key=f"share_form_{s_file}"):
                                        st.write(f"Contribute **{s_file}**")
                                        desc_input = st.text_area("Description")
                                        author_input = st.text_input(
                                            "Author Name", value="Anonymous"
                                        )

                                        if st.form_submit_button("Submit PR"):
                                            if desc_input:
                                                # Use Push Protocol (Benchmarking + Naming)
                                                ok, msg = store.push_skill_candidate(
                                                    s_file,
                                                    s_code,
                                                    desc_input,
                                                    author_input,
                                                )
                                                if ok:
                                                    st.balloons()
                                                    st.success(msg)
                                                    st.session_state[
                                                        f"sharing_mode_{s_file}"
                                                    ] = False
                                                    time.sleep(2)
                                                    st.rerun()
                                                else:
                                                    st.error(msg)
                                            else:
                                                st.warning("Description required.")
                            except Exception as e:
                                st.error(f"Error reading file: {e}")
            else:
                st.info("Skills directory not initialized.")
