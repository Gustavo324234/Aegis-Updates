import streamlit as st
import database
import requests
import time
import os
from modules.auth_vault import auth
import modules.updater as updater
import modules.galactic_store as store


def render_settings_tabs(brain_instance):
    """
    Renders the Settings expander with tabs for AI Brain, API Vault, System Ops, and Galactic Store.
    Args:
        brain_instance: The initialized AegisBrain instance (needed for installing skills).
    """
    with st.expander("⚙️ Settings"):
        tab_ai, tab_keys, tab_sys, tab_store = st.tabs(
            ["🧠 AI Brain", "🔐 API Vault", "🔄 System", "🛒 Store"]
        )

        with tab_ai:
            st.caption("Architecture Configuration")

            # --- 0. OPERATION MODE SELECTOR ---
            current_mode = database.get_setting("operation_mode") or "Hybrid (Smart)"

            # Legacy Mapping
            mapping = {
                "Local (Ollama)": "Local Only (Sovereign)",
                "Cloud (Gemini/OpenAI)": "Cloud Only",
                "Hybrid": "Hybrid (Smart)",
            }
            if current_mode in mapping:
                current_mode = mapping[current_mode]
                database.set_setting("operation_mode", current_mode)

            valid_modes = ["Cloud Only", "Local Only (Sovereign)", "Hybrid (Smart)"]
            if current_mode not in valid_modes:
                current_mode = "Hybrid (Smart)"

            op_mode = st.radio(
                "Source of Intelligence",
                valid_modes,
                index=valid_modes.index(current_mode),
                horizontal=True,
            )

            if op_mode != current_mode:
                database.set_setting("operation_mode", op_mode)
                st.rerun()

            st.divider()

            # --- 1. OLLAMA CONFIGURATION (Local & Hybrid) ---
            local_models = []
            if op_mode in ["Local Only (Sovereign)", "Hybrid (Smart)"]:
                st.markdown("**🤖 Local Brain (Ollama)**")
                current_ollama_url = (
                    database.get_setting("ollama_url") or "http://localhost:11434"
                )

                c_url, c_test = st.columns([3, 1])
                with c_url:
                    ollama_url = st.text_input(
                        "Connection URL",
                        value=current_ollama_url,
                        label_visibility="collapsed",
                    )
                with c_test:
                    if st.button("Test Link"):
                        try:
                            tags_url = (
                                f"{ollama_url}/api/tags"
                                if not ollama_url.endswith("/")
                                else f"{ollama_url}api/tags"
                            )
                            resp = requests.get(tags_url, timeout=3)
                            if resp.status_code == 200:
                                st.success("Online!")
                            else:
                                st.error(f"Error: {resp.status_code}")
                        except Exception as e:
                            st.error(f"Unreachable: {e}")

                if ollama_url != current_ollama_url:
                    database.set_setting("ollama_url", ollama_url.strip())
                    st.rerun()

                # Fetch Local Models
                try:
                    tags_url = (
                        f"{ollama_url}/api/tags"
                        if not ollama_url.endswith("/")
                        else f"{ollama_url}api/tags"
                    )
                    tags_resp = requests.get(tags_url, timeout=2)
                    if tags_resp.status_code == 200:
                        data = tags_resp.json()
                        local_models = [m["name"] for m in data.get("models", [])]
                except Exception:
                    if op_mode == "Local Only (Sovereign)":
                        st.error(f"⚠️ Sovereignty Lost: Cannot connect to {ollama_url}")
                    else:
                        st.warning(f"Ollama disconnected at {ollama_url}")

                st.divider()

            # --- 2. ACTIVE MODEL SELECTOR ---

            # Base Cloud Models
            cloud_models = [
                "gemini-1.5-flash",
                "gemini-1.5-pro",
                "gpt-4o-mini",
                "gpt-4o",
                "claude-3-haiku-20240307",
                "claude-3-opus-20240229",
                "llama3-70b-8192",
                "mixtral-8x7b-32768",  # Groq
                "google/gemini-2.0-flash-exp:free",  # OpenRouter
            ]

            # Determine Available Options based on Mode
            model_options = []
            if op_mode == "Cloud Only":
                model_options = cloud_models
            elif op_mode == "Local Only (Sovereign)":
                model_options = (
                    local_models if local_models else ["No Local Models Found"]
                )
            else:  # Hybrid
                model_options = local_models + cloud_models

            current_model = database.get_setting("active_model") or "gemini-1.5-flash"

            # Safeguard if current model not in available options
            if model_options and current_model not in model_options:
                current_model = model_options[0]
                database.set_setting("active_model", current_model)

            if model_options:
                selected_model = st.selectbox(
                    "Active Model (Base)",
                    model_options,
                    index=model_options.index(current_model)
                    if current_model in model_options
                    else 0,
                )
                if selected_model != current_model:
                    database.set_setting("active_model", selected_model)
                    st.rerun()
            else:
                st.error("No models available in this mode.")

            st.divider()

            # --- HUGGING FACE AUTH ---
            st.markdown("### 🤗 Hugging Face Token")
            curr_hf = database.get_setting("hf_token") or ""
            new_hf = st.text_input(
                "HF_TOKEN (Optional - For Gated Models)",
                value=curr_hf,
                type="password",
                help="Needed to download restricted models without warnings.",
            )
            if new_hf != curr_hf:
                database.set_setting("hf_token", new_hf)
                st.toast("HF Token Updated. Restart required.")

            st.divider()

            # --- 3. SMART MODE (Hybrid Only) ---
            if op_mode == "Hybrid (Smart)":
                st.divider()
                current_smart = database.get_setting("smart_mode") == "true"
                smart_mode = st.toggle(
                    "🧠 Enable Smart Mode (AI Tiering)", value=current_smart
                )
                if smart_mode != current_smart:
                    database.set_setting(
                        "smart_mode", "true" if smart_mode else "false"
                    )
                    st.rerun()

            st.divider()

            # --- 4. SPECIALIST ROLES (Local/Hybrid) ---
            if op_mode in ["Local Only (Sovereign)", "Hybrid (Smart)"] and local_models:
                st.markdown("**🦾 Specialist Roles (Ollama)**")

                col_spec1, col_spec2 = st.columns(2)

                # Defaults
                def_chat = database.get_setting("local_chat_model") or local_models[0]
                def_logic = database.get_setting("local_logic_model") or local_models[0]
                def_coder = database.get_setting("local_coder_model") or local_models[0]
                def_heavy = database.get_setting("local_heavy_model") or local_models[0]

                # Ensure defaults exist
                if def_chat not in local_models:
                    def_chat = local_models[0]

                with col_spec1:
                    s_chat = st.selectbox(
                        "💬 Chat (Default)",
                        local_models,
                        index=local_models.index(def_chat)
                        if def_chat in local_models
                        else 0,
                    )
                    if s_chat != def_chat:
                        database.set_setting("local_chat_model", s_chat)

                    s_coder = st.selectbox(
                        "💻 Code Specialist",
                        local_models,
                        index=local_models.index(def_coder)
                        if def_coder in local_models
                        else 0,
                    )
                    if s_coder != def_coder:
                        database.set_setting("local_coder_model", s_coder)

                with col_spec2:
                    s_logic = st.selectbox(
                        "🧠 Logic/Reasoning",
                        local_models,
                        index=local_models.index(def_logic)
                        if def_logic in local_models
                        else 0,
                    )
                    if s_logic != def_logic:
                        database.set_setting("local_logic_model", s_logic)

                    s_heavy = st.selectbox(
                        "📚 Heavy Context",
                        local_models,
                        index=local_models.index(def_heavy)
                        if def_heavy in local_models
                        else 0,
                    )
                    if s_heavy != def_heavy:
                        database.set_setting("local_heavy_model", s_heavy)

            st.divider()
            st.markdown("**🔊 Voice Interface**")
            # Voice Interface Toggle
            if "voice_response_enabled" not in st.session_state:
                st.session_state.voice_response_enabled = False

            st.toggle(
                "Enable Voice Response",
                help="Aegis will read responses aloud.",
                key="voice_response_enabled",
            )

        with tab_keys:
            st.markdown("### 🛡️ Secure Key Vault")
            st.caption(
                "Keys are encrypted with your Master Password. Supports multi-provider fallback."
            )

            if "enc_key" not in st.session_state:
                st.error(
                    "⚠️ Encryption Session Key missing. Please Log Out and Re-Login."
                )
            else:
                # Add New Key
                with st.form("add_key_form"):
                    c1, c2, c3 = st.columns([2, 3, 1])
                    with c1:
                        new_prov = st.selectbox(
                            "Provider",
                            [
                                "gemini",
                                "groq",
                                "openai",
                                "anthropic",
                                "openrouter",
                                "cerebras",
                                "together",
                            ],
                        )
                    with c2:
                        new_key = st.text_input(
                            "New API Key", type="password", help="Paste sk-..."
                        )
                    with c3:
                        new_prio = st.number_input(
                            "Priority",
                            min_value=0,
                            max_value=100,
                            value=10,
                            help="Higher = Used first",
                        )

                    if st.form_submit_button("➕ Encrypt & Store"):
                        if new_key:
                            try:
                                # Encrypt
                                enc_str = auth.encrypt_content(
                                    new_key, st.session_state.enc_key
                                )
                                database.add_api_key(new_prov, enc_str, new_prio)
                                st.success(f"Securely stored {new_prov} key.")
                                time.sleep(1)
                                st.rerun()
                            except Exception as e:
                                st.error(f"Encryption Failed: {e}")

                st.divider()
                st.markdown("**Manejador de Llaves Activadas**")
                keys = database.get_api_keys()
                if keys:
                    for k in keys:
                        col_prov, col_mask, col_del = st.columns([2, 3, 1])
                        col_prov.markdown(
                            f"**{k['provider'].upper()}** (Pr: {k['priority']})"
                        )
                        # Mask
                        col_mask.code(
                            "••••" + k["api_key"][-6:]
                            if len(k["api_key"]) > 12
                            else "••••••"
                        )
                        if col_del.button("🗑️", key=f"del_key_{k['rowid']}"):
                            database.delete_api_key(k["rowid"])
                            st.rerun()
                else:
                    st.info("Vault is empty. Add keys to enable Providers.")

        with tab_sys:
            st.subheader("System Update Center")
            st.caption("Verifies integrity and pulls latest patches from repository.")

            # Re-fetch manager to ensure we have the instance
            # We don't have get_daemon_manager here.
            # Ideally we pass it in, or we just rely on logic that runs the update.
            # Updater requires manager only for `perform_update(daemon_manager)`.
            # I should import `get_daemon_manager` from `app_web`? No, circular import.
            # I should probably pass daemon_manager as arg or move get_daemon_manager to a shared utility?
            # Or define a local helper since it's a Singleton.
            pass
            # I will assume daemon_manager is passed or obtained via cached resource if I could import it.
            # But simplified: `updater.perform_update` usually needs to stop daemons.
            # Let's import DaemonManager from modules and instantiate/get it.

            from modules.daemon_manager import DaemonManager
            # Since it's a singleton in practice (or uses lock), we can get an instance or handle it.
            # The original app_web.py cached it.
            # I'll just use the class or create a new instance which should attach to existing if shared state,
            # but standard DaemonManager isn't a singleton class by default in Python unless implemented as such.
            # app_web.py uses `@st.cache_resource` for `get_daemon_manager`.
            # I can't easily access the cached resource from another file without passing it.
            # I'll assume we pass `daemon_manager` to this function as well.

            # NOTE: Adding daemon_manager to arguments.

            # Use session state for update status
            if "update_checked" not in st.session_state:
                st.session_state.update_checked = False
                st.session_state.update_available = False
                st.session_state.update_log = ""

            if st.button("🔄 Buscar Actualizaciones"):
                with st.spinner("Contacting remote repo..."):
                    try:
                        has_update, update_log = updater.check_for_updates()
                        st.session_state.update_checked = True
                        st.session_state.update_available = has_update
                        st.session_state.update_log = update_log
                        if not has_update:
                            st.toast("System is up to date.")
                    except Exception as e:
                        st.error(f"Update Check Failed: {e}")

            if st.session_state.update_checked:
                if st.session_state.update_available:
                    st.success("✨ Update Available!")
                    with st.expander("Show Patch Notes", expanded=True):
                        st.code(st.session_state.update_log)

                    st.warning(
                        "⚠️ Warning: Update will stop all services and restart the application."
                    )
                    if st.button("🚀 INSTALAR ACTUALIZACIÓN", type="primary"):
                        st.info("Initiating Update Sequence... Hold on!")
                        time.sleep(1)
                        # We need daemon_manager here.
                        # I'll rely on it being passed in `kwargs` or `daemon_manager` arg.
                        if (
                            "daemon_manager" in st.session_state
                        ):  # Fallback or pass explicit
                            updater.perform_update(st.session_state.daemon_manager)
                        else:
                            # Try to get it
                            dm = DaemonManager()
                            updater.perform_update(dm)
                    else:
                        st.info("System is up to date. No patches found.")

        with tab_store:
            st.subheader("Cloud Skills Registry")
            st.caption("Browse and install new capabilities from the community.")

            # Search UI
            search_q = st.text_input(
                "Search Skills (e.g. 'PDF', 'YouTube')", placeholder="Enter topic..."
            )

            # Defaults
            if not search_q:
                st.info("Top Rated Tools")
                skills = store.search_cloud_skills(None)  # Get recommended
            else:
                with st.spinner("Searching Galaxy..."):
                    skills = store.search_cloud_skills(search_q)

            if not skills:
                st.warning("No skills found. Try another query.")

            # Layout Grid
            # Use columns for cards
            cols = st.columns(3)

            for i, skill in enumerate(skills):
                c = cols[i % 3]
                with c:
                    with st.container(border=True):
                        st.markdown(f"**{skill['name']}**")
                        author = skill.get("author", "Unknown")
                        stars = skill.get("stars", 0)
                        st.caption(f"by {author} | ⭐ {stars}")
                        st.write(skill.get("description", "No description."))

                        if st.button(
                            "📥 Install",
                            key=f"inst_btn_{i}_{skill['name']}",
                            help=skill.get("url"),
                        ):
                            with st.spinner("Auditing & Installing..."):
                                ok, msg = store.install_skill(
                                    skill["url"],
                                    skill["name"],
                                    brain_instance=brain_instance,
                                )
                                if ok:
                                    st.toast(
                                        f"Installed {skill['name']}! Check 'Installed Skills'."
                                    )
                                    time.sleep(1)
                                    st.rerun()
                                else:
                                    st.error(msg)

            st.divider()
            st.subheader("My Skills")
            st.caption("Manage and contribute your custom tools.")

            user_root = os.getenv("AEGIS_USER_ROOT", ".")
            local_skills_dir = os.path.join(user_root, "skills")

            if os.path.exists(local_skills_dir):
                local_files = [
                    f for f in os.listdir(local_skills_dir) if f.endswith(".py")
                ]

                if not local_files:
                    st.info("No local skills found.")
                else:
                    for s_file in local_files:
                        with st.expander(f"🛠️ {s_file}"):
                            # Read content for preview/share
                            try:
                                with open(
                                    os.path.join(local_skills_dir, s_file),
                                    "r",
                                    encoding="utf-8",
                                ) as f:
                                    s_code = f.read()

                                st.code(s_code[:300] + "...", language="python")

                                if st.button(
                                    "🚀 Share to Galaxy", key=f"share_btn_{s_file}"
                                ):
                                    st.session_state[f"sharing_mode_{s_file}"] = True

                                if st.session_state.get(
                                    f"sharing_mode_{s_file}", False
                                ):
                                    with st.form(key=f"share_form_{s_file}"):
                                        st.write(f"Contribute **{s_file}**")
                                        desc_input = st.text_area("Description")
                                        author_input = st.text_input(
                                            "Author Name", value="Anonymous"
                                        )

                                        if st.form_submit_button("Submit PR"):
                                            if desc_input:
                                                # Use Push Protocol (Benchmarking + Naming)
                                                ok, msg = store.push_skill_candidate(
                                                    s_file,
                                                    s_code,
                                                    desc_input,
                                                    author_input,
                                                )
                                                if ok:
                                                    st.balloons()
                                                    st.success(msg)
                                                    st.session_state[
                                                        f"sharing_mode_{s_file}"
                                                    ] = False
                                                    time.sleep(2)
                                                    st.rerun()
                                                else:
                                                    st.error(msg)
                                            else:
                                                st.warning("Description required.")
                            except Exception as e:
                                st.error(f"Error reading file: {e}")
            else:
                st.info("Skills directory not initialized.")
