import streamlit as st


def apply_custom_styles():
    # --- MOBILE OPTIMIZATION ---
    st.markdown(
        '<meta name="apple-mobile-web-app-capable" content="yes">',
        unsafe_allow_html=True,
    )
    st.markdown(
        '<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">',
        unsafe_allow_html=True,
    )

    # --- CUSTOM CSS (Phase 11: Singularity Glassmorphism) ---
    st.markdown(
        """
    <style>
        @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;700&display=swap');
        
        /* GLOBAL RESET & GLASS BACKGROUND */
        .stApp { 
            background-color: #000000 !important;
            background-image: radial-gradient(circle at 50% 50%, #111 0%, #000 100%);
            color: #e0e0e0; 
            font-family: 'JetBrains Mono', monospace !important; 
        }
        
        /* SIDEBAR GLASS */
        section[data-testid="stSidebar"] { 
            background-color: rgba(0, 0, 0, 0.6) !important; 
            border-right: 1px solid rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(20px);
        }
        
        /* CHAT BUBBLES - LIQUID GLASS */
        .stChatMessage { 
            background: rgba(255, 255, 255, 0.03) !important;
            border: 1px solid rgba(255, 255, 255, 0.05);
            border-radius: 12px !important;
            padding: 20px;
            margin-bottom: 15px;
            backdrop-filter: blur(10px);
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }
        
        .stChatMessage:hover {
            background: rgba(255, 255, 255, 0.05) !important;
            border-color: rgba(0, 242, 255, 0.3);
            box-shadow: 0 0 20px rgba(0, 242, 255, 0.1);
            transform: translateY(-2px);
        }
    
        /* AGENT CARDS (HTML Injection Support) */
        .agent-card {
            margin: 10px 0;
            padding: 15px;
            border-radius: 8px;
            font-size: 0.9em;
            backdrop-filter: blur(5px);
        }
        .agent-card-oracle { 
            border-left: 3px solid #bf00ff; 
            background: linear-gradient(90deg, rgba(191,0,255,0.05) 0%, transparent 100%);
        }
        .agent-card-coder { 
            border-left: 3px solid #00ff41; 
            background: linear-gradient(90deg, rgba(0,255,65,0.05) 0%, transparent 100%);
        }
        .agent-card-logic { 
            border-left: 3px solid #ff9900; 
            background: linear-gradient(90deg, rgba(255,153,0,0.05) 0%, transparent 100%);
        }
        
        /* USER BUBBLE */
        div[data-testid="stChatMessage"]:nth-child(even) {
            border-left: 2px solid #00ff41 !important;
        }
        
        /* AI BUBBLE */
        div[data-testid="stChatMessage"]:nth-child(odd) {
            border-left: 2px solid #00f2ff !important;
        }
    
        /* INPUT FIELD - OMNIBOX STYLE */
        .stTextInput input, .stChatInput textarea {
            background-color: rgba(0, 0, 0, 0.5) !important;
            color: #fff !important;
            border: 1px solid rgba(255, 255, 255, 0.1) !important;
            border-radius: 20px !important;
            padding-left: 15px !important;
        }
        .stTextInput input:focus, .stChatInput textarea:focus {
            border-color: #00f2ff !important;
            background-color: rgba(0, 242, 255, 0.05) !important;
        }
        
        /* PULSE ORB ANIMATION */
        @keyframes pulse-cyan { 0% { box-shadow: 0 0 5px #00f2ff; } 50% { box-shadow: 0 0 20px #00f2ff; } 100% { box-shadow: 0 0 5px #00f2ff; } }
        @keyframes pulse-purple { 0% { box-shadow: 0 0 5px #bf00ff; } 50% { box-shadow: 0 0 20px #bf00ff; transform: scale(1.1); } 100% { box-shadow: 0 0 5px #bf00ff; } }
        @keyframes pulse-red { 0% { box-shadow: 0 0 5px #ff0000; } 50% { box-shadow: 0 0 20px #ff0000; } 100% { box-shadow: 0 0 5px #ff0000; } }
        
        .orb {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            margin: 0 auto;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2em;
            backdrop-filter: blur(10px);
            transition: all 0.5s ease;
        }
        .orb-idle { background: radial-gradient(circle, rgba(0,242,255,0.2) 0%, rgba(0,0,0,0) 70%); border: 1px solid rgba(0,242,255,0.3); animation: pulse-cyan 3s infinite; color: #00f2ff; }
        .orb-think { background: radial-gradient(circle, rgba(191,0,255,0.2) 0%, rgba(0,0,0,0) 70%); border: 1px solid rgba(191,0,255,0.3); animation: pulse-purple 0.5s infinite; color: #bf00ff; }
        .orb-error { background: radial-gradient(circle, rgba(255,0,0,0.2) 0%, rgba(0,0,0,0) 70%); border: 1px solid rgba(255,0,0,0.3); animation: pulse-red 1s infinite; color: #ff0000; }
        
        /* TOAST OVERRIDE */
        div[data-testid="stToast"] {
            background-color: rgba(0,0,0,0.9) !important;
            border: 1px solid #333 !important;
            color: #fff !important;
            border-radius: 10px !important;
        }
    
    </style>
    <!-- Mobile PWA Meta -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover" />
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="theme-color" content="#0e1117">
    """,
        unsafe_allow_html=True,
    )
