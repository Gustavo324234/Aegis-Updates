import streamlit as st
import database
import datetime
import requests
import json
from modules.resource_monitor import monitor
from modules.soul_sync import soul_sync
from modules.auth_vault import auth
import pandas as pd
import altair as alt


def render_neural_map():
    st.title("🧠 Neural Map")

    # 1. BRAIN STATUS ORB
    metrics = monitor.get_metrics()

    # Determine Orb State
    orb_state = "orb-idle"
    orb_icon = "💠"
    active_model = database.get_setting("active_model")

    if metrics.get("ram_percent", 0) > 90:
        orb_state = "orb-error"
        orb_icon = "⚠️"
    elif "thinking" in st.session_state.get("brain_state", ""):  # Mock state
        orb_state = "orb-think"
        orb_icon = "🧠"

    # THE PULSE ORB
    st.markdown(
        f"""
    <div class="orb {orb_state}">
        {orb_icon}
    </div>
    <div style="text-align: center; margin-top: 10px; color: #666; font-size: 0.8em;">
        {active_model}<br>
        MEM: {metrics.get("ram_percent", 0)}% | CPU: {metrics.get("cpu_percent", 0)}%
    </div>
    """,
        unsafe_allow_html=True,
    )

    st.divider()

    # 2. NODES NEXUS (Satellites)
    st.subheader("🛰️ Nexus Mesh")
    nodes = database.get_all_nodes()

    # --- PHASE 9: MODEL EFFICIENCY GRAPH --
    st.subheader("📊 Model Efficiency & Economy")
    try:
        # Mock data for prototype
        metric_data = pd.DataFrame(
            {
                "Model": [
                    "Llama 3.2 (1B)",
                    "Gemini Flash",
                    "Llama 3.1 (8B)",
                    "Mistral Nemo",
                ],
                "Cost (Tokens)": [0, 0.05, 0, 0],
                "Speed (ms)": [45, 120, 240, 560],
                "Usage (%)": [60, 25, 10, 5],
            }
        )

        chart = (
            alt.Chart(metric_data)
            .mark_bar()
            .encode(x="Model", y="Usage (%)", tooltip=["Cost (Tokens)", "Speed (ms)"])
            .properties(height=200)
        )

        st.altair_chart(chart, use_container_width=True)

        # Savings Counter
        savings = 12.50
        st.metric("Estimated Monthly Savings", f"${savings:.2f}", "+$2.10 this week")

    except ImportError:
        st.warning("Install pandas/altair for graphs.")

    if nodes:
        cols_nodes = st.columns(len(nodes))
        for i, node in enumerate(nodes):
            with cols_nodes[i]:
                st.info(f"**{node['node_id']}**")
                st.caption(f"Status: {node['status']}")
                st.caption(f"Last Seen: {node['last_seen']}")
                if node["status"] == "online":
                    st.success("LINKED")
                else:
                    st.error("OFFLINE")
    else:
        st.warning("No satellites linked. You are alone.")

    st.divider()

    # 3. CODEX VISUALIZER
    st.subheader("🕸️ Semantic Connections (Codex)")
    snippets = database.get_all_codex_snippets()
    if snippets:
        st.write("Recent Knowledge Acquisitions:")
        graph_html = "<div style='display: flex; gap: 10px; flex-wrap: wrap;'>"
        for snip in snippets[:10]:
            graph_html += f"""
             <div style='border: 1px solid #00f2ff; padding: 10px; border-radius: 10px; background: rgba(0, 242, 255, 0.1); width: 150px;'>
                 <div style='font-weight: bold; font-size: 0.8em; color: #fff;'>{snip["title"][:20]}..</div>
                 <div style='font-size: 0.7em; color: #aaa;'>{snip["language"]}</div>
             </div>
             """
        graph_html += "</div>"
        st.markdown(graph_html, unsafe_allow_html=True)

    st.divider()

    # 4. SOUL SYNC
    st.subheader("🛡️ Soul Sync (Protocol Phoenix)")
    last_sync = database.get_setting("last_soul_sync")
    if last_sync:
        st.info(f"Last External Sync: {last_sync}")
    else:
        st.warning("⚠️ Never Synced to Cloud/External.")

    col_soul1, col_soul2 = st.columns([1, 3])
    with col_soul1:
        if st.button("Initiate Soul Dump", type="primary"):
            st.toast("⏳ Compressing Soul...")

            def enc_wrapper(data):
                if "enc_key" in st.session_state:
                    from cryptography.fernet import Fernet

                    f = Fernet(st.session_state.enc_key)
                    return f.encrypt(data)
                return data

            ok, msg = soul_sync.perform_sync(encrypt_func=enc_wrapper)
            if ok:
                st.success(f"✅ Soul Saved: {msg}")
                database.log_audit_event(
                    "SOUL_SYNC", "Backup Created", "SUCCESS", details=msg, approved=True
                )
            else:
                st.error(f"❌ Dump Failed: {msg}")
