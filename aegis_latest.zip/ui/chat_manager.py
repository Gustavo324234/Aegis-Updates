import streamlit as st
import database
import json
import time
import datetime
import re
import os

# Modules
import requests

from modules.auth_vault import auth
from modules.vault_manager import vault
from modules.validator import sentinel

# UI Components
from .dashboard import render_neural_map


# --- SOVEREIGN PROTOCOL: PRIVILEGED MODULES ---
# Modules in this list bypass the "User Approval" dialog.
# They are auto-executed to allow the AI to manage its own memory and internal state.
SELF_MANAGED_MODULES = [
    "identity_manager",
    "project_manager",
    "data_architect",
    "db_logger",
    "database_ops",
    "memory_manager",
    "life_manager",
]


# Helper: Text to Speech (Copied from app_web.py)
def _text_to_speech(text):
    try:
        from gtts import gTTS
        import io

        if not text:
            return None
        # Clean text
        clean_text = text.replace("*", "").replace("#", "").replace("`", "")
        if len(clean_text) > 300:
            clean_text = clean_text[:300] + "..."

        fp = io.BytesIO()
        tts = gTTS(text=clean_text, lang="es")
        tts.write_to_fp(fp)
        fp.seek(0)
        return fp
    except Exception:
        return None


def render_chat_interface(brain_instance, hands_free_mode=False, zen_mode=False):
    """
    Renders the main Chat Interface, handling message history, Omnibox input, and Brain responses.
    This also includes the 'Neural Map' view toggling.
    """

    # --- SESSION STARTUP / INACTIVITY DETECTION ---
    try:
        check_hist = database.get_history(limit=1, thread_tag="general")
        user_name = database.get_user_fact("user_name", "identity")
        ai_name = database.get_setting("ai_name") or "Aegis-IA"

        # 1. GENESIS PROTOCOL (Fresh Install)
        if not check_hist and not user_name:
            with st.spinner("Initializing Genesis Protocol..."):
                genesis_greeting = brain_instance.query(
                    "SYSTEM: SYSTEM STARTUP. INITIATE GENESIS SEQUENCE. GREET THE USER.",
                    [],
                    "llama3.2:1b",
                    api_key=None,
                    hive_override=False,
                )
                database.save_message("assistant", genesis_greeting, "Aegis", "general")
                st.rerun()

        # 2. MORNING BRIEFING (Proactive Welcome)
        # Se activa si es una sesión nueva (session_state) o si pasaron 4 horas
        should_greet = False
        if "session_booted" not in st.session_state:
            st.session_state.session_booted = True
            should_greet = True

        if check_hist:
            last_msg_ts = check_hist[0][2]
            last_time = datetime.datetime.fromisoformat(last_msg_ts)
            hours_passed = (datetime.datetime.now() - last_time).total_seconds() / 3600
            if hours_passed > 4:
                should_greet = True

        if should_greet and user_name:
            with st.spinner("Generando Reporte de Guardia..."):
                briefing = brain_instance.generate_morning_briefing()
                database.save_message("assistant", briefing, ai_name, "general")
                st.rerun()

    except Exception as e:
        print(f"[DEBUG] Startup Error: {e}")

    # VIEW CONTROLLER (Tab System)
    view_mode = st.radio(
        "Access Node",
        ["Main Console", "Neural Map"],
        horizontal=True,
        label_visibility="collapsed",
    )

    if view_mode == "Neural Map":
        render_neural_map()
        st.stop()  # Stop execution for Main Console logic

    # --- IDENTITY VISUAL BLOCK (Caja de Personalidad) ---
    # DISABLED: Identity configuration now happens exclusively via conversational
    # onboarding (Genesis State Machine in brain.py). No Streamlit forms needed.
    #
    # if user_name and ai_name == "Aegis-IA":
    #     with st.chat_message("assistant"):
    #         st.markdown("### 🌌 Activación de la Caja de Personalidad")
    #         st.write(
    #             f"Hola {user_name}. He detectado que mi identidad aún no está completa. "
    #             "Es momento de que me des un nombre y elijas mi personalidad para finalizar mi integración."
    #         )
    #
    #         c1, c2 = st.columns(2)
    #         with c1:
    #             new_ai_name = st.text_input(
    #                 "¿Cómo quieres llamarme?", placeholder="Jarvis, Cortana, Aegis..."
    #             )
    #         with c2:
    #             pers_options = [
    #                 "Socio Tecnológico (Directo)",
    #                 "Compañero (Cálido)",
    #                 "Butler (Formal)",
    #                 "Sarcástico/Hacker",
    #             ]
    #             selected_pers = st.selectbox("Personalidad", pers_options)
    #
    #         if st.button("Confirmar Vínculo", type="primary", use_container_width=True):
    #             if new_ai_name:
    #                 # Update Name
    #                 brain_instance.module_manager.execute_module(
    #                     "identity_manager",
    #                     {
    #                         "action": "update_preference",
    #                         "args": {"key": "ai_name", "value": new_ai_name},
    #                     },
    #                 )
    #                 # Update Personality
    #                 brain_instance.module_manager.execute_module(
    #                     "identity_manager",
    #                     {
    #                         "action": "update_preference",
    #                         "args": {
    #                             "key": "assistant_personality",
    #                             "value": selected_pers,
    #                         },
    #                     },
    #                 )
    #                 st.success(
    #                     f"Vínculo confirmado. Mi nombre es {new_ai_name} y operaré como tu {selected_pers}."
    #                 )
    #                 time.sleep(2)
    #                 st.rerun()
    #             else:
    #                 st.warning("Por favor, asígname un nombre para continuar.")
    #     st.stop()

    # --- DEFAULT VIEW: MAIN CONSOLE ---
    context = "general"  # Default context tag

    # --- PROJECT LAUNCHER NOTIFICATION ---
    if "last_project_launch" in st.session_state:
        proj_name = st.session_state["last_project_launch"]
        safe_name = proj_name.strip().replace(" ", "_")
        snapshot_path = os.path.join("workspace/projects", safe_name, "ui_snapshot.png")

        with st.container():
            st.success(f"Project '{proj_name}' updated successfully.")

            # Visual Preview (Escenario)
            if os.path.exists(snapshot_path):
                st.image(
                    snapshot_path,
                    caption=f"Previsualización de {proj_name}",
                    use_container_width=True,
                )

            col_launch, col_tele, col_idx = st.columns([1, 1, 3])
            with col_launch:
                if st.button("🚀 Lanzar"):
                    # Execute via Project Manager (Unified Logic)
                    try:
                        res = brain_instance.module_manager.execute_module(
                            "project_manager",
                            {"action": "execute_project", "project_name": proj_name},
                            brain_instance=brain_instance,
                        )
                        if "Error" in str(res):
                            st.error(res)
                        else:
                            st.toast(f"Launched {proj_name}!", icon="🚀")
                    except Exception as e:
                        st.error(f"Launch failed: {e}")

            with col_tele:
                if st.button("📡 Teleport"):
                    # Find target node (Desktop/Satellite)
                    nodes = database.get_all_nodes()
                    online_nodes = [n for n in nodes if n["status"] == "online"]

                    if not online_nodes:
                        st.error(
                            "No hay dispositivos Nexus conectados para teletransporte."
                        )
                    else:
                        # Prefer desktop if on laptop, or first available
                        target = next(
                            (
                                n["node_id"]
                                for n in online_nodes
                                if "desktop" in n["node_id"].lower()
                            ),
                            online_nodes[0]["node_id"],
                        )

                        _u = (
                            database.get_user_fact("user_name", "identity") or "Usuario"
                        )
                        st.info(
                            f"{_u}, estoy moviendo tu proyecto de {proj_name} a tu PC potente. Estará listo en un momento."
                        )

                        try:
                            res = brain_instance.module_manager.execute_module(
                                "project_manager",
                                {
                                    "action": "teleport_project",
                                    "project_name": proj_name,
                                    "target": target,
                                },
                                brain_instance=brain_instance,
                            )
                            if "Error" in str(res):
                                st.error(res)
                            else:
                                st.toast(
                                    f"Teleport Success: {proj_name} -> {target}",
                                    icon="🛰️",
                                )
                        except Exception as e:
                            st.error(f"Teleport failed: {e}")

    # --- OPTIMIZATION NOTIFICATION ---
    if (
        "optimization_notify" in st.session_state
        and st.session_state["optimization_notify"]
    ):
        st.info(st.session_state["optimization_notify"], icon="🚀")
        # Save to history so it persists in the chat
        database.save_message(
            "assistant", st.session_state["optimization_notify"], "Aegis", context
        )
        del st.session_state["optimization_notify"]
        st.rerun()

    # 1. Render History
    history = database.get_history(limit=50, thread_tag=context)

    for role, message, ts in history:
        with st.chat_message(role):
            if role == "assistant":
                # Enable HTML for Hive Logs
                st.markdown(message, unsafe_allow_html=True)

                # Timestamp
                try:
                    t_obj = datetime.datetime.fromisoformat(ts)
                    nice_time = t_obj.strftime("%H:%M")
                    st.caption(f"🕒 {nice_time}")
                except Exception:
                    pass

                # --- NEXUS CODE SYNC (OPTIMIZED) ---
                if (
                    "```" in message
                    and role == "assistant"
                    and message == history[-1][1]
                ):
                    online_nodes = [
                        n for n in database.get_all_nodes() if n["status"] == "online"
                    ]
                    if online_nodes:
                        target_sat = next(
                            (
                                n["node_id"]
                                for n in online_nodes
                                if "desktop" in n["node_id"].lower()
                            ),
                            online_nodes[0]["node_id"],
                        )

                        st.divider()
                        col_sync, col_info = st.columns([1, 2])
                        with col_sync:
                            if st.button(
                                "🚀 Enviar a Workspace", key=f"sync_{len(history)}"
                            ):
                                with st.spinner(f"Sincronizando con {target_sat}..."):
                                    payload = {
                                        "target_node": target_sat,
                                        "content": {
                                            "cmd": "write_to_workspace",
                                            "args": {
                                                "filename": ".aegis_task.md",
                                                "content": message,
                                            },
                                        },
                                    }
                                    try:
                                        resp = requests.post(
                                            "http://localhost:8000/send_message",
                                            json=payload,
                                        )
                                        if resp.status_code == 200:
                                            st.toast(f"✅ Tarea enviada a {target_sat}")
                                        else:
                                            st.error(f"Error: {resp.text}")
                                    except Exception as e:
                                        st.error(f"Link Fail: {e}")
                try:
                    t_obj = datetime.datetime.fromisoformat(ts)
                    nice_time = t_obj.strftime("%H:%M")
                    st.caption(f"🕒 {nice_time}")
                except Exception:
                    pass
            else:
                # System or User
                display_msg = message
                undo_payload = None

                if "[UNDO_DATA:" in message:
                    try:
                        parts = message.split("[UNDO_DATA:")
                        display_msg = parts[0].strip()
                        json_str = parts[1].strip("]")
                        undo_payload = json.loads(json_str)
                    except Exception:
                        pass

                st.markdown(display_msg)

                if undo_payload:
                    # --- OPTIMIZACIÓN DESHACER (Lifespan) ---
                    # Desaparece si han pasado 5 minutos o si hay más de 2 mensajes nuevos después
                    msg_time = datetime.datetime.fromisoformat(ts)
                    mins_passed = (
                        datetime.datetime.now() - msg_time
                    ).total_seconds() / 60

                    # Buscamos la distancia en el historial actual
                    msg_index = next(
                        (i for i, h in enumerate(history) if h[2] == ts), 0
                    )
                    msg_distance = len(history) - 1 - msg_index

                    if mins_passed < 5 and msg_distance < 3:
                        col_u1, col_u2 = st.columns([1, 4])
                        with col_u1:
                            if st.button("↩️ Deshacer", key=f"undo_hist_{ts}"):
                                if undo_payload["type"] == "expense":
                                    database.delete_expense(undo_payload["id"])
                                    st.toast("Gasto eliminado.")
                                elif undo_payload["type"] == "task":
                                    database.delete_task(undo_payload["id"])
                                    st.toast("Tarea eliminada.")

                                st.rerun()

                try:
                    t_obj = datetime.datetime.fromisoformat(ts)
                    nice_time = t_obj.strftime("%H:%M")
                    st.caption(f"🕒 {nice_time}")
                except Exception:
                    pass

    # 2. Check for Pending Actions (JSON/Skill Proposals)
    if history and history[-1][0] == "assistant":
        last_msg = history[-1][1]
        command_data = None

        # Check JSON
        json_match = re.search(r"\{.*\}", last_msg, re.DOTALL)
        if json_match:
            try:
                data = json.loads(json_match.group(0))
                if "module" in data and "action" in data:
                    command_data = data
            except Exception:
                pass

        # Check SKILL_PROPOSAL
        if "SKILL_PROPOSAL:" in last_msg:
            try:
                json_part = last_msg.split("SKILL_PROPOSAL:")[1]
                payload = json.loads(json_part)
                command_data = {
                    "module": "skill_builder",
                    "action": "install_skill_confirmed",
                    "filename": payload.get("filename"),
                    "code": payload.get("code"),
                }
            except Exception:
                pass

        if command_data:
            st.divider()
            is_executable = True

            # Sentinel
            if command_data.get("module") == "skill_builder":
                code_to_validate = command_data.get("code", "")
                with st.spinner("🛡️ Sentinel analyzing..."):
                    is_valid, val_report = sentinel.check_syntax(code_to_validate)

                if is_valid:
                    st.success("🛡️ Sentinel: Verified.")
                    st.session_state.skill_retry_active = False
                else:
                    if not st.session_state.get("skill_retry_active", False):
                        st.warning("⚠️ Sentinel detected errors. Auto-repairing...")
                        # Logic to trigger repair loop (omitted full recursion for brevity, implementing basic retry)
                        # In full implementation, this calls brain.query again.
                        st.session_state.skill_retry_active = True
                        # For now, we block execution but allow manual override? No, strict.
                        is_executable = False
                    else:
                        st.error("❌ Auto-repair failed.")
                        is_executable = False

            if is_executable:
                module_name = command_data.get("module")
                action_name = command_data.get("action")

                # --- PRIVILEGED EXECUTION PROTOCOL ---
                is_privileged = module_name in SELF_MANAGED_MODULES

                if is_privileged:
                    # AUTO EXECTUION
                    st.toast(
                        f"Auto-Executing: {module_name} -> {action_name}", icon="⚡"
                    )

                    # Execute immediately without UI block
                    delegate = st.session_state.get("current_delegate")
                    if delegate and module_name == "project_manager":
                        st.info(
                            f"🛰️ Redireccionando ejecución a {delegate} (Swarm Balanced)"
                        )
                        try:
                            resp = requests.post(
                                "http://localhost:8000/send_message",
                                json={"target_node": delegate, "content": command_data},
                                timeout=10,
                            )
                            res = (
                                resp.json()
                                if resp.status_code == 200
                                else f"Error: {resp.text}"
                            )
                        except Exception as e:
                            res = f"Delegation Error: {e}"
                    else:
                        res = brain_instance.module_manager.execute_module(
                            module_name, command_data, brain_instance=brain_instance
                        )

                    # Parse Result for Undo Logic
                    msg_result = str(res)
                    undo_data = None
                    try:
                        import ast

                        if isinstance(res, dict):
                            res_dict = res
                        else:
                            # Try parsing string dict representation
                            res_dict = ast.literal_eval(msg_result)

                        if (
                            isinstance(res_dict, dict)
                            and "id" in res_dict
                            and "type" in res_dict
                        ):
                            undo_data = res_dict
                            msg_result = res_dict.get("message", msg_result)
                    except Exception:
                        pass

                    # Log silently to System (with UNDO Tag)
                    log_msg = f"AUTO-EXEC ({module_name}): {msg_result}"
                    if undo_data:
                        try:
                            log_msg += f" [UNDO_DATA:{json.dumps(undo_data)}]"
                        except Exception:
                            pass

                    database.save_message(
                        "system",
                        log_msg,
                        "Aegis",
                        context,
                    )

                    # PROJECT LAUNCHER CHECK
                    if (
                        "Error" not in msg_result
                        and command_data.get("module") == "project_manager"
                    ):
                        st.session_state["last_project_launch"] = command_data.get(
                            "project_name"
                        ) or command_data.get("name")

                    time.sleep(0.5)
                    st.rerun()

                else:
                    # STANDARD CONFIRMATION UI
                    st.warning(f"⚠️ PENDING ACTION: {module_name} -> {action_name}")

                    target_options = ["Local (This PC)"] + [
                        n["node_id"]
                        for n in database.get_all_nodes()
                        if n["status"] == "online"
                    ]
                    target_node = st.selectbox("Execute On:", target_options)

                    col_exec, col_cancel = st.columns(2)
                    with col_exec:
                        if st.button("🚀 EXECUTE / APPROVE"):
                            with st.spinner(f"Executing on {target_node}..."):
                                success = False
                                msg_result = ""

                                if target_node == "Local (This PC)":
                                    res = brain_instance.module_manager.execute_module(
                                        command_data["module"],
                                        command_data,
                                        brain_instance=brain_instance,
                                    )
                                    msg_result = str(res)
                                    success = "Error" not in msg_result

                                    # PROJECT LAUNCHER CHECK
                                    if (
                                        success
                                        and command_data.get("module")
                                        == "project_manager"
                                    ):
                                        st.session_state["last_project_launch"] = (
                                            command_data.get("project_name")
                                            or command_data.get("name")
                                        )

                                else:
                                    # Remote
                                    try:
                                        payload = {
                                            "target_node": target_node,
                                            "content": {
                                                "cmd": "terminal_cmd"
                                                if command_data.get("action")
                                                == "terminal"
                                                else "unknown",
                                                "args": {
                                                    "command": command_data.get(
                                                        "command"
                                                    )
                                                },
                                                "raw_module": command_data.get(
                                                    "module"
                                                ),
                                                "raw_action": command_data.get(
                                                    "action"
                                                ),
                                            },
                                        }
                                        resp = requests.post(
                                            "http://localhost:8000/send_message",
                                            json=payload,
                                        )
                                        if resp.status_code == 200:
                                            msg_result = f"Remote OK: {resp.json()}"
                                            success = True
                                        else:
                                            msg_result = f"Gateway Error: {resp.text}"
                                    except Exception as e:
                                        msg_result = f"Conn Fail: {e}"

                                st.success(f"Result: {msg_result}")
                                database.save_message(
                                    "system",
                                    f"EXECUTION RESULT ({target_node}):\n{msg_result}",
                                    "Aegis",
                                    context,
                                )

                                # Log Audit
                                database.log_audit_event(
                                    command_data.get("module"),
                                    command_data.get("action"),
                                    "SUCCESS" if success else "FAILURE",
                                    approved=True,
                                )

                                time.sleep(1)
                                st.rerun()

                    with col_cancel:
                        if st.button("❌ CANCEL"):
                            database.save_message(
                                "system", "Action Cancelled.", "Aegis", context
                            )
                            st.rerun()

        # --- AUTO-TRIGGER VISUAL REVIEW ---
        elif (
            history
            and history[-1][0] == "system"
            and "[VISUAL_REVIEW_REQUEST]" in history[-1][1]
        ):
            proj_name = history[-1][1].split("[VISUAL_REVIEW_REQUEST]")[-1].strip()
            safe_name = proj_name.strip().replace(" ", "_")
            snapshot_path = os.path.join(
                "workspace/projects", safe_name, "ui_snapshot.png"
            )

            if os.path.exists(snapshot_path):
                # Load image for Vision Driver
                from PIL import Image

                img = Image.open(snapshot_path)

                with st.chat_message("assistant"):
                    with st.spinner(f"🔍 Aegis revisando visualmente {proj_name}..."):
                        # Invoke Brain with Visual Reviewer context
                        api_key = auth.get_api_key(
                            st.session_state.get("master_password")
                        )
                        if not api_key:
                            api_key = "local_mode_active"

                        review_response = brain_instance.query(
                            f"[VISUAL_REVIEW_REQUEST] {proj_name}",
                            [],  # No history needed for specialist critique
                            "gemini-1.5-flash",  # Force vision model
                            api_key=api_key,
                            image_input=img,
                        )

                        # Display and save
                        st.markdown(review_response)
                        database.save_message(
                            "assistant", review_response, "Visual Reviewer", context
                        )
                        st.rerun()

    # 3. PROTOCOL OMNI-LINK (Input)
    omni_context = ""
    uploaded_image = None
    omni_files = []

    c_file, c_mic, c_spacer = st.columns([1, 1, 8])
    with c_file:
        with st.popover("📎", help="Adjuntar archivos"):
            if "omni_key" not in st.session_state:
                st.session_state.omni_key = 0
            uploaded_files = st.file_uploader(
                "Omni-Link Upload",
                accept_multiple_files=True,
                key=f"omni_{st.session_state.omni_key}",
            )

    with c_mic:
        try:
            from streamlit_mic_recorder import speech_to_text

            voice_key = f"mic_{st.session_state.omni_key}"
            voice_input = speech_to_text(
                language="es-ES",
                start_prompt="🎙️",
                stop_prompt="⏹️",
                just_once=True,
                key=voice_key,
            )
        except ImportError:
            voice_input = None

    if uploaded_files:
        omni_files = uploaded_files
        st.caption(f"📦 {len(omni_files)} archivo(s).")
        file_metadata = []
        for f in omni_files:
            ftype = f.name.split(".")[-1].lower()
            if ftype in ["png", "jpg", "jpeg"]:
                if not uploaded_image:
                    uploaded_image = f
                    st.image(f, width=100, caption="Visual Uplink")
                file_metadata.append(f"{f.name} (Image)")
            else:
                status = vault.index_file(
                    f.name, collection="session_rag", file_bytes=f
                )
                file_metadata.append(f"{f.name} ({ftype})")

        if file_metadata:
            omni_context += f"\n[SYSTEM: Uploaded files: {', '.join(file_metadata)}.]"

    # --- CHAT UTILITIES (EXPORT) ---
    with st.expander("Utilidades de Chat", expanded=False):
        try:
            full_hist = database.get_history(limit=100, thread_tag=context)
            timestamp_now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
            export_str = (
                f"{'-' * 50}\nAEGIS-IA CONVERSATION LOG - {timestamp_now}\n{'-' * 50}\n"
            )

            for role, msg, ts in full_hist:
                try:
                    t_val = datetime.datetime.fromisoformat(ts).strftime(
                        "%Y-%m-%d %H:%M:%S"
                    )
                except Exception:
                    t_val = ts
                export_str += f"[{t_val}] {role.upper()}: {msg}\n{'-' * 50}\n"

            st.download_button(
                label="📥 Exportar Conversación (.txt)",
                data=export_str,
                file_name=f"aegis_chat_log_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.txt",
                mime="text/plain",
            )
        except Exception as e:
            st.error(f"Error exportando chat: {e}")

    prompt = st.chat_input("Command Aegis...")

    # Genesis Prompt Logic (Usually comes from Home buttons, we assume passed or state?)
    # In app_web, genesis_prompt was a local var.
    # We can check session state or assume None if not passed.
    # For now, simplistic approach.
    genesis_prompt = None

    active_input = prompt or voice_input or genesis_prompt

    if omni_context and active_input:
        active_input += f"\n\n{omni_context}"
    elif omni_context and not active_input and uploaded_files:
        active_input = "Analiza los archivos adjuntos." + f"\n\n{omni_context}"

    if active_input:
        try:
            recent_db_history = database.get_history(limit=6)
            hist_for_brain = [(r[0], r[1]) for r in recent_db_history]
        except Exception:
            hist_for_brain = []

        is_voice = active_input == voice_input

        with st.chat_message("user"):
            st.markdown(active_input)
            if is_voice:
                st.caption("🎙️ Voice Command")
            if uploaded_image:
                st.image(uploaded_image, caption="Visual Context", width=300)

        database.save_message("user", active_input, "User", context)

        # --- RESPONSE GENERATION ---
        with st.chat_message("assistant"):
            placeholder = st.empty()
            full_response = ""

            api_key = auth.get_api_key(st.session_state.get("master_password"))
            active_model = database.get_setting("active_model") or "gemini-1.5-flash"

            # Sovereign Guard
            if "ollama" in active_model or "llama" in active_model or not api_key:
                api_key = "local_mode_active"

            key_ring = st.session_state.get("api_key_ring", {})

            if hands_free_mode:
                active_input += " [SYSTEM: VOICE MODE. KEEP CONCISE.]"

            try:
                # 0. PROTOCOL NEURAL ROUTER
                route = brain_instance.route_request(
                    active_input,
                    file_metadata=omni_context if omni_context else None,
                    api_key=api_key,
                )

                # Persistence of delegation for current turn
                st.session_state["current_delegate"] = route.get("delegate_to")

                # A. MISSION/AGENTS
                if route["intent"] in ["mission", "parallel_swarm", "mission_project"]:
                    st.toast(f"Swarm Active: {route['intent']}", icon="🤖")

                    status_label = "⚙️ Activando Enjambre..."
                    active_node = route.get("delegate_to", "Local")
                    if active_node != "Local":
                        status_label = f"⚙️ Procesando en: {active_node}"

                    with st.status(status_label, expanded=True) as status:
                        if active_node != "Local":
                            status.write(
                                f"🚀 Tarea delegada a nodo potente: **{active_node}**"
                            )

                        status.write(f"Agents: {route.get('agents')}")

                        stream_obj = brain_instance.query(
                            active_input,
                            hist_for_brain,
                            active_model,
                            api_key=api_key,
                            image_input=uploaded_image,
                            stream=True,
                            key_ring=key_ring,
                        )

                        current_stream_text = ""
                        if stream_obj:
                            for chunk in stream_obj:
                                text_chunk = (
                                    chunk.text if hasattr(chunk, "text") else str(chunk)
                                )
                                current_stream_text += text_chunk
                                placeholder.markdown(current_stream_text + "▌")
                            placeholder.markdown(current_stream_text)
                            full_response = current_stream_text

                        status.update(
                            label="✅ Misión Completada",
                            state="complete",
                            expanded=False,
                        )

                # B. CHAT DIRECT
                else:
                    stream_obj = brain_instance.query(
                        active_input,
                        hist_for_brain,
                        active_model,
                        api_key=api_key,
                        image_input=uploaded_image,
                        stream=True,
                        key_ring=key_ring,
                    )
                    if isinstance(stream_obj, str):
                        full_response = stream_obj
                        placeholder.markdown(full_response)
                    elif stream_obj:
                        for chunk in stream_obj:
                            text = chunk.text if hasattr(chunk, "text") else str(chunk)
                            full_response += text
                            placeholder.markdown(full_response + "▌")
                        placeholder.markdown(full_response)

                database.save_message("assistant", full_response, active_model, context)

                # --- EXECUTIVE MODE FILTER (SRE HARDENING) ---
                # Checks if response has JSON + Text and mutes text.
                executive_mode = database.get_setting("executive_mode") == "true"
                if executive_mode:
                    # re is already imported globally
                    json_match = re.search(r"(\{.*\})", full_response, re.DOTALL)
                    if (
                        json_match
                        and len(full_response) > len(json_match.group(1)) + 10
                    ):
                        # Extra text detected. Scrub it.
                        clean_json = json_match.group(1)
                        full_response = clean_json
                        placeholder.markdown(
                            full_response
                        )  # Update UI to show only JSON
                        # Update DB entry to reflect scrubbed reality?
                        # Re-saving might be safer to ensure history is clean for next turn.
                        database.save_message(
                            "assistant", full_response, active_model, context
                        )

                # Reset Omni
                if omni_context or uploaded_image:
                    st.session_state.omni_key += 1

                # Audio Response (Siren Protocol)
                if hands_free_mode or st.session_state.get("voice_response_enabled"):
                    with st.spinner("🔊 Generando voz..."):
                        audio_fp = _text_to_speech(full_response)
                        if audio_fp:
                            # autoplay=True inicia la reproducción inmediata
                            st.audio(audio_fp, format="audio/mp3", autoplay=True)

                # Code Autodetection
                if "```" in full_response and "{" not in full_response:
                    st.toast("Code detected.", icon="💾")
                    st.rerun()  # Refresh to show execution buttons

                # PROTOCOLO GÉNESIS: Force Rerun on Identity Update
                if "configurando mi núcleo de memoria" in full_response:
                    st.toast("Identidad configurada. Reiniciando núcleo...", icon="🧠")
                    time.sleep(1)
                    st.rerun()

            except Exception as e:
                placeholder.error(f"System Error: {e}")
                database.log_audit_event(
                    "CHAT_CRASH", "Exception", "CRITICAL", str(e), False
                )
