import subprocess
import time
import os
import sys
import datetime

# Configuration
# Configuration
TARGET_SCRIPT = "app_web.py"
GATEWAY_SCRIPT = "modules/nexus_gateway.py"
CRASH_LOG = "crash_log.txt"
CHECK_INTERVAL = 10  # Seconds

def log_incident(message):
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_entry = f"[{timestamp}] {message}\n"
    print(log_entry.strip())
    try:
        with open(CRASH_LOG, "a", encoding="utf-8") as f:
            f.write(log_entry)
    except Exception as e:
        print(f"Failed to write to crash log: {e}")

def run_process():
    """Starts the target process (Streamlit Hub)."""
    cmd = [sys.executable, "-m", "streamlit", "run", TARGET_SCRIPT]
    log_incident(f"Starting {TARGET_SCRIPT}...")
    
    # Platform-specific flags for new console window
    kwargs = {'cwd': os.getcwd()}
    if os.name == 'nt':
        kwargs['creationflags'] = subprocess.CREATE_NEW_CONSOLE
    else:
        # Redirect stdout/stderr on POSIX
        kwargs['stdout'] = open("hub.log", "a")
        kwargs['stderr'] = subprocess.STDOUT
        # We don't detach unless user specifically wants, but let's assume we want to keep it manageable.
        # But this is watchdog, so it keeps handle. That's fine.

    return subprocess.Popen(cmd, **kwargs)

def launch_nexus_gateway():
    """Launches the Nexus Gateway in a separate console."""
    if not os.path.exists(GATEWAY_SCRIPT):
        log_incident(f"⚠️ Gateway script not found: {GATEWAY_SCRIPT}")
        return

    cmd = [sys.executable, GATEWAY_SCRIPT]
    log_incident(f"Starting Nexus Gateway ({GATEWAY_SCRIPT})...")

    kwargs = {'cwd': os.getcwd()}
    if os.name == 'nt':
        kwargs['creationflags'] = subprocess.CREATE_NEW_CONSOLE
    else:
        # POSIX
        kwargs['stdout'] = open("gateway.log", "a")
        kwargs['stderr'] = subprocess.STDOUT
    
    try:
        subprocess.Popen(cmd, **kwargs)
        log_incident("✅ Nexus Gateway Launched (Port 8000)")
    except Exception as e:
        log_incident(f"❌ Failed to launch Gateway: {e}")

def main():
    print("🔥 PROTOCOL PHOENIX WATCHDOG ACTIVE 🔥")
    print(f"Monitoring: {TARGET_SCRIPT} & Launching Gateway")
    
    # 1. Launch Gateway (Fire & Forget, let it manage itself or just run)
    launch_nexus_gateway()
    
    # 2. Launch & Monitor Hub
    process = run_process()
    
    try:
        while True:
            time.sleep(CHECK_INTERVAL)
            
            # Check if process is still running
            ret_code = process.poll()
            
            if ret_code is not None:
                # Process ended
                if ret_code != 0:
                    log_incident(f"⚠️ CRASH DETECTED! Exit Code: {ret_code}. Restarting in 3s...")
                else:
                    log_incident("⚠️ Process exited normally (0). Restarting to maintain persistence...")
                
                time.sleep(3)
                process = run_process()
                
    except KeyboardInterrupt:
        log_incident("Watchdog stopped by user.")
        process.terminate()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
        sys.exit(0)

if __name__ == "__main__":
    main()
