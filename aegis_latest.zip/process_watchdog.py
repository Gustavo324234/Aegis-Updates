import subprocess
import time
import os
import sys
import datetime

import logging

# Silence HF Hub Warnings in Watchdog too
logging.getLogger("huggingface_hub").setLevel(logging.ERROR)

# --- WATCHDOG CONFIGURATION ---
TARGET_SCRIPT = "admin_launcher.py"  # The Orchestrator
GATEWAY_SCRIPT = "modules/nexus_gateway.py"
CHECK_INTERVAL = 10  # Seconds


def log_incident(message, status="INFO"):
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_entry = f"[{timestamp}] {message}"
    print(log_entry)

    # Optional: Log to file
    try:
        with open("watchdog.log", "a") as f:
            f.write(log_entry + "\n")
    except Exception:
        pass


def run_process():
    """Starts the Orchestrator (admin_launcher.py)."""
    # Verify script exists
    if not os.path.exists(TARGET_SCRIPT):
        log_incident(f"CRITICAL: {TARGET_SCRIPT} NOT FOUND!", status="CRITICAL")
        return None

    cmd = [
        sys.executable,
        "-m",
        "streamlit",
        "run",
        TARGET_SCRIPT,
        "--server.port=8501",
        "--server.headless=true",
        "--browser.gatherUsageStats=false",
    ]

    log_incident(f"Starting Orchestrator: {TARGET_SCRIPT}...")

    kwargs = {"cwd": os.getcwd()}
    if os.name == "nt":
        kwargs["creationflags"] = subprocess.CREATE_NEW_CONSOLE
    else:
        # Redirect stdout/stderr on POSIX
        kwargs["stdout"] = subprocess.DEVNULL  # Or open("orchestrator.log", "a")
        kwargs["stderr"] = subprocess.STDOUT

    try:
        return subprocess.Popen(cmd, **kwargs)
    except Exception as e:
        log_incident(f"Failed to start Orchestrator: {e}", status="ERROR")
        return None


def launch_nexus_gateway():
    """Launches the Nexus Gateway."""
    # Verify script exists
    full_gw_path = os.path.join(os.getcwd(), GATEWAY_SCRIPT)
    if not os.path.exists(full_gw_path):
        log_incident(f"⚠️ Gateway script not found: {GATEWAY_SCRIPT}", status="WARNING")
        return None

    cmd = [sys.executable, GATEWAY_SCRIPT]
    log_incident(f"Starting Nexus Gateway ({GATEWAY_SCRIPT})...")

    kwargs = {"cwd": os.getcwd()}
    if os.name == "nt":
        kwargs["creationflags"] = subprocess.CREATE_NEW_CONSOLE
    else:
        kwargs["stdout"] = subprocess.DEVNULL  # Or open("gateway.log", "a")
        kwargs["stderr"] = subprocess.STDOUT

    try:
        proc = subprocess.Popen(cmd, **kwargs)
        log_incident("Nexus Gateway Launched (Port 8000)", status="SUCCESS")
        return proc
    except Exception as e:
        log_incident(f"Failed to launch Gateway: {e}", status="CRITICAL")
        return None


def main():
    print("🔥 AEGIS WATCHDOG ONLINE (ORCHESTRATOR MODE) 🔥")
    print(f"Target: {TARGET_SCRIPT} | Gateway: {GATEWAY_SCRIPT}")

    # 1. Launch Gateway (The Nervous System)
    gateway_proc = launch_nexus_gateway()

    # Wait for Gateway to initialize
    time.sleep(2)

    # 2. Launch Orchestrator (The Brain)
    hub_proc = run_process()

    try:
        while True:
            time.sleep(CHECK_INTERVAL)

            # --- MONITOR ORCHESTRATOR ---
            if hub_proc:
                hub_ret = hub_proc.poll()
                if hub_ret is not None:
                    log_incident(
                        f"ORCHESTRATOR DIED (Code: {hub_ret}). Respawning...",
                        status="ERROR",
                    )
                    hub_proc = run_process()
            else:
                # Try to star it if it failed initially
                hub_proc = run_process()

            # --- MONITOR GATEWAY ---
            if gateway_proc:
                gw_ret = gateway_proc.poll()
                if gw_ret is not None:
                    log_incident(
                        f"GATEWAY DIED (Code: {gw_ret}). Respawning...",
                        status="CRITICAL",
                    )
                    gateway_proc = launch_nexus_gateway()
            else:
                gateway_proc = launch_nexus_gateway()

    except KeyboardInterrupt:
        log_incident("Watchdog stopping...")
        if hub_proc:
            hub_proc.terminate()
        if gateway_proc:
            gateway_proc.terminate()
        sys.exit(0)
    except Exception as e:
        log_incident(f"Watchdog Loop Error: {e}", status="CRITICAL")
        time.sleep(5)


if __name__ == "__main__":
    main()
