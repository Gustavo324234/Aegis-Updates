import subprocess
import time
import os
import sys
import datetime

# Configuration
TARGET_SCRIPT = "app_web.py"
CRASH_LOG = "crash_log.txt"
CHECK_INTERVAL = 10  # Seconds

def log_incident(message):
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_entry = f"[{timestamp}] {message}\n"
    print(log_entry.strip())
    try:
        with open(CRASH_LOG, "a", encoding="utf-8") as f:
            f.write(log_entry)
    except Exception as e:
        print(f"Failed to write to crash log: {e}")

def run_process():
    """Starts the target process."""
    cmd = [sys.executable, "-m", "streamlit", "run", TARGET_SCRIPT]
    log_incident(f"Starting {TARGET_SCRIPT}...")
    # Use Popen to run non-blocking
    return subprocess.Popen(cmd, cwd=os.getcwd())

def main():
    print("🔥 PROTOCOL PHOENIX WATCHDOG ACTIVE 🔥")
    print(f"Monitoring: {TARGET_SCRIPT}")
    
    process = run_process()
    
    try:
        while True:
            time.sleep(CHECK_INTERVAL)
            
            # Check if process is still running
            ret_code = process.poll()
            
            if ret_code is not None:
                # Process ended
                if ret_code != 0:
                    log_incident(f"⚠️ CRASH DETECTED! Exit Code: {ret_code}. Restarting in 3s...")
                else:
                    log_incident("⚠️ Process exited normally (0). Restarting to maintain persistence...")
                
                time.sleep(3)
                process = run_process()
                
    except KeyboardInterrupt:
        log_incident("Watchdog stopped by user.")
        process.terminate()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
        sys.exit(0)

if __name__ == "__main__":
    main()
