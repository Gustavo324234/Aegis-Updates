import subprocess
import time
import os
import sys
import datetime

# Configuration
# Configuration
# Configuration
import requests

# Configuration
TARGET_SCRIPT = "admin_launcher.py"
GATEWAY_SCRIPT = "modules/nexus_gateway.py"
CHECK_INTERVAL = 10  # Seconds



def log_incident(message, status="INFO"):
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_entry = f"[{timestamp}] {message}\n"
    print(log_entry.strip())
    
    # HTTP BRIDGE (Centralized Audit)
    # We call the Nexus Gateway to log this event
    try:
        requests.post("http://localhost:8000/log_event", json={
            "module": "WATCHDOG",
            "action": message[:50],
            "status": status,
            "details": message
        }, timeout=1)
    except:
        # Gateway might be down (which is why we are here often), so just ignore network errors.
        # Console output above is sufficient for local debugging.
        pass

def run_process():
    """Starts the target process (Streamlit Hub/Admin)."""
    cmd = [sys.executable, "-m", "streamlit", "run", TARGET_SCRIPT]
    log_incident(f"Starting {TARGET_SCRIPT}...")
    
    # Platform-specific flags for new console window
    kwargs = {'cwd': os.getcwd()}
    if os.name == 'nt':
        kwargs['creationflags'] = subprocess.CREATE_NEW_CONSOLE
    else:
        # Redirect stdout/stderr on POSIX
        kwargs['stdout'] = open("hub.log", "a")
        kwargs['stderr'] = subprocess.STDOUT
        # We don't detach unless user specifically wants, but let's assume we want to keep it manageable.
        # But this is watchdog, so it keeps handle. That's fine.

    return subprocess.Popen(cmd, **kwargs)

def launch_nexus_gateway():
    """Launches the Nexus Gateway in a separate console."""
    if not os.path.exists(GATEWAY_SCRIPT):
        log_incident(f"⚠️ Gateway script not found: {GATEWAY_SCRIPT}")
        return None  # Return None if not found

    cmd = [sys.executable, GATEWAY_SCRIPT]
    log_incident(f"Starting Nexus Gateway ({GATEWAY_SCRIPT})...")

    kwargs = {'cwd': os.getcwd()}
    if os.name == 'nt':
        kwargs['creationflags'] = subprocess.CREATE_NEW_CONSOLE
    else:
        # POSIX
        kwargs['stdout'] = open("gateway.log", "a")
        kwargs['stderr'] = subprocess.STDOUT
    
    
    try:
        proc = subprocess.Popen(cmd, **kwargs)
        log_incident("Nexus Gateway Launched (Port 8000)", status="SUCCESS")
        return proc
    except Exception as e:
        log_incident(f"Failed to launch Gateway: {e}", status="CRITICAL")
        return None

def main():
    print("🔥 PROTOCOL PHOENIX WATCHDOG ACTIVE 🔥")
    print(f"Monitoring: {TARGET_SCRIPT} & Launching Gateway")
    
    # 1. Launch Gateway
    gateway_proc = launch_nexus_gateway()
    
    # Wait for Gateway to initialize
    time.sleep(2)
    
    # 2. Launch & Monitor Hub
    hub_proc = run_process()
    
    try:
        while True:
            time.sleep(CHECK_INTERVAL)
            
            # --- MONITOR HUB ---
            if hub_proc:
                hub_ret = hub_proc.poll()
                if hub_ret is not None:
                    log_incident(f"HUB CRASH (Code: {hub_ret}). Restarting...", status="ERROR")
                    hub_proc = run_process()
            else:
                hub_proc = run_process()

            # --- MONITOR GATEWAY ---
            if gateway_proc:
                gw_ret = gateway_proc.poll()
                if gw_ret is not None:
                     log_incident(f"GATEWAY CRASH (Code: {gw_ret}). Restarting...", status="CRITICAL")
                     gateway_proc = launch_nexus_gateway()
            else:
                 gateway_proc = launch_nexus_gateway()
                
    except KeyboardInterrupt:
        log_incident("Watchdog stopped by user.")
        if hub_proc: hub_proc.terminate()
        if gateway_proc: gateway_proc.terminate()
    except Exception as e:
        log_incident(f"Watchdog Error: {e}")
        time.sleep(5)

if __name__ == "__main__":
    main()
