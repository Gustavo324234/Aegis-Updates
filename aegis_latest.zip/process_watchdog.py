import subprocess
import time
import os
import sys
import datetime

import logging

# Silence HF Hub Warnings in Watchdog too
logging.getLogger("huggingface_hub").setLevel(logging.ERROR)

# --- WATCHDOG CONFIGURATION ---
TARGET_SCRIPT = "server_aegis.py"  # El nuevo núcleo FastAPI
GATEWAY_SCRIPT = "modules/nexus_gateway.py"
MCP_GATEWAY_SCRIPT = "modules/mcp_gateway.py"
CHECK_INTERVAL = 10  # Seconds


def log_incident(message, status="INFO"):
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_entry = f"[{timestamp}] {message}"
    print(log_entry)

    # Optional: Log to file
    try:
        with open("watchdog.log", "a") as f:
            f.write(log_entry + "\n")
    except Exception:
        pass


def run_process(is_headless=False, port="8000"):
    """Starts the Orchestrator (server_aegis.py)."""
    # Verify script exists
    if not os.path.exists(TARGET_SCRIPT):
        log_incident(f"CRITICAL: {TARGET_SCRIPT} NOT FOUND!", status="CRITICAL")
        return None

    cmd = [sys.executable, TARGET_SCRIPT]

    log_incident(f"Starting Orchestrator: {TARGET_SCRIPT}...")

    kwargs = {"cwd": os.getcwd()}
    if os.name == "nt":
        kwargs["creationflags"] = subprocess.CREATE_NEW_CONSOLE
    else:
        # Redirect stdout/stderr on POSIX
        kwargs["stdout"] = subprocess.DEVNULL  # Or open("orchestrator.log", "a")
        kwargs["stderr"] = subprocess.STDOUT

    try:
        proc = subprocess.Popen(cmd, **kwargs)

        # Lázaro Protocol: Ping local server to trigger auto-heal early in headless mode
        def ping_server():
            time.sleep(3)
            try:
                import urllib.request

                urllib.request.urlopen(f"http://127.0.0.1:{port}/", timeout=2)
            except Exception:
                pass

        import threading

        threading.Thread(target=ping_server, daemon=True).start()

        return proc
    except Exception as e:
        log_incident(f"Failed to start Orchestrator: {e}", status="ERROR")
        return None


def launch_nexus_gateway():
    """Launches the Nexus Gateway."""
    # Verify script exists
    full_gw_path = os.path.join(os.getcwd(), GATEWAY_SCRIPT)
    if not os.path.exists(full_gw_path):
        log_incident(f"⚠️ Gateway script not found: {GATEWAY_SCRIPT}", status="WARNING")
        return None

    cmd = [sys.executable, GATEWAY_SCRIPT]
    log_incident(f"Starting Nexus Gateway ({GATEWAY_SCRIPT})...")

    kwargs = {"cwd": os.getcwd()}
    if os.name == "nt":
        kwargs["creationflags"] = subprocess.CREATE_NEW_CONSOLE
    else:
        kwargs["stdout"] = subprocess.DEVNULL  # Or open("gateway.log", "a")
        kwargs["stderr"] = subprocess.STDOUT

    try:
        proc = subprocess.Popen(cmd, **kwargs)
        log_incident("Nexus Gateway Launched (Port 8000)", status="SUCCESS")
        return proc
    except Exception as e:
        log_incident(f"Failed to launch Gateway: {e}", status="CRITICAL")
        return None


def launch_mcp_gateway():
    """Launches the Remote MCP Gateway (SSE)."""
    full_path = os.path.join(os.getcwd(), MCP_GATEWAY_SCRIPT)
    if not os.path.exists(full_path):
        log_incident(
            f"⚠️ MCP Gateway script not found: {MCP_GATEWAY_SCRIPT}", status="WARNING"
        )
        return None

    log_dir = "logs"
    os.makedirs(log_dir, exist_ok=True)
    log_file = os.path.join(log_dir, "mcp_gateway.log")

    cmd = [sys.executable, MCP_GATEWAY_SCRIPT]
    log_incident(f"Starting MCP Gateway ({MCP_GATEWAY_SCRIPT})...")

    kwargs = {"cwd": os.getcwd()}
    if os.name == "nt":
        # On Windows, we still use a console for visibility or hide it
        kwargs["creationflags"] = subprocess.CREATE_NEW_CONSOLE
    else:
        # On Linux/Headless, we capture to log file
        f = open(log_file, "a")
        kwargs["stdout"] = f
        kwargs["stderr"] = subprocess.STDOUT

    try:
        proc = subprocess.Popen(cmd, **kwargs)
        log_incident("Remote MCP Gateway Launched (Port 7000)", status="SUCCESS")
        return proc
    except Exception as e:
        log_incident(f"Failed to launch MCP Gateway: {e}", status="ERROR")
        return None


def main():
    print("🔥 AEGIS WATCHDOG ONLINE (ORCHESTRATOR MODE) 🔥")
    print(
        f"Target: {TARGET_SCRIPT} | Gateway: {GATEWAY_SCRIPT} | MCP: {MCP_GATEWAY_SCRIPT}"
    )

    is_headless = "--headless" in sys.argv
    data_root = None

    # Extract data root if provided
    for i, arg in enumerate(sys.argv):
        if arg == "--data-root" and i + 1 < len(sys.argv):
            data_root = sys.argv[i + 1]
            os.environ["AEGIS_USER_ROOT"] = data_root

    if is_headless:
        try:
            import socket

            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            lan = s.getsockname()[0]
            s.close()
        except Exception:
            lan = "Tu_IP_Local"

        print("\n" + "=" * 60)
        print("✅ CORE MASTER INICIADO. Accede al PANEL DE ADMINISTRACIÓN en:")
        print(f"👉 LAN IP:  http://{lan}:8000")
        print("👉 Local:   http://127.0.0.1:8000")
        print("=" * 60 + "\n")

    # 1. Launch Gateway (The Nervous System)
    gateway_proc = launch_nexus_gateway()

    # 1b. Launch MCP Gateway (The Bridge)
    mcp_proc = launch_mcp_gateway()

    # Wait for Gateway to initialize
    time.sleep(2)

    # 2. Launch Orchestrator (The Brain)
    hub_proc = run_process(is_headless=is_headless)

    # Loop de monitoreo eterno

    try:
        while True:
            time.sleep(CHECK_INTERVAL)

            # --- MONITOR ORCHESTRATOR ---
            if hub_proc:
                hub_ret = hub_proc.poll()
                if hub_ret is not None:
                    log_incident(
                        f"ORCHESTRATOR DIED (Code: {hub_ret}). Respawning...",
                        status="ERROR",
                    )
                    hub_proc = run_process(is_headless=is_headless)
            else:
                # Try to star it if it failed initially
                hub_proc = run_process(is_headless=is_headless)

            # --- MONITOR GATEWAY ---
            if gateway_proc:
                gw_ret = gateway_proc.poll()
                if gw_ret is not None:
                    log_incident(
                        f"GATEWAY DIED (Code: {gw_ret}). Respawning...",
                        status="CRITICAL",
                    )
                    gateway_proc = launch_nexus_gateway()
            else:
                gateway_proc = launch_nexus_gateway()

            # --- MONITOR MCP GATEWAY ---
            if mcp_proc:
                mcp_ret = mcp_proc.poll()
                if mcp_ret is not None:
                    log_incident(
                        f"MCP GATEWAY DIED (Code: {mcp_ret}). Respawning...",
                        status="ERROR",
                    )
                    mcp_proc = launch_mcp_gateway()
            else:
                mcp_proc = launch_mcp_gateway()

    except KeyboardInterrupt:
        log_incident(
            "Watchdog deteniéndose... PRESIONA CTRL+C DE NUEVO RAUDAMENTE PARA PANIC KILL 🚨",
            status="WARNING",
        )

        # Wait up to 1.5 seconds for a second Ctrl+C
        panic_triggered = False
        try:
            time.sleep(1.5)
        except KeyboardInterrupt:
            panic_triggered = True

        if panic_triggered:
            log_incident(
                "🚨 PROTOCOLO FÉNIX: PANIC KILL ACTIVADO 🚨", status="CRITICAL"
            )
            log_incident(
                "Purging all Docker containers and Sub-Agents...", status="CRITICAL"
            )
            try:
                subprocess.run(
                    "docker kill $(docker ps -q)",
                    shell=True,
                    stderr=subprocess.DEVNULL,
                    stdout=subprocess.DEVNULL,
                )
                subprocess.run(
                    "docker rm $(docker ps -a -q)",
                    shell=True,
                    stderr=subprocess.DEVNULL,
                    stdout=subprocess.DEVNULL,
                )
            except Exception:
                pass
            log_incident(
                "Limpieza completa. Terminando el sistema de forma abrupta.",
                status="CRITICAL",
            )
            if hub_proc:
                hub_proc.kill()
            if gateway_proc:
                gateway_proc.kill()
            if mcp_proc:
                mcp_proc.kill()
            sys.exit(1)
        else:
            # Graceful shutdown
            if hub_proc:
                hub_proc.terminate()
            if gateway_proc:
                gateway_proc.terminate()
            if mcp_proc:
                mcp_proc.terminate()
            sys.exit(0)
    except Exception as e:
        log_incident(f"Watchdog Loop Error: {e}", status="CRITICAL")
        time.sleep(5)


if __name__ == "__main__":
    main()
