import paramiko


def ssh_exec_manual(host, user, password, remote_base):
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(host, username=user, password=password, timeout=10)

    python_bin = f"{remote_base}/.venv/bin/python"
    command = f"cd {remote_base} && {python_bin} process_watchdog.py --headless"

    print(f"Running: {command}")
    stdin, stdout, stderr = client.exec_command(command)

    # We read a bit of output to see if it starts
    import time

    time.sleep(2)

    out = ""
    if stdout.channel.recv_ready():
        out += stdout.channel.recv(1024).decode()
    if stderr.channel.recv_ready():
        out += "ERR: " + stderr.channel.recv(1024).decode()

    client.close()
    return out


if __name__ == "__main__":
    print(ssh_exec_manual("192.168.1.9", "diego", "@34345196", "/home/diego/Aegis-IA"))
