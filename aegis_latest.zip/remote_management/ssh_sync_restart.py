import paramiko
import os
import glob


def ssh_sync_and_restart(host, user, password, local_base, remote_base):
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect(host, username=user, password=password, timeout=10)
        sftp = client.open_sftp()

        # Files and directories to sync
        items_to_sync = [
            "server_aegis.py",
            "process_watchdog.py",
            "database.py",
            "services/db/schema.py",
            "services/db/audit.py",
            "services/db/ops.py",
            "services/db/chat.py",
            "services/db/nexus.py",
            "services/db/connection.py",
            "ui_client/src/App.jsx",
            "ui_client/src/main.jsx",
            "ui_client/src/store/useSystemStore.js",
            "ui_client/src/store/useChatStore.js",
            "ui_client/src/components/*.jsx",
            "ui_client/src/views/*.jsx",
            "ui_client/vite.config.js",
            "ui_client/package.json",
            "ui_client/tailwind.config.js",
            "ui_client/postcss.config.js",
        ]

        def mkdir_p(sftp, remote_directory):
            if remote_directory in ["/", "", "."]:
                return
            try:
                sftp.chdir(remote_directory)
            except IOError:
                dirname, basename = os.path.split(remote_directory.rstrip("/"))
                mkdir_p(sftp, dirname)
                try:
                    sftp.mkdir(basename)
                except:
                    pass
                sftp.chdir(basename)

        for item in items_to_sync:
            # Expand globs
            local_pattern = os.path.join(local_base, item.replace("/", os.sep))
            for local_path in glob.glob(local_pattern):
                if os.path.isdir(local_path):
                    continue

                # Relative path from local_base
                rel_path = os.path.relpath(local_path, local_base)
                remote_path = os.path.join(
                    remote_base, rel_path.replace("\\", "/")
                ).replace("\\", "/")

                print(f"Syncing {rel_path}...")
                remote_dir = os.path.dirname(remote_path)
                mkdir_p(sftp, remote_dir)
                sftp.put(local_path, remote_path)

        sftp.close()

        # Kill old processes
        print("Cleaning up processes...")
        # Use sudo -S to pass password to sudo
        client.exec_command(f"echo {password} | sudo -S pkill -f python")
        client.exec_command(f"echo {password} | sudo -S pkill -f uvicorn")
        client.exec_command(f"echo {password} | sudo -S pkill -f streamlit")

        # Build frontend
        print("Building UI on remote (this might take a while)...")
        stdin, stdout, stderr = client.exec_command(
            f"cd {remote_base}/ui_client && npm run build"
        )
        exit_status = stdout.channel.recv_exit_status()
        if exit_status != 0:
            print(f"Build failed with status {exit_status}")
            print(stderr.read().decode())

        # Start Master Server via systemd for better persistence
        print("Restarting aegis-core service...")
        client.exec_command(
            f"echo {password} | sudo -S systemctl restart aegis-core.service"
        )

        client.close()
        return True, "Sync and Restart completed."
    except Exception as e:
        return False, str(e)


if __name__ == "__main__":
    success, msg = ssh_sync_and_restart(
        "192.168.1.9", "diego", "@34345196", "e:/Aegis-IA", "/home/diego/Aegis-IA"
    )
    print(msg)
