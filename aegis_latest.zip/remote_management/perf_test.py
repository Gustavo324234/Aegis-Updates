import requests
import time
import sys


def test_ollama(host="http://127.0.0.1:11434"):
    print(f"Testing Ollama at {host}...")

    # 1. Tags
    start = time.time()
    try:
        r = requests.get(f"{host}/api/tags", timeout=5)
        print(f"[TAGS] Status: {r.status_code}, Time: {time.time() - start:.2f}s")
    except Exception as e:
        print(f"[TAGS] FAILED: {e}")

    # 2. Embeddings (mxbai-embed-large)
    model_emb = "mxbai-embed-large"
    print(f"Testing Embeddings with {model_emb}...")
    start = time.time()
    try:
        r = requests.post(
            f"{host}/api/embeddings",
            json={"model": model_emb, "prompt": "Confirmar estado de sistema local"},
            timeout=20,
        )
        print(f"[EMB] Status: {r.status_code}, Time: {time.time() - start:.2f}s")
    except Exception as e:
        print(f"[EMB] FAILED: {e}")

    # 3. Simple Chat (llama3.2:3b)
    model_chat = "llama3.2:3b"
    print(f"Testing Chat with {model_chat}...")
    start = time.time()
    try:
        payload = {
            "model": model_chat,
            "messages": [{"role": "user", "content": "hola, responde brevemente"}],
            "stream": False,
        }
        r = requests.post(f"{host}/api/chat", json=payload, timeout=60)
        print(f"[CHAT] Status: {r.status_code}, Time: {time.time() - start:.2f}s")
        if r.status_code == 200:
            print(f"Response: {r.json().get('message', {}).get('content')}")
    except Exception as e:
        print(f"[CHAT] FAILED: {e}")


if __name__ == "__main__":
    test_ollama()
