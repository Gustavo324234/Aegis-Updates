import paramiko


def ssh_read(host, user, password, path):
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect(host, username=user, password=password, timeout=10)
        sftp = client.open_sftp()
        with sftp.open(path, "r") as f:
            content = f.read().decode()
        sftp.close()
        client.close()
        return content
    except Exception as e:
        return str(e)


if __name__ == "__main__":
    host = "192.168.1.9"
    user = "diego"
    password = "@34345196"

    print(
        ssh_read(host, user, password, "/home/diego/Aegis-IA/process_watchdog.py")[
            0:500
        ]
    )
