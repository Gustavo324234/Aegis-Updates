import asyncio
import httpx
import json
import os
import sys

# Agregamos el path de mcp por las dudas si no está instalado globalmente
# Pero asumimos que está disponible como en el servidor.
try:
    from mcp.client.sse import sse_client
    from mcp.client.session import ClientSession
except ImportError:
    print("Error: La librería 'mcp' no está instalada en este entorno.")
    sys.exit(1)


async def check_mcp_gateway(url):
    print(f"Intentando conectar a {url}...")
    try:
        async with sse_client(url) as streams:
            async with ClientSession(streams[0], streams[1]) as session:
                print("Inicializando sesión...")
                await session.initialize()

                print("Listando herramientas...")
                tools_resp = await session.list_tools()
                tools = tools_resp.tools
                print(f"Herramientas encontradas: {[t.name for t in tools]}")

                # Intentamos acceder a la base de datos
                print("Verificando acceso a la base de datos de Aegis...")
                result = await session.call_tool(
                    "query_aegis_memory",
                    {
                        "sql_query": "SELECT name FROM sqlite_master WHERE type='table' LIMIT 5;"
                    },
                )

                print("\nResultado de la base de datos:")
                print(result.content[0].text)

                return True
    except Exception as e:
        print(f"Error durante la conexión/ejecución: {e}")
        return False


if __name__ == "__main__":
    # Probamos con localhost ya que detectamos que el servicio corre ahí
    url = "http://localhost:7000/mcp/sse"
    asyncio.run(check_mcp_gateway(url))
