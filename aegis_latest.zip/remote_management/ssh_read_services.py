import paramiko


def ssh_exec(host, user, password, command):
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(host, username=user, password=password, timeout=10)
    stdin, stdout, stderr = client.exec_command(f"echo {password} | sudo -S {command}")
    return stdout.read().decode("utf-8", "ignore")


if __name__ == "__main__":
    host = "192.168.1.9"
    user = "diego"
    password = "@34345196"

    print("Reading aegis.service:")
    print(ssh_exec(host, user, password, "cat /etc/systemd/system/aegis.service"))

    print("\nReading aegis-core.service:")
    print(ssh_exec(host, user, password, "cat /etc/systemd/system/aegis-core.service"))
