import paramiko
import sys


def ssh_exec(host, user, password, command):
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect(host, username=user, password=password, timeout=10)
        stdin, stdout, stderr = client.exec_command(command)
        out = stdout.read().decode()
        err = stderr.read().decode()
        client.close()
        return out, err
    except Exception as e:
        return None, str(e)


if __name__ == "__main__":
    host = "192.168.1.9"
    user = "diego"
    password = "@34345196"

    # 1. Check directory structure
    print("--- Check Directory ---")
    out, err = ssh_exec(host, user, password, "ls -R | grep server_aegis.py")
    if out:
        print("Found server_aegis.py at paths:")
        print(out)
    else:
        print("Not found in home. checking /opt or other common places...")
        out, err = ssh_exec(host, user, password, "ls /")
        print("Root folders:", out)

    # 2. Check running processes
    print("\n--- Check Processes ---")
    out, err = ssh_exec(host, user, password, "ps aux | grep python")
    print(out)

    # 3. Check ports
    print("\n--- Check Ports ---")
    out, err = ssh_exec(host, user, password, "netstat -tuln | grep 8000")
    print(out)
