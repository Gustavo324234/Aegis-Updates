import paramiko


def ssh_exec(host, user, password, command):
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(host, username=user, password=password, timeout=10)
    client.exec_command(command)
    client.close()


if __name__ == "__main__":
    host = "192.168.1.9"
    user = "diego"
    password = "@34345196"
    remote_base = "/home/diego/Aegis-IA"
    python_bin = f"{remote_base}/.venv/bin/python"

    # Intento con tmux (si existe) o usando setsid
    # setsid corre el proceso en una nueva sesión
    cmd = f"cd {remote_base} && setsid {python_bin} process_watchdog.py --headless > watchdog_persistent.log 2>&1 &"
    print(f"Running: {cmd}")
    ssh_exec(host, user, password, cmd)
