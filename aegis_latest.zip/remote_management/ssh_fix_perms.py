import paramiko


def ssh_exec_sudo(client, password, command):
    stdin, stdout, stderr = client.exec_command(f"echo {password} | sudo -S {command}")
    return stdout.read().decode("utf-8", "ignore")


def fix_permissions(host, user, password, remote_base):
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect(host, username=user, password=password, timeout=10)

        print("Fixing permissions...")
        ssh_exec_sudo(client, password, f"chown -R {user}:{user} {remote_base}")
        ssh_exec_sudo(client, password, f"chmod -R 755 {remote_base}")
        # Bases de datos necesitan 666 o al menos ser escribibles por el usuario
        ssh_exec_sudo(
            client, password, f"find {remote_base} -name '*.db' -exec chmod 664 {{}} +"
        )

        print("Restarting service...")
        ssh_exec_sudo(client, password, "systemctl restart aegis-core.service")

        client.close()
        return True, "Permissions fixed and service restarted."
    except Exception as e:
        return False, str(e)


if __name__ == "__main__":
    success, msg = fix_permissions(
        "192.168.1.9", "diego", "@34345196", "/home/diego/Aegis-IA"
    )
    print(msg)
