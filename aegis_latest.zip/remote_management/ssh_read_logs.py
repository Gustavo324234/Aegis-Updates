import paramiko


def ssh_exec(host, user, password, command):
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(host, username=user, password=password, timeout=10)
    stdin, stdout, stderr = client.exec_command(f"echo {password} | sudo -S {command}")
    return stdout.read().decode("utf-8", "ignore")


if __name__ == "__main__":
    host = "192.168.1.9"
    user = "diego"
    password = "@34345196"

    out = ssh_exec(
        host, user, password, "journalctl -u aegis-core.service -n 50 --no-pager"
    )
    print("JOURNAL_LOGS:")
    # Filtrar no-ascii
    print("".join([i if ord(i) < 128 else " " for i in out]))
