import paramiko


def ssh_exec_sudo(client, password, command):
    print(f"Executing: {command}")
    stdin, stdout, stderr = client.exec_command(f"echo {password} | sudo -S {command}")
    return stdout.read().decode("utf-8", "ignore"), stderr.read().decode(
        "utf-8", "ignore"
    )


def final_remote_fix(host, user, password, remote_base):
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect(host, username=user, password=password, timeout=10)

        # 1. Stop services
        ssh_exec_sudo(client, password, "systemctl stop aegis.service")
        ssh_exec_sudo(client, password, "systemctl disable aegis.service")
        ssh_exec_sudo(client, password, "systemctl stop aegis-core.service")

        # 2. Kill all python processes
        ssh_exec_sudo(client, password, "pkill -f python")

        # 3. Build UI
        print("Re-building UI...")
        client.exec_command(
            f"cd {remote_base}/ui_client && npm install && npm run build"
        )

        # 4. Launch Watchdog
        print("Launching Watchdog (Master Mode)...")
        # Ensure we use the full path to python in the venv
        python_bin = f"{remote_base}/.venv/bin/python"
        launch_cmd = f"cd {remote_base} && nohup {python_bin} process_watchdog.py --headless > /home/diego/Aegis-IA/watchdog_startup.log 2>&1 &"
        client.exec_command(launch_cmd)

        client.close()
        return True, "Master Server Restarted successfully on remote."
    except Exception as e:
        return False, str(e)


if __name__ == "__main__":
    success, msg = final_remote_fix(
        "192.168.1.9", "diego", "@34345196", "/home/diego/Aegis-IA"
    )
    print(msg)
