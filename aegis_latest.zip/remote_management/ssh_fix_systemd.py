import paramiko


def ssh_exec_sudo(client, password, command):
    stdin, stdout, stderr = client.exec_command(f"echo {password} | sudo -S {command}")
    return stdout.read().decode("utf-8", "ignore")


def fix_systemd(host, user, password, remote_base):
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect(host, username=user, password=password, timeout=10)

        # New service definition
        service_content = f"""[Unit]
Description=Aegis-IA Unified Core Service (Master)
After=network.target

[Service]
User=diego
Group=diego
WorkingDirectory={remote_base}
ExecStart={remote_base}/.venv/bin/python {remote_base}/server_aegis.py
Restart=always
Environment=PYTHONUNBUFFERED=1
Environment=AEGIS_PRODUCTION=true
Environment=AEGIS_USER_ROOT={remote_base}
Environment=PATH={remote_base}/.venv/bin:/usr/local/bin:/usr/bin:/bin

[Install]
WantedBy=multi-user.target
"""
        # Write to temp file
        with open("aegis-core.service", "w") as f:
            f.write(service_content)

        # Upload
        sftp = client.open_sftp()
        sftp.put("aegis-core.service", "/tmp/aegis-core.service")
        sftp.close()

        # Move to systemd and reload
        ssh_exec_sudo(
            client,
            password,
            "mv /tmp/aegis-core.service /etc/systemd/system/aegis-core.service",
        )
        ssh_exec_sudo(client, password, "systemctl daemon-reload")
        ssh_exec_sudo(client, password, "systemctl stop aegis.service")
        ssh_exec_sudo(client, password, "systemctl disable aegis.service")
        ssh_exec_sudo(client, password, "systemctl stop aegis-core.service")
        # Ensure all python processes are dead
        ssh_exec_sudo(client, password, "pkill -f python")

        # Start
        ssh_exec_sudo(client, password, "systemctl start aegis-core.service")

        # Check status
        status = ssh_exec_sudo(client, password, "systemctl status aegis-core.service")
        print("Final Status:")
        print(status)

        client.close()
        return True, "Service updated and started."
    except Exception as e:
        return False, str(e)


if __name__ == "__main__":
    success, msg = fix_systemd(
        "192.168.1.9", "diego", "@34345196", "/home/diego/Aegis-IA"
    )
    print(msg)
