import paramiko


def ssh_exec_sudo(client, password, command):
    stdin, stdout, stderr = client.exec_command(f"echo {password} | sudo -S {command}")
    return stdout.read().decode("utf-8", "ignore")


def final_attempt(host, user, password, remote_base):
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect(host, username=user, password=password, timeout=10)

        # Kill everything
        ssh_exec_sudo(client, password, "pkill -f python")

        # Start watchdog
        python_bin = f"{remote_base}/.venv/bin/python"
        cmd = f"cd {remote_base} && nohup {python_bin} process_watchdog.py --headless > watchdog_persistent.log 2>&1 &"
        print(f"Executing: {cmd}")
        client.exec_command(cmd)

        import time

        time.sleep(2)

        # Check if it's running
        stdin, stdout, stderr = client.exec_command("ps aux | grep process_watchdog.py")
        print("Check process:")
        print(stdout.read().decode())

        client.close()
        return True, "Done"
    except Exception as e:
        return False, str(e)


if __name__ == "__main__":
    final_attempt("192.168.1.9", "diego", "@34345196", "/home/diego/Aegis-IA")
