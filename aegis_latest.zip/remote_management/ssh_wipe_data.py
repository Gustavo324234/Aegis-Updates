import paramiko


def ssh_exec_sudo(client, password, command):
    stdin, stdout, stderr = client.exec_command(f"echo {password} | sudo -S {command}")
    return stdout.read().decode("utf-8", "ignore")


def wipe_remote_data(host, user, password, remote_base):
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect(host, username=user, password=password, timeout=10)

        print("Stopping services...")
        ssh_exec_sudo(client, password, "systemctl stop aegis-core.service")
        ssh_exec_sudo(client, password, "pkill -f python")

        print("Wiping data...")
        # Remove main DB and users folder
        ssh_exec_sudo(client, password, f"rm -rf {remote_base}/aegis_memory.db")
        ssh_exec_sudo(client, password, f"rm -rf {remote_base}/users/*")
        ssh_exec_sudo(client, password, f"rm -rf {remote_base}/tenants_registry.json")

        # Also clean logs for a fresh start
        ssh_exec_sudo(client, password, f"rm -rf {remote_base}/logs/*")

        print("Restarting service...")
        ssh_exec_sudo(client, password, "systemctl start aegis-core.service")

        client.close()
        return True, "Remote DB and Users wiped. System restarted."
    except Exception as e:
        return False, str(e)


if __name__ == "__main__":
    success, msg = wipe_remote_data(
        "192.168.1.9", "diego", "@34345196", "/home/diego/Aegis-IA"
    )
    print(msg)
