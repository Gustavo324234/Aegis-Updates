import paramiko


def ssh_exec(host, user, password, command):
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(host, username=user, password=password, timeout=10)
    stdin, stdout, stderr = client.exec_command(command)
    return stdout.read().decode("utf-8", "ignore")


if __name__ == "__main__":
    host = "192.168.1.9"
    user = "diego"
    password = "@34345196"

    print("Reading watchdog_startup.log:")
    print(
        ssh_exec(host, user, password, "cat /home/diego/Aegis-IA/watchdog_startup.log")
    )
