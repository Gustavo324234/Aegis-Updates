# AEGIS-IA: The Singularity (v20)
**Version 20.0 | Codename: "The Big Bang"**

Aegis-IA is a **Sovereign AI Operating System** designed for complete data privacy, offline capability, and autonomous coding. It integrates a powerful Chat UI, a decentralized Mesh Network (Nexus), and a fully synchronized Cloud IDE (The Forge).

---

## 🚀 Installation & Deployment

### 1. The Core (Server/Host) - Linux (Recommended)
This installs the Aegis Dashboard, The Forge (IDE), and the Nexus Gateway as system services.

```bash
# Clone the repository
git clone https://github.com/YourRepo/Aegis-IA.git
cd Aegis-IA

# Run the Master Installer
# This handles Python dependencies, Code-Server installation, and Systemd services.
python3 setup.py --sre-deploy
```

**Access Points:**
- **🖥️ Dashboard:** `http://[SERVER_IP]:8501` (Chat, Memory, Admin)
- **🛠️ The Forge IDE:** `http://[SERVER_IP]:8080` (VS Code with Auto-Synced AI)
- **🔗 Nexus Gateway:** `http://[SERVER_IP]:8000` (WebSocket Mesh)

### 2. The Satellite (Client) - Windows
Execute tasks remotely and sync files from your Windows Desktop.

1.  Download `AegisSatellite.exe` from the server (or build it using `python tools/build_installer.py`).
2.  Run the executable. It will appear in your **System Tray**.
3.  On first run, it will ask to **Pair**.
4.  Go to the Aegis Dashboard -> **Network Mesh** -> **Generate Pairing Code**.
5.  Enter the code in the Satellite popup.

---

## 🛠️ Features

### 🧠 The Singularity Core
-   **Multi-Model Intelligence:** Switches seamlessly between Local (Ollama) and Cloud (Gemini, OpenAI, Anthropic) models based on task complexity.
-   **Infinite Memory:** Uses "Protocol Chronos" to summarize and retain context indefinitely.
-   **Sovereign Mode:** Can operate 100% offline using local LLMs.

### 🌐 Project Nexus (Mesh Network)
-   **Decentralized Intelligence:** Connect multiple devices (Limbs) to share processing power and files.
-   **Encrypted Transport:** All communication between nodes is encrypted with Fernet/AES.
-   **Offline Queue:** Messages sent to offline nodes are encrypted and stored until they reconnect.

### ⚒️ The Forge (Integrated IDE)
-   **Zero-Config AI Coding:** Clicking "The Forge" in the dashboard opens a VS Code instance where the **"Continue" extension is pre-configured** with your Aegis settings (API Keys, Local Models).
-   **Browser-Based:** Code from any device, anywhere.

---

## 🔒 Security
-   **Audit Logs:** Every AI action is logged in an immutable SQLite audit trail.
-   **Sandboxing:** File operations are restricted to the `AEGIS_USER_ROOT` directory.
-   **Role-Based Access:** Validates API keys and Pairing Codes for all network operations.

---

## 💻 Tech Stack
-   **Core:** Python 3.11+, Streamlit, FastAPI
-   **AI:** Google Gemini, Ollama, LangChain
-   **Network:** WebSockets, Fernet Encryption
-   **IDE:** Code-Server, Continue Extension

---
*Built for the Architect.*
