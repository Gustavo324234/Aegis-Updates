# Aegis Capabilities

This file is auto-generated. It lists all available modules and their descriptions.

## auth_vault

No description available.


## backup_manager

No description available.


## beacon

No description available.


## bridge_browser

No description available.


## browser_tools

Use this module to interact with the web.
Commands:
1. Navigate: {"module": "browser_tools", "action": "navigate", "url": "https://example.com"}
2. Scrape (Focus): {"module": "browser_tools", "action": "scrape"} -> Devuelve el árbol interactivo de la página con referencias [ref=eX].
3. Click: {"module": "browser_tools", "action": "click", "ref": "e12"}
4. Type: {"module": "browser_tools", "action": "type", "ref": "e14", "text": "hello"}
5. Visual Query (NEW): {"module": "browser_tools", "action": "visual_query", "url": "https://example.com", "question": "What is the account balance shown?"}


## codex

No description available.


## cron_manager

Module: cron_manager
Purpose: Schedule recurring tasks using natural language.
Actions:
- schedule_task: Registers a new repeating task.
Usage: {"module": "cron_manager", "action": "schedule_task", "args": {"natural_time": "every day at 9am", "task_description": "check disk space"}}


## daemon_manager

No description available.


## data_architect

No description available.


## db_logger

No description available.


## docker_sandbox

No description available.


## env_probe

No description available.


## file_writer

Module: file_writer
Purpose: Controlled File Writing. Allows the AI to write text or code to a file in the workspace.
Actions:
- write_file: Writes content to a specific file path inside the workspace. Will overwrite if exists.
- submit_system_improvement: Submits a proposal to improve a core/sensitive file.
  The AI cannot modify sensitive files directly; this action writes a proposal report to
  workspace/proposals/ and emails it to the Architect for manual review and approval.

Usage format:
  write_file:
    {"module": "file_writer", "action": "write_file", "args": {"path": "main.py", "content": "print('Hello World')"}}
  submit_system_improvement:
    {"module": "file_writer", "action": "submit_system_improvement", "args": {"filename": "brain.py", "description": "Improve context handling", "proposed_code": "..."}}


## galactic_store

No description available.


## ide_bridge

No description available.


## identity_manager

Module: identity_manager
Purpose: Active memory management. Allows the AI to save user preferences and facts to long-term memory.
Actions:
- update_preference: Saves a key-value pair as a user fact.
Usage format:
{"module": "identity_manager", "action": "update_preference", "args": {"key": "user_name", "value": "Diego", "category": "identity"}}
{"module": "identity_manager", "action": "update_preference", "args": {"key": "coding_style", "value": "concise", "category": "preference"}}


## json_healer

No description available.


## life_manager

Use this module to manage the user's personal life: Expenses, Tasks, and Contexts (Projects).

Commands:
1. Expenses:
   {"module": "life_manager", "action": "add_expense", "amount": 10.5, "category": "Food", "desc": "Lunch"}
   
2. Tasks/Calendar:
   {"module": "life_manager", "action": "add_task", "task": "Buy milk", "due_date": "Tomorrow"}
   {"module": "life_manager", "action": "schedule_event", "event": "Meeting using X", "time": "2023-10-20 10:00"}
   {"module": "life_manager", "action": "complete_task", "task_id": 1}
   {"module": "life_manager", "action": "complete_objective", "objective": "Learn to play guitar"}

3. Context/Projects:
   {"module": "life_manager", "action": "switch_context", "context": "project_name"}
   {"module": "life_manager", "action": "create_project", "name": "project_name", "content": "initial notes"}

Rules:
- If the user talks about a project, switch context to it if it exists.
- If the user wants to go back to normal chat, switch context to 'general'.


## nexus_gateway

No description available.


## notifier

No description available.


## project_manager

Active Project Manager for User Private Workspace.


## project_oracle

Module: project_oracle
Purpose: Workspace Awareness. Allows the AI to read, search, and understand the project structure and file contents.
Actions:
- list_structure: Scans the current directory tree (ignoring git/cache) to generate a file map.
- read_files: Reads the content of a list of specific files.
- search_code: Searches for a keyword or regex in the project files.
Usage format:
{"module": "project_oracle", "action": "list_structure", "args": {"root_path": "."}}
{"module": "project_oracle", "action": "read_files", "args": {"file_paths": ["main.py", "utils.py"]}}
{"module": "project_oracle", "action": "search_code", "args": {"query": "def my_func", "root_path": "."}}


## resource_monitor

No description available.


## satellite_bridge

No description available.


## skill_builder

Use this module to CREATE or MODIFY SKILLS (Self-Programming).
If you encounter a problem you cannot solve with current modules, propose a new module code.
CRITICAL FOR "APPS": If user asks for an App, CREATE A STANDALONE SCRIPT.
- Use standard libraries (random, datetime, math) or propose `pip install` in instructions.
- Do NOT invent modules. WRITE THE CODE.

Commands:
1. Propose New Skill:
   {"module": "skill_builder", "action": "propose_skill", "filename": "new_skill.py", "code": "full_python_code"}

2. Read Existing Skill (for Refactoring):
   {"module": "skill_builder", "action": "read_skill", "filename": "existing_skill.py"}

3. Rollback Skill (Restore Backup):
   {"module": "skill_builder", "action": "rollback_skill", "filename": "broken_skill.py"}

Rules:
- The 'code' must include a DESCRIPTION string and an execute(query) function.
- The system will validation with Sentinel before installation.
- Refactoring: Use 'read_skill' to get current code, then 'propose_skill' with improved code.


## soul_sync

No description available.


## studio_exporter

No description available.


## subagent_spawner

Use this module to delegate tasks to a Background Subagent.
A subagent works silently, has a fresh memory context to save tokens, and can use tools independently.
When finished, it will report back to you via an [SUBAGENT_ANNOUNCE] event.
Commands:
- spawn_subagent: {"module": "subagent_spawner", "action": "spawn", "task_description": "Create a python script that does X...", "tools_needed": ["system_tools", "file_writer"]}


## synapse

Module: synapse
Purpose: Ejecuta integraciones externas (Skills) pasándole comandos REST/CLI generados o parametrizados en base a archivos Markdown.


## system_doctor

Module: system_doctor
Purpose: Self-diagnosis and troubleshooting. Allows Aegis to inspect internal logs.
Actions:
- check_logs: Retrieves the latest error or failure logs from the audit table.
- status: Returns detailed system status report.
Usage format:
{"module": "system_doctor", "action": "check_logs", "args": {"limit": 10}}
{"module": "system_doctor", "action": "status", "args": {}}


## system_service

No description available.


## system_tools

Module: system_tools
Purpose: Interact with the underlying OS (Terminal, File System).
Safety: Command execution is sandboxed to the user's workspace.
Actions:
- terminal: Execute shell commands. Commands longer than 3s auto-detach to background.
- poll_process: Check progress of a background Job ID. Args: {"job_id": "..."}
- sysinfo: Get system stats.
- shutdown: EMERGENCY ONLY.
Usage format:
    {"module": "system_tools", "action": "terminal", "args": {"command": "npm install"}}
    {"module": "system_tools", "action": "poll_process", "args": {"job_id": "abc12345"}}


## unifier

No description available.


## updater

No description available.


## uplink

Module: uplink
Purpose: Secure communication channel for the AI to submit improvement proposals
         to the Architect (human operator) via Email. The AI CANNOT self-modify;
         instead it uses this module to request changes that a human must review
         and apply manually.
Actions:
- submit_system_improvement: Writes a proposal file and sends it to the Architect.
Usage format:
{"module": "uplink", "action": "submit_system_improvement", "args": {"filename": "brain.py", "description": "Improve context window handling", "proposed_code": "..."}}


## utils

No description available.


## validator

No description available.


## vault_manager

No description available.


## web_reader

Module: web_reader
Purpose: Deep analysis of web content. Extracts clean text from URLs.
Actions:
- scrape: Fetches and cleans the main content of a webpage.
Usage format:
{"module": "web_reader", "action": "scrape", "args": {"url": "https://example.com/article"}}


## web_search

Module: web_search
Purpose: Connect to the Internet to find real-time information.
Actions:
- search: Perform a web search and return top 5 results with snippets.
Usage format:
{"module": "web_search", "action": "search", "args": {"query": "Bitcoin price today"}}

