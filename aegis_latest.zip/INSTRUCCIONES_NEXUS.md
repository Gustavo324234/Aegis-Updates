# Manual de Operaciones: The Nexus Mesh (v14.0)

Bienvenido a la versión final de The Nexus Mesh. Este documento detalla cómo operar la red distribuida entre tu Notebook (Cerebro/Hub) y tu PC de Escritorio (Satélite/Limb).

## 0. Instalación de Dependencias

Antes de comenzar, asegúrate de que ambos dispositivos tengan las librerías necesarias. El script `setup.py` ha sido actualizado para incluirlas.

En la **Notebook** y en la **PC Satélite**:
```bash
python setup.py
# O instalar manualmente:
pip install streamlit fastapi uvicorn websockets cryptography plyer requests
```

---

## 1. Iniciando el Gateway (Cerebro)

El Gateway es el sistema nervioso central que corre en tu Notebook.

1.  Abre una terminal en la carpeta `Aegis-IA`.
2.  Ejecuta el Gateway:
    ```bash
    python modules/nexus_gateway.py
    ```
    *Verás: "INFO: Started server process" en el puerto 8000.*

3.  En otra terminal, inicia la interfaz web (Aegis Brain):
    ```bash
    streamlit run app_web.py
    ```

---

## 2. Emparejando el Satélite (PC Escritorio)

Para conectar tu PC potente a la red de forma segura:

1.  **En la Notebook (Web UI)**:
    - Ve a la barra lateral -> Despliega **"🌐 Network Mesh"**.
    - Busca la sección **"🔗 Device Pairing"**.
    - Haz clic en **"Generate Pairing Code"**.
    - Copia el código de 6 dígitos (ej: `123456`) o escanea el QR.

2.  **En la PC Escritorio (Satélite)**:
    - Navega a la carpeta donde tengas `aegis_limb.py`.
    - Ejecuta el satélite:
        ```bash
        python aegis_limb.py
        ```
    - La consola te pedirá: `Enter Pairing Code:`.
    - Ingresa el código generado en el paso 1.

**Resultado:**
- Verás `✅ Registration Successful. Keys Exchanged.`
- El satélite quedará conectado y esperando órdenes.
- Si cierras el satélite, la próxima vez se reconectará automáticamente sin pedir código (mientras no borres `aegis_limb_config.json`).

---

## 3. Operaciones Remotas

### A. Botón "🚀 Enviar a Antigravity"
Cuando Aegis genere un bloque de código en el chat:
1.  Aegis detectará automáticamente que hay código útil.
2.  Si un satélite está conectado, aparecerá un botón debajo del mensaje: **"🚀 Enviar a Workspace de Antigravity"**.
3.  Al hacer clic, el código se enviará instantáneamente a tu PC de escritorio.
4.  **Notificación**: En tu PC verás una alerta visual nativa: *"🛡️ Aegis: New Task - Received: archivo.py"*.
5.  **Auto-Open**: Si lo configuraste, el archivo se abrirá solo en tu editor (VS Code, etc.).

### B. Indexado Remoto (Mapa de Proyecto)
Para que Aegis conozca los archivos de tu PC:
1.  Ve a la barra lateral -> **"🔄 Unify / Bridge"**.
2.  Activa **"Generate Context File"**.
3.  Esto ordenará al satélite escanear su carpeta actual (`workspace_root`) y enviará el mapa al Hub.
4.  Descarga el `.txt` generado y úsalo en **Google AI Studio (Gemini 3 Pro)** para tener contexto total de tu proyecto.

---


---

## 4. Instalación como Servicio (Persistencia)

Para que Aegis-IA (Gateway + Hub) se inicie automáticamente al encender la PC:

1.  Abre una terminal como **Administrador** (Windows) o con `sudo` (Linux).
2.  Ejecuta:
    ```bash
    python setup.py --sre-deploy
    ```
3.  **Windows**: Se creará una Tarea Programada (`AegisAI_Watchdog`) que iniciará los servicios al loguearte.
4.  **Linux**: Se generará un script `install_linux.sh` listo con los comandos necesarios. Ejecútalo así:
    ```bash
    ./install_linux.sh
    ```
    *(Requiere conexión a internet para apt/curl si no se poseen, pero el script solo configura systemd localemente)*

Esto garantiza que tu "Cerebro" esté siempre disponible sin intervención manual.

---

## 5. Rendimiento y Seguridad

- **Reconexión Exponencial**: Si la Notebook se apaga o se desconecta de la red, el Satélite NO saturará tu PC ni la red. Intentará reconectar tras 1 segundo, luego 5 segundos, y finalmente entrará en modo de espera (cada 30 segundos). Esto garantiza **cero impacto en el rendimiento** mientras juegas o trabajas.
- **Cifrado E2EE**: Todas las comunicaciones (comandos y archivos) están cifradas con una llave Fernet única intercambiada durante el emparejamiento. Solo tu Hub puede leer lo que envía tu Satélite.
- **Anti-Zombies**: El Gateway limpia automáticamente las conexiones muertas, manteniendo la red saludable.
- **Visibilidad SRE**: Al iniciar el servicio, se abrirán consolas dedicadas para el Gateway y el Hub, permitiendo monitorear los logs en tiempo real.

---

*System Status: OPTIMAL*
*Protocol: THE SINGULARITY*

