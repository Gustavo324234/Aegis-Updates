from datetime import datetime
from .connection import get_connection


# --- CHAT HISTORY ---
def save_message(role, content, model="unknown", thread_tag="general"):
    conn = get_connection()
    c = conn.cursor()
    timestamp = datetime.now().isoformat()
    c.execute(
        "INSERT INTO history (timestamp, role, message, model_name, thread_tag) VALUES (?, ?, ?, ?, ?)",
        (timestamp, role, content, model, thread_tag),
    )
    conn.commit()
    conn.close()


def get_history(limit=50, thread_tag="general"):
    conn = get_connection()
    c = conn.cursor()
    c.execute(
        "SELECT role, message, timestamp, model_name FROM history WHERE thread_tag=? ORDER BY timestamp DESC LIMIT ?",
        (thread_tag, limit),
    )
    rows = c.fetchall()

    # Return as list of tuples: (role, message, timestamp, model_name)
    conn.close()
    return rows[::-1]


def get_history_count():
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM history")
    count = c.fetchone()[0]
    conn.close()
    return count
