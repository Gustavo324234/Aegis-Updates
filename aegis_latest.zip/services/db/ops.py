from datetime import datetime
from .connection import get_connection


# --- SETTINGS MANAGEMENT ---
def set_setting(key, value):
    conn = get_connection()
    c = conn.cursor()
    c.execute(
        "INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (key, value)
    )
    conn.commit()
    conn.close()


def get_setting(key):
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT value FROM settings WHERE key=?", (key,))
    result = c.fetchone()
    conn.close()
    return result[0] if result else None


# --- USER MEMORY (FACTS) ---
def add_user_fact(key, value, category="general", confidence=1.0):
    conn = get_connection()
    c = conn.cursor()
    timestamp = datetime.now().isoformat()
    # Check uniqueness for key/value pair to avoid spam
    c.execute("SELECT rowid FROM user_metadata WHERE key=? AND value=?", (key, value))
    if not c.fetchone():
        c.execute(
            "INSERT INTO user_metadata VALUES (?, ?, ?, ?, ?)",
            (key, value, category, confidence, timestamp),
        )
    conn.commit()
    conn.close()


def get_user_fact(key, category=None):
    conn = get_connection()
    c = conn.cursor()
    if category:
        c.execute(
            "SELECT value FROM user_metadata WHERE key=? AND category=? ORDER BY timestamp DESC LIMIT 1",
            (key, category),
        )
    else:
        c.execute(
            "SELECT value FROM user_metadata WHERE key=? ORDER BY timestamp DESC LIMIT 1",
            (key,),
        )
    res = c.fetchone()
    conn.close()
    return res[0] if res else None


def get_user_facts(limit=20):
    conn = get_connection()
    c = conn.cursor()
    c.execute(
        "SELECT key, value, confidence FROM user_metadata ORDER BY timestamp DESC LIMIT ?",
        (limit,),
    )
    rows = c.fetchall()
    conn.close()
    return rows


def get_latest_context_summary():
    conn = get_connection()
    c = conn.cursor()
    c.execute(
        "SELECT value FROM user_metadata WHERE key='chronos_summary' ORDER BY timestamp DESC LIMIT 1"
    )
    res = c.fetchone()
    conn.close()
    return res[0] if res else None


def get_active_projects():
    # Retrieve active projects from User Facts
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT key FROM user_metadata WHERE category='project_active'")
    rows = c.fetchall()
    conn.close()
    return [r[0] for r in rows]


def get_latest_project():
    conn = get_connection()
    c = conn.cursor()
    c.execute(
        "SELECT value FROM user_metadata WHERE category='project_active' ORDER BY timestamp DESC LIMIT 1"
    )
    res = c.fetchone()
    conn.close()
    return res[0] if res else None


# --- FINANCE STREAM ---
def add_expense(amount, category, description, currency="USD"):
    conn = get_connection()
    c = conn.cursor()
    timestamp = datetime.now().isoformat()
    c.execute(
        "INSERT INTO expenses VALUES (?, ?, ?, ?, ?)",
        (timestamp, amount, category, description, currency),
    )
    row_id = c.lastrowid
    conn.commit()
    conn.close()
    return {
        "status": "success",
        "message": f"Expense Logged: {currency} {amount} for {category}",
        "id": row_id,
        "type": "expense",
    }


def get_expenses(limit=10):
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM expenses ORDER BY timestamp DESC LIMIT ?", (limit,))
    res = c.fetchall()
    conn.close()
    return res


def get_daily_spend():
    conn = get_connection()
    c = conn.cursor()
    # Assuming timestamp is ISO format YYYY-MM-DD...
    today = datetime.now().strftime("%Y-%m-%d")
    c.execute("SELECT amount FROM expenses WHERE timestamp LIKE ?", (f"{today}%",))
    rows = c.fetchall()
    conn.close()
    return sum(r[0] for r in rows)


def delete_expense(rowid):
    conn = get_connection()
    c = conn.cursor()
    c.execute("DELETE FROM expenses WHERE rowid=?", (rowid,))
    conn.commit()
    conn.close()


# --- TASKS (MISSION CONTROL) ---
def add_task(task, due_date=None, priority="Medium"):
    conn = get_connection()
    c = conn.cursor()
    c.execute(
        "INSERT INTO tasks (task, status, due_date, priority) VALUES (?, ?, ?, ?)",
        (task, "pending", due_date, priority),
    )
    row_id = c.lastrowid
    conn.commit()
    conn.close()
    return {
        "status": "success",
        "message": f"Task Added: {task}",
        "id": row_id,
        "type": "task",
    }


def get_tasks(status="pending"):
    conn = get_connection()
    c = conn.cursor()
    c.execute(
        "SELECT id, task, due_date, priority FROM tasks WHERE status=?", (status,)
    )
    res = c.fetchall()
    conn.close()
    return res


def complete_task(task_id):
    conn = get_connection()
    c = conn.cursor()
    c.execute("UPDATE tasks SET status='completed' WHERE id=?", (task_id,))
    conn.commit()
    conn.close()


def get_pending_tasks(limit=5):
    """Helper for Daily Briefing"""
    conn = get_connection()
    c = conn.cursor()
    c.execute(
        "SELECT task, priority FROM tasks WHERE status='pending' ORDER BY priority DESC LIMIT ?",
        (limit,),
    )
    rows = c.fetchall()
    conn.close()
    return [{"task": r[0], "priority": r[1]} for r in rows]


def get_next_task():
    conn = get_connection()
    c = conn.cursor()
    # Get pending task with earliest due date, or just high priority
    # Simple logic: First pending task
    c.execute(
        "SELECT task, due_date FROM tasks WHERE status='pending' ORDER BY due_date ASC LIMIT 1"
    )
    res = c.fetchone()
    conn.close()
    if res:
        return {"task": res[0], "time": res[1] or "Anytime"}
    return None


def delete_task(rowid):
    conn = get_connection()
    c = conn.cursor()
    c.execute("DELETE FROM tasks WHERE id=?", (rowid,))
    conn.commit()
    conn.close()


# --- THE CODEX (CODE SNIPPETS) ---
def save_codex_snippet(title, code, tags, language="python"):
    conn = get_connection()
    c = conn.cursor()
    ts = datetime.now().isoformat()
    c.execute(
        "INSERT INTO codex_snippets (title, code, tags, language, created_at) VALUES (?, ?, ?, ?, ?)",
        (title, code, tags, language, ts),
    )
    conn.commit()
    conn.close()


def get_all_codex_snippets():
    conn = get_connection()
    c = conn.cursor()
    c.execute(
        "SELECT title, code, tags, language FROM codex_snippets ORDER BY created_at DESC"
    )
    rows = c.fetchall()
    conn.close()
    return [{"title": r[0], "code": r[1], "tags": r[2], "language": r[3]} for r in rows]


def search_codex(query):
    conn = get_connection()
    c = conn.cursor()
    # Simple text search
    c.execute(
        "SELECT title, code, language FROM codex_snippets WHERE title LIKE ? OR tags LIKE ?",
        (f"%{query}%", f"%{query}%"),
    )
    rows = c.fetchall()
    conn.close()


# --- KNOWLEDGE GRAPH (GRAPH RAG) ---
def add_graph_triple(subject, predicate, obj):
    conn = get_connection()
    c = conn.cursor()
    ts = datetime.now().isoformat()
    try:
        c.execute(
            "INSERT OR IGNORE INTO knowledge_graph VALUES (?, ?, ?, ?)",
            (
                str(subject).lower().strip(),
                str(predicate).lower().strip(),
                str(obj).lower().strip(),
                ts,
            ),
        )
        conn.commit()
    except Exception as e:
        print(f"Graph Insert Error: {e}")
    finally:
        conn.close()


def get_graph_context(entity):
    conn = get_connection()
    c = conn.cursor()
    entity = str(entity).lower().strip()
    # Buscar nodos adyacentes (1-hop) donde la entidad sea Sujeto u Objeto
    c.execute(
        "SELECT subject, predicate, object FROM knowledge_graph WHERE subject LIKE ? OR object LIKE ? LIMIT 15",
        (f"%{entity}%", f"%{entity}%"),
    )
    rows = c.fetchall()
    conn.close()
    return [f"({r[0]} -> {r[1]} -> {r[2]})" for r in rows]
