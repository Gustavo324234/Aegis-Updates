from datetime import datetime
from .connection import get_connection


def init_db():
    conn = get_connection()
    c = conn.cursor()

    # 1. Chat History
    c.execute("""CREATE TABLE IF NOT EXISTS history
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  timestamp TEXT, 
                  role TEXT, 
                  message TEXT, 
                  model_name TEXT, 
                  thread_tag TEXT DEFAULT 'general')""")

    # 2. Key-Value Settings (The Configuration Cortex)
    c.execute("""CREATE TABLE IF NOT EXISTS settings
                 (key TEXT PRIMARY KEY, value TEXT)""")

    # 3. User Metadata (Long-Term Memory / Facts)
    c.execute("""CREATE TABLE IF NOT EXISTS user_metadata
                 (key TEXT, value TEXT, category TEXT, confidence REAL, timestamp TEXT)""")

    # 4. Expenses (Finance Stream)
    c.execute("""CREATE TABLE IF NOT EXISTS expenses
                 (timestamp TEXT, amount REAL, category TEXT, description TEXT, currency TEXT)""")

    # Migrations for Expenses
    try:
        # Check if 'date' exists and rename to 'timestamp'
        c.execute("PRAGMA table_info(expenses)")
        columns = [col[1] for col in c.fetchall()]
        if "date" in columns and "timestamp" not in columns:
            c.execute("ALTER TABLE expenses RENAME COLUMN date TO timestamp")
        elif "timestamp" not in columns:
            c.execute("ALTER TABLE expenses ADD COLUMN timestamp TEXT")

        if "currency" not in columns:
            c.execute("ALTER TABLE expenses ADD COLUMN currency TEXT DEFAULT 'USD'")
    except Exception:
        pass

    # 5. Tasks (Mission Control)
    c.execute("""CREATE TABLE IF NOT EXISTS tasks
                 (id INTEGER PRIMARY KEY AUTOINCREMENT, task TEXT, status TEXT, due_date TEXT, priority TEXT)""")

    # 6. Nexus Mesh (Network Nodes)
    # Includes 'last_indexed' and 'compute_score' columns
    c.execute("""CREATE TABLE IF NOT EXISTS network_nodes
                 (node_id TEXT PRIMARY KEY, 
                  ip_address TEXT, 
                  public_key TEXT, 
                  status TEXT, 
                  last_seen TEXT,
                  capabilities TEXT,
                  shared_key TEXT,
                  last_indexed TEXT,
                  compute_score REAL DEFAULT 0)""")

    # Migrations for existing table
    try:
        c.execute("ALTER TABLE network_nodes ADD COLUMN last_indexed TEXT")
    except Exception:
        pass

    try:
        c.execute("ALTER TABLE network_nodes ADD COLUMN compute_score REAL DEFAULT 0")
    except Exception:
        pass

    # 7. Pairing Codes (Security)
    c.execute("""CREATE TABLE IF NOT EXISTS pairing_codes
                 (code TEXT PRIMARY KEY, created_at TEXT)""")

    # 8. API Vault (The Swarm)
    c.execute("""CREATE TABLE IF NOT EXISTS api_vault
                 (id INTEGER PRIMARY KEY AUTOINCREMENT, provider TEXT, api_key TEXT, priority INTEGER)""")

    # 9. Codex Snippets (Code Library)
    c.execute("""CREATE TABLE IF NOT EXISTS codex_snippets
                 (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, code TEXT, tags TEXT, language TEXT, created_at TEXT)""")

    # 10. Audit Log (Security)
    # Columns: timestamp, module, action, status, approved, details, user, hash
    c.execute("""CREATE TABLE IF NOT EXISTS audit_log
                 (timestamp TEXT, module TEXT, action TEXT, status TEXT, approved BOOLEAN, details TEXT, user TEXT, hash TEXT)""")

    # Migrations for Audit Log
    # Ensure 'details' column exists
    try:
        c.execute("ALTER TABLE audit_log ADD COLUMN details TEXT")
    except Exception:
        pass

    # Ensure 'hash' column exists
    try:
        c.execute("ALTER TABLE audit_log ADD COLUMN hash TEXT")
    except Exception:
        pass

    # Ensure 'user' column exists
    try:
        c.execute("ALTER TABLE audit_log ADD COLUMN user TEXT")
    except Exception:
        pass

    # Ensure 'approved' column exists
    try:
        c.execute("ALTER TABLE audit_log ADD COLUMN approved BOOLEAN")
    except Exception:
        pass

    # 11. Daemons (The Overseer)
    c.execute("""CREATE TABLE IF NOT EXISTS daemons
                 (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, type TEXT, config TEXT, status TEXT, last_run TEXT)""")

    # Migrations for Daemons
    try:
        c.execute("ALTER TABLE daemons RENAME COLUMN task_type TO type")
    except Exception:
        pass

    try:
        c.execute("ALTER TABLE daemons ADD COLUMN config TEXT")
    except Exception:
        pass

    try:
        c.execute("ALTER TABLE daemons ADD COLUMN last_run TEXT")
    except Exception:
        pass

    # 12. Message Queue (Offline Persistence)
    c.execute("""CREATE TABLE IF NOT EXISTS message_queue
                 (id INTEGER PRIMARY KEY AUTOINCREMENT, 
                  target_node TEXT, 
                  sender_id TEXT, 
                  content TEXT, 
                  timestamp TEXT, 
                  status TEXT)""")

    # 13. Agent Missions (Background Execution)
    c.execute("""CREATE TABLE IF NOT EXISTS agent_missions
                 (id INTEGER PRIMARY KEY AUTOINCREMENT, 
                  goal TEXT, 
                  steps_json TEXT, 
                  current_step INTEGER, 
                  status TEXT, 
                  log_json TEXT,
                  created_at TEXT)""")

    # 14. Vault Embeddings (Semantic Memory)
    # Centralized from vault_manager.py
    c.execute("""CREATE TABLE IF NOT EXISTS vault_embeddings 
                 (filename TEXT,
                  collection TEXT DEFAULT 'vault',
                  embedding BLOB,
                  last_updated TEXT,
                  access_count INTEGER DEFAULT 0,
                  last_accessed TEXT,
                  PRIMARY KEY (filename, collection))""")

    # Migrations for Vault Embeddings
    try:
        c.execute(
            "ALTER TABLE vault_embeddings ADD COLUMN access_count INTEGER DEFAULT 0"
        )
    except Exception:
        pass

    try:
        c.execute("ALTER TABLE vault_embeddings ADD COLUMN last_accessed TEXT")
    except Exception:
        pass

    try:
        c.execute(
            "ALTER TABLE vault_embeddings ADD COLUMN collection TEXT DEFAULT 'vault'"
        )
    except Exception:
        pass

    # Register Default Daemons
    try:
        c.execute(
            "INSERT OR IGNORE INTO daemons (name, type, status, config, last_run) VALUES (?, ?, ?, ?, ?)",
            ("SoulSync", "soul_sync", "RUNNING", "{}", datetime.now().isoformat()),
        )
    except Exception:
        pass

    try:
        # Registrar el espejo neural con un intervalo de 60 segundos
        c.execute(
            "INSERT OR IGNORE INTO daemons (name, type, status, config, last_run) VALUES (?, ?, ?, ?, ?)",
            (
                "NeuralMirror",
                "neural_mirror",
                "STOPPED",
                '{"interval": 60}',
                datetime.now().isoformat(),
            ),
        )
    except Exception:
        pass

    try:
        # Registrar Chronos con un intervalo largo (ej. cada 4 horas)
        c.execute(
            "INSERT OR IGNORE INTO daemons (name, type, status, config, last_run) VALUES (?, ?, ?, ?, ?)",
            (
                "ChronosEngine",
                "chronos_evolution",
                "RUNNING",
                '{"interval": 14400}',
                datetime.now().isoformat(),
            ),
        )
    except Exception:
        pass

    # 15. Knowledge Graph (Triple Store)
    c.execute("""CREATE TABLE IF NOT EXISTS knowledge_graph
                 (subject TEXT, predicate TEXT, object TEXT, timestamp TEXT,
                  UNIQUE(subject, predicate, object))""")

    # 16. Action Queue (Server-side tool execution)
    c.execute("""CREATE TABLE IF NOT EXISTS action_queue
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  session_id TEXT,
                  tool_name TEXT,
                  tool_args TEXT,
                  status TEXT,
                  created_at TEXT)""")

    # 17. System Logs (Operational Tracing)
    c.execute("""CREATE TABLE IF NOT EXISTS system_logs
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  timestamp TEXT,
                  level TEXT,
                  module TEXT,
                  message TEXT)""")

    conn.commit()
    conn.close()
