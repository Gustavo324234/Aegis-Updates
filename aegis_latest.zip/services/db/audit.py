import json
import hashlib
from datetime import datetime
from .connection import get_connection


# --- AUDIT & DAEMONS (THE OVERSEER) ---
def log_audit_event(
    module, action, status, details=None, user="SYSTEM", approved=False
):
    """
    Logs comprehensive audit events for security and debugging.
    """
    conn = get_connection()
    c = conn.cursor()
    ts = datetime.now().isoformat()

    # 1. Fetch Previous Hash (Block Chain)
    prev_hash = "GENESIS_0000000000000000000000000000000000000000"
    try:
        c.execute("SELECT hash FROM audit_log ORDER BY timestamp DESC LIMIT 1")
        last = c.fetchone()
        if last and last[0]:
            prev_hash = last[0]
    except:
        pass

    # 2. Calculate New Hash (Merkle-like)
    content = f"{ts}|{module}|{action}|{status}|{details or ''}|{user}|{prev_hash}"
    new_hash = hashlib.sha256(content.encode()).hexdigest()

    try:
        # Try new schema first (V8 Immutable)
        c.execute(
            "INSERT INTO audit_log (timestamp, module, action, status, approved, details, user, hash) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (ts, module, action, status, approved, details, user, new_hash),
        )
    except Exception as e:
        print(f"[DATABASE] Audit Log Failed (Schema mismatch?): {e}")
        try:
            # Attempt legacy insert (V7)
            c.execute(
                "INSERT INTO audit_log (timestamp, module, action, status, approved, details, user) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (ts, module, action, status, approved, details, user),
            )
        except:
            pass

    conn.commit()
    conn.close()


def verify_audit_chain():
    """Validates the integrity of the audit log chain."""
    conn = get_connection()
    c = conn.cursor()
    c.execute(
        "SELECT timestamp, module, action, status, details, user, hash FROM audit_log ORDER BY timestamp ASC"
    )
    rows = c.fetchall()
    conn.close()

    prev_hash = "GENESIS_0000000000000000000000000000000000000000"

    for i, row in enumerate(rows):
        # row: (ts, mod, act, stat, det, usr, hash)
        current_hash = row[6]
        # Reconstruct
        content = (
            f"{row[0]}|{row[1]}|{row[2]}|{row[3]}|{row[4] or ''}|{row[5]}|{prev_hash}"
        )
        calc_hash = hashlib.sha256(content.encode()).hexdigest()

        if current_hash != calc_hash:
            return False, i  # Chain Broken at index i

        prev_hash = current_hash

    return True, len(rows)


def get_audit_logs(limit=50):
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM audit_log ORDER BY timestamp DESC LIMIT ?", (limit,))
    rows = c.fetchall()
    conn.close()
    return rows


# --- DAEMONS ---
def register_daemon(name, dtype, config):
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT id FROM daemons WHERE name=?", (name,))
    if c.fetchone():
        c.execute(
            "UPDATE daemons SET config=?, status='RUNNING' WHERE name=?",
            (json.dumps(config), name),
        )
    else:
        c.execute(
            "INSERT INTO daemons (name, type, config, status) VALUES (?, ?, ?, ?)",
            (name, dtype, json.dumps(config), "RUNNING"),
        )
    conn.commit()
    conn.close()


def update_daemon_status(name, status, last_run=None):
    conn = get_connection()
    c = conn.cursor()
    if last_run:
        c.execute(
            "UPDATE daemons SET status=?, last_run=? WHERE name=?",
            (status, last_run, name),
        )
    else:
        c.execute("UPDATE daemons SET status=? WHERE name=?", (status, name))
    conn.commit()
    conn.close()


def get_all_daemons():
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT id, name, type, config, status, last_run FROM daemons")
    rows = c.fetchall()
    conn.close()
    return [
        {
            "id": r[0],
            "name": r[1],
            "type": r[2],
            "config": json.loads(r[3]),
            "status": r[4],
            "last_run": r[5],
        }
        for r in rows
    ]


def get_daemons():
    """Returns raw rows for DaemonManager loop with mocked interval."""
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT id, name, type, status, config, last_run FROM daemons")
    rows = c.fetchall()
    conn.close()

    adapted = []
    for r in rows:
        # r: (id, name, type, status, config_str, last_run)
        # construct: (id, name, type, status, interval, config, last_run)
        interval = 60
        try:
            cfg = json.loads(r[4])
            interval = cfg.get("interval", 60)
        except:
            pass
        adapted.append((r[0], r[1], r[2], r[3], interval, r[4], r[5]))

    return adapted


def get_daemon(daemon_id):
    """Get single daemon tuple for run_loop."""
    conn = get_connection()
    c = conn.cursor()
    c.execute(
        "SELECT id, name, type, status, config, last_run FROM daemons WHERE id=?",
        (daemon_id,),
    )
    r = c.fetchone()
    conn.close()
    if not r:
        return None

    interval = 60
    try:
        cfg = json.loads(r[4])
        interval = cfg.get("interval", 60)
    except:
        pass

    return (r[0], r[1], r[2], r[3], interval, r[4], r[5])


def update_daemon_last_run(daemon_id):
    conn = get_connection()
    c = conn.cursor()
    ts = datetime.now().isoformat()
    c.execute("UPDATE daemons SET last_run=? WHERE id=?", (ts, daemon_id))
    conn.commit()
    conn.close()


def register_daemon_db(name, task_type, interval, config_str):
    # Adapter for DaemonManager.register_daemon
    try:
        cfg = json.loads(config_str)
        cfg["interval"] = interval

        register_daemon(name, task_type, cfg)  # Reuse existing
        return "Daemon Registered"
    except Exception as e:
        return str(e)


def set_daemon_status(name, status):
    update_daemon_status(name, status)


# --- AGENT MISSIONS (ASYNC) ---
def create_mission(goal, steps):
    """Creates a new mission for the MissionWorker."""
    conn = get_connection()
    c = conn.cursor()
    ts = datetime.now().isoformat()
    steps_json = json.dumps(steps)
    c.execute(
        "INSERT INTO agent_missions (goal, steps_json, current_step, status, log_json, created_at) VALUES (?, ?, 0, 'pending', '[]', ?)",
        (goal, steps_json, ts),
    )
    mid = c.lastrowid
    conn.commit()
    conn.close()
    return mid


def get_active_missions():
    """Gets pending/running missions."""
    conn = get_connection()
    c = conn.cursor()
    c.execute(
        "SELECT id, goal, steps_json, current_step, status, log_json FROM agent_missions WHERE status IN ('pending', 'running')"
    )
    rows = c.fetchall()
    conn.close()
    return [
        {
            "id": r[0],
            "goal": r[1],
            "steps": json.loads(r[2]),
            "step_idx": r[3],
            "status": r[4],
            "logs": json.loads(r[5]),
        }
        for r in rows
    ]


def update_mission_progress(mission_id, step_idx, log_entry=None, status="running"):
    """Updates mission state."""
    conn = get_connection()
    c = conn.cursor()

    # First get current logs
    c.execute("SELECT log_json FROM agent_missions WHERE id=?", (mission_id,))
    try:
        current_logs = json.loads(c.fetchone()[0])
    except:
        current_logs = []

    if log_entry:
        current_logs.append(log_entry)

    c.execute(
        "UPDATE agent_missions SET current_step=?, status=?, log_json=? WHERE id=?",
        (step_idx, status, json.dumps(current_logs), mission_id),
    )
    conn.commit()
    conn.close()


def fail_mission(mission_id, error_msg):
    update_mission_progress(mission_id, -1, f"ERROR: {error_msg}", "failed")


def complete_mission(mission_id):
    update_mission_progress(mission_id, 999, "MISSION COMPLETE", "completed")
