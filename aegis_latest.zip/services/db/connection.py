import os
import sqlite3

# --- CONFIGURATION & MULTI-TENANCY ---
# Support for multi-user environments (e.g., Linux server with multiple users)
AEGIS_USER_ROOT = os.getenv("AEGIS_USER_ROOT")

if AEGIS_USER_ROOT:
    # Tenant Mode: Strict isolation
    USER_ROOT = AEGIS_USER_ROOT
    if not os.path.exists(USER_ROOT):
        print(f"[DATABASE] Zero-Config: Initializing Data Root at {USER_ROOT}")
        try:
            os.makedirs(USER_ROOT, exist_ok=True)
        except Exception as e:
            print(
                f"[DATABASE] CRITICAL: Failed to create Data Vault at {USER_ROOT}: {e}"
            )
            # Fallback to local to prevent crash, but warn heavily
            USER_ROOT = "."
else:
    # System/Global Mode: Default behavior (Dev/Local)
    USER_ROOT = "."

# Ensure core folders exist for this tenant (or global)
# These are MANDATORY for the system to function
REQUIRED_DIRS = ["vault", "backups", "quarantine", "config", "global_config", "users"]
for d in REQUIRED_DIRS:
    target = os.path.join(USER_ROOT, d)
    if not os.path.exists(target):
        try:
            os.makedirs(target, exist_ok=True)
        except Exception:
            pass

DB_NAME = os.path.join(USER_ROOT, "aegis_memory.db")


def get_connection():
    """Establishes a connection to the SQLite database with WAL mode enabled."""
    conn = sqlite3.connect(DB_NAME, check_same_thread=False)
    # Enable Write-Ahead Logging for concurrency
    try:
        conn.execute("PRAGMA journal_mode=WAL;")
    except Exception:
        pass
    return conn
