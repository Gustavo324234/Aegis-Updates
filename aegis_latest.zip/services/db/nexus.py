import json
from datetime import datetime, timedelta
from .connection import get_connection


# --- NEXUS MESH (P2P NETWORK) ---
def register_node(
    node_id, ip, public_key, capabilities, shared_key=None, contribution_mode=False
):
    conn = get_connection()
    c = conn.cursor()
    now = datetime.now().isoformat()
    # Handle optional shared_key and contribution_mode via capabilities json or separate fields if schema evolved
    # For now, simplistic update or insert

    c.execute("SELECT node_id FROM network_nodes WHERE node_id=?", (node_id,))
    exists = c.fetchone()

    if exists:
        # Update
        c.execute(
            """UPDATE network_nodes SET 
                     ip_address=?, public_key=?, status='online', last_seen=?, capabilities=?, shared_key=? 
                     WHERE node_id=?""",
            (ip, public_key, now, json.dumps(capabilities), shared_key, node_id),
        )
    else:
        # Insert
        c.execute(
            """INSERT INTO network_nodes 
                     (node_id, ip_address, public_key, status, last_seen, capabilities, shared_key, last_indexed) 
                     VALUES (?, ?, ?, 'online', ?, ?, ?, NULL)""",
            (node_id, ip, public_key, now, json.dumps(capabilities), shared_key),
        )

    conn.commit()
    conn.close()


def update_node_status(node_id, status):
    conn = get_connection()
    c = conn.cursor()
    c.execute("UPDATE network_nodes SET status=? WHERE node_id=?", (status, node_id))
    conn.commit()
    conn.close()


def update_node_heartbeat(node_id, ip=None):
    conn = get_connection()
    c = conn.cursor()
    now = datetime.now().isoformat()
    if ip:
        c.execute(
            "UPDATE network_nodes SET last_seen=?, status='online', ip_address=? WHERE node_id=?",
            (now, ip, node_id),
        )
    else:
        c.execute(
            "UPDATE network_nodes SET last_seen=?, status='online' WHERE node_id=?",
            (now, node_id),
        )
    conn.commit()
    conn.close()


def update_node_last_indexed(node_id):
    conn = get_connection()
    c = conn.cursor()
    now = datetime.now().isoformat()
    c.execute("UPDATE network_nodes SET last_indexed=? WHERE node_id=?", (now, node_id))
    conn.commit()
    conn.close()


def get_all_nodes():
    conn = get_connection()
    c = conn.cursor()
    # Check if last_indexed exists in schema (it should after init)
    try:
        c.execute(
            "SELECT node_id, status, last_seen, ip_address, capabilities, last_indexed FROM network_nodes"
        )
        rows = c.fetchall()
        return [
            {
                "node_id": r[0],
                "status": r[1],
                "last_seen": r[2],
                "last_ip": r[3],
                "caps": r[4],
                "last_indexed": r[5],
            }
            for r in rows
        ]
    except:
        # Fallback if migration hasn't run or something
        c.execute(
            "SELECT node_id, status, last_seen, ip_address, capabilities FROM network_nodes"
        )
        rows = c.fetchall()
        return [
            {
                "node_id": r[0],
                "status": r[1],
                "last_seen": r[2],
                "last_ip": r[3],
                "caps": r[4],
                "last_indexed": None,
            }
            for r in rows
        ]


def get_contributors():
    """Get nodes with contribution_mode=True"""
    # Assuming 'contribution_mode' is in capabilities JSON
    nodes = get_all_nodes()
    contributors = []
    for n in nodes:
        try:
            caps = json.loads(n["caps"])
            if caps.get("contribution_mode", False) or caps.get("brain_power", False):
                contributors.append(n)
        except:
            pass
    return contributors


def get_node_key(node_id):
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT shared_key FROM network_nodes WHERE node_id=?", (node_id,))
    res = c.fetchone()
    conn.close()
    return res[0] if res else None


def set_node_key(node_id, key):
    conn = get_connection()
    c = conn.cursor()
    c.execute("UPDATE network_nodes SET shared_key=? WHERE node_id=?", (key, node_id))
    conn.commit()
    conn.close()


# --- PAIRING CODES ---
def create_pairing_code(code):
    conn = get_connection()
    c = conn.cursor()
    now = datetime.now().isoformat()
    # Expire old codes first (older than 10 mins)
    c.execute("INSERT OR REPLACE INTO pairing_codes VALUES (?, ?)", (code, now))
    conn.commit()
    conn.close()


def validate_pairing_code(code):
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT created_at FROM pairing_codes WHERE code=?", (code,))
    res = c.fetchone()
    if res:
        created_at = datetime.fromisoformat(res[0])
        if (datetime.now() - created_at).total_seconds() < 600:  # 10 mins
            c.execute("DELETE FROM pairing_codes WHERE code=?", (code,))
            conn.commit()
            conn.close()
            return True
    conn.close()
    return False


# --- MESSAGE QUEUE ---
def queue_message(target_node, sender_id, content):
    """Enqueues a message for later delivery."""
    conn = get_connection()
    c = conn.cursor()
    ts = datetime.now().isoformat()
    # Content is expected to be a JSON string
    c.execute(
        "INSERT INTO message_queue (target_node, sender_id, content, timestamp, status) VALUES (?, ?, ?, ?, 'pending')",
        (target_node, sender_id, content, ts),
    )
    conn.commit()
    conn.close()


def get_and_clear_queued_messages(target_node):
    """Retrieves pending messages and marks them as delivered/deleted."""
    conn = get_connection()
    c = conn.cursor()

    # Select pending messages
    c.execute(
        "SELECT id, sender_id, content, timestamp FROM message_queue WHERE target_node=? AND status='pending' ORDER BY timestamp ASC",
        (target_node,),
    )
    rows = c.fetchall()

    messages = []
    ids_to_delete = []

    for r in rows:
        messages.append(
            {
                "id": r[0],
                "sender": r[1],
                "content": r[2],  # JSON string
                "timestamp": r[3],
            }
        )
        ids_to_delete.append(r[0])

    # Delete retrieved messages (Simple queue semantics)
    if ids_to_delete:
        c.executemany(
            "DELETE FROM message_queue WHERE id=?", [(i,) for i in ids_to_delete]
        )
        conn.commit()

    conn.close()
    return messages


# --- API VAULT (THE SWARM) ---
def add_api_key(provider, enc_key, priority=10):
    conn = get_connection()
    c = conn.cursor()
    c.execute(
        "INSERT INTO api_vault (provider, api_key, priority) VALUES (?, ?, ?)",
        (provider, enc_key, priority),
    )
    conn.commit()
    conn.close()


def get_api_keys():
    conn = get_connection()
    c = conn.cursor()
    c.execute(
        "SELECT rowid, provider, api_key, priority FROM api_vault ORDER BY priority DESC"
    )
    rows = c.fetchall()
    conn.close()
    return [
        {"rowid": r[0], "provider": r[1], "api_key": r[2], "priority": r[3]}
        for r in rows
    ]


def delete_api_key(rowid):
    conn = get_connection()
    c = conn.cursor()
    c.execute("DELETE FROM api_vault WHERE rowid=?", (rowid,))
    conn.commit()
    conn.close()
