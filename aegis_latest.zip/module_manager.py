# module_manager.py
import os
import sys
import importlib.util
import json

class ModuleManager:
    def __init__(self):
        self.module_paths = ["modules", "skills"]
        self.modules = {}
        self.discover_modules()

    def discover_modules(self):
        """Scans the modules and skills directories and loads valid python modules."""
        for path in self.module_paths:
            if not os.path.exists(path):
                os.makedirs(path)
                continue

            for filename in os.listdir(path):
                if filename.endswith(".py") and filename != "__init__.py":
                    module_name = filename[:-3]
                    self._load_module(module_name, path)

    def _load_module(self, module_name, folder):
        """Loads a single module by name from a specific folder."""
        # Security: Priority check
        # If module already loaded (likely from 'modules/' core), ignore 'skills/' version
        if module_name in self.modules:
            print(f"[!] Security Warning: Module '{module_name}' already loaded. Ignoring version in '{folder}'.")
            return

        file_path = os.path.join(folder, f"{module_name}.py")
        spec = importlib.util.spec_from_file_location(module_name, file_path)
        if spec and spec.loader:
            module = importlib.util.module_from_spec(spec)
            sys.modules[module_name] = module
            spec.loader.exec_module(module)
            
            # Check for MANIFEST (V5 Standard) or DESCRIPTION (Legacy)
            if hasattr(module, "MANIFEST") and hasattr(module, "execute"):
                self.modules[module_name] = module
                print(f"[+] Loaded Skill (V5): {module_name}")
            elif hasattr(module, "DESCRIPTION") and hasattr(module, "execute"):
                self.modules[module_name] = module
                print(f"[+] Loaded Module (Legacy): {module_name}")
            else:
                print(f"[!] Skipped invalid module: {module_name}")

    # V7: Active Skills Management
    def toggle_skill(self, module_name, active):
        """Enables or disables a skill."""
        # For persistence, we'll use a simple JSON registry
        registry = self._load_registry()
        registry[module_name] = active
        self._save_registry(registry)
        
    def delete_skill(self, module_name):
        """Deletes a skill file. SECURITY: Ensures it's in the skills/ directory."""
        # 1. Validation
        if module_name not in self.modules:
            return "Error: Module not found."
            
        module = self.modules[module_name]
        # Check file path safely
        try:
            file_path = module.__file__
            if "skills" not in os.path.abspath(file_path):
                return "Error: SECURITY ALERT. Cannot delete system modules, only user skills."
            
            os.remove(file_path)
            del self.modules[module_name]
            
            # Remove from registry
            reg = self._load_registry()
            if module_name in reg:
                del reg[module_name]
                self._save_registry(reg)
                
            return f"Skill '{module_name}' deleted."
        except Exception as e:
            return f"Deletion Error: {str(e)}"

    def _load_registry(self):
        try:
            if os.path.exists("skills_registry.json"):
                with open("skills_registry.json", "r") as f:
                    return json.load(f)
        except:
            pass
        return {}

    def _save_registry(self, registry):
        with open("skills_registry.json", "w") as f:
            json.dump(registry, f)

    def is_active(self, module_name):
        registry = self._load_registry()
        # Default to True if not in registry (newly discovered)
        return registry.get(module_name, True)

    def get_system_prompt_additions(self):
        """Returns the description of ACTIVE modules for the AI."""
        descriptions = []
        for name, module in self.modules.items():
            if not self.is_active(name):
                continue
                
            if hasattr(module, "MANIFEST"):
                manifest = module.MANIFEST
                desc = f"Skill '{manifest.get('name', name)}':\n{manifest.get('description', '')}\nCommands: {json.dumps(manifest.get('commands', {}))}"
                descriptions.append(desc)
            else:
                descriptions.append(f"Module '{name}':\n{module.DESCRIPTION}")
        return "\n\n".join(descriptions)

    def execute_module(self, module_name, query, brain_instance=None):
        """
        Executes a specific module.
        PROTOCOL GENESIS: If module is missing, attempts to acquire or create it autonomously.
        """
        # 1. Existing Module
        if module_name in self.modules:
            # Check if active
            if not self.is_active(module_name):
                 return f"Error: Skill '{module_name}' is currently disabled."
                 
            try:
                return self.modules[module_name].execute(query)
            except Exception as e:
                return f"Error executing module {module_name}: {str(e)}"
        
        # 2. Missing Module -> PROTOCOL GENESIS
        print(f"[GENESIS] Module '{module_name}' not found. Initiating acquisition sequence...")
        
        if not brain_instance:
            return f"Error: Module '{module_name}' not found and Brain unavailable for genesis."
            
        import modules.galactic_store as store
        import modules.skill_builder as builder
        import time
        
        # A. SEARCH CLOUD (Galactic Store)
        # We assume the module name matches the store file name convention (snake_case)
        # Try finding exact match or close match
        search_results = store.search_cloud_skills(module_name)
        target_skill = None
        
        # smart match
        for skill in search_results:
            if skill['name'].replace(".py", "") == module_name:
                target_skill = skill
                break
        
        if target_skill:
            print(f"[GENESIS] Found in Galaxy: {target_skill['name']}. Downloading...")
            # Install & Audit
            ok, msg = store.install_skill(target_skill['url'], target_skill['name'], brain_instance)
            if ok:
                # Reload Modules to pick up the new file
                self.discover_modules()
                if module_name in self.modules:
                    return self.modules[module_name].execute(query)
                else:
                    return f"Error: Installed {module_name} but failed to load it."
            else:
                return f"Genesis Failed (Cloud Audit): {msg}"
                
        # B. CREATE (Skill Builder)
        print(f"[GENESIS] Not found in Galaxy. Fabricating new skill '{module_name}'...")
        
        # 1. Prompt Brain for Code
        genesis_prompt = f"""
PROTOCOL GENESIS:
User requested module '{module_name}' with query: {json.dumps(query)}.
This module does not exist. YOU must write it now.

Rules:
1. Return ONLY the Python code for the module.
2. Must have a `DESCRIPTION` string.
3. Must have an `execute(query)` function that handles the user's request.
4. Use standard libraries (os, sys, json, requests).
5. No markdown fencing around the code (or minimal ```python).

GOAL: Implement '{module_name}' to solve: {query}
"""
        # Use high tier model for coding
        # We need to call brain.query, but brain is passed in
        # We assume brain has a query method.
        # We pass empty history as this is an internal thought process
        code_response = brain_instance.query(genesis_prompt, [], "gemini-1.5-pro", hive_override=True)
        
        # Strip markdown if present
        if "```python" in code_response:
            code_response = code_response.split("```python")[1].split("```")[0].strip()
        elif "```" in code_response:
             code_response = code_response.split("```")[1].split("```")[0].strip()
             
        # 2. Install (via Skill Builder logic which does syntax check & backup, but we use store's safe install for simplicity or builder?)
        # Let's use builder logic manually or via a helper
        # Actually developer said "Llama a SkillBuilder".
        
        # We simulate a "confirmed install" query to skill builder
        filename = f"{module_name}.py"
        install_query = {
            "module": "skill_builder",
            "action": "install_skill_confirmed",
            "filename": filename,
            "code": code_response
        }
        
        result = builder.execute(install_query)
        
        if "Success" in result:
             # Reload
             self.discover_modules()
             if module_name in self.modules:
                 return self.modules[module_name].execute(query)
             else:
                 return f"Error: Genesis created {module_name} but loader failed."
        else:
            return f"Genesis Failed (Fabrication): {result}\nCode Generated:\n{code_response[:500]}..."
