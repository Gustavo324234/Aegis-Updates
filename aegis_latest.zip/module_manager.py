# module_manager.py
import os
import sys
import importlib.util
import inspect
import json
import logging


class ModuleManager:
    def __init__(self):
        self.module_paths = ["modules", "skills"]
        self.modules = {}
        self.logger = logging.getLogger("ModuleManager")
        self.discover_modules()

    def discover_modules(self):
        """Scans the modules and skills directories and loads valid python modules."""
        for path in self.module_paths:
            if not os.path.exists(path):
                try:
                    os.makedirs(path)
                except OSError as e:
                    self.logger.error(f"Failed to create directory {path}: {e}")
                continue

            for filename in os.listdir(path):
                if filename.endswith(".py") and filename != "__init__.py":
                    module_name = filename[:-3]
                    self._load_module(module_name, path)

    def _load_module(self, module_name, folder):
        """Loads a single module by name from a specific folder."""
        # Security: Priority check
        # If module already loaded (likely from 'modules/' core), ignore 'skills/' version
        if module_name in self.modules:
            # Silent skip or low level log to avoid noise
            return

        file_path = os.path.join(folder, f"{module_name}.py")

        try:
            # 1. Spec Creation
            spec = importlib.util.spec_from_file_location(module_name, file_path)
            if not spec or not spec.loader:
                self.logger.warning(f"Could not create spec for module: {module_name}")
                return

            # 2. Module Creation & Execution (Safe Load)
            module = importlib.util.module_from_spec(spec)
            sys.modules[module_name] = module

            try:
                spec.loader.exec_module(module)
            except Exception as e:
                self.logger.error(
                    f"Failed to execute module '{module_name}': {e}. Skipping."
                )
                print(f"[!] Module '{module_name}' failed to load: {e}")
                # Clean up dirty module from sys.modules to prevent partial state
                if module_name in sys.modules:
                    del sys.modules[module_name]
                return

            # 3. Registration (Manifest/Description Check)
            if hasattr(module, "MANIFEST") and hasattr(module, "execute"):
                self.modules[module_name] = module
                print(f"[+] Loaded Skill (V5): {module_name}")
            elif hasattr(module, "DESCRIPTION") and hasattr(module, "execute"):
                self.modules[module_name] = module
                print(f"[+] Loaded Module (Legacy): {module_name}")
            else:
                # Valid python file but not an Aegis module
                # self.logger.debug(f"Skipped non-module file: {module_name}")
                pass

        except Exception as e:
            self.logger.error(f"CRITICAL: Error loading {module_name}: {e}")
            if module_name in sys.modules:
                del sys.modules[module_name]

    # V7: Active Skills Management
    def toggle_skill(self, module_name, active):
        """Enables or disables a skill."""
        registry = self._load_registry()
        registry[module_name] = active
        self._save_registry(registry)

    def delete_skill(self, module_name):
        """Deletes a skill file. SECURITY: Ensures it's in the skills/ directory."""
        if module_name not in self.modules:
            return "Error: Module not found."

        module = self.modules[module_name]
        try:
            file_path = module.__file__
            if "skills" not in os.path.abspath(file_path):
                return "Error: SECURITY ALERT. Cannot delete system modules, only user skills."

            os.remove(file_path)
            del self.modules[module_name]

            reg = self._load_registry()
            if module_name in reg:
                del reg[module_name]
                self._save_registry(reg)

            return f"Skill '{module_name}' deleted."
        except Exception as e:
            return f"Deletion Error: {str(e)}"

    def _load_registry(self):
        try:
            if os.path.exists("skills_registry.json"):
                with open("skills_registry.json", "r") as f:
                    return json.load(f)
        except Exception:
            pass
        return {}

    def _save_registry(self, registry):
        try:
            with open("skills_registry.json", "w") as f:
                json.dump(registry, f)
        except Exception as e:
            self.logger.error(f"Failed to save registry: {e}")

    def is_active(self, module_name):
        registry = self._load_registry()
        return registry.get(module_name, True)

    def get_system_prompt_additions(self):
        """Returns the description of ACTIVE modules for the AI."""
        descriptions = []
        for name, module in self.modules.items():
            if not self.is_active(name):
                continue

            if hasattr(module, "MANIFEST"):
                manifest = module.MANIFEST
                desc = f"Skill '{manifest.get('name', name)}':\n{manifest.get('description', '')}\nCommands: {json.dumps(manifest.get('commands', {}))}"
                descriptions.append(desc)
            else:
                descriptions.append(f"Module '{name}':\n{module.DESCRIPTION}")
        return "\n\n".join(descriptions)

    def execute_module(self, module_name, query, brain_instance=None):
        """
        Executes a specific module.
        PROTOCOL GENESIS: If module is missing, attempts to acquire or create it autonomously.
        """
        # 1. Existing Module
        if module_name in self.modules:
            if not self.is_active(module_name):
                return f"Error: Skill '{module_name}' is currently disabled."

            try:
                target_func = self.modules[module_name].execute
                sig = inspect.signature(target_func)
                if "brain_instance" in sig.parameters or any(
                    p.kind == p.VAR_KEYWORD for p in sig.parameters.values()
                ):
                    return target_func(query, brain_instance=brain_instance)
                else:
                    return target_func(query)
            except Exception as e:
                return f"Error executing module {module_name}: {str(e)}"

        # 2. Missing Module -> PROTOCOL GENESIS
        print(
            f"[GENESIS] Module '{module_name}' not found. Initiating acquisition sequence..."
        )

        if not brain_instance:
            return f"Error: Module '{module_name}' not found and Brain unavailable for genesis."

        # Lazy imports to avoid circular deps if this file is imported early
        import modules.galactic_store as store
        import modules.skill_builder as builder

        # A. SEARCH CLOUD
        search_results = store.search_cloud_skills(module_name)
        target_skill = None
        for skill in search_results:
            if skill["name"].replace(".py", "") == module_name:
                target_skill = skill
                break

        if target_skill:
            print(f"[GENESIS] Found in Galaxy: {target_skill['name']}. Downloading...")
            ok, msg = store.install_skill(
                target_skill["url"], target_skill["name"], brain_instance
            )
            if ok:
                self.discover_modules()
                if module_name in self.modules:
                    target_func = self.modules[module_name].execute
                    sig = inspect.signature(target_func)
                    if "brain_instance" in sig.parameters or any(
                        p.kind == p.VAR_KEYWORD for p in sig.parameters.values()
                    ):
                        return target_func(query, brain_instance=brain_instance)
                    else:
                        return target_func(query)
                else:
                    return f"Error: Installed {module_name} but failed to load it."
            else:
                return f"Genesis Failed (Cloud Audit): {msg}"

        # B. CREATE (Skill Builder)
        print(
            f"[GENESIS] Not found in Galaxy. Fabricating new skill '{module_name}'..."
        )

        genesis_prompt = f"""
PROTOCOL GENESIS:
User requested module '{module_name}' with query: {json.dumps(query)}.
This module does not exist. YOU must write it now.

Rules:
1. Return ONLY the Python code for the module.
2. Must have a `DESCRIPTION` string.
3. Must have an `execute(query)` function.
4. Use standard libraries.

GOAL: Implement '{module_name}' to solve: {query}
"""
        try:
            # Assuming brain_instance has query method
            # We use hive_override=True for max intelligence
            # Tool Smithing: Hot Logic Specialist + Coder
            plan = brain_instance.query(
                f"Plan implementation for skill '{module_name}' to solve: {json.dumps(query)}",
                [],
                "specialist:logic",
            )
            code_response = brain_instance.query(
                genesis_prompt + f"\nContext Plan: {plan}", [], "specialist:coder"
            )

            if "```python" in code_response:
                code_response = (
                    code_response.split("```python")[1].split("```")[0].strip()
                )
            elif "```" in code_response:
                code_response = code_response.split("```")[1].split("```")[0].strip()

            filename = f"{module_name}.py"
            # Simulate install query
            install_query = {
                "module": "skill_builder",
                "action": "install_skill_confirmed",
                "filename": filename,
                "code": code_response,
            }

            result = builder.execute(install_query)

            if "Success" in result:
                # Force Hot Reload
                self.discover_modules()
                # Check if loaded
                if module_name in self.modules:
                    target_func = self.modules[module_name].execute
                    sig = inspect.signature(target_func)
                    if "brain_instance" in sig.parameters or any(
                        p.kind == p.VAR_KEYWORD for p in sig.parameters.values()
                    ):
                        return target_func(query, brain_instance=brain_instance)
                    else:
                        return target_func(query)
                else:
                    # Retry load specific
                    self._load_module(module_name, "skills")
                    if module_name in self.modules:
                        target_func = self.modules[module_name].execute
                        sig = inspect.signature(target_func)
                        if "brain_instance" in sig.parameters or any(
                            p.kind == p.VAR_KEYWORD for p in sig.parameters.values()
                        ):
                            return target_func(query, brain_instance=brain_instance)
                        else:
                            return target_func(query)
                    return f"Error: Genesis created {module_name} but Linker failed."
            else:
                return f"Genesis Failed (Fabrication): {result}"

        except Exception as e:
            return f"Genesis Critical Failure: {e}"

    # --- SENTINEL RED-TEAMING (Security Sweep) ---
    def perform_security_sweep(self, brain_instance=None):
        """
        Periodically scans all installed skills for vulnerabilities or malicious patterns.
        Moves suspicious skills to 'quarantine/'.
        """
        print("[SENTINEL] Starting Red-Team Sweep...")
        skills_dir = "skills"
        if not os.path.exists(skills_dir):
            return

        quarantine_dir = "quarantine"
        if not os.path.exists(quarantine_dir):
            os.makedirs(quarantine_dir)

        report = []

        for filename in os.listdir(skills_dir):
            if not filename.endswith(".py"):
                continue

            filepath = os.path.join(skills_dir, filename)
            try:
                with open(filepath, "r", encoding="utf-8") as f:
                    code = f.read()

                # 1. Static Pattern Matching
                suspicious_patterns = [
                    "os.system",
                    "subprocess.call",
                    "eval(",
                    "exec(",
                    "shutil.rmtree",
                    "socket.socket",
                ]
                hits = [p for p in suspicious_patterns if p in code]

                risk_level = "LOW"
                if hits:
                    risk_level = "HIGH"

                # 2. Logic Check (if brain available and HIGH risk)
                if risk_level == "HIGH" and brain_instance:
                    audit_prompt = f"""
                    [ROLE: SECURITY AUDITOR]
                    Analyze this python module code for MALICIOUS intent or capability to escape the sandbox (SAFE_ROOT bypass).
                    If code is legitimate tool (e.g. system_tool is expected to use subprocess), allow it.
                    If code seems obfuscated, malicious, or dangerously unbounded, allow it to be flagged.
                    
                    Code:
                    {code[:2000]}
                    
                    Return ONLY 'SAFE' or 'DANGEROUS'.
                    """
                    try:
                        verdict = (
                            brain_instance.query(audit_prompt, [], "specialist:logic")
                            .strip()
                            .upper()
                        )
                        if "DANGEROUS" in verdict:
                            risk_level = "CRITICAL"
                    except Exception:
                        pass

                if risk_level == "CRITICAL":
                    # Quarantine!
                    print(
                        f"[SENTINEL] 🚨 Quarantining {filename} due to CRITICAL risk."
                    )
                    import shutil
                    import datetime

                    ts = datetime.datetime.now().strftime("%Y%m%d%H%M")
                    dest = os.path.join(quarantine_dir, f"{filename}.{ts}.infected")
                    shutil.move(filepath, dest)
                    report.append(f"⛔ {filename} MOVED TO QUARANTINE (Critical Risk)")

                    # Log to DB
                    import database

                    database.log_audit_event(
                        "SENTINEL",
                        f"Quarantined {filename}",
                        "SECURITY_SWEEP",
                        "CRITICAL",
                        approved=False,
                    )

                elif risk_level == "HIGH":
                    report.append(
                        f"⚠️ {filename} flagged as High Risk (Manual Review Needed): {hits}"
                    )

            except Exception as e:
                print(f"[SENTINEL] Error scanning {filename}: {e}")

        return report
