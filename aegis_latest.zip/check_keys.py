import database

keys = database.get_api_keys()
print(f"Total keys: {len(keys)}")
for k in keys:
    print(
        f"Provider: {k['provider']} | Key starts with: {k['key'][:5]}... | Active: {k['active']}"
    )
