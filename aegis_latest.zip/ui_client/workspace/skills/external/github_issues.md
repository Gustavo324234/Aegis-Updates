---
name: github_issues
description: Lee issues de un repositorio de GitHub
auth_env: GITHUB_TOKEN
---

# GitHub Issues API

Usa esta API para obtener los issues de un repo. 
Comando curl de ejemplo:
`curl -L -H "Accept: application/vnd.github+json" -H "Authorization: Bearer $GITHUB_TOKEN" -H "X-GitHub-Api-Version: 2022-11-28" https://api.github.com/repos/OWNER/REPO/issues`

Reemplaza OWNER y REPO con los reales.