import React, { useState, useEffect } from 'react';
import {
    Users,
    Terminal,
    Activity,
    Trash2,
    Play,
    Square,
    Plus,
    ShieldAlert,
    Server,
    Zap,
    Link,
    Copy,
    Globe
} from 'lucide-react';
import useSystemStore from '../store/useSystemStore';

export default function AdminPanelView() {
    const {
        tenants,
        fetchTenants,
        deployTenant,
        stopTenant,
        startTenant,
        deleteTenant,
        mcpBridge,
        fetchStatus
    } = useSystemStore();

    const [newTenant, setNewTenant] = useState({ username: '', port: '' });
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        fetchTenants();
        fetchStatus();
        const interval = setInterval(() => {
            fetchTenants();
            fetchStatus();
        }, 5000);
        return () => clearInterval(interval);
    }, [fetchTenants, fetchStatus]);

    const handleDeploy = async (e) => {
        e.preventDefault();
        if (!newTenant.username || !newTenant.port) return;
        setLoading(true);
        await deployTenant(newTenant.username, parseInt(newTenant.port), 'local');
        setNewTenant({ username: '', port: '' });
        setLoading(false);
    };

    const handlePurgeSystem = () => {
        if (confirm("☢️ CRITICAL WARNING: This will purge all system temporary data and logs. Are you sure?")) {
            console.log("System Purge Triggered");
            // Add store action if available: await purgeSystem();
        }
    };

    return (
        <div className="p-8 space-y-8 animate-in fade-in duration-500">
            <header className="flex items-center justify-between">
                <div>
                    <h1 className="text-3xl font-bold neon-text flex items-center gap-3">
                        <Terminal className="w-8 h-8" />
                        COMMAND CENTER
                    </h1>
                    <p className="text-gray-400 mt-2">Centralized multi-tenant orchestration and system oversight.</p>
                </div>
                <div className="flex gap-4">
                    <div className="glass-panel px-4 py-2 flex items-center gap-2">
                        <Activity className="w-4 h-4 text-green-400 animate-pulse" />
                        <span className="text-xs font-bold">SYSTEM ACTIVE</span>
                    </div>
                </div>
            </header>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* User Factory Section */}
                <section className="lg:col-span-1 space-y-6">
                    <div className="glass-panel p-6 border-l-4 border-aegis-cyan">
                        <h2 className="text-xl font-bold flex items-center gap-2 mb-6">
                            <Users className="w-5 h-5 text-aegis-cyan" />
                            👥 User Factory
                        </h2>

                        <form onSubmit={handleDeploy} className="space-y-4">
                            <div>
                                <label className="block text-xs font-bold text-gray-500 mb-1 uppercase tracking-wider">Tenant Identity</label>
                                <input
                                    type="text"
                                    placeholder="e.g. neuro_nexus"
                                    className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-3 text-sm focus:border-aegis-cyan outline-none transition-all"
                                    value={newTenant.username}
                                    onChange={(e) => setNewTenant({ ...newTenant, username: e.target.value })}
                                />
                            </div>
                            <div>
                                <label className="block text-xs font-bold text-gray-500 mb-1 uppercase tracking-wider">Assigned Port</label>
                                <input
                                    type="number"
                                    placeholder="e.g. 8001"
                                    className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-3 text-sm focus:border-aegis-cyan outline-none transition-all"
                                    value={newTenant.port}
                                    onChange={(e) => setNewTenant({ ...newTenant, port: e.target.value })}
                                />
                            </div>
                            <button
                                disabled={loading}
                                className="w-full bg-aegis-cyan/10 hover:bg-aegis-cyan/20 border border-aegis-cyan/40 text-aegis-cyan font-bold py-3 rounded-lg flex items-center justify-center gap-2 transition-all group disabled:opacity-50"
                            >
                                <Plus className="w-4 h-4 group-hover:rotate-90 transition-transform" />
                                DEPLOY INSTANCE
                            </button>
                        </form>
                    </div>

                    <div className="glass-panel p-6 border-l-4 border-aegis-purple">
                        <h2 className="text-xl font-bold flex items-center gap-2 mb-4 text-aegis-purple">
                            <Globe className="w-5 h-5" />
                            🌐 Aegis MCP Bridge
                        </h2>
                        <div className="space-y-4">
                            <div className="flex items-center justify-between bg-black/40 p-3 rounded-lg border border-white/5">
                                <div className="text-xs font-bold text-gray-500 uppercase">Status</div>
                                <div className={`text-xs font-bold px-2 py-0.5 rounded ${mcpBridge.active ? 'bg-green-500/10 text-green-400' : 'bg-red-500/10 text-red-400'}`}>
                                    {mcpBridge.active ? 'ONLINE (SSE)' : 'OFFLINE'}
                                </div>
                            </div>
                            <div>
                                <label className="block text-[10px] font-bold text-gray-500 mb-1 uppercase tracking-widest">Global Connection URL</label>
                                <div className="flex gap-2">
                                    <input
                                        readOnly
                                        className="w-full bg-black/40 border border-white/10 rounded-lg px-3 py-2 text-[10px] font-mono text-aegis-cyan"
                                        value={mcpBridge.url || `http://localhost:${mcpBridge.port}/mcp/sse`}
                                    />
                                    <button
                                        onClick={() => {
                                            navigator.clipboard.writeText(mcpBridge.url || `http://localhost:${mcpBridge.port}/mcp/sse`);
                                            alert("URL Copied to clipboard!");
                                        }}
                                        className="p-2 bg-white/5 hover:bg-white/10 rounded-lg transition-all"
                                    >
                                        <Copy className="w-4 h-4 text-gray-400" />
                                    </button>
                                </div>
                            </div>
                            <p className="text-[10px] text-gray-500 italic">Connect external agents (Claude Desktop, Cursor) through this bridge.</p>
                        </div>
                    </div>

                    <div className="glass-panel p-6 border-l-4 border-aegis-red">
                        <h2 className="text-xl font-bold flex items-center gap-2 mb-4 text-aegis-red">
                            <ShieldAlert className="w-5 h-5" />
                            ☢️ System Ops
                        </h2>
                        <p className="text-sm text-gray-400 mb-6">Critical maintenance routines for emergency scenarios.</p>
                        <button
                            onClick={handlePurgeSystem}
                            className="w-full bg-aegis-red/10 hover:bg-aegis-red/20 border border-aegis-red/40 text-aegis-red font-bold py-3 rounded-lg flex items-center justify-center gap-2 transition-all"
                        >
                            <Trash2 className="w-4 h-4" />
                            NUCLEAR PURGE
                        </button>
                    </div>
                </section>

                {/* Active Tenants Grid */}
                <section className="lg:col-span-2">
                    <div className="glass-panel p-6 min-h-[500px]">
                        <div className="flex items-center justify-between mb-8">
                            <h2 className="text-xl font-bold flex items-center gap-2">
                                <Server className="w-5 h-5 text-aegis-purple" />
                                Active Tenants
                            </h2>
                            <span className="text-[10px] bg-white/5 px-2 py-1 rounded text-gray-400 font-mono uppercase tracking-[0.2em]">
                                Live Mesh Status
                            </span>
                        </div>

                        <div className="space-y-4">
                            {tenants.map((tenant) => (
                                <div key={tenant.username} className="flex items-center justify-between p-4 bg-white/5 border border-white/10 rounded-xl hover:bg-white/[0.07] transition-all group">
                                    <div className="flex items-center gap-4">
                                        <div className={`p-3 rounded-lg ${tenant.status === 'online' ? 'bg-green-500/10 text-green-400' : 'bg-red-500/10 text-red-400'}`}>
                                            {tenant.status === 'online' ? <Zap className="w-5 h-5" /> : <Square className="w-5 h-5" />}
                                        </div>
                                        <div>
                                            <div className="font-bold text-white group-hover:text-aegis-cyan transition-colors">{tenant.username}</div>
                                            <div className="text-xs text-gray-500 font-mono">PORT: {tenant.port} • MODE: {tenant.mode || 'local'}</div>
                                        </div>
                                    </div>

                                    <div className="flex items-center gap-4">
                                        <div className="text-right mr-4">
                                            <div className={`text-[10px] font-bold uppercase tracking-widest ${tenant.status === 'online' ? 'text-green-400' : 'text-red-400'}`}>
                                                {tenant.status}
                                            </div>
                                        </div>

                                        <div className="flex gap-2">
                                            {tenant.status === 'online' ? (
                                                <button
                                                    onClick={() => stopTenant(tenant.username)}
                                                    className="p-2 bg-white/5 hover:bg-orange-500/20 text-gray-400 hover:text-orange-400 rounded-lg transition-all"
                                                    title="Stop Instance"
                                                >
                                                    <Square className="w-4 h-4 fill-current" />
                                                </button>
                                            ) : (
                                                <button
                                                    onClick={() => startTenant(tenant.username)}
                                                    className="p-2 bg-white/5 hover:bg-green-500/20 text-gray-400 hover:text-green-400 rounded-lg transition-all"
                                                    title="Start Instance"
                                                >
                                                    <Play className="w-4 h-4 fill-current" />
                                                </button>
                                            )}
                                            <button
                                                onClick={() => deleteTenant(tenant.username)}
                                                className="p-2 bg-white/5 hover:bg-red-500/20 text-gray-400 hover:text-red-400 rounded-lg transition-all"
                                                title="Purge Identity"
                                            >
                                                <Trash2 className="w-4 h-4" />
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            ))}

                            {tenants.length === 0 && (
                                <div className="h-40 flex flex-col items-center justify-center text-gray-600 border-2 border-dashed border-white/5 rounded-2xl">
                                    <Users className="w-8 h-8 mb-2 opacity-20" />
                                    <p className="text-sm font-bold">NO TENANTS REGISTERED</p>
                                </div>
                            )}
                        </div>
                    </div>
                </section>
            </div>
        </div>
    );
}
