import React, { useEffect, useState } from 'react';
import {
    Settings2,
    Cpu,
    Globe,
    Zap,
    Cloud,
    HardDrive,
    RefreshCw,
    Link,
    ShieldCheck,
    BrainCircuit,
    Code,
    Eye,
    MessageSquare
} from 'lucide-react';
import useSystemStore from '../store/useSystemStore';

export default function AdvancedSettingsView() {
    const {
        settings,
        updateSettings,
        hardwareTier,
        ollamaStatus,
        checkOllama,
        fetchSettings
    } = useSystemStore();

    const [ollamaUrl, setOllamaUrl] = useState(settings.ollama_url || 'http://localhost:11434');

    useEffect(() => {
        fetchSettings();
        checkOllama();
    }, [fetchSettings, checkOllama]);

    const handleUpdate = async (key, value) => {
        await updateSettings({ [key]: value });
    };

    const handleOllamaUrlUpdate = async () => {
        await updateSettings({ ollama_url: ollamaUrl });
        await checkOllama();
    };

    return (
        <div className="p-8 max-w-7xl mx-auto space-y-8 animate-in slide-in-from-bottom-4 duration-700">
            <header className="flex items-center justify-between">
                <div>
                    <h1 className="text-3xl font-bold neon-text flex items-center gap-3">
                        <Settings2 className="w-8 h-8" />
                        ADVANCED CONFIGURATION
                    </h1>
                    <p className="text-gray-400 mt-2 font-mono text-sm tracking-tight">Core AI architecture and local engine orchestration.</p>
                </div>

                <div className="glass-panel px-6 py-3 border-l-4 border-aegis-purple flex items-center gap-4">
                    <Cpu className="w-6 h-6 text-aegis-purple" />
                    <div>
                        <div className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">Hardware Tier</div>
                        <div className="text-sm font-black text-white">{hardwareTier?.name || 'Standard'} • {hardwareTier?.id === 2 ? '16GB RAM' : 'Detection Active'}</div>
                    </div>
                </div>
            </header>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                {/* Architecture Section */}
                <section className="lg:col-span-12">
                    <div className="glass-panel p-6">
                        <h2 className="text-xl font-bold flex items-center gap-2 mb-6 text-white uppercase tracking-tighter">
                            <Globe className="w-5 h-5 text-aegis-cyan" />
                            ⚙️ Arquitectura de Procesamiento
                        </h2>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                            {[
                                { id: 'local', label: 'Local Only', desc: '100% Private. Runs on your hardware.', icon: HardDrive },
                                { id: 'cloud', label: 'Cloud Only', desc: 'Maximum Power. Uses Gemini/Anthropic.', icon: Cloud },
                                { id: 'hybrid', label: 'Hybrid Mode', desc: 'Smart Balance. Local logic, Cloud wisdom.', icon: Zap }
                            ].map((mode) => (
                                <button
                                    key={mode.id}
                                    onClick={() => handleUpdate('operation_mode', mode.id)}
                                    className={`p-6 rounded-xl border transition-all relative overflow-hidden group ${settings.operation_mode === mode.id
                                            ? 'bg-aegis-cyan/10 border-aegis-cyan text-aegis-cyan shadow-[0_0_30px_rgba(0,242,254,0.1)]'
                                            : 'bg-white/5 border-white/10 text-gray-400 hover:border-white/20'
                                        }`}
                                >
                                    <mode.icon className={`w-8 h-8 mb-4 transition-transform group-hover:scale-110 ${settings.operation_mode === mode.id ? 'text-aegis-cyan' : 'text-gray-600'}`} />
                                    <div className="text-lg font-black uppercase mb-1 tracking-tighter">{mode.label}</div>
                                    <div className="text-xs opacity-70 leading-relaxed max-w-[200px] mx-auto">{mode.desc}</div>
                                    {settings.operation_mode === mode.id && (
                                        <div className="absolute top-3 right-3">
                                            <ShieldCheck className="w-4 h-4" />
                                        </div>
                                    )}
                                </button>
                            ))}
                        </div>
                    </div>
                </section>

                {/* Local Engine Section */}
                <section className="lg:col-span-5">
                    <div className="glass-panel p-6 h-full border-b-2 border-aegis-cyan/20">
                        <h2 className="text-xl font-bold flex items-center gap-2 mb-6">
                            <HardDrive className="w-5 h-5 text-aegis-green" />
                            🔌 Motor Local
                        </h2>
                        <div className="space-y-6">
                            <div>
                                <label className="block text-[10px] font-black text-gray-500 mb-2 uppercase tracking-widest">Ollama Endpoint URL</label>
                                <div className="flex gap-2">
                                    <div className="relative flex-1">
                                        <Link className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-600" />
                                        <input
                                            type="text"
                                            className="w-full bg-black/40 border border-white/10 rounded-lg pl-10 pr-4 py-3 text-sm focus:border-aegis-green outline-none transition-all"
                                            value={ollamaUrl}
                                            onChange={(e) => setOllamaUrl(e.target.value)}
                                        />
                                    </div>
                                    <button
                                        onClick={handleOllamaUrlUpdate}
                                        className="p-3 bg-white/5 border border-white/10 rounded-lg text-gray-400 hover:text-aegis-green hover:border-aegis-green transition-all"
                                        title="Check Connection"
                                    >
                                        <RefreshCw className={`w-5 h-5 ${ollamaStatus.status === 'checking' ? 'animate-spin' : ''}`} />
                                    </button>
                                </div>
                            </div>

                            <div className={`p-4 rounded-xl border flex items-center justify-between ${ollamaStatus.status === 'online' ? 'bg-green-500/5 border-green-500/20' : 'bg-red-500/5 border-red-500/20'
                                }`}>
                                <div className="flex items-center gap-3">
                                    <div className={`w-2 h-2 rounded-full ${ollamaStatus.status === 'online' ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`} />
                                    <span className="text-xs font-bold uppercase tracking-widest">Status: {ollamaStatus.status}</span>
                                </div>
                                {ollamaStatus.version && <span className="text-[10px] font-mono text-gray-500">v{ollamaStatus.version}</span>}
                            </div>

                            {ollamaStatus.status === 'offline' && (
                                <div className="p-4 bg-red-950/20 rounded-lg border border-red-500/10 text-red-500 text-[10px] leading-relaxed">
                                    ⚠️ SYSTEM ALERT: Ollama engine is unreachable. Local models are currently disabled. Ensure the service is running and CORS is configured.
                                </div>
                            )}
                        </div>
                    </div>
                </section>

                {/* Roles / Specialist Matrix Section */}
                <section className="lg:col-span-7">
                    <div className="glass-panel p-6 h-full">
                        <h2 className="text-xl font-bold flex items-center gap-2 mb-6">
                            <BrainCircuit className="w-5 h-5 text-aegis-cyan" />
                            🦾 Matriz de Especialistas (Roles)
                        </h2>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
                            <RoleSelector
                                icon={MessageSquare}
                                label="Chat / General"
                                value={settings.local_chat_model}
                                options={ollamaStatus.models}
                                onChange={(v) => handleUpdate('local_chat_model', v)}
                            />
                            <RoleSelector
                                icon={Code}
                                label="Coder / Forge"
                                value={settings.local_coder_model}
                                options={ollamaStatus.models}
                                onChange={(v) => handleUpdate('local_coder_model', v)}
                            />
                            <RoleSelector
                                icon={Cpu}
                                label="Logic / Reasoning"
                                value={settings.local_logic_model}
                                options={ollamaStatus.models}
                                onChange={(v) => handleUpdate('local_logic_model', v)}
                            />
                            <RoleSelector
                                icon={Zap}
                                label="Heavy Context"
                                value={settings.local_heavy_model}
                                options={ollamaStatus.models}
                                onChange={(v) => handleUpdate('local_heavy_model', v)}
                            />
                            <RoleSelector
                                icon={Eye}
                                label="Vision Control"
                                value={settings.local_vision_model}
                                options={ollamaStatus.models}
                                onChange={(v) => handleUpdate('local_vision_model', v)}
                            />
                        </div>
                    </div>
                </section>
            </div>
        </div>
    );
}

function RoleSelector({ icon: Icon, label, value, options = [], onChange }) {
    return (
        <div className="space-y-2 group">
            <label className="flex items-center gap-2 text-[10px] font-black text-gray-500 uppercase tracking-[0.2em] group-hover:text-aegis-cyan transition-colors">
                <Icon className="w-3 h-3" />
                {label}
            </label>
            <select
                value={value || ""}
                onChange={(e) => onChange(e.target.value)}
                className="w-full bg-black/40 border border-white/10 rounded-lg px-3 py-2 text-xs font-mono text-white focus:border-aegis-cyan outline-none transition-all cursor-pointer hover:bg-black/60"
            >
                <option value="">Auto Detect / Not Set</option>
                {options.map((m) => (
                    <option key={m.name} value={m.name}>
                        {m.name.split(':')[0].toUpperCase()} ({(m.size / (1024 ** 3)).toFixed(1)}GB)
                    </option>
                ))}
            </select>
        </div>
    );
}
