import React, { useEffect, useState } from 'react';
import { Terminal, RefreshCw, AlertTriangle, Info, ShieldAlert } from 'lucide-react';
import { API_BASE } from '../store/useSystemStore';

const SystemLogsView = () => {
    const [logs, setLogs] = useState([]);
    const [loading, setLoading] = useState(false);
    const [filter, setFilter] = useState('ALL');

    const fetchLogs = async () => {
        setLoading(true);
        try {
            const url = filter === 'ALL'
                ? `${API_BASE}/api/system/logs?limit=100`
                : `${API_BASE}/api/system/logs?limit=100&level=${filter}`;
            const resp = await fetch(url);
            const data = await resp.json();
            setLogs(data);
        } catch (e) {
            console.error("Failed to fetch logs", e);
        }
        setLoading(false);
    };

    useEffect(() => {
        fetchLogs();
        const interval = setInterval(fetchLogs, 5000);
        return () => clearInterval(interval);
    }, [filter]);

    const getLevelIcon = (level) => {
        switch (level) {
            case 'ERROR': return <AlertTriangle size={14} className="text-red-500" />;
            case 'WARNING': return <ShieldAlert size={14} className="text-yellow-500" />;
            default: return <Info size={14} className="text-cyan-500" />;
        }
    };

    const getLevelClass = (level) => {
        switch (level) {
            case 'ERROR': return 'text-red-400 bg-red-500/10 border-red-500/20';
            case 'WARNING': return 'text-yellow-400 bg-yellow-500/10 border-yellow-500/20';
            default: return 'text-cyan-400 bg-cyan-500/10 border-cyan-500/20';
        }
    };

    return (
        <div className="h-full flex flex-col space-y-4 animate-in fade-in duration-500">
            <header className="flex justify-between items-center bg-white/5 p-4 rounded-2xl border border-white/10 backdrop-blur-md">
                <div className="flex items-center gap-3">
                    <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                        <Terminal size={20} />
                    </div>
                    <div>
                        <h2 className="text-lg font-bold text-white tracking-tight">REGISTROS DEL SISTEMA</h2>
                        <p className="text-[10px] text-gray-500 uppercase tracking-widest">Trazabilidad en Tiempo Real</p>
                    </div>
                </div>

                <div className="flex items-center gap-3">
                    <select
                        value={filter}
                        onChange={(e) => setFilter(e.target.value)}
                        className="bg-black/40 border border-white/10 text-[10px] text-gray-300 rounded-lg px-3 py-1 outline-none focus:border-cyan-500 transition-all font-mono"
                    >
                        <option value="ALL">TODOS LOS NIVELES</option>
                        <option value="INFO">INFO</option>
                        <option value="WARNING">WARNING</option>
                        <option value="ERROR">ERROR</option>
                    </select>

                    <button
                        onClick={fetchLogs}
                        disabled={loading}
                        className="p-2 rounded-xl bg-white/5 text-gray-400 hover:text-white hover:bg-white/10 transition-all border border-white/5"
                    >
                        <RefreshCw size={16} className={loading ? 'animate-spin' : ''} />
                    </button>
                </div>
            </header>

            <div className="flex-1 overflow-hidden glass-panel border border-white/5 rounded-2xl flex flex-col">
                <div className="grid grid-cols-[160px_80px_140px_1fr] gap-4 p-3 border-b border-white/5 text-[10px] font-bold text-gray-500 uppercase tracking-widest bg-white/2">
                    <span>Timestamp</span>
                    <span>Nivel</span>
                    <span>Módulo</span>
                    <span>Mensaje</span>
                </div>

                <div className="flex-1 overflow-y-auto font-mono text-[11px] p-1 custom-scrollbar">
                    {logs.length === 0 ? (
                        <div className="h-full flex items-center justify-center text-gray-600 italic">
                            No hay registros disponibles...
                        </div>
                    ) : (
                        logs.map((log, idx) => (
                            <div key={idx} className="grid grid-cols-[160px_80px_140px_1fr] gap-4 p-2 hover:bg-white/5 border-b border-white/5 transition-colors group">
                                <span className="text-gray-500 opacity-60 group-hover:opacity-100">
                                    {log.timestamp.replace('T', ' ').split('.')[0]}
                                </span>
                                <div className="flex items-center gap-2">
                                    <span className={`px-2 py-0.5 rounded-md border text-[9px] font-bold ${getLevelClass(log.level)}`}>
                                        {log.level}
                                    </span>
                                </div>
                                <span className="text-purple-400 font-bold tracking-tight">
                                    [{log.module}]
                                </span>
                                <span className="text-gray-300 break-all">
                                    {log.message}
                                </span>
                            </div>
                        ))
                    )}
                </div>
            </div>

            <footer className="p-2 text-center">
                <p className="text-[9px] text-gray-600 uppercase tracking-[0.3em]">Protocolo de Auditoría Activo • Aegis SRE Console</p>
            </footer>
        </div>
    );
};

export default SystemLogsView;
