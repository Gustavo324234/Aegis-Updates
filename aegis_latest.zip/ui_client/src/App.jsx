import React, { useEffect } from 'react';
import useSystemStore from './store/useSystemStore.js';
import AppLayout from './components/AppLayout.jsx';
import ChatConsole from './components/ChatConsole.jsx';
import AdminPanelView from './views/AdminPanelView.jsx';
import AdvancedSettingsView from './views/AdvancedSettingsView.jsx';
import AuthGate from './components/AuthGate.jsx';
import KnowledgeMap from './components/KnowledgeMap.jsx';
import WorkspaceView from './components/WorkspaceView.jsx';

export default function App() {
  const { activeView, fetchStatus } = useSystemStore();

  useEffect(() => {
    fetchStatus();
  }, [fetchStatus]);

  const renderView = () => {
    switch (activeView) {
      case 'chat':
        return <ChatConsole />;
      case 'graph':
        return <KnowledgeMap />;
      case 'settings':
        return <AdvancedSettingsView />;
      case 'admin':
        return <AdminPanelView />;
      case 'workspace':
        return <WorkspaceView />;
      default:
        return <ChatConsole />;
    }
  };

  return (
    <AuthGate>
      <AppLayout>
        {renderView()}
      </AppLayout>
    </AuthGate>
  );
}
