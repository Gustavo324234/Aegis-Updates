import React, { useEffect } from 'react';
import useSystemStore from './store/useSystemStore.js';
import ChatConsole from './components/ChatConsole.jsx';
import AdminPanel from './components/AdminPanel.jsx';
import SettingsPanel from './components/SettingsPanel.jsx';
import AuthScreens from './components/AuthScreens.jsx';

export default function App() {
  const { activeView, setActiveView, fetchStatus, setupComplete, authenticated } = useSystemStore();

  useEffect(() => {
    fetchStatus();
  }, []);

  // Forzar pantallas de seguridad si es necesario
  if (!setupComplete || activeView === 'onboarding') {
    return <AuthScreens />;
  }

  if (!authenticated || activeView === 'login') {
    // Truco: Si ya se hizo el setup pero no estamos auth, forzamos la vista login
    if (activeView !== 'login') setActiveView('login');
    return <AuthScreens />;
  }

  const navButton = (view, icon, title, colorClass) => (
    <button
      onClick={() => setActiveView(view)}
      className={`p-3 rounded-xl mb-4 transition-all w-12 h-12 flex items-center justify-center text-lg ${activeView === view ? colorClass : 'text-gray-500 hover:text-gray-300 hover:bg-gray-800/50'}`}
      title={title}
    >
      {icon}
    </button>
  );

  return (
    <div className="flex h-screen bg-[#000000] text-gray-200 font-mono">
      {/* Sidebar */}
      <nav className="w-16 flex flex-col items-center py-4 border-r border-gray-800 bg-[#0d1117] z-50">
        <div className="text-cyan-400 font-bold text-xl mb-8 shadow-cyan">🛡️</div>

        {navButton('chat', '💬', 'Consola Neural', 'bg-cyan-900/40 text-cyan-400 border border-cyan-500/50 shadow-[0_0_15px_rgba(0,242,254,0.2)]')}
        {navButton('settings', '🔐', 'Bóveda y Motores', 'bg-green-900/40 text-green-400 border border-green-500/50 shadow-[0_0_15px_rgba(74,222,128,0.2)]')}
        {navButton('admin', '⚙️', 'Panel SRE', 'bg-purple-900/40 text-purple-400 border border-purple-500/50 shadow-[0_0_15px_rgba(191,0,255,0.2)]')}

        <div className="mt-auto">
          <button onClick={() => { useSystemStore.setState({ authenticated: false }); setActiveView('login'); }} className="text-gray-600 hover:text-red-500 transition-colors" title="Lock System">
            🔒
          </button>
        </div>
      </nav>

      {/* Main Area */}
      <main className="flex-1 relative overflow-hidden">
        {activeView === 'chat' && <ChatConsole />}
        {activeView === 'settings' && <SettingsPanel />}
        {activeView === 'admin' && <AdminPanel />}
      </main>
    </div>
  );
}
