import React, { useEffect } from 'react';
import useSystemStore from './store/useSystemStore.js';
import AppLayout from './components/AppLayout.jsx';
import ChatConsole from './components/ChatConsole.jsx';
import AdminPanelView from './views/AdminPanelView.jsx';
import AdvancedSettingsView from './views/AdvancedSettingsView.jsx';
import AuthGate from './components/AuthGate.jsx';
import KnowledgeMap from './components/KnowledgeMap.jsx';
import WorkspaceView from './components/WorkspaceView.jsx';
import SystemLogsView from './views/SystemLogsView.jsx';

export default function App() {
  const { activeView, fetchStatus, systemRole } = useSystemStore();

  useEffect(() => {
    fetchStatus();
  }, [fetchStatus]);

  if (!systemRole) return (
    <div className="h-screen w-screen bg-[#050505] flex items-center justify-center">
      <div className="text-cyan-500 animate-pulse font-mono">INITIALIZING AEGIS_PROTOCOL...</div>
    </div>
  );

  const renderView = () => {
    // Modo Master: Solo Gestión y Configuración Global
    if (systemRole === 'master') {
      if (activeView === 'settings') return <AdvancedSettingsView />;
      if (activeView === 'logs') return <SystemLogsView />;
      return <AdminPanelView />;
    }

    // Modo Tenant: Interfaz de Usuario e IA
    switch (activeView) {
      case 'chat':
        return <ChatConsole />;
      case 'graph':
        return <KnowledgeMap />;
      case 'settings':
        return <AdvancedSettingsView />;
      case 'workspace':
        return <WorkspaceView />;
      case 'logs':
        return <SystemLogsView />;
      default:
        return <ChatConsole />;
    }
  };

  return (
    <AuthGate>
      <AppLayout>
        {renderView()}
      </AppLayout>
    </AuthGate>
  );
}
