import { create } from 'zustand';

const useChatStore = create((set, get) => ({
    messages: [],
    isThinking: false,
    currentThought: "",
    artifacts: [], // { id, title, language, code, timestamp }
    swarmStatus: "Awaiting Command",
    metadata: null,
    pendingActions: [],
    currentSources: [],
    currentCitations: {},
    connectionStatus: 'disconnected', // 'connected', 'disconnected', 'connecting'
    socket: null,

    // Acciones para actualizar el estado
    addMessage: (msg) => set((state) => ({ messages: [...state.messages, msg] })),

    updateLastMessage: (updater) => set((state) => {
        if (state.messages.length === 0) return state;
        const lastIdx = state.messages.length - 1;
        const newMessages = [...state.messages];
        newMessages[lastIdx] = updater(newMessages[lastIdx]);
        return { messages: newMessages };
    }),

    setThinking: (status) => set({ isThinking: status }),
    setSwarmStatus: (status) => set({ swarmStatus: status }),
    clearThought: () => set({ currentThought: "", currentSources: [], currentCitations: {} }),

    addArtifact: (artifact) => set((state) => ({
        artifacts: [...state.artifacts, { ...artifact, id: Date.now() }]
    })),

    addAction: (action) => set((state) => ({
        pendingActions: [...state.pendingActions, action]
    })),

    removeAction: (jobId) => set((state) => ({
        pendingActions: state.pendingActions.filter(a => a.job_id !== jobId)
    })),

    setConnectionStatus: (status) => set({ connectionStatus: status }),

    // Lógica de WebSocket encapsulada
    connectWebSocket: (sessionId = "default_session") => {
        if (get().socket) return;

        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const host = window.location.host; // includes port

        // If we are in dev mode (vite), host will be reachable at port 8000 on the same hostname
        const finalHost = window.location.port === '5173' ? `${window.location.hostname}:8000` : host;

        const wsUrl = `${protocol}//${finalHost}/ws/chat/${sessionId}`;
        let ws = null;
        let reconnectTimeout = null;
        let reconnectAttempts = 0;

        const connect = () => {
            ws = new WebSocket(wsUrl);

            ws.onopen = () => {
                console.log('🔗 WebSocket Connected');
                set({ connectionStatus: 'connected', socket: ws, isThinking: false, swarmStatus: "Operational" });
                reconnectAttempts = 0;
            };

            ws.onmessage = (event) => {
                try {
                    const data = JSON.parse(event.data);
                    const type = data.type;

                    if (type === 'text') {
                        const state = get();
                        const lastMsg = state.messages[state.messages.length - 1];
                        if (lastMsg && lastMsg.role === 'assistant' && lastMsg.isStreaming) {
                            get().updateLastMessage(msg => ({
                                ...msg,
                                content: msg.content + data.content,
                                citations: { ...(msg.citations || {}), ...state.currentCitations }
                            }));
                        } else {
                            get().addMessage({
                                id: Date.now(),
                                role: 'assistant',
                                content: data.content,
                                isStreaming: true,
                                citations: state.currentCitations
                            });
                        }
                    }
                    else if (type === 'thought') {
                        set((state) => ({ currentThought: state.currentThought + data.content }));
                    }
                    else if (type === 'retrieval') {
                        set({ currentSources: data.sources });
                    }
                    else if (type === 'citations') {
                        set((state) => ({ currentCitations: { ...state.currentCitations, ...data.data } }));
                    }
                    else if (type === 'status') {
                        set({ swarmStatus: data.msg });
                        get().addMessage({ id: Date.now(), role: 'system', content: data.msg });
                    }
                    else if (type === 'metadata') {
                        set({ metadata: data });
                    }
                    else if (type === 'tool_call') {
                        // Initialize tool call with status and empty logs
                        get().addAction({
                            ...data,
                            status: data.status || 'Pending',
                            logs: []
                        });
                    }
                    else if (type === 'terminal_output') {
                        set((state) => ({
                            pendingActions: state.pendingActions.map(a =>
                                a.job_id === data.job_id
                                    ? { ...a, status: 'Executing', logs: [...(a.logs || []), data.line] }
                                    : a
                            )
                        }));
                    }
                    else if (type === 'tool_result' || type === 'tool_error') {
                        const status = type === 'tool_error' ? 'Failed' : 'Completed';
                        set((state) => ({
                            pendingActions: state.pendingActions.map(a =>
                                a.job_id === data.job_id
                                    ? { ...a, status, result: data.result || data.error }
                                    : a
                            )
                        }));

                        get().addMessage({
                            id: Date.now(),
                            role: 'system',
                            content: `Action ${data.tool_name} ${status.toLowerCase()}: ${JSON.stringify(data.result || data.error)}`
                        });
                    }
                    else if (type === 'done') {
                        get().updateLastMessage(msg => ({ ...msg, isStreaming: false }));
                        set({ isThinking: false, swarmStatus: "Operational" });
                    }

                } catch (e) {
                    console.error("Error parsing WS message:", e, event.data);
                }
            };

            ws.onclose = () => {
                console.log('🔴 WebSocket Disconnected');
                set({ connectionStatus: 'disconnected', socket: null, isThinking: false });

                // Exponential Backoff Reconnection
                const backoff = Math.min(1000 * (2 ** reconnectAttempts), 10000);
                console.log(`Will reconnect in ${backoff}ms...`);
                reconnectAttempts++;
                reconnectTimeout = setTimeout(connect, backoff);
            };

            ws.onerror = (err) => {
                console.error('WebSocket Error:', err);
                // onclose will be called after this
            };
        };

        connect();

        return () => {
            if (reconnectTimeout) clearTimeout(reconnectTimeout);
            if (ws) {
                ws.onclose = null; // Evitar reconexión al desmontar
                ws.close();
            }
        };
    },

    sendMessage: (text, image = null) => {
        const state = get();
        if (!state.socket || state.connectionStatus !== 'connected') {
            console.error("Cannot send message, WS disconnected");
            return;
        }

        // Reset UI state for new message
        set({ currentThought: "", currentSources: [], currentCitations: {}, swarmStatus: "Routing Request..." });
        get().addMessage({ id: Date.now(), role: 'user', content: text, image });
        get().setThinking(true);

        // Enviar al servidor
        state.socket.send(JSON.stringify({ prompt: text, image: image }));
    },

    fetchHistory: async (sessionId = "general") => {
        try {
            const host = window.location.port === '5173' ? `${window.location.protocol}//${window.location.hostname}:8000` : window.location.origin;
            const res = await fetch(`${host}/api/chat/history?thread_tag=${sessionId}`);
            const data = await res.json();
            set({ messages: data });
        } catch (e) {
            console.error("Error fetching history:", e);
        }
    },

}));

export default useChatStore;
