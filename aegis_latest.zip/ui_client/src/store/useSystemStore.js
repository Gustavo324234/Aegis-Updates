import { create } from 'zustand';

const getApiBase = () => {
    if (window.location.port === '5173') {
        return `${window.location.protocol}//${window.location.hostname}:8000`;
    }
    return ''; // Relative to current host
};

export const API_BASE = getApiBase();

const useSystemStore = create((set) => ({
    setupComplete: true,
    authenticated: false,
    health: 'GREEN',
    metrics: {},
    hardwareTier: { id: 2, name: 'Standard' },
    settings: {},
    daemons: [],
    nodes: [],
    tenants: [],
    apiKeys: [],
    ollamaStatus: { status: 'checking', models: [], version: '' },
    activeView: 'chat', // 'chat', 'settings', 'nodes', 'vault', 'onboarding', 'login'
    layoutMode: 'user', // 'user' (Neural Interface) or 'admin' (Command Center)

    // Fetchers
    checkOllama: async () => {
        try {
            const resp = await fetch(`${API_BASE}/api/system/ollama/check`);
            const data = await resp.json();
            set({ ollamaStatus: data });
        } catch (e) {
            set({ ollamaStatus: { status: 'offline', models: [], message: e.message } });
        }
    },
    fetchStatus: async () => {
        try {
            const resp = await fetch(`${API_BASE}/api/system/status`);
            const data = await resp.json();
            set({
                setupComplete: data.setup_complete,
                health: data.health,
                metrics: data.metrics,
                hardwareTier: data.hardware_tier
            });
            if (!data.setup_complete) set({ activeView: 'onboarding' });
        } catch (e) {
            console.error("Failed to fetch status", e);
        }
    },

    fetchSettings: async () => {
        try {
            const resp = await fetch(`${API_BASE}/api/settings`);
            const data = await resp.json();
            set({ settings: data });
        } catch (e) {
            console.error("Failed to fetch settings", e);
        }
    },

    updateSettings: async (newSettings) => {
        try {
            await fetch(`${API_BASE}/api/settings`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(newSettings)
            });
            set((state) => ({ settings: { ...state.settings, ...newSettings } }));
        } catch (e) {
            console.error("Failed to update settings", e);
        }
    },

    fetchDaemons: async () => {
        try {
            const resp = await fetch(`${API_BASE}/api/daemons`);
            const data = await resp.json();
            set({ daemons: data });
        } catch (e) {
            console.error("Failed to fetch daemons", e);
        }
    },

    toggleDaemon: async (name) => {
        try {
            await fetch(`${API_BASE}/api/daemons/${name}/toggle`, { method: 'POST' });
            // Refresh
            const resp = await fetch(`${API_BASE}/api/daemons`);
            const data = await resp.json();
            set({ daemons: data });
        } catch (e) {
            console.error("Failed to toggle daemon", e);
        }
    },

    fetchNodes: async () => {
        try {
            const resp = await fetch(`${API_BASE}/api/nodes`);
            const data = await resp.json();
            set({ nodes: data });
        } catch (e) {
            console.error("Failed to fetch nodes", e);
        }
    },

    // Tenants (User Factory)
    fetchTenants: async () => {
        try {
            const resp = await fetch(`${API_BASE}/api/tenants`);
            const data = await resp.json();
            set({ tenants: data });
        } catch (e) {
            console.error("Failed to fetch tenants", e);
        }
    },

    deployTenant: async (username, port, mode) => {
        try {
            const resp = await fetch(`${API_BASE}/api/tenants/deploy`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, port, mode })
            });
            const data = await resp.json();
            if (data.status === 'success') {
                const updated = await fetch(`${API_BASE}/api/tenants`);
                set({ tenants: await updated.json() });
            }
            return data;
        } catch (e) {
            console.error("Failed to deploy tenant", e);
            return { status: 'error', message: e.message };
        }
    },

    stopTenant: async (username) => {
        try {
            const resp = await fetch(`${API_BASE}/api/tenants/${username}/stop`, { method: 'POST' });
            const data = await resp.json();
            if (data.status === 'success') {
                const updated = await fetch(`${API_BASE}/api/tenants`);
                set({ tenants: await updated.json() });
            }
            return data;
        } catch (e) {
            console.error("Failed to stop tenant", e);
            return { status: 'error', message: e.message };
        }
    },

    startTenant: async (username) => {
        try {
            const resp = await fetch(`${API_BASE}/api/tenants/${username}/start`, { method: 'POST' });
            const data = await resp.json();
            if (data.status === 'success') {
                const updated = await fetch(`${API_BASE}/api/tenants`);
                set({ tenants: await updated.json() });
            }
            return data;
        } catch (e) {
            console.error("Failed to start tenant", e);
            return { status: 'error', message: e.message };
        }
    },

    deleteTenant: async (username) => {
        try {
            const resp = await fetch(`${API_BASE}/api/tenants/${username}`, { method: 'DELETE' });
            const data = await resp.json();
            if (data.status === 'success') {
                const updated = await fetch(`${API_BASE}/api/tenants`);
                set({ tenants: await updated.json() });
            }
            return data;
        } catch (e) {
            console.error("Failed to delete tenant", e);
            return { status: 'error', message: e.message };
        }
    },

    // API Keys
    fetchKeys: async () => {
        try {
            const resp = await fetch(`${API_BASE}/api/keys`);
            const data = await resp.json();
            set({ apiKeys: data });
        } catch (e) {
            console.error("Failed to fetch keys", e);
        }
    },

    addKey: async (service, key, masterPassword) => {
        try {
            const resp = await fetch(`${API_BASE}/api/keys`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ service, key, master_password: masterPassword })
            });
            const data = await resp.json();
            if (data.status === 'success') {
                const updated = await fetch(`${API_BASE}/api/keys`);
                set({ apiKeys: await updated.json() });
            }
            return data;
        } catch (e) {
            console.error("Failed to add key", e);
            return { status: 'error', message: e.message };
        }
    },

    deleteKey: async (service) => {
        try {
            const resp = await fetch(`${API_BASE}/api/keys/${service}`, {
                method: 'DELETE'
            });
            const data = await resp.json();
            if (data.status === 'success') {
                const updated = await fetch(`${API_BASE}/api/keys`);
                set({ apiKeys: await updated.json() });
            }
            return data;
        } catch (e) {
            console.error("Failed to delete key", e);
            return { status: 'error', message: e.message };
        }
    },

    login: async (password) => {
        try {
            const resp = await fetch(`${API_BASE}/api/auth/login`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ password })
            });
            const data = await resp.json();
            if (data.status === 'success') {
                set({ authenticated: true, activeView: 'chat' });
                return true;
            }
            return false;
        } catch (e) {
            console.error("Login failed", e);
            return false;
        }
    },

    setupSystem: async (payload) => {
        try {
            const resp = await fetch(`${API_BASE}/api/auth/setup`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            const data = await resp.json();
            if (data.status === 'success') {
                set({ setupComplete: true, authenticated: true, activeView: 'chat' });
                return true;
            }
            return false;
        } catch (e) {
            console.error("Setup failed", e);
            return false;
        }
    },

    setActiveView: (view) => set({ activeView: view }),
    setLayoutMode: (mode) => set({ layoutMode: mode }),
    setAuthenticated: (status) => set({ authenticated: status })
}));

export default useSystemStore;
