import React, { useEffect, useState } from 'react';
import useSystemStore from '../store/useSystemStore';

export default function SettingsPanel() {
    const { settings, fetchSettings, updateSettings, checkOllama, ollamaStatus, apiKeys, fetchKeys, addKey, deleteKey } = useSystemStore();
    const [ollamaUrl, setOllamaUrl] = useState("");

    // API Vault State
    const [masterPass, setMasterPass] = useState("");
    const [newProvider, setNewProvider] = useState("gemini");
    const [newApiValue, setNewApiValue] = useState("");

    useEffect(() => {
        fetchSettings();
        checkOllama();
        fetchKeys();
    }, []);

    useEffect(() => {
        if (settings.ollama_url) setOllamaUrl(settings.ollama_url);
    }, [settings]);

    const handleSaveOllama = () => {
        updateSettings({ ollama_url: ollamaUrl });
        setTimeout(checkOllama, 500);
    };

    const handleAddKey = async () => {
        if (!masterPass) return alert("Se requiere la Contraseña Maestra para encriptar la llave.");
        if (!newApiValue) return alert("El valor de la API Key no puede estar vacío.");

        await addKey(newProvider, newApiValue, masterPass);
        setNewApiValue(""); // Limpiar input
    };

    return (
        <div className="p-10 h-full overflow-y-auto bg-[#050505] text-gray-300 scrollbar-refined">
            <h1 className="text-3xl text-cyan-400 font-bold mb-2 tracking-wider">BÓVEDA DE CONFIGURACIÓN</h1>
            <p className="text-gray-500 mb-8">Gestiona el motor de inteligencia y tus credenciales seguras.</p>

            <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">

                {/* Motor Local */}
                <div className="glass-panel p-6 h-fit">
                    <h2 className="text-xl text-green-400 border-b border-gray-800 pb-2 mb-4 font-bold flex items-center gap-2">
                        🧠 Motor Local (Ollama)
                    </h2>
                    <div className="flex gap-2 mb-4">
                        <input
                            type="text"
                            value={ollamaUrl}
                            onChange={(e) => setOllamaUrl(e.target.value)}
                            className="flex-1 bg-black border border-gray-700 rounded p-2 text-sm text-white focus:border-green-500 outline-none"
                            placeholder="http://127.0.0.1:11434"
                        />
                        <button onClick={handleSaveOllama} className="bg-green-900/40 text-green-400 px-4 rounded border border-green-500/50 hover:bg-green-800/60 transition-all">
                            Guardar / Test
                        </button>
                    </div>
                    <div className="p-3 bg-black/50 rounded border border-gray-800 text-sm">
                        <span className="text-gray-400">Estado: </span>
                        {ollamaStatus?.status === 'online' ? <span className="text-green-400 font-bold">ONLINE</span> : <span className="text-red-400 font-bold">OFFLINE</span>}
                        <br />
                        <span className="text-gray-400">Modelos Detectados: </span>
                        <span className="text-cyan-300">{ollamaStatus?.models?.length || 0} instalados</span>
                    </div>
                </div>

                {/* Llaves API */}
                <div className="glass-panel p-6">
                    <h2 className="text-xl text-purple-400 border-b border-gray-800 pb-2 mb-4 font-bold">
                        🔑 API Vault (Nube)
                    </h2>

                    {/* Master Password Input */}
                    <div className="mb-6 p-4 bg-black/50 border border-gray-800 rounded-lg">
                        <label className="block text-xs text-gray-500 mb-1">Contraseña Maestra (Requerida para Encriptar/Desencriptar)</label>
                        <input
                            type="password"
                            value={masterPass}
                            onChange={(e) => setMasterPass(e.target.value)}
                            className="w-full bg-[#0d1117] border border-gray-700 rounded p-2 text-sm text-white focus:border-purple-500 outline-none"
                            placeholder="**********"
                        />
                    </div>

                    {/* Agregar Nueva Llave */}
                    <div className="flex gap-2 mb-6">
                        <select
                            value={newProvider}
                            onChange={(e) => setNewProvider(e.target.value)}
                            className="bg-black border border-gray-700 rounded p-2 text-sm text-white focus:border-purple-500 outline-none w-1/3"
                        >
                            <option value="gemini">Gemini</option>
                            <option value="openai">OpenAI</option>
                            <option value="anthropic">Anthropic</option>
                            <option value="groq">Groq</option>
                        </select>
                        <input
                            type="password"
                            value={newApiValue}
                            onChange={(e) => setNewApiValue(e.target.value)}
                            className="flex-1 bg-black border border-gray-700 rounded p-2 text-sm text-white focus:border-purple-500 outline-none"
                            placeholder="sk-..."
                        />
                        <button onClick={handleAddKey} className="bg-purple-900/40 text-purple-400 px-4 rounded border border-purple-500/50 hover:bg-purple-800/60 transition-all font-bold">
                            + Añadir
                        </button>
                    </div>

                    {/* Lista de Llaves Activas */}
                    <h3 className="text-sm text-gray-400 mb-2">Llaves Encriptadas Activas:</h3>
                    {apiKeys?.length === 0 ? (
                        <p className="text-xs text-gray-600 italic">No hay llaves registradas en la bóveda.</p>
                    ) : (
                        <div className="space-y-2">
                            {apiKeys?.map((k) => (
                                <div key={k.id} className="flex justify-between items-center p-3 bg-[#0d1117] border border-gray-800 rounded">
                                    <span className="text-sm font-bold text-gray-300 uppercase">{k.service}</span>
                                    <div className="flex items-center gap-4">
                                        <span className="text-xs text-gray-500 tracking-widest">••••••••••••</span>
                                        <button
                                            onClick={() => deleteKey(k.service)}
                                            className="text-red-500 hover:text-red-400 bg-red-900/20 px-2 py-1 rounded border border-red-900/50 text-xs"
                                        >
                                            ELIMINAR
                                        </button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>

            </div>
        </div>
    );
}
