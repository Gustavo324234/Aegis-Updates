import React, { useEffect, useState } from 'react';
import useSystemStore from '../store/useSystemStore';

/**
 * SettingsView.jsx
 * Componente principal de configuraciones con arquitectura Headless.
 * Diseño: Cyber-Dark / Glassmorphism
 */
const SettingsView = () => {
    const {
        settings, fetchSettings, updateSettings,
        apiKeys, fetchKeys, addKey, deleteKey,
        ollamaStatus, checkOllama
    } = useSystemStore();

    const [activeTab, setActiveTab] = useState('brain');
    const [loading, setLoading] = useState(false);

    // Form states for API Vault
    const [masterPass, setMasterPass] = useState("");
    const [newProvider, setNewProvider] = useState("gemini");
    const [newApiValue, setNewApiValue] = useState("");

    useEffect(() => {
        const init = async () => {
            setLoading(true);
            await Promise.all([fetchSettings(), fetchKeys(), checkOllama()]);
            setLoading(false);
        };
        init();
    }, []);

    const handleUpdateSetting = async (key, value) => {
        setLoading(true);
        await updateSettings({ [key]: value });
        setLoading(false);
    };

    const handleAddKey = async (e) => {
        e.preventDefault();
        if (!masterPass || !newApiValue) return;
        setLoading(true);
        const res = await addKey(newProvider, newApiValue, masterPass);
        setLoading(false);
        if (res.status === 'success') {
            setNewApiValue("");
        }
    };

    const handleDeleteKey = async (provider) => {
        if (confirm(`¿Eliminar llave de ${provider.toUpperCase()}?`)) {
            setLoading(true);
            await deleteKey(provider);
            setLoading(false);
        }
    };

    const handleCheckUpdates = async () => {
        setLoading(true);
        // Simulación de interacción con endpoints SRE
        try {
            await new Promise(r => setTimeout(r, 2000));
            alert("¡Aegis-IA está en su versión operativa más reciente (Bunker-Headless v2.5)!");
        } finally {
            setLoading(false);
        }
    };

    // Spinner Component
    const LoadingOverlay = () => (
        <div className="absolute inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50 rounded-xl">
            <div className="flex flex-col items-center">
                <div className="w-12 h-12 border-4 border-aegis-cyan border-t-transparent rounded-full animate-spin shadow-[0_0_15px_rgba(0,242,254,0.5)]"></div>
                <p className="mt-4 text-xs font-bold text-aegis-cyan animate-pulse tracking-[0.2em]">SINCRONIZANDO...</p>
            </div>
        </div>
    );

    return (
        <div className="relative w-full h-full max-w-6xl mx-auto p-6 animate-in fade-in duration-500">
            {loading && <LoadingOverlay />}

            <header className="mb-8 pl-2">
                <h1 className="text-4xl font-black neon-text uppercase tracking-tighter mb-1">
                    Configuración del Sistema
                </h1>
                <p className="text-gray-500 text-sm font-light">Acceso Maestro a la Infraestructura de Aegis-IA</p>
            </header>

            <div className="flex flex-col lg:flex-row gap-6 h-[calc(100%-120px)]">
                {/* Tab Sidebar */}
                <nav className="flex lg:flex-col gap-2 w-full lg:w-64">
                    <TabButton
                        active={activeTab === 'brain'}
                        icon="🧠"
                        label="AI Brain"
                        onClick={() => setActiveTab('brain')}
                    />
                    <TabButton
                        active={activeTab === 'vault'}
                        icon="🔐"
                        label="API Vault"
                        onClick={() => setActiveTab('vault')}
                    />
                    <TabButton
                        active={activeTab === 'system'}
                        icon="🚀"
                        label="System Update"
                        onClick={() => setActiveTab('system')}
                    />
                </nav>

                {/* Content Panel */}
                <main className="flex-1 glass-panel p-8 overflow-y-auto scrollbar-refined relative border-white/5">

                    {activeTab === 'brain' && (
                        <div className="space-y-10">
                            <section>
                                <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
                                    <span className="text-aegis-cyan">01.</span> Operation Mode
                                </h2>
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                    {['cloud', 'local', 'hybrid'].map((mode) => (
                                        <button
                                            key={mode}
                                            onClick={() => handleUpdateSetting('operation_mode', mode)}
                                            className={`p-4 rounded-lg border transition-all duration-300 ${settings.operation_mode === mode
                                                    ? 'bg-aegis-cyan/10 border-aegis-cyan text-aegis-cyan shadow-[0_0_15px_rgba(0,242,254,0.2)]'
                                                    : 'bg-white/5 border-white/10 text-gray-400 hover:border-white/20'
                                                }`}
                                        >
                                            <div className="text-xs uppercase font-bold mb-1 tracking-widest">{mode} Only</div>
                                            <p className="text-[10px] opacity-60 leading-tight">
                                                {mode === 'cloud' && "Prioriza Gemini/Anthropic para máxima potencia."}
                                                {mode === 'local' && "Procesamiento 100% privado en tu hardware."}
                                                {mode === 'hybrid' && "Equilibrio inteligente entre nube y local."}
                                            </p>
                                        </button>
                                    ))}
                                </div>
                            </section>

                            <section>
                                <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
                                    <span className="text-aegis-cyan">02.</span> Local Engines (Ollama)
                                </h2>
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                    <ModelSelect
                                        label="Chat Model"
                                        value={settings.local_chat_model}
                                        options={ollamaStatus.models}
                                        onChange={(v) => handleUpdateSetting('local_chat_model', v)}
                                    />
                                    <ModelSelect
                                        label="Coder Model"
                                        value={settings.local_coder_model}
                                        options={ollamaStatus.models}
                                        onChange={(v) => handleUpdateSetting('local_coder_model', v)}
                                    />
                                    <ModelSelect
                                        label="Logic Model"
                                        value={settings.local_logic_model}
                                        options={ollamaStatus.models}
                                        onChange={(v) => handleUpdateSetting('local_logic_model', v)}
                                    />
                                </div>
                                {ollamaStatus.status === 'offline' && (
                                    <div className="mt-4 p-3 bg-red-950/20 border border-red-900/50 rounded-lg text-red-400 text-xs flex items-center gap-2">
                                        ⚠️ Ollama está desconectado. Los modelos locales no estarán disponibles.
                                        <button onClick={checkOllama} className="underline font-bold ml-auto cursor-pointer">REINTENTAR</button>
                                    </div>
                                )}
                            </section>
                        </div>
                    )}

                    {activeTab === 'vault' && (
                        <div className="space-y-10">
                            <section>
                                <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2 text-aegis-purple">
                                    <span>🔐</span> Vault Inventory
                                </h2>
                                <div className="overflow-hidden border border-white/5 rounded-xl bg-black/20">
                                    <table className="w-full text-left border-collapse">
                                        <thead>
                                            <tr className="bg-white/5 text-[10px] uppercase tracking-widest text-gray-500 font-bold">
                                                <th className="px-6 py-4">Proveedor</th>
                                                <th className="px-6 py-4">Token Status</th>
                                                <th className="px-6 py-4 text-right">Acciones</th>
                                            </tr>
                                        </thead>
                                        <tbody className="text-sm">
                                            {apiKeys.length === 0 ? (
                                                <tr>
                                                    <td colSpan="3" className="px-6 py-8 text-center text-gray-600 italic">No hay credenciales activas.</td>
                                                </tr>
                                            ) : (
                                                apiKeys.map((key) => (
                                                    <tr key={key.id} className="border-t border-white/5 hover:bg-white/[0.02] transition-colors">
                                                        <td className="px-6 py-4 font-black tracking-tighter text-white uppercase">{key.service}</td>
                                                        <td className="px-6 py-4 text-xs font-mono text-aegis-cyan/60">●●●●●●●●●●●●●●●●</td>
                                                        <td className="px-6 py-4 text-right">
                                                            <button
                                                                onClick={() => handleDeleteKey(key.service)}
                                                                className="text-red-500 hover:text-red-400 text-[10px] font-bold uppercase tracking-widest px-3 py-1 rounded bg-red-500/10 border border-red-500/20 transition-all"
                                                            >
                                                                Wipe
                                                            </button>
                                                        </td>
                                                    </tr>
                                                ))
                                            )}
                                        </tbody>
                                    </table>
                                </div>
                            </section>

                            <section className="bg-white/[0.02] p-6 rounded-xl border border-white/5">
                                <h3 className="text-sm font-bold text-gray-400 mb-4 uppercase tracking-widest">Añadir Nueva Inyección</h3>
                                <form onSubmit={handleAddKey} className="space-y-4">
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        <div>
                                            <label className="text-[10px] text-gray-500 uppercase font-bold block mb-1">Provider</label>
                                            <select
                                                value={newProvider}
                                                onChange={(e) => setNewProvider(e.target.value)}
                                                className="w-full bg-black/50 border border-white/10 rounded-lg p-2.5 text-white text-sm focus:border-aegis-purple focus:ring-1 focus:ring-aegis-purple outline-none transition-all"
                                            >
                                                <option value="gemini">Google Gemini</option>
                                                <option value="openai">OpenAI</option>
                                                <option value="anthropic">Anthropic</option>
                                                <option value="groq">Groq / Llama-3</option>
                                                <option value="mistral">Mistral AI</option>
                                            </select>
                                        </div>
                                        <div>
                                            <label className="text-[10px] text-gray-500 uppercase font-bold block mb-1 text-aegis-purple">Master Password</label>
                                            <input
                                                type="password"
                                                autoComplete="current-password"
                                                value={masterPass}
                                                onChange={(e) => setMasterPass(e.target.value)}
                                                placeholder="Contraseña Maestra"
                                                className="w-full bg-black/50 border border-white/10 rounded-lg p-2.5 text-white text-sm focus:border-aegis-cyan outline-none"
                                            />
                                        </div>
                                    </div>
                                    <div className="flex gap-2">
                                        <input
                                            type="password"
                                            value={newApiValue}
                                            onChange={(e) => setNewApiValue(e.target.value)}
                                            placeholder="Introduce el API Key Token..."
                                            className="flex-1 bg-black/50 border border-white/10 rounded-lg p-2.5 text-white text-sm focus:border-aegis-purple outline-none"
                                        />
                                        <button
                                            type="submit"
                                            className="px-6 py-2.5 bg-aegis-purple/20 border border-aegis-purple text-aegis-purple rounded-lg hover:bg-aegis-purple text-sm font-black transition-all"
                                        >
                                            VULNERAR & GUARDAR
                                        </button>
                                    </div>
                                </form>
                            </section>
                        </div>
                    )}

                    {activeTab === 'system' && (
                        <div className="flex flex-col items-center justify-center h-full text-center py-20">
                            <div className="w-24 h-24 mb-6 relative">
                                <span className="text-6xl animate-bounce inline-block">🚀</span>
                                <div className="absolute inset-0 bg-aegis-cyan/20 blur-3xl animate-pulse"></div>
                            </div>
                            <h2 className="text-2xl font-black text-white mb-2">Protocolo de Actualización SRE</h2>
                            <p className="text-gray-400 max-w-sm mb-10 text-sm">
                                Conecta con el Repositorio Central para desplegar parches críticos y nuevas capacidades neuronales.
                            </p>
                            <button
                                onClick={handleCheckUpdates}
                                className="px-10 py-4 bg-aegis-cyan text-black font-black rounded-full hover:shadow-[0_0_30px_rgba(0,242,254,0.6)] hover:scale-105 transition-all text-sm uppercase tracking-widest"
                            >
                                Verificar Ciclo de Vida
                            </button>
                        </div>
                    )}

                </main>
            </div>
        </div>
    );
};

// Sub-components
const TabButton = ({ active, icon, label, onClick }) => (
    <button
        onClick={onClick}
        className={`flex items-center gap-3 px-6 py-4 rounded-xl border transition-all duration-300 group ${active
                ? 'bg-white/10 border-white/20 text-white shadow-xl translate-x-1'
                : 'bg-transparent border-transparent text-gray-500 hover:text-gray-300 hover:bg-white/5'
            }`}
    >
        <span className="text-xl group-hover:scale-125 transition-transform">{icon}</span>
        <span className={`text-sm font-bold uppercase tracking-widest ${active ? 'neon-text' : ''}`}>{label}</span>
    </button>
);

const ModelSelect = ({ label, value, options = [], onChange }) => (
    <div className="flex flex-col gap-2">
        <label className="text-[10px] text-gray-500 uppercase font-black tracking-widest">{label}</label>
        <select
            value={value || ""}
            onChange={(e) => onChange(e.target.value)}
            className="w-full bg-black/60 border border-white/10 rounded-lg p-3 text-white text-xs font-mono focus:border-aegis-cyan outline-none transition-all cursor-pointer hover:bg-black/80"
        >
            <option value="">(Sin seleccionar)</option>
            {options.map((m) => (
                <option key={m.name} value={m.name}>
                    {m.name.toUpperCase()} ({(m.size / 1024 / 1024 / 1024).toFixed(1)}GB)
                </option>
            ))}
        </select>
    </div>
);

export default SettingsView;
