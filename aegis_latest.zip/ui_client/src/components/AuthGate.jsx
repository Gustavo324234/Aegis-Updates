import React, { useState, useEffect } from 'react';
import useSystemStore from '../store/useSystemStore';
import { Lock, Cpu, Globe, Zap, AlertTriangle, ShieldCheck, Database, Key } from 'lucide-react';

const AuthGate = ({ children }) => {
    const {
        setupComplete,
        authenticated,
        login,
        setupSystem,
        fetchStatus
    } = useSystemStore();

    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);

    // Genesis State
    const [genesisData, setGenesisData] = useState({
        master_password: '',
        mode: 'Hybrid',
        gemini_key: ''
    });

    useEffect(() => {
        fetchStatus();
    }, [fetchStatus]);

    const handleLogin = async (e) => {
        e.preventDefault();
        setError('');
        setLoading(true);
        const success = await login(password);
        if (!success) {
            setError('ACCESS DENIED: INVALID CREDENTIALS');
        }
        setLoading(false);
    };

    const handleGenesis = async (e) => {
        e.preventDefault();
        if (!genesisData.master_password) {
            setError('MASTER PASSWORD REQUIRED');
            return;
        }
        setError('');
        setLoading(true);
        const success = await setupSystem(genesisData);
        if (!success) {
            setError('GENESIS FAILURE: SYSTEM INITIALIZATION FAILED');
        }
        setLoading(false);
    };

    // Render logic
    if (!setupComplete) {
        return (
            <div className="min-h-screen w-full bg-black flex items-center justify-center p-4 relative overflow-hidden">
                {/* Background Glow */}
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-blue-500/10 blur-[120px] rounded-full"></div>

                <div className="glass-panel w-full max-w-2xl p-8 relative z-10 border-blue-500/30">
                    <div className="flex flex-col items-center mb-10 text-center">
                        <div className="w-16 h-16 bg-blue-500/20 rounded-full flex items-center justify-center mb-4 border border-blue-500/50 animate-pulse">
                            <Cpu className="text-blue-400 w-8 h-8" />
                        </div>
                        <h1 className="text-3xl font-bold tracking-[0.2em] text-white">GENESIS SEQUENCE</h1>
                        <p className="text-sm text-blue-400 mt-2 font-mono">INITIALIZING SYSTEM CORE FOR THE FIRST TIME</p>
                    </div>

                    <form onSubmit={handleGenesis} className="space-y-6">
                        <div className="space-y-4">
                            <div className="group">
                                <label className="block text-xs uppercase tracking-widest text-gray-400 mb-2 font-bold flex items-center gap-2">
                                    <ShieldCheck size={14} className="text-blue-400" /> Master Password
                                </label>
                                <input
                                    type="password"
                                    required
                                    className="w-full bg-black/50 border border-white/10 rounded-lg p-3 text-white focus:outline-none focus:border-blue-500/50 transition-all font-mono"
                                    placeholder="Define your master key..."
                                    value={genesisData.master_password}
                                    onChange={(e) => setGenesisData({ ...genesisData, master_password: e.target.value })}
                                />
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div className="group">
                                    <label className="block text-xs uppercase tracking-widest text-gray-400 mb-2 font-bold flex items-center gap-2">
                                        <Globe size={14} className="text-blue-400" /> Operation Mode
                                    </label>
                                    <select
                                        className="w-full bg-black/50 border border-white/10 rounded-lg p-3 text-white focus:outline-none focus:border-blue-500/50 transition-all font-mono appearance-none"
                                        value={genesisData.mode}
                                        onChange={(e) => setGenesisData({ ...genesisData, mode: e.target.value })}
                                    >
                                        <option value="Local Only">Local Only (Private)</option>
                                        <option value="Cloud Only">Cloud Only (Extended)</option>
                                        <option value="Hybrid">Hybrid (Optimal)</option>
                                    </select>
                                </div>
                                <div className="group">
                                    <label className="block text-xs uppercase tracking-widest text-gray-400 mb-2 font-bold flex items-center gap-2">
                                        <Key size={14} className="text-blue-400" /> Gemini API Key
                                    </label>
                                    <input
                                        type="password"
                                        className="w-full bg-black/50 border border-white/10 rounded-lg p-3 text-white focus:outline-none focus:border-blue-500/50 transition-all font-mono"
                                        placeholder="Optional..."
                                        value={genesisData.gemini_key}
                                        onChange={(e) => setGenesisData({ ...genesisData, gemini_key: e.target.value })}
                                    />
                                </div>
                            </div>
                        </div>

                        {error && (
                            <div className="flex items-center gap-2 text-red-500 bg-red-500/10 p-3 rounded border border-red-500/30 text-xs font-mono animate-pulse">
                                <AlertTriangle size={14} />
                                {error}
                            </div>
                        )}

                        <button
                            type="submit"
                            disabled={loading}
                            className="w-full group relative overflow-hidden bg-blue-600 hover:bg-blue-500 text-white font-bold py-4 rounded-lg transition-all flex items-center justify-center gap-3 shadow-[0_0_20px_rgba(37,99,235,0.4)] disabled:opacity-50"
                        >
                            {loading ? (
                                <span className="flex items-center gap-2 animate-pulse font-mono tracking-widest">
                                    <Cpu className="animate-spin" size={20} /> INITIATING...
                                </span>
                            ) : (
                                <>
                                    <Zap size={20} /> INITIATE SYSTEM
                                </>
                            )}
                        </button>
                    </form>

                    <div className="mt-8 pt-6 border-t border-white/5 flex justify-between items-center opacity-30">
                        <span className="text-[10px] font-mono tracking-tighter uppercase">Protocol: 0x9923-AEGIS</span>
                        <span className="text-[10px] font-mono tracking-tighter uppercase">Auth Driver: Native</span>
                    </div>
                </div>
            </div>
        );
    }

    if (!authenticated) {
        return (
            <div className="min-h-screen w-full bg-black flex items-center justify-center p-4 relative overflow-hidden">
                {/* Background Glow */}
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-cyan-500/10 blur-[100px] rounded-full"></div>

                <div className="glass-panel w-full max-w-md p-10 relative z-10 border-white/10">
                    <div className="flex flex-col items-center mb-8">
                        <div className="w-12 h-12 bg-white/5 rounded-full flex items-center justify-center mb-4 border border-white/10">
                            <Lock className="text-white/60 w-5 h-5" />
                        </div>
                        <h1 className="text-2xl font-bold tracking-[0.3em] text-white">SYSTEM LOCKED</h1>
                    </div>

                    <form onSubmit={handleLogin} className="space-y-6">
                        <div className="space-y-2">
                            <label className="block text-[10px] uppercase tracking-widest text-gray-500 font-bold ml-1">
                                Master Password
                            </label>
                            <input
                                type="password"
                                required
                                autoFocus
                                className="w-full bg-black/50 border border-white/10 rounded-lg p-3 text-white focus:outline-none focus:border-cyan-500/50 transition-all text-center font-mono placeholder:text-gray-700"
                                placeholder="****************"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                            />
                        </div>

                        {error && (
                            <div className="text-center text-red-500 text-[10px] font-mono tracking-widest animate-pulse border-y border-red-500/20 py-2">
                                {error}
                            </div>
                        )}

                        <button
                            type="submit"
                            disabled={loading}
                            className="w-full bg-white hover:bg-white/90 text-black font-bold py-3 rounded-lg transition-all flex items-center justify-center gap-2 disabled:opacity-50 group"
                        >
                            {loading ? (
                                <span className="flex items-center gap-2 animate-pulse font-mono uppercase tracking-[0.2em] text-sm">
                                    Verifying...
                                </span>
                            ) : (
                                <>
                                    UNLOCK SYSTEM
                                </>
                            )}
                        </button>
                    </form>

                    <div className="absolute bottom-4 left-0 right-0 text-center opacity-10">
                        <span className="text-[10px] font-mono uppercase tracking-widest">Secure Terminal Access Only</span>
                    </div>
                </div>
            </div>
        );
    }

    return <>{children}</>;
};

export default AuthGate;
