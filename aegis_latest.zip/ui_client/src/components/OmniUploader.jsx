import React, { useRef, useState, useEffect } from 'react';
import { Paperclip, X, FileText, Image as ImageIcon, FileCode } from 'lucide-react';

/**
 * OmniUploader - High-performance file selection and Base64 processor.
 * Supports images for Vision and documents for RAG.
 */
const OmniUploader = ({ onFilesUpdate, resetTrigger }) => {
    const [selectedFiles, setSelectedFiles] = useState([]);
    const fileInputRef = useRef(null);

    // Reset internal state when parent requests (e.g., after message sent)
    useEffect(() => {
        if (resetTrigger) {
            setSelectedFiles([]);
        }
    }, [resetTrigger]);

    const handleFileChange = async (e) => {
        const files = Array.from(e.target.files);
        if (files.length === 0) return;

        const processedFiles = await Promise.all(
            files.map(async (file) => {
                const base64 = await convertToBase64(file);
                return {
                    id: Math.random().toString(36).substr(2, 9),
                    name: file.name,
                    size: file.size,
                    type: file.type,
                    base64: base64,
                    preview: file.type.startsWith('image/') ? base64 : null
                };
            })
        );

        const newFiles = [...selectedFiles, ...processedFiles];
        setSelectedFiles(newFiles);
        onFilesUpdate(newFiles);

        // Clear input so same file can be selected again if deleted
        if (fileInputRef.current) fileInputRef.current.value = '';
    };

    const convertToBase64 = (file) => {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => resolve(reader.result);
            reader.onerror = error => reject(error);
        });
    };

    const removeFile = (id) => {
        const updated = selectedFiles.filter(f => f.id !== id);
        setSelectedFiles(updated);
        onFilesUpdate(updated);
    };

    return (
        <div className="w-full flex flex-col gap-2 pointer-events-auto">
            {/* Previsualización de Archivos (Píldoras/Thumbnails) */}
            {selectedFiles.length > 0 && (
                <div className="flex flex-wrap gap-2 px-1 mb-1 animate-in fade-in slide-in-from-bottom-2">
                    {selectedFiles.map((file) => (
                        <div
                            key={file.id}
                            className="group relative flex items-center gap-2 p-1.5 pr-3 bg-slate-900/80 border border-white/10 rounded-xl crystal-blur shadow-lg hover:border-cyan-500/40 transition-all"
                        >
                            {/* Icono o Miniatura */}
                            <div className="w-8 h-8 flex items-center justify-center bg-black/20 rounded-lg overflow-hidden border border-white/5">
                                {file.preview ? (
                                    <img src={file.preview} alt="preview" className="w-full h-full object-cover" />
                                ) : (
                                    <FileText size={16} className="text-cyan-400 opacity-60" />
                                )}
                            </div>

                            {/* Nombre del archivo */}
                            <div className="flex flex-col">
                                <span className="text-[10px] font-mono text-slate-200 max-w-[100px] truncate leading-tight">
                                    {file.name}
                                </span>
                                <span className="text-[8px] text-slate-500 uppercase font-bold tracking-tighter">
                                    {(file.size / 1024).toFixed(1)} KB
                                </span>
                            </div>

                            {/* Botón de eliminar */}
                            <button
                                onClick={() => removeFile(file.id)}
                                className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-red-500 hover:bg-red-400 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow-lg"
                            >
                                <X size={10} />
                            </button>
                        </div>
                    ))}
                </div>
            )}

            {/* Input Oculto y Trigger (Clip) */}
            <input
                type="file"
                multiple
                ref={fileInputRef}
                onChange={handleFileChange}
                className="hidden"
                accept="image/*,.txt,.pdf,.py,.js,.html,.json,.md"
            />

            <button
                onClick={() => fileInputRef.current?.click()}
                title="Adjuntar archivos estratégicos (Imágenes/Docs)"
                className="absolute left-4 bottom-4 transition-all hover:scale-110 active:scale-90 text-slate-500 hover:text-cyan-400"
            >
                <Paperclip size={20} />
            </button>
        </div>
    );
};

export default OmniUploader;
