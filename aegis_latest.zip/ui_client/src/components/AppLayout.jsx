import React from 'react';
import useSystemStore from '../store/useSystemStore';

/**
 * AppLayout - The Modern "Cyber-Dark" Shell for Aegis-IA.
 * Provides a slim sidebar for navigation and a global header for system metrics.
 */
const AppLayout = ({ children }) => {
    const {
        health,
        metrics,
        activeView,
        setActiveView
    } = useSystemStore();

    // Navigation items configuration
    const navItems = [
        { id: 'chat', icon: '💬', label: 'Chat' },
        { id: 'workspace', icon: '📁', label: 'Workspace' },
        { id: 'graph', icon: '🧠', label: 'Neural Map' },
        { id: 'settings', icon: '⚙️', label: 'Settings' },
        { id: 'admin', icon: '🛡️', label: 'SRE Admin' }
    ];

    return (
        <div className="h-screen w-screen overflow-hidden flex bg-black text-gray-200 font-mono">
            {/* Sidebar Izquierdo (Slim Nav) */}
            <aside className="w-16 md:w-20 glass-panel m-2 mr-0 flex flex-col items-center py-6 gap-8 z-50">
                <div className="mb-4">
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 to-purple-600 flex items-center justify-center shadow-[0_0_15px_rgba(6,182,212,0.5)]">
                        <span className="text-white font-bold text-xl">A</span>
                    </div>
                </div>

                <nav className="flex-1 flex flex-col gap-6">
                    {navItems.map((item) => (
                        <button
                            key={item.id}
                            onClick={() => setActiveView(item.id)}
                            title={item.label}
                            className={`
                                w-12 h-12 flex items-center justify-center rounded-xl transition-all duration-300 group relative
                                ${activeView === item.id
                                    ? 'bg-cyan-500/10 shadow-[inset_0_0_10px_rgba(6,182,212,0.2)]'
                                    : 'hover:bg-white/5'}
                            `}
                        >
                            {/* Neon indicator border for active item */}
                            {activeView === item.id && (
                                <div className="absolute inset-x-0 -left-1 w-1 h-8 bg-cyan-400 rounded-r-full shadow-[0_0_10px_#22d3ee]" />
                            )}

                            <span className={`text-2xl transition-transform duration-300 group-hover:scale-110 ${activeView === item.id ? 'neon-text' : 'opacity-70 group-hover:opacity-100'}`}>
                                {item.icon}
                            </span>
                        </button>
                    ))}
                </nav>

                <div className="mt-auto opacity-40 text-[10px] text-center">
                    v2.0
                </div>
            </aside>

            {/* Area Principal */}
            <main className="flex-1 flex flex-col min-w-0">
                {/* Top Header */}
                <header className="h-12 flex items-center justify-end px-6 gap-6 border-b border-white/5 bg-black/40 backdrop-blur-md">
                    {/* Health Status Dot */}
                    <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10">
                        <div
                            className={`w-2 h-2 rounded-full animate-pulse shadow-[0_0_8px] ${health === 'GREEN'
                                ? 'bg-green-400 shadow-green-400/50'
                                : 'bg-red-500 shadow-red-500/50'
                                }`}
                        />
                        <span className="text-[10px] uppercase tracking-widest opacity-60">System {health}</span>
                    </div>

                    {/* RAM Metrics */}
                    <div className="flex items-center gap-2">
                        <span className="text-[10px] uppercase tracking-widest opacity-40">Memory</span>
                        <span className="text-xs font-mono text-cyan-400">
                            {metrics?.app_ram_usage_mb || 0} <span className="opacity-50 text-[10px]">MB</span>
                        </span>
                    </div>

                    {/* Node Count (Optional but useful) */}
                    {metrics?.active_nodes !== undefined && (
                        <div className="flex items-center gap-2 border-l border-white/10 pl-4">
                            <span className="text-[10px] uppercase tracking-widest opacity-40">Nodes</span>
                            <span className="text-xs font-mono text-purple-400">
                                {metrics.active_nodes}
                            </span>
                        </div>
                    )}
                </header>

                {/* Content Area */}
                <section className="flex-1 relative overflow-hidden p-4">
                    {children}
                </section>
            </main>
        </div>
    );
};

export default AppLayout;
