import React from 'react';
import {
    Terminal,
    Settings,
    Network,
    Database,
    Activity,
    Shield,
    Cpu,
    MessageSquare,
    Eye,
    EyeOff,
    Monitor
} from 'lucide-react';
import useSystemStore from '../store/useSystemStore';
import useChatStore from '../store/useChatStore';

const Sidebar = () => {
    const {
        activeView,
        setActiveView,
        health,
        metrics,
        hardwareTier,
        daemons,
        toggleDaemon,
        layoutMode,
        setLayoutMode
    } = useSystemStore();
    const { pendingActions, connectionStatus } = useChatStore();

    const menuItems = [
        { id: 'chat', label: 'Neural Link', icon: MessageSquare, mode: 'user' },
        { id: 'graph', label: 'Mapa Neural', icon: Network, mode: 'user' },
        { id: 'nodes', label: 'Nexus Mesh', icon: Monitor, mode: 'admin' },
        { id: 'vault', label: 'Secure Vault', icon: Database, mode: 'admin' },
        { id: 'settings', label: 'Cortex Config', icon: Settings, mode: 'admin' },
        { id: 'system', label: 'Cortex Control', icon: Shield, mode: 'admin' },
    ];

    const filteredItems = menuItems.filter(item => item.mode === layoutMode);
    const mirrorActive = daemons.find(d => d.name === 'NeuralMirror')?.status === 'RUNNING';

    return (
        <aside className="w-72 border-r border-white/5 bg-[#050505] flex flex-col p-6 relative overflow-hidden h-full">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-cyan-500/40 to-transparent" />

            {/* Logo */}
            <div className="flex items-center gap-3 mb-10 z-10 transition-transform hover:scale-105 duration-300">
                <Shield className="text-cyan-400" size={24} />
                <h1 className="text-lg font-bold tracking-[0.2em] text-white drop-shadow-[0_0_8px_rgba(0,242,254,0.4)]">AEGIS OS</h1>
            </div>

            {/* Mode Switcher */}
            <div className="flex bg-white/5 p-1 rounded-xl border border-white/10 mb-8 items-center">
                <button
                    onClick={() => { setLayoutMode('user'); setActiveView('chat'); }}
                    className={`flex-1 py-1.5 px-2 rounded-lg text-[10px] uppercase font-bold tracking-widest transition-all ${layoutMode === 'user' ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30' : 'text-gray-500 hover:text-gray-300'}`}
                >
                    Neural Link
                </button>
                <button
                    onClick={() => { setLayoutMode('admin'); setActiveView('settings'); }}
                    className={`flex-1 py-1.5 px-2 rounded-lg text-[10px] uppercase font-bold tracking-widest transition-all ${layoutMode === 'admin' ? 'bg-purple-500/20 text-purple-400 border border-purple-500/30' : 'text-gray-500 hover:text-gray-300'}`}
                >
                    System
                </button>
            </div>

            {/* Main Nav */}
            <nav className="space-y-2 mb-10">
                {filteredItems.map(item => (
                    <button
                        key={item.id}
                        onClick={() => setActiveView(item.id)}
                        className={`w-full flex items-center gap-3 p-3 rounded-lg transition-all group ${activeView === item.id
                            ? (layoutMode === 'user' ? 'bg-cyan-500/10 border border-cyan-500/30 text-cyan-50' : 'bg-purple-500/10 border border-purple-500/30 text-purple-50')
                            : 'text-gray-500 hover:text-gray-300 hover:bg-white/5 border border-transparent'
                            }`}
                    >
                        <item.icon size={18} className={activeView === item.id ? (layoutMode === 'user' ? 'text-cyan-400' : 'text-purple-400') : 'group-hover:text-cyan-400'} />
                        <span className="text-xs font-bold uppercase tracking-widest">{item.label}</span>
                    </button>
                ))}
            </nav>

            {/* System Health */}
            <div className="mb-8 p-4 rounded-xl bg-black/40 border border-white/5">
                <div className="text-[10px] uppercase text-gray-500 tracking-[0.2em] mb-4 flex items-center justify-between font-bold">
                    System Health
                    <Activity size={12} className={health === 'GREEN' ? 'text-green-500' : 'text-red-500'} />
                </div>

                <div className="space-y-3">
                    <div className="flex justify-between items-center text-[10px]">
                        <span className="text-gray-600">TIER:</span>
                        <span className="text-cyan-400 font-bold">{hardwareTier.name} (T{hardwareTier.id})</span>
                    </div>
                    <div className="flex justify-between items-center text-[10px]">
                        <span className="text-gray-600">RAM USAGE:</span>
                        <span className="text-gray-300">{metrics.app_ram_usage_mb || 0} MB</span>
                    </div>
                    <div className="flex justify-between items-center text-[10px]">
                        <span className="text-gray-600">CORE:</span>
                        <span className={connectionStatus === 'connected' ? "text-green-400 font-bold" : "text-red-500 font-bold"}>
                            {connectionStatus.toUpperCase()}
                        </span>
                    </div>
                </div>
            </div>

            {/* Quick Actions */}
            <div className="mt-auto space-y-4">
                <button
                    onClick={() => toggleDaemon('NeuralMirror')}
                    className={`w-full flex items-center justify-between p-3 rounded-lg border transition-all ${mirrorActive
                        ? 'border-purple-500/40 bg-purple-500/5 text-purple-100'
                        : 'border-white/10 bg-white/5 text-gray-500 hover:bg-white/10'
                        }`}
                >
                    <div className="flex items-center gap-2">
                        {mirrorActive ? <Eye size={16} className="text-purple-400" /> : <EyeOff size={16} />}
                        <span className="text-[10px] font-bold uppercase tracking-widest leading-none">Neural Mirror</span>
                    </div>
                    <div className={`w-2 h-2 rounded-full ${mirrorActive ? 'bg-purple-400 animate-pulse' : 'bg-gray-700'}`} />
                </button>

                <div className="p-3 rounded-lg border border-white/5 bg-black/60">
                    <div className="text-[9px] text-gray-600 uppercase mb-1">Security Node</div>
                    <div className="text-[10px] text-gray-400 font-mono flex items-center gap-2">
                        <Cpu size={10} /> SINGULARITY_V2.5
                    </div>
                </div>
            </div>
        </aside>
    );
};

export default Sidebar;
