import React, { useState, useEffect } from 'react';
import { Users, Plus, Play, ExternalLink, Shield, Server, Box, Square, Trash2 } from 'lucide-react';
import useSystemStore from '../store/useSystemStore';

const TenantManager = () => {
    const { tenants, fetchTenants, deployTenant, stopTenant, startTenant, deleteTenant } = useSystemStore();
    const [loading, setLoading] = useState(false);
    const [formData, setFormData] = useState({
        username: '',
        port: 8501,
        mode: 'reactor' // Default to new stack
    });

    useEffect(() => {
        fetchTenants();
        const interval = setInterval(fetchTenants, 5000);
        return () => clearInterval(interval);
    }, []);

    const handleDeploy = async (e) => {
        e.preventDefault();
        setLoading(true);
        const res = await deployTenant(formData.username, formData.port, formData.mode);
        if (res.status === 'success') {
            setFormData({ username: '', port: formData.port + 1, mode: 'reactor' });
        } else {
            alert(res.message);
        }
        setLoading(false);
    };

    return (
        <div className="flex-1 overflow-y-auto p-12 bg-black scrollbar-refined animate-in fade-in duration-700">
            <header className="mb-12">
                <h1 className="text-4xl font-bold text-white mb-2 tracking-tighter">NEXUS USER FACTORY</h1>
                <p className="text-gray-500 font-mono text-sm uppercase tracking-[0.3em]">Gestión de Instancias Aisladas y Multitenancy</p>
            </header>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
                {/* Form Side */}
                <div className="lg:col-span-1 space-y-8">
                    <section className="glass-panel border border-white/10 p-8 rounded-2xl relative overflow-hidden">
                        <div className="absolute top-0 left-0 w-full h-1 bg-cyan-500/40" />
                        <h2 className="text-lg font-bold text-cyan-50 mb-6 flex items-center gap-2 uppercase tracking-widest">
                            <Plus size={18} /> Nuevo Spoke
                        </h2>

                        <form onSubmit={handleDeploy} className="space-y-6">
                            <div className="space-y-2">
                                <label className="text-[10px] uppercase text-gray-500 font-bold tracking-widest">Identificador único</label>
                                <input
                                    className="w-full bg-white/5 border border-white/10 rounded-xl p-4 text-white focus:border-cyan-500 outline-none transition-all font-mono"
                                    placeholder="ej: neuron_01"
                                    value={formData.username}
                                    onChange={e => setFormData({ ...formData, username: e.target.value })}
                                    required
                                />
                            </div>

                            <div className="space-y-2">
                                <label className="text-[10px] uppercase text-gray-500 font-bold tracking-widest">Puerto asignado</label>
                                <input
                                    type="number"
                                    className="w-full bg-white/5 border border-white/10 rounded-xl p-4 text-white focus:border-cyan-500 outline-none transition-all font-mono"
                                    value={formData.port}
                                    onChange={e => setFormData({ ...formData, port: parseInt(e.target.value) })}
                                    required
                                />
                            </div>

                            <div className="space-y-3">
                                <label className="text-[10px] uppercase text-gray-500 font-bold tracking-widest">Arquitectura de Ejecución</label>
                                <div className="grid grid-cols-2 gap-2">
                                    <button
                                        type="button"
                                        onClick={() => setFormData({ ...formData, mode: 'reactor' })}
                                        className={`p-3 rounded-xl border text-[10px] font-bold uppercase transition-all flex flex-col items-center gap-2 ${formData.mode === 'reactor' ? 'border-cyan-500 bg-cyan-500/10 text-white' : 'border-white/5 text-gray-500'}`}
                                    >
                                        <Server size={14} /> Reactor (API)
                                    </button>
                                    <button
                                        type="button"
                                        onClick={() => setFormData({ ...formData, mode: 'legacy' })}
                                        className={`p-3 rounded-xl border text-[10px] font-bold uppercase transition-all flex flex-col items-center gap-2 ${formData.mode === 'legacy' ? 'border-purple-500 bg-purple-500/10 text-white' : 'border-white/5 text-gray-500'}`}
                                    >
                                        <Box size={14} /> Legacy (Streamlit)
                                    </button>
                                </div>
                            </div>

                            <button
                                type="submit"
                                disabled={loading}
                                className="w-full py-4 bg-cyan-500 text-black font-bold rounded-xl hover:bg-cyan-400 transition-all shadow-lg shadow-cyan-500/20 flex items-center justify-center gap-2"
                            >
                                {loading ? <Play className="animate-spin" size={18} /> : <Play size={18} />}
                                DEPLOY INSTANCE
                            </button>
                        </form>
                    </section>
                </div>

                {/* List Side */}
                <div className="lg:col-span-2 space-y-6">
                    <h2 className="text-xs font-bold text-gray-500 uppercase tracking-[0.3em] mb-4">Instancias Activas en el Nexus</h2>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {tenants.map(tenant => (
                            <div key={tenant.username} className="glass-panel border border-white/5 p-6 rounded-2xl group hover:border-white/20 transition-all flex flex-col justify-between h-40">
                                <div className="flex justify-between items-start">
                                    <div>
                                        <div className="text-sm font-bold text-white mb-1 uppercase tracking-tighter">{tenant.username}</div>
                                        <div className="text-[10px] text-gray-500 font-mono">Port: {tenant.port}</div>
                                    </div>
                                    <div className={`px-2 py-1 rounded text-[8px] font-bold uppercase ${tenant.status === 'online' ? 'bg-green-500/10 text-green-400' : 'bg-red-500/10 text-red-400'}`}>
                                        {tenant.status}
                                    </div>
                                </div>

                                <div className="flex items-center justify-between mt-auto pt-4 border-t border-white/5">
                                    <div className="flex items-center gap-2">
                                        {tenant.status === 'online' ? (
                                            <button
                                                onClick={() => stopTenant(tenant.username)}
                                                className="p-2 bg-red-500/10 text-red-500 rounded-lg hover:bg-red-500 hover:text-white transition-all"
                                                title="Stop Instance"
                                            >
                                                <Square size={12} fill="currentColor" />
                                            </button>
                                        ) : (
                                            <button
                                                onClick={() => startTenant(tenant.username)}
                                                className="p-2 bg-green-500/10 text-green-500 rounded-lg hover:bg-green-500 hover:text-white transition-all"
                                                title="Start Instance"
                                            >
                                                <Play size={12} fill="currentColor" />
                                            </button>
                                        )}
                                        <button
                                            onClick={() => {
                                                if (window.confirm(`¿Seguro que quieres eliminar a ${tenant.username} y todos sus datos?`)) {
                                                    deleteTenant(tenant.username);
                                                }
                                            }}
                                            className="p-2 bg-white/5 text-gray-500 rounded-lg hover:bg-red-600 hover:text-white transition-all"
                                            title="Delete Completely"
                                        >
                                            <Trash2 size={12} />
                                        </button>
                                    </div>

                                    <div className="flex items-center gap-4">
                                        <span className="text-[9px] text-gray-600 font-mono uppercase">{new Date(tenant.created_at).toLocaleDateString()}</span>
                                        {tenant.status === 'online' && (
                                            <a
                                                href={`http://${window.location.hostname}:${tenant.port}`}
                                                target="_blank"
                                                rel="noreferrer"
                                                className="text-cyan-400 hover:text-white transition-colors flex items-center gap-1 text-[10px] font-bold uppercase"
                                            >
                                                Open <ExternalLink size={12} />
                                            </a>
                                        )}
                                    </div>
                                </div>
                            </div>
                        ))}

                        {tenants.length === 0 && (
                            <div className="col-span-full py-20 text-center border border-dashed border-white/10 rounded-2xl">
                                <Users className="mx-auto text-gray-800 mb-4" size={48} />
                                <div className="text-gray-600 text-xs font-bold uppercase tracking-widest">No hay tenantes registrados</div>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default TenantManager;
