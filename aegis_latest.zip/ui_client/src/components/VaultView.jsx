import React, { useState, useEffect } from 'react';
import { Database, File, Lock, Search, Download, Trash2, ShieldCheck } from 'lucide-react';

const VaultView = () => {
    const [files, setFiles] = useState([]);
    const [searchTerm, setSearchTerm] = useState("");

    // Mock index for now, we'd fetch this from /api/vault/list if we add it
    useEffect(() => {
        // Fetch vault content would go here
        setFiles([
            { name: 'protocol_genesis.pdf', size: '1.2 MB', type: 'document', date: '2024-02-20' },
            { name: 'neural_weights_v4.bin', size: '450 MB', type: 'data', date: '2024-02-21' },
            { name: 'security_audit_logs.json', size: '15 KB', type: 'log', date: '2024-02-22' }
        ]);
    }, []);

    const filtered = files.filter(f => f.name.toLowerCase().includes(searchTerm.toLowerCase()));

    return (
        <div className="flex-1 overflow-y-auto p-12 bg-black scrollbar-refined animate-in fade-in duration-700">
            <header className="mb-12 flex justify-between items-end">
                <div>
                    <h1 className="text-4xl font-bold text-white mb-2 tracking-tighter uppercase">Secure Vault</h1>
                    <p className="text-gray-500 font-mono text-sm uppercase tracking-[0.3em]">Cámara de Almacenamiento Criptográfico</p>
                </div>
                <div className="flex items-center gap-2 text-green-500 bg-green-500/10 px-4 py-2 rounded-full border border-green-500/20 text-[10px] font-bold uppercase tracking-widest">
                    <ShieldCheck size={14} /> Citadel Active
                </div>
            </header>

            <div className="mb-8 relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
                <input
                    className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-white placeholder:text-gray-700 focus:border-cyan-500 outline-none transition-all font-mono"
                    placeholder="Buscar en el vault cifrado..."
                    value={searchTerm}
                    onChange={e => setSearchTerm(e.target.value)}
                />
            </div>

            <div className="glass-panel border border-white/5 rounded-2xl overflow-hidden">
                <table className="w-full text-left">
                    <thead>
                        <tr className="border-b border-white/5 bg-white/[0.02]">
                            <th className="p-6 text-[10px] font-bold text-gray-500 uppercase tracking-widest">Nombre del Archivo</th>
                            <th className="p-6 text-[10px] font-bold text-gray-500 uppercase tracking-widest">Tamaño</th>
                            <th className="p-6 text-[10px] font-bold text-gray-500 uppercase tracking-widest">Fecha</th>
                            <th className="p-6 text-[10px] font-bold text-gray-500 uppercase tracking-widest text-right">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filtered.map((file, i) => (
                            <tr key={i} className="border-b border-white/5 hover:bg-white/[0.01] transition-colors group">
                                <td className="p-6">
                                    <div className="flex items-center gap-4">
                                        <div className="p-3 bg-white/5 rounded-xl text-cyan-400 group-hover:bg-cyan-500/10 transition-all">
                                            <File size={20} />
                                        </div>
                                        <div>
                                            <div className="text-sm font-bold text-white">{file.name}</div>
                                            <div className="text-[10px] text-gray-600 font-mono uppercase">{file.type}</div>
                                        </div>
                                    </div>
                                </td>
                                <td className="p-6 text-xs text-gray-400 font-mono">{file.size}</td>
                                <td className="p-6 text-xs text-gray-400 font-mono">{file.date}</td>
                                <td className="p-6 text-right">
                                    <div className="flex justify-end gap-2">
                                        <button className="p-2 text-gray-500 hover:text-cyan-400 transition-colors">
                                            <Download size={16} />
                                        </button>
                                        <button className="p-2 text-gray-500 hover:text-red-500 transition-colors">
                                            <Trash2 size={16} />
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default VaultView;
