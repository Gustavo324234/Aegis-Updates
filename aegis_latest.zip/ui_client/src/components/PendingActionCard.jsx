import React, { useEffect, useRef } from 'react';
import { Terminal, Play, X, Loader2, CheckCircle2, AlertCircle, Code } from 'lucide-react';
import useChatStore from '../store/useChatStore';

/**
 * PendingActionCard: Componente para gestionar aprobaciones de herramientas
 * con visualización de argumentos, logs en tiempo real y estados de ejecución.
 */
const PendingActionCard = ({ action }) => {
    const { socket, removeAction } = useChatStore();

    // El objeto action contiene: tool, args, job_id, status, logs[]
    const { tool, args, job_id, status, logs = [], result, error } = action;

    // Auto-scroll para los logs de la terminal
    const logEndRef = useRef(null);
    useEffect(() => {
        if (logEndRef.current) {
            logEndRef.current.scrollIntoView({ behavior: 'smooth' });
        }
    }, [logs]);

    const handleApprove = () => {
        if (socket && socket.readyState === WebSocket.OPEN) {
            socket.send(JSON.stringify({
                type: 'authorize_action',
                job_id: job_id
            }));

            // Actualización optimista del estado local
            useChatStore.setState((state) => ({
                pendingActions: state.pendingActions.map(a =>
                    a.job_id === job_id ? { ...a, status: 'Executing' } : a
                )
            }));
        }
    };

    const handleDiscard = () => {
        removeAction(job_id);
    };

    // Configuración visual dinámica según el estado
    const statusConfig = {
        Pending: {
            border: 'border-yellow-500/30',
            bg: 'bg-yellow-500/5',
            icon: <AlertCircle className="text-yellow-500" size={18} />,
            title: 'AUTORIZACIÓN REQUERIDA'
        },
        Executing: {
            border: 'border-cyan-500/50',
            bg: 'bg-cyan-500/5',
            icon: <Loader2 className="text-cyan-500 animate-spin" size={18} />,
            title: 'EJECUTANDO OPERACIÓN'
        },
        Completed: {
            border: 'border-green-500/50',
            bg: 'bg-green-500/5',
            icon: <CheckCircle2 className="text-green-500" size={18} />,
            title: 'OPERACIÓN COMPLETADA'
        },
        Failed: {
            border: 'border-red-500/50',
            bg: 'bg-red-500/5',
            icon: <AlertCircle className="text-red-500" size={18} />,
            title: 'ERROR EN EJECUCIÓN'
        }
    };

    const currentStyle = statusConfig[status] || statusConfig.Pending;

    return (
        <div className={`my-6 overflow-hidden rounded-2xl border ${currentStyle.border} ${currentStyle.bg} backdrop-blur-xl shadow-2xl animate-in fade-in slide-in-from-bottom-4 duration-500`}>
            {/* Cabecera Técnica */}
            <div className="flex items-center justify-between px-4 py-3 border-b border-white/5 bg-white/5">
                <div className="flex items-center gap-2">
                    {currentStyle.icon}
                    <span className="text-[10px] font-black tracking-[0.2em] text-white/90 uppercase">
                        {currentStyle.title}: <span className="text-cyan-400 font-mono italic">{tool}</span>
                    </span>
                </div>
                {status === 'Pending' && (
                    <div className="flex items-center gap-2">
                        <span className="flex h-2 w-2 rounded-full bg-yellow-500 animate-pulse"></span>
                        <span className="text-[9px] font-mono text-yellow-500/80 font-bold uppercase">Safe Mode</span>
                    </div>
                )}
            </div>

            {/* Panel de Contenido */}
            <div className="p-4 space-y-4">
                {/* Argumentos de la Herramienta */}
                <div className="bg-black/60 rounded-xl p-3 border border-white/5">
                    <div className="flex items-center gap-2 mb-2 opacity-50">
                        <Code size={12} className="text-cyan-500" />
                        <span className="text-[9px] font-mono tracking-widest uppercase font-bold">Payload / Arguments</span>
                    </div>
                    <pre className="text-[11px] font-mono text-cyan-300 leading-relaxed overflow-x-auto custom-scrollbar">
                        {JSON.stringify(args, null, 2)}
                    </pre>
                </div>

                {/* Logs de Terminal en tiempo real */}
                {(status === 'Executing' || (status === 'Completed' && logs.length > 0)) && (
                    <div className="bg-slate-950 rounded-xl p-3 border border-white/10 shadow-inner">
                        <div className="flex items-center gap-2 mb-2 text-cyan-500/70">
                            <Terminal size={12} />
                            <span className="text-[9px] font-mono tracking-widest uppercase font-bold">Live Stream Output</span>
                        </div>
                        <div className="max-h-56 overflow-y-auto font-mono text-[10px] text-slate-300 space-y-1.5 scrollbar-thin scrollbar-thumb-white/10 pr-2">
                            {logs.length === 0 && <span className="italic opacity-30">Iniciando sub-proceso...</span>}
                            {logs.map((log, i) => (
                                <div key={i} className="flex gap-3 items-start border-l border-white/5 pl-2">
                                    <span className="text-white/20 select-none min-w-[20px] text-right">{i + 1}</span>
                                    <span className="break-all">{log}</span>
                                </div>
                            ))}
                            <div ref={logEndRef} />
                        </div>
                    </div>
                )}

                {/* Resultado Final */}
                {status === 'Completed' && (
                    <div className="bg-green-500/10 rounded-xl p-3 border border-green-500/20 animate-in slide-in-from-top-2">
                        <div className="flex items-center gap-2 mb-1 text-green-400">
                            <CheckCircle2 size={12} />
                            <span className="text-[9px] font-mono uppercase font-bold">Respuesta del Sistema:</span>
                        </div>
                        <pre className="text-[11px] font-mono text-green-200/80 whitespace-pre-wrap">
                            {typeof result === 'string' ? result : JSON.stringify(result, null, 2)}
                        </pre>
                    </div>
                )}

                {/* Feedback de Error */}
                {status === 'Failed' && (
                    <div className="bg-red-500/10 rounded-xl p-4 border border-red-500/20 font-mono text-[11px] text-red-400">
                        <div className="flex items-center gap-2 mb-2 font-bold uppercase">
                            <AlertCircle size={14} />
                            <span>System Error Exception:</span>
                        </div>
                        <div className="pl-6 italic opacity-80">
                            {error || 'Unknown execution error occurred.'}
                        </div>
                    </div>
                )}

                {/* Controles de Acción (Solo en Pending) */}
                {status === 'Pending' && (
                    <div className="flex gap-3 pt-2">
                        <button
                            onClick={handleApprove}
                            className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-[11px] font-bold tracking-[0.2em] transition-all hover:scale-[1.02] active:scale-95 shadow-xl shadow-cyan-900/20 uppercase"
                        >
                            <Play size={14} fill="currentColor" />
                            Aprobar Acción
                        </button>
                        <button
                            onClick={handleDiscard}
                            className="flex items-center justify-center px-6 py-3 rounded-xl bg-white/5 hover:bg-red-500/20 text-white/50 hover:text-red-400 border border-white/10 hover:border-red-500/30 text-[11px] font-bold tracking-widest transition-all uppercase"
                        >
                            <X size={14} />
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
};

export default PendingActionCard;
