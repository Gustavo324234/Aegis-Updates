import React, { useState } from 'react';
import useSystemStore from '../store/useSystemStore';

/**
 * WorkspaceView - Modern Project Management & Forge Orchestrator.
 * Part of the Aegis-IA system for local project handling.
 */
const WorkspaceView = () => {
    const { metrics } = useSystemStore();
    const [syncing, setSyncing] = useState(false);

    // Mock state for projects
    const [projects] = useState([
        { id: 1, name: "Proyecto Alpha", status: "Activo", path: "~/workspace/alpha" },
        { id: 2, name: "Landing Page", status: "Activo", path: "~/workspace/landing" },
        { id: 3, name: "Script Scraper", status: "Activo", path: "~/workspace/scraper" }
    ]);

    const handleOpenForge = async () => {
        setSyncing(true);
        try {
            // Sincronizar caminos neuronales (Simulated API call)
            await fetch('/api/system/forge/sync').catch(() => {
                console.warn("Forge sync endpoint not responding, proceeding with local launch...");
            });

            // Simular un pequeño retardo de procesamiento
            await new Promise(resolve => setTimeout(resolve, 800));

            // Abrir IDE en nueva pestaña
            window.open('http://localhost:8080/?folder=/workspace', '_blank');
        } finally {
            setSyncing(false);
        }
    };

    return (
        <div className="h-full overflow-y-auto scrollbar-refined flex flex-col gap-6 p-4 animate-in fade-in slide-in-from-bottom-4 duration-700">
            {/* System Header */}
            <div className="flex items-end justify-between border-l-4 border-cyan-500 pl-4 py-2 bg-gradient-to-r from-cyan-500/10 to-transparent">
                <div>
                    <h1 className="text-3xl font-bold tracking-tighter neon-text uppercase">Workspace Terminal</h1>
                    <p className="text-xs text-cyan-400/60 font-mono tracking-widest mt-1">
                        AEGIS-IA_LOCAL_ORCHESTRATOR v2.4 // SESSION_ACTIVE
                    </p>
                </div>
                <div className="text-right hidden md:block">
                    <span className="text-[10px] text-white/40 uppercase block font-mono">Mesh Nodes</span>
                    <span className="text-xl font-mono text-purple-400">{metrics?.active_nodes || 1}</span>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Section A: The Forge (IDE) */}
                <div className="lg:col-span-2 glass-panel p-8 flex flex-col items-center justify-center relative overflow-hidden group border-cyan-500/20 hover:border-cyan-500/40 transition-all duration-500 min-h-[400px]">
                    {/* Visual FX: Background Pulse */}
                    <div className="absolute -top-24 -right-24 w-64 h-64 bg-cyan-500/10 rounded-full blur-[100px] group-hover:bg-cyan-500/20 transition-all duration-1000" />
                    <div className="absolute -bottom-24 -left-24 w-64 h-64 bg-purple-600/5 rounded-full blur-[100px] group-hover:bg-purple-600/10 transition-all duration-1000" />

                    <div className="z-10 text-center flex flex-col items-center">
                        <div className="w-24 h-24 mb-6 rounded-3xl bg-black/40 border border-cyan-500/30 flex items-center justify-center text-5xl shadow-[0_0_30px_rgba(6,182,212,0.2)] group-hover:shadow-[0_0_50px_rgba(6,182,212,0.4)] transition-all duration-500">
                            <span className="group-hover:scale-110 transition-transform duration-500">📁</span>
                        </div>
                        <h2 className="text-5xl font-black mb-2 tracking-tighter uppercase italic">The Forge</h2>
                        <div className="h-1 w-20 bg-cyan-500 mb-4 mx-auto rounded-full shadow-[0_0_10px_#00f2fe]" />
                        <p className="text-gray-400 mb-8 max-w-md text-sm leading-relaxed font-mono">
                            Kernel de desarrollo integrado. Acceso directo al sistema de archivos del bunker y sincronización de red mesh.
                        </p>

                        <button
                            onClick={handleOpenForge}
                            disabled={syncing}
                            className={`
                                relative px-8 py-5 bg-cyan-500 hover:bg-cyan-400 text-black font-black uppercase text-[12px] tracking-[0.2em] rounded-md
                                transition-all transform hover:scale-105 active:scale-95 shadow-[0_10px_30px_rgba(6,182,212,0.4)]
                                flex items-center gap-3 overflow-hidden border border-cyan-300
                                ${syncing ? 'opacity-70 cursor-wait' : ''}
                            `}
                        >
                            {syncing ? (
                                <>
                                    <div className="w-4 h-4 border-2 border-black/30 border-t-black animate-spin rounded-full" />
                                    Synchronizing...
                                </>
                            ) : (
                                <>
                                    🚀 Sincronizar Caminos Neuronales & Abrir IDE
                                </>
                            )}
                        </button>
                    </div>

                    {/* Cosmetic Matrix overlay */}
                    <div className="absolute inset-0 opacity-[0.05] pointer-events-none font-mono text-[10px] overflow-hidden select-none p-4 flex flex-col gap-1">
                        {Array.from({ length: 15 }).map((_, i) => (
                            <div key={i} className="whitespace-nowrap overflow-hidden">
                                {Array.from({ length: 80 }).map(() => Math.random() > 0.7 ? '█' : (Math.random() > 0.5 ? '1' : '0')).join('')}
                            </div>
                        ))}
                    </div>
                </div>

                {/* Section A-Sub: Meta Info */}
                <div className="glass-panel p-6 flex flex-col gap-5 border-purple-500/10">
                    <h3 className="text-[10px] font-black text-purple-400 uppercase tracking-[0.3em] border-b border-purple-500/20 pb-3">Operational Status</h3>

                    <div className="space-y-5">
                        <div className="flex justify-between items-center group">
                            <span className="text-white/40 text-xs uppercase tracking-wider font-mono">Docker Engine</span>
                            <span className="text-green-400 font-bold text-xs ring-1 ring-green-400/30 px-2 py-0.5 rounded bg-green-400/10">READY</span>
                        </div>
                        <div className="flex justify-between items-center">
                            <span className="text-white/40 text-xs uppercase tracking-wider font-mono">Source Kernel</span>
                            <span className="text-cyan-400 font-mono text-xs">v20 (LTS)</span>
                        </div>
                        <div className="flex justify-between items-center">
                            <span className="text-white/40 text-xs uppercase tracking-wider font-mono">Mesh Auth</span>
                            <span className="text-white font-bold text-xs flex items-center gap-1">
                                <span className="w-1.5 h-1.5 bg-green-500 rounded-full" />
                                OK
                            </span>
                        </div>
                    </div>

                    <div className="mt-auto space-y-3">
                        <div className="flex justify-between text-[10px] text-white/30 font-bold uppercase">
                            <span>Indexing Workspace</span>
                            <span>{syncing ? '99%' : '100%'}</span>
                        </div>
                        <div className="w-full bg-white/5 h-1 rounded-full overflow-hidden">
                            <div className="w-full h-full bg-gradient-to-r from-cyan-500 to-purple-600 shadow-[0_0_10px_rgba(6,182,212,0.5)]" />
                        </div>
                        <div className="p-3 bg-white/5 border border-white/10 rounded-lg text-[10px] font-mono text-white/50 leading-tight">
                            &gt; system_log: forge_bridge established via port 8080. ready for neural uplink.
                        </div>
                    </div>
                </div>
            </div>

            {/* Section B: Mis Proyectos */}
            <div className="mt-4">
                <div className="flex items-center gap-4 mb-8">
                    <div className="h-0.5 w-8 bg-purple-500 rounded-full" />
                    <h2 className="text-xl font-black uppercase tracking-[0.2em] italic text-purple-200">Mis Proyectos</h2>
                    <span className="text-[10px] font-mono text-white/30 ml-auto">PROJECTS_COUNT: {projects.length}</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                    {projects.map((project) => (
                        <div key={project.id} className="glass-panel p-6 border-white/5 hover:border-purple-500/40 group transition-all duration-500 hover:-translate-y-1">
                            <div className="flex justify-between items-start mb-6">
                                <div>
                                    <h3 className="text-lg font-black group-hover:text-purple-300 transition-colors uppercase font-mono tracking-tight">{project.name}</h3>
                                    <span className="text-[9px] font-mono text-white/30 uppercase tracking-widest">{project.path}</span>
                                </div>
                                <div className="flex flex-col items-end gap-1">
                                    <span className="flex items-center gap-1.5 px-2 py-0.5 rounded-sm bg-green-500/10 border border-green-500/20 text-[9px] text-green-400 font-black uppercase tracking-widest shadow-[inset_0_0_5px_rgba(34,197,94,0.2)]">
                                        <span className="w-1 h-1 bg-green-500 rounded-full animate-pulse shadow-[0_0_5px_#22c55e]" />
                                        {project.status}
                                    </span>
                                </div>
                            </div>

                            <div className="flex gap-3">
                                <button className="flex-1 py-2.5 bg-black/40 hover:bg-black/60 border border-white/10 hover:border-white/20 rounded font-black text-[9px] uppercase tracking-[0.2em] transition-all flex items-center justify-center gap-2 group/btn">
                                    <span className="group-hover/btn:scale-125 transition-transform">▶️</span> Lanzar
                                </button>
                                <button className="flex-1 py-2.5 bg-purple-500/5 hover:bg-purple-500/10 border border-purple-500/20 hover:border-purple-500/40 text-purple-400 rounded font-black text-[9px] uppercase tracking-[0.2em] transition-all flex items-center justify-center gap-2 group/btn">
                                    <span className="group-hover/btn:scale-125 transition-transform">📡</span> Teletransportar
                                </button>
                            </div>
                        </div>
                    ))}

                    {/* Add New Hook */}
                    <button className="glass-panel p-6 border-dashed border-white/10 hover:border-cyan-500/40 flex flex-col items-center justify-center gap-2 group transition-all opacity-40 hover:opacity-100 min-h-[160px]">
                        <div className="w-10 h-10 rounded-full border border-dashed border-white/20 flex items-center justify-center text-2xl text-white/20 group-hover:text-cyan-400 group-hover:border-cyan-500/50 transition-all">
                            +
                        </div>
                        <span className="text-[9px] font-black uppercase tracking-[0.3em] text-white/20 group-hover:text-cyan-200 transition-colors">Inicializar Nexus</span>
                    </button>
                </div>
            </div>
        </div>
    );
};

export default WorkspaceView;
