import React, { useState } from 'react';
import { Shield, Lock, Power, Box, Cloud, Zap } from 'lucide-react';
import useSystemStore, { API_BASE } from '../store/useSystemStore';

const Onboarding = () => {
    const { fetchStatus } = useSystemStore();
    const [step, setStep] = useState(1);
    const [formData, setFormData] = useState({
        master_password: '',
        mode: 'Local Only (Sovereign)',
        gemini_key: ''
    });
    const [loading, setLoading] = useState(false);

    const handleSubmit = async () => {
        setLoading(true);
        try {
            const resp = await fetch(`${API_BASE}/api/auth/setup`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(formData)
            });
            const data = await resp.json();
            if (data.status === 'success') {
                await fetchStatus(); // Should trigger activeView change to chat/login
            } else {
                alert(data.message);
            }
        } catch (e) {
            alert("Connection error: " + e.message);
        }
        setLoading(false);
    };

    return (
        <div className="fixed inset-0 z-[100] bg-black flex items-center justify-center p-6 overflow-hidden">
            {/* Background Grid */}
            <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 pointer-events-none" />
            <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/10 via-transparent to-purple-500/10" />

            <div className="max-w-xl w-full glass-panel border border-white/10 p-12 relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-cyan-500 to-purple-500" />

                <header className="mb-10 text-center">
                    <div className="inline-flex p-3 rounded-2xl bg-cyan-500/10 text-cyan-400 mb-6 border border-cyan-500/20">
                        <Shield size={32} />
                    </div>
                    <h1 className="text-3xl font-bold text-white mb-2 tracking-tighter uppercase whitespace-pre">P R O T O C O L O   G É N E S I S</h1>
                    <p className="text-gray-500 text-xs font-mono tracking-widest uppercase">Inicialización del Núcleo Aegis v2.5</p>
                </header>

                <div className="space-y-8 min-h-[300px]">
                    {step === 1 && (
                        <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-500">
                            <div className="space-y-2">
                                <label className="text-[10px] text-gray-400 uppercase font-bold tracking-[0.2em] flex items-center gap-2">
                                    <Lock size={12} /> Definir Llave Maestra
                                </label>
                                <input
                                    type="password"
                                    value={formData.master_password}
                                    onChange={(e) => setFormData({ ...formData, master_password: e.target.value })}
                                    className="w-full bg-white/5 border border-white/10 rounded-xl p-4 text-white focus:border-cyan-500 outline-none transition-all placeholder:text-gray-700"
                                    placeholder="Ingrese contraseña de cifrado..."
                                />
                                <p className="text-[9px] text-gray-600 italic">Esta llave cifra todas tus llaves API y la Bóveda de memoria.</p>
                            </div>
                            <button
                                onClick={() => setStep(2)}
                                disabled={formData.master_password.length < 4}
                                className="w-full py-4 bg-white text-black font-bold rounded-xl flex items-center justify-center gap-2 hover:bg-cyan-500 transition-all disabled:opacity-20"
                            >
                                Continuar <Zap size={16} />
                            </button>
                        </div>
                    )}

                    {step === 2 && (
                        <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-500">
                            <div className="space-y-4">
                                <label className="text-[10px] text-gray-400 uppercase font-bold tracking-[0.2em]">Arquitectura Inicial</label>

                                <div className="grid grid-cols-1 gap-3">
                                    {[
                                        { id: 'Local Only (Sovereign)', icon: Box, desc: 'Privacidad total. Usa hardware local.' },
                                        { id: 'Hybrid (Smart)', icon: Zap, desc: 'Local para tareas simples, Cloud para potencia.' },
                                        { id: 'Cloud Only', icon: Cloud, desc: 'Inferencia remota de alta velocidad.' }
                                    ].map(mode => (
                                        <button
                                            key={mode.id}
                                            onClick={() => setFormData({ ...formData, mode: mode.id })}
                                            className={`flex items-center gap-4 p-4 rounded-xl border transition-all text-left ${formData.mode === mode.id
                                                ? 'border-cyan-500 bg-cyan-500/10 text-white'
                                                : 'border-white/5 bg-white/5 text-gray-500 hover:border-white/20'
                                                }`}
                                        >
                                            <mode.icon size={20} />
                                            <div>
                                                <div className="text-xs font-bold leading-none mb-1">{mode.id}</div>
                                                <div className="text-[10px] opacity-60">{mode.desc}</div>
                                            </div>
                                        </button>
                                    ))}
                                </div>
                            </div>

                            {formData.mode !== 'Local Only (Sovereign)' && (
                                <div className="space-y-2 animate-in fade-in duration-500">
                                    <label className="text-[10px] text-gray-400 uppercase font-bold tracking-[0.2em]">Llave API Inicial (Opcional)</label>
                                    <input
                                        type="password"
                                        value={formData.gemini_key}
                                        onChange={(e) => setFormData({ ...formData, gemini_key: e.target.value })}
                                        className="w-full bg-white/5 border border-white/10 rounded-xl p-4 text-white focus:border-cyan-500 outline-none transition-all placeholder:text-gray-700 font-mono"
                                        placeholder="Pega aquí tu Gemini o OpenAI Key..."
                                    />
                                    <p className="text-[9px] text-gray-600 italic">Por defecto Aegis intentará usar Gemini si no se especifica otra. Podrás añadir más proveedores en Configuración.</p>
                                </div>
                            )}

                            <div className="flex gap-4">
                                <button onClick={() => setStep(1)} className="flex-1 py-4 border border-white/10 text-gray-500 font-bold rounded-xl hover:text-white transition-all">Atrás</button>
                                <button
                                    onClick={handleSubmit}
                                    disabled={loading}
                                    className="flex-[2] py-4 bg-cyan-500 text-black font-bold rounded-xl flex items-center justify-center gap-2 hover:bg-cyan-400 transition-all shadow-lg shadow-cyan-500/20"
                                >
                                    {loading ? <div className="w-4 h-4 border-2 border-black/20 border-t-black rounded-full animate-spin" /> : "Iniciar Secuencia"} <Power size={16} />
                                </button>
                            </div>
                        </div>
                    )}
                </div>

                <div className="mt-8 pt-6 border-t border-white/5 flex justify-between items-center opacity-30">
                    <span className="text-[8px] font-mono">CODE: SEED_ALLOCATION.GENESIS</span>
                    <span className="text-[8px] font-mono">STATUS: PENDING_AUTH</span>
                </div>
            </div>
        </div>
    );
};

export default Onboarding;
