import { useEffect, useState, useRef, useMemo } from 'react';
import { X, Network, RefreshCw, Search, Database, Share2 } from 'lucide-react';
import { API_BASE } from '../store/useSystemStore';

const KnowledgeMap = ({ isOpen = true, onClose, isModal = false }) => {
    const [data, setData] = useState({ triples: [] });
    const [loading, setLoading] = useState(false);
    const [searchQuery, setSearchQuery] = useState('');
    const containerRef = useRef(null);

    const fetchGraph = async () => {
        setLoading(true);
        try {
            const res = await fetch(`${API_BASE}/api/graph`);
            const json = await res.json();
            setData(json);
        } catch (e) {
            console.error("Error fetching graph:", e);
        }
        setLoading(false);
    };

    useEffect(() => {
        if (isOpen) {
            fetchGraph();
        }
    }, [isOpen]);

    const filteredTriples = useMemo(() => {
        if (!searchQuery.trim()) return data.triples;
        const query = searchQuery.toLowerCase();
        return data.triples.filter(t =>
            t.subject.toLowerCase().includes(query) ||
            t.predicate.toLowerCase().includes(query) ||
            t.object.toLowerCase().includes(query)
        );
    }, [data.triples, searchQuery]);

    if (!isOpen) return null;

    // Process nodes and links for filtered data
    const nodes = {};
    const links = [];

    filteredTriples.forEach((t) => {
        if (!nodes[t.subject]) nodes[t.subject] = { id: t.subject, type: 'entity' };
        if (!nodes[t.object]) nodes[t.object] = { id: t.object, type: 'entity' };
        links.push({ source: t.subject, target: t.object, predicate: t.predicate });
    });

    const nodeArray = Object.values(nodes);
    const nodeCount = nodeArray.length;

    // Simple Circular Layout for nodes in SVG coordinate space (800x600)
    nodeArray.forEach((node, i) => {
        const angle = (i / nodeCount) * 2 * Math.PI;
        const radius = 220; // Fixed radius for stability
        node.x = 400 + radius * Math.cos(angle);
        node.y = 300 + radius * Math.sin(angle);
    });

    const containerClasses = isModal
        ? "fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-xl p-4 lg:p-10"
        : "w-full h-full flex flex-col";

    return (
        <div className={containerClasses}>
            <div className={`relative w-full h-full bg-black/60 glass-panel lg:rounded-2xl border border-white/10 shadow-[0_0_50px_rgba(0,242,254,0.05)] overflow-hidden flex flex-col`}>

                {/* Header Section */}
                <header className="p-4 lg:p-6 border-b border-white/5 flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                        <div className="p-2 bg-cyan-500/10 rounded-lg border border-cyan-500/20">
                            <Network className="text-[#00f2fe]" size={22} />
                        </div>
                        <div>
                            <h2 className="text-base lg:text-xl font-bold tracking-[0.1em] text-white">Graph RAG - Memoria Semántica</h2>
                            <p className="text-[10px] text-[#00f2fe]/60 font-mono flex items-center gap-1 uppercase tracking-widest">
                                <Database size={10} /> Neural Map Active // Connections: {links.length}
                            </p>
                        </div>
                    </div>

                    <div className="flex flex-1 max-w-md items-center gap-3">
                        <div className="relative flex-1">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={14} />
                            <input
                                type="text"
                                placeholder="FILTER RELATIONS..."
                                className="w-full bg-black/40 border border-white/10 rounded-full py-2 pl-9 pr-4 text-xs font-mono text-white focus:outline-none focus:border-[#00f2fe]/50 transition-all"
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                            />
                        </div>
                        <button
                            onClick={fetchGraph}
                            disabled={loading}
                            className="bg-white/5 hover:bg-white/10 p-2 rounded-full border border-white/10 transition-colors"
                        >
                            <RefreshCw size={18} className={`${loading ? "animate-spin" : ""} text-[#00f2fe]`} />
                        </button>
                        {onClose && (
                            <button onClick={onClose} className="text-gray-500 hover:text-white transition-colors">
                                <X size={24} />
                            </button>
                        )}
                    </div>
                </header>

                {/* Main Graph Area */}
                <div className="flex-1 relative overflow-hidden bg-[radial-gradient(circle_at_50%_50%,rgba(0,242,254,0.05)_0%,transparent_70%)]" ref={containerRef}>

                    <div className="absolute top-4 left-4 z-10 flex flex-col gap-2">
                        <div className="flex items-center gap-2 text-[10px] font-mono text-gray-400">
                            <span className="w-2 h-2 rounded-full bg-[#00f2fe]"></span> Nodos: Entidades
                        </div>
                        <div className="flex items-center gap-2 text-[10px] font-mono text-gray-400">
                            <span className="w-2 h-2 rounded-full bg-[#f093fb]"></span> Lineas: Predicados
                        </div>
                    </div>

                    <svg width="100%" height="100%" viewBox="0 0 800 600" className="w-full h-full" preserveAspectRatio="xMidYMid meet">
                        <defs>
                            <marker id="arrowhead" viewBox="0 -5 10 10" refX="22" refY="0" markerWidth="6" markerHeight="6" orient="auto">
                                <path d="M0,-5L10,0L0,5" fill="#f093fb" />
                            </marker>
                            <filter id="glow">
                                <feGaussianBlur stdDeviation="2.5" result="coloredBlur" />
                                <feMerge>
                                    <feMergeNode in="coloredBlur" />
                                    <feMergeNode in="SourceGraphic" />
                                </feMerge>
                            </filter>
                        </defs>

                        {/* Links (Relations) */}
                        {links.map((link, i) => {
                            const src = nodes[link.source];
                            const tgt = nodes[link.target];
                            if (!src || !tgt) return null;

                            const midX = (src.x + tgt.x) / 2;
                            const midY = (src.y + tgt.y) / 2;

                            return (
                                <g key={`link-${i}`} className="group/link">
                                    <line
                                        x1={src.x} y1={src.y} x2={tgt.x} y2={tgt.y}
                                        stroke="#f093fb"
                                        strokeWidth="1.5"
                                        strokeOpacity="0.15"
                                        className="transition-all group-hover/link:stroke-opacity-50 group-hover/link:stroke-[2px]"
                                        markerEnd="url(#arrowhead)"
                                    />
                                    <g transform={`translate(${midX}, ${midY})`}>
                                        <rect
                                            x="-30" y="-8" width="60" height="16" rx="4"
                                            fill="#0d1117"
                                            stroke="#f093fb"
                                            strokeWidth="0.5"
                                            className="opacity-40 group-hover/link:opacity-90"
                                        />
                                        <text
                                            fontSize="8"
                                            fill="#f093fb"
                                            textAnchor="middle"
                                            dominantBaseline="middle"
                                            className="pointer-events-none uppercase font-mono tracking-tighter filter"
                                            style={{ filter: 'url(#glow)' }}
                                        >
                                            {link.predicate}
                                        </text>
                                    </g>
                                </g>
                            );
                        })}

                        {/* Nodes (Entities) */}
                        {nodeArray.map((node, i) => (
                            <g key={`node-${i}`} className="group/node">
                                {/* Glow background */}
                                <circle
                                    cx={node.x} cy={node.y} r="12"
                                    fill="rgba(0, 242, 254, 0.1)"
                                    className="animate-pulse"
                                />
                                <circle
                                    cx={node.x} cy={node.y} r="6"
                                    fill="#000"
                                    stroke="#00f2fe"
                                    strokeWidth="2"
                                    className="transition-all duration-300 group-hover/node:r-[8px] group-hover/node:stroke-[3px]"
                                    style={{ filter: 'url(#glow)' }}
                                />
                                <g transform={`translate(${node.x}, ${node.y + 22})`}>
                                    <text
                                        fontSize="9"
                                        fill="#fff"
                                        textAnchor="middle"
                                        className="pointer-events-none font-bold uppercase tracking-widest"
                                    >
                                        {node.id}
                                    </text>
                                </g>
                            </g>
                        ))}
                    </svg>

                    {nodeArray.length === 0 && (
                        <div className="absolute inset-0 flex flex-col items-center justify-center text-gray-700 space-y-4">
                            <Share2 size={40} className="opacity-10" />
                            <div className="text-xs italic uppercase tracking-[0.4em] opacity-40">
                                {searchQuery ? "No matches found in neural map" : "Neural Knowledge Graph Empty"}
                            </div>
                        </div>
                    )}
                </div>

                {/* Footer Info */}
                <footer className="p-3 bg-black/40 border-t border-white/5 flex justify-between items-center">
                    <div className="flex gap-4">
                        <div className="flex items-center gap-2 text-[9px] font-mono text-gray-500 uppercase tracking-widest">
                            <span className="text-[#00f2fe] ring-1 ring-[#00f2fe]/30 px-1 rounded">RAG</span> Active
                        </div>
                        <div className="flex items-center gap-2 text-[9px] font-mono text-gray-500 uppercase tracking-widest">
                            <span className="text-[#f093fb] ring-1 ring-[#f093fb]/30 px-1 rounded">Memory</span> Persistent
                        </div>
                    </div>
                    <span className="text-[9px] font-mono text-gray-600 uppercase tracking-tighter">
                        Aegis Cognitive Engine // Unified Semantics v2.0
                    </span>
                </footer>
            </div>
        </div>
    );
};

export default KnowledgeMap;
