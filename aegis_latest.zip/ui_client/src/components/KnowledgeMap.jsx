import { useEffect, useState, useRef } from 'react';
import { X, Network, RefreshCw } from 'lucide-react';
import { API_BASE } from '../store/useSystemStore';

const KnowledgeMap = ({ isOpen, onClose }) => {
    const [data, setData] = useState({ triples: [] });
    const [loading, setLoading] = useState(false);
    const containerRef = useRef(null);

    const fetchGraph = async () => {
        setLoading(true);
        try {
            const res = await fetch(`${API_BASE}/api/graph`);
            const json = await res.json();
            setData(json);
        } catch (e) {
            console.error("Error fetching graph:", e);
        }
        setLoading(false);
    };

    useEffect(() => {
        if (isOpen) fetchGraph();
    }, [isOpen]);

    if (!isOpen) return null;

    // Simple Force-Graph-ish simulation in SVG
    const nodes = {};
    const links = [];

    data.triples.forEach((t) => {
        if (!nodes[t.subject]) nodes[t.subject] = { id: t.subject, type: 'entity' };
        if (!nodes[t.object]) nodes[t.object] = { id: t.object, type: 'entity' };
        links.push({ source: t.subject, target: t.object, predicate: t.predicate });
    });

    const nodeArray = Object.values(nodes);
    const nodeCount = nodeArray.length;

    // Simple Circular Layout for nodes
    nodeArray.forEach((node, i) => {
        const angle = (i / nodeCount) * 2 * Math.PI;
        const radius = Math.min(window.innerWidth, window.innerHeight) * 0.3;
        node.x = 400 + radius * Math.cos(angle);
        node.y = 300 + radius * Math.sin(angle);
    });

    return (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-xl animate-in fade-in duration-300 p-10">
            <div className="relative w-full h-full bg-[#050505] rounded-3xl border border-white/10 shadow-[0_0_100px_rgba(0,242,254,0.1)] overflow-hidden flex flex-col">

                <header className="p-6 border-b border-white/5 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <Network className="text-cyan-400" size={20} />
                        <h2 className="text-lg font-bold tracking-widest text-white uppercase">Neural Knowledge Graph</h2>
                    </div>
                    <div className="flex items-center gap-4">
                        <button onClick={fetchGraph} className="text-gray-500 hover:text-cyan-400 transition-colors">
                            <RefreshCw size={18} className={loading ? "animate-spin" : ""} />
                        </button>
                        <button onClick={onClose} className="text-gray-500 hover:text-white transition-colors">
                            <X size={24} />
                        </button>
                    </div>
                </header>

                <div className="flex-1 relative cursor-grab active:cursor-grabbing overflow-hidden" ref={containerRef}>
                    <svg width="100%" height="100%" viewBox="0 0 800 600" className="w-full h-full">
                        <defs>
                            <marker id="arrow" viewBox="0 -5 10 10" refX="20" refY="0" markerWidth="4" markerHeight="4" orient="auto">
                                <path d="M0,-5L10,0L0,5" fill="#22d3ee" opacity="0.5" />
                            </marker>
                        </defs>

                        {/* Links */}
                        {links.map((link, i) => {
                            const src = nodes[link.source];
                            const tgt = nodes[link.target];
                            if (!src || !tgt) return null;
                            return (
                                <g key={i}>
                                    <line
                                        x1={src.x} y1={src.y} x2={tgt.x} y2={tgt.y}
                                        stroke="rgba(34, 211, 238, 0.2)"
                                        strokeWidth="1"
                                        markerEnd="url(#arrow)"
                                    />
                                    <text
                                        x={(src.x + tgt.x) / 2}
                                        y={(src.y + tgt.y) / 2}
                                        fontSize="6"
                                        fill="#666"
                                        textAnchor="middle"
                                        className="pointer-events-none uppercase tracking-tighter"
                                    >
                                        {link.predicate}
                                    </text>
                                </g>
                            );
                        })}

                        {/* Nodes */}
                        {nodeArray.map((node, i) => (
                            <g key={i} className="group">
                                <circle
                                    cx={node.x} cy={node.y} r="6"
                                    fill="#000"
                                    stroke="#22d3ee"
                                    strokeWidth="2"
                                    className="transition-all duration-300 group-hover:r-[8px] group-hover:shadow-[0_0_15px_#22d3ee]"
                                />
                                <text
                                    x={node.x} y={node.y + 15}
                                    fontSize="8"
                                    fill="#fff"
                                    textAnchor="middle"
                                    className="pointer-events-none font-bold uppercase tracking-widest bg-black px-1"
                                >
                                    {node.id}
                                </text>
                            </g>
                        ))}
                    </svg>

                    {nodeArray.length === 0 && (
                        <div className="absolute inset-0 flex items-center justify-center text-gray-700 text-xs italic uppercase tracking-[0.4em]">
                            Knowledge Graph Empty. Execute missions to generate nodes.
                        </div>
                    )}
                </div>

                <footer className="p-4 bg-black/40 border-t border-white/5 text-[8px] text-gray-600 uppercase tracking-[0.2em] flex justify-between">
                    <span>Aegis Relational Engine // v1.0</span>
                    <span>Nodes: {nodeArray.length} // Links: {links.length}</span>
                </footer>
            </div>
        </div>
    );
};

export default KnowledgeMap;
