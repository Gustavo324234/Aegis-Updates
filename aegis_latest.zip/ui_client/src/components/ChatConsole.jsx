import React, { useEffect, useState, useRef } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import useChatStore from '../store/useChatStore';

export default function ChatConsole() {
    const { messages, connectWebSocket, sendMessage, isThinking, swarmStatus, fetchHistory, pendingActions, socket, removeAction } = useChatStore();
    const [input, setInput] = useState("");
    const endOfMessagesRef = useRef(null);

    useEffect(() => {
        fetchHistory();
        connectWebSocket("general");
    }, []);

    useEffect(() => {
        endOfMessagesRef.current?.scrollIntoView({ behavior: "smooth" });
    }, [messages, isThinking, pendingActions]);

    const handleSend = (e) => {
        e.preventDefault();
        if (!input.trim()) return;
        sendMessage(input);
        setInput("");
    };

    const handleApprove = (jobId) => {
        if (socket) {
            socket.send(JSON.stringify({ type: 'authorize_action', job_id: jobId }));
        }
    };

    const handleDeny = (jobId) => {
        removeAction(jobId);
        // Añadimos un mensaje de sistema para dejar rastro en la UI
        useChatStore.getState().addMessage({ id: Date.now(), role: 'system', content: `[ACCIÓN DENEGADA POR EL USUARIO]` });
    };

    return (
        <div className="flex flex-col h-full bg-[#050505]">
            {/* Header */}
            <header className="p-4 border-b border-gray-800 bg-[#0d1117] flex justify-between items-center crystal-blur">
                <div>
                    <h1 className="text-cyan-400 font-bold tracking-widest text-lg">AEGIS_OS // TERMINAL</h1>
                    <p className="text-xs text-gray-500">Status: {swarmStatus}</p>
                </div>
            </header>

            {/* Messages Window */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6 scrollbar-refined">
                {messages.map((msg, i) => (
                    <div key={msg.id || i} className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
                        <div className={`max-w-[85%] p-4 rounded-xl shadow-lg ${msg.role === 'user'
                                ? 'bg-gray-800 border border-gray-700 text-green-400'
                                : msg.role === 'system'
                                    ? 'bg-purple-900/20 border border-purple-500/30 text-purple-300 text-sm'
                                    : 'bg-[#0d1117] border border-cyan-500/30 text-gray-200'
                            }`}>
                            {msg.role === 'user' || msg.role === 'system' ? (
                                <div className="whitespace-pre-wrap font-mono text-sm">{msg.content}</div>
                            ) : (
                                <div className="prose prose-invert prose-cyan max-w-none text-sm font-mono leading-relaxed">
                                    <ReactMarkdown remarkPlugins={[remarkGfm]}>
                                        {msg.content}
                                    </ReactMarkdown>
                                </div>
                            )}
                        </div>
                    </div>
                ))}

                {/* Pending Actions (Human-in-the-Loop) */}
                {pendingActions.filter(a => a.status === 'Pending').map(action => (
                    <div key={`pending_${action.job_id}`} className="flex flex-col items-start w-full">
                        <div className="max-w-[85%] bg-[#1a0f00] border border-orange-500/50 p-4 rounded-xl shadow-[0_0_15px_rgba(249,115,22,0.1)]">
                            <h3 className="text-orange-400 font-bold mb-2 text-sm flex items-center gap-2">
                                ⚠️ Autorización Requerida: <span className="text-white bg-orange-900/50 px-2 py-0.5 rounded">{action.tool}</span>
                            </h3>
                            <pre className="text-xs text-gray-400 bg-black p-3 rounded mb-4 overflow-x-auto border border-gray-800">
                                {JSON.stringify(action.args, null, 2)}
                            </pre>
                            <div className="flex gap-3">
                                <button onClick={() => handleApprove(action.job_id)} className="bg-green-900/40 text-green-400 border border-green-500/50 px-6 py-2 rounded-lg text-sm font-bold hover:bg-green-800 transition-all shadow-[0_0_10px_rgba(34,197,94,0.2)]">
                                    APROBAR
                                </button>
                                <button onClick={() => handleDeny(action.job_id)} className="bg-red-900/40 text-red-400 border border-red-500/50 px-6 py-2 rounded-lg text-sm font-bold hover:bg-red-800 transition-all">
                                    DENEGAR
                                </button>
                            </div>
                        </div>
                    </div>
                ))}

                {/* Action Executing Logs */}
                {pendingActions.filter(a => a.status === 'Executing').map(action => (
                    <div key={`exec_${action.job_id}`} className="flex flex-col items-start w-full">
                        <div className="max-w-[85%] bg-blue-900/10 border border-blue-500/30 p-4 rounded-xl w-full">
                            <h3 className="text-blue-400 font-bold text-sm mb-2 animate-pulse">⚙️ Ejecutando: {action.tool}...</h3>
                            <pre className="text-xs text-gray-500 bg-black p-2 rounded h-24 overflow-y-auto flex flex-col-reverse">
                                {action.logs?.join("") || "Iniciando proceso..."}
                            </pre>
                        </div>
                    </div>
                ))}

                {isThinking && (
                    <div className="flex items-start">
                        <div className="max-w-[80%] p-4 rounded-xl bg-[#0d1117] border border-cyan-500/50 animate-pulse text-cyan-400">
                            <span className="text-sm font-mono">Procesando petición... ▌</span>
                        </div>
                    </div>
                )}
                <div ref={endOfMessagesRef} />
            </div>

            {/* Input Bar */}
            <div className="p-4 bg-[#0d1117] border-t border-gray-800">
                <form onSubmit={handleSend} className="flex gap-2">
                    <input
                        type="text"
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        placeholder="Comando para Aegis..."
                        className="flex-1 bg-black border border-gray-700 focus:border-cyan-500 rounded-lg p-4 text-white outline-none transition-all font-mono text-sm shadow-inner"
                    />
                    <button
                        type="submit"
                        className="bg-cyan-900/50 hover:bg-cyan-800 text-cyan-400 border border-cyan-500/50 px-8 rounded-lg font-bold transition-all hover:shadow-[0_0_15px_rgba(0,242,254,0.3)] active:scale-95"
                    >
                        ENVIAR
                    </button>
                </form>
            </div>
        </div>
    );
}
