import React, { useEffect, useRef, useState } from 'react';
import useChatStore from '../store/useChatStore';
import { Send, Terminal, Cpu, Sparkles, User, Bot, ChevronRight, Activity } from 'lucide-react';
import MessageRenderer from './MessageRenderer';
import PendingActionCard from './PendingActionCard';
import OmniUploader from './OmniUploader';

const ChatConsole = () => {
    const {
        messages,
        sendMessage,
        isThinking,
        swarmStatus,
        connectWebSocket,
        pendingActions
    } = useChatStore();

    const [input, setInput] = useState('');
    const [pendingFiles, setPendingFiles] = useState([]);
    const [resetUploader, setResetUploader] = useState(false);
    const scrollRef = useRef(null);
    const inputRef = useRef(null);

    // Conectar WebSocket al montar siguiendo instrucciones
    useEffect(() => {
        const cleanup = connectWebSocket();
        return () => {
            if (cleanup) cleanup();
        };
    }, []);

    // Scroll al fondo automático con comportamiento suave
    useEffect(() => {
        if (scrollRef.current) {
            scrollRef.current.scrollTo({
                top: scrollRef.current.scrollHeight,
                behavior: 'smooth'
            });
        }
    }, [messages, isThinking, pendingActions]);

    const handleSend = () => {
        if ((input.trim() || pendingFiles.length > 0) && !isThinking) {
            // Extraer solo los base64 de los archivos para el payload
            const filesData = pendingFiles.map(f => f.base64);

            // Si solo hay una imagen, podemos usar el campo 'image' antiguo para compatibilidad
            // o pasar el array completo al nuevo backend.
            const primaryImage = pendingFiles.find(f => f.type.startsWith('image/'))?.base64 || null;

            sendMessage(input, primaryImage, filesData);

            setInput('');
            setPendingFiles([]);
            setResetUploader(prev => !prev);

            // Reset textarea height
            if (inputRef.current) {
                inputRef.current.style.height = 'auto';
            }
        }
    };

    const handleKeyDown = (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSend();
        }
    };

    return (
        <div className="flex flex-col h-full bg-slate-950/20">
            {/* Contenedor de Mensajes con scroll refinado */}
            <div
                ref={scrollRef}
                className="flex-1 overflow-y-auto px-4 py-10 scrollbar-refined"
            >
                <div className="max-w-4xl mx-auto space-y-10">
                    {messages.length === 0 && (
                        <div className="flex flex-col items-center justify-center min-h-[50vh] text-slate-500">
                            <div className="relative mb-6">
                                <div className="absolute inset-0 bg-cyan-500/20 blur-2xl rounded-full animate-pulse" />
                                <Sparkles size={64} className="relative text-cyan-400 opacity-60" />
                            </div>
                            <h2 className="text-2xl font-light tracking-widest uppercase mb-2">Aegis-IA Mesh</h2>
                            <p className="text-sm font-mono opacity-40">Awaiting Operator Command...</p>
                        </div>
                    )}

                    {messages.map((msg) => {
                        if (msg.role === 'system') {
                            return (
                                <div key={msg.id} className="flex justify-center">
                                    <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-[10px] uppercase tracking-wider text-slate-500 font-mono">
                                        <Activity size={10} className="text-cyan-500/50" />
                                        {msg.content}
                                    </div>
                                </div>
                            );
                        }

                        const isUser = msg.role === 'user';

                        return (
                            <div
                                key={msg.id}
                                className={`flex ${isUser ? 'justify-end' : 'justify-start'} group animate-in fade-in slide-in-from-bottom-2 duration-500`}
                            >
                                <div className={`flex flex-col max-w-[85%] sm:max-w-3xl ${isUser ? 'items-end' : 'items-start'}`}>
                                    {/* Etiqueta de Origen */}
                                    <div className={`flex items-center gap-2 mb-2 px-1 transition-opacity ${isUser ? 'flex-row-reverse text-amber-500/60' : 'text-cyan-500/60'}`}>
                                        {isUser ? <User size={12} /> : <Bot size={12} />}
                                        <span className="text-[10px] uppercase tracking-widest font-bold">
                                            {isUser ? 'Operador' : 'Aegis Core'}
                                        </span>
                                    </div>

                                    {/* Cuerpo del Mensaje */}
                                    <div className={`
                                        relative p-5 rounded-3xl text-[15px] leading-relaxed
                                        ${isUser
                                            ? 'bg-slate-800/40 border border-slate-700/50 text-slate-200 rounded-tr-none shadow-lg'
                                            : 'bg-slate-900/60 border border-slate-800/80 text-slate-100 rounded-tl-none shadow-xl backdrop-blur-md'
                                        }
                                    `}>
                                        <MessageRenderer
                                            content={msg.content}
                                            isStreaming={msg.isStreaming}
                                        />
                                    </div>
                                </div>
                            </div>
                        );
                    })}

                    {/* Acciones Pendientes que requieren aprobación */}
                    <div className="space-y-4">
                        {pendingActions.map((action) => (
                            <PendingActionCard key={action.job_id} action={action} />
                        ))}
                    </div>



                    {/* Espacio final para evitar que el Omnibox tape mensajes */}
                    <div className="h-32" />
                </div>
            </div>

            {/* Omnibox Flotante */}
            <div className="fixed bottom-0 left-0 right-0 p-6 pointer-events-none">
                <div className="max-w-4xl mx-auto pointer-events-auto">

                    {/* Status del Enjambre */}
                    {isThinking && (
                        <div className="flex items-center gap-3 mb-4 px-5 py-2 rounded-2xl bg-slate-900/80 border border-cyan-500/30 w-max mx-auto shadow-2xl shadow-cyan-500/10 backdrop-blur-md animate-pulse">
                            <div className="flex gap-1">
                                <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                                <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                                <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full animate-bounce"></span>
                            </div>
                            <p className="text-[11px] text-cyan-400 uppercase tracking-[0.2em] font-bold">
                                {swarmStatus || 'Aegis está pensando...'}
                            </p>
                        </div>
                    )}

                    <div className="group relative">
                        {/* Previsualizaciones y Trigger de Subida */}
                        <OmniUploader
                            onFilesUpdate={setPendingFiles}
                            resetTrigger={resetUploader}
                        />

                        {/* Brillo de enfoque */}
                        <div className="absolute -inset-1 bg-gradient-to-r from-cyan-500/20 via-purple-500/20 to-amber-500/20 rounded-[2rem] blur-xl opacity-0 group-focus-within:opacity-100 transition duration-1000"></div>

                        <div className="glass-panel relative flex items-end gap-3 p-3 pl-12 bg-slate-900/90 border-slate-800/50 shadow-2xl rounded-[1.5rem]">
                            <textarea
                                ref={inputRef}
                                value={input}
                                onChange={(e) => setInput(e.target.value)}
                                onKeyDown={handleKeyDown}
                                placeholder="Introduce una instrucción estratégica..."
                                rows={1}
                                className="flex-1 max-h-64 min-h-[48px] bg-transparent border-none focus:ring-0 text-slate-100 placeholder-slate-600 py-3 px-5 resize-none transition-all font-mono text-sm"
                                style={{ height: 'auto' }}
                                onInput={(e) => {
                                    e.target.style.height = 'auto';
                                    e.target.style.height = e.target.scrollHeight + 'px';
                                }}
                            />

                            <button
                                onClick={handleSend}
                                disabled={(!input.trim() && pendingFiles.length === 0) || isThinking}
                                className={`
                                    flex items-center justify-center w-12 h-12 rounded-2xl transition-all duration-500
                                    ${!input.trim() || isThinking
                                        ? 'text-slate-700 bg-slate-800/50 cursor-not-allowed opacity-50'
                                        : 'bg-cyan-600 text-white hover:bg-cyan-500 hover:scale-110 active:scale-90 shadow-lg shadow-cyan-900/40'
                                    }
                                `}
                            >
                                <Send size={20} className={isThinking ? 'animate-ping' : ''} />
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ChatConsole;
