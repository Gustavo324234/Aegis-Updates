import React, { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';
import remarkGfm from 'remark-gfm';
import { Copy, Check, Cpu, ChevronRight } from 'lucide-react';

/**
 * MessageRenderer component to handle Markdown rendering, Syntax Highlighting,
 * and ReAct tag parsing (<think>, <tool>).
 */
const MessageRenderer = ({ content, isStreaming }) => {

    // Logic to hide <tool>...</tool> and extract <think>...</think>
    const parseContent = (text) => {
        if (!text) return { mainContent: '', thought: null };

        // Hide <tool> tags entirely
        let cleaned = text.replace(/<tool>[\s\S]*?<\/tool>/g, '');

        // Extract <think> content
        const thinkMatch = cleaned.match(/<think>([\s\S]*?)<\/think>/);
        let thought = null;
        if (thinkMatch) {
            thought = thinkMatch[1].trim();
            cleaned = cleaned.replace(/<think>[\s\S]*?<\/think>/, '');
        }

        return { mainContent: cleaned.trim(), thought };
    };

    const { mainContent, thought } = parseContent(content);

    return (
        <div className="flex flex-col gap-4">
            {/* Thought/Processing Block */}
            {thought && (
                <details className="bg-black/40 rounded-xl overflow-hidden border border-white/5 group/details shadow-inner">
                    <summary className="px-4 py-2.5 cursor-pointer text-[10px] text-slate-400 flex items-center justify-between hover:bg-white/5 transition-colors list-none">
                        <div className="flex items-center gap-2">
                            <Cpu size={14} className="text-cyan-500 animate-pulse" />
                            <span className="font-mono tracking-widest uppercase opacity-80 font-bold">Proceso Cognitivo</span>
                        </div>
                        <ChevronRight size={14} className="group-open/details:rotate-90 transition-transform opacity-40" />
                    </summary>
                    <div className="px-5 py-4 text-[13px] text-slate-400 font-mono italic leading-relaxed border-t border-white/5 bg-slate-950/20">
                        <ReactMarkdown remarkPlugins={[remarkGfm]}>
                            {thought}
                        </ReactMarkdown>
                    </div>
                </details>
            )}

            {/* Main Markdown Content */}
            <div className="prose prose-invert prose-sm max-w-none 
                prose-p:leading-relaxed prose-p:text-slate-200 
                prose-headings:text-cyan-400 prose-headings:font-light prose-headings:tracking-tight
                prose-strong:text-cyan-200 prose-a:text-cyan-400 hover:prose-a:text-cyan-300
                prose-ul:list-disc prose-ol:list-decimal">
                <ReactMarkdown
                    remarkPlugins={[remarkGfm]}
                    components={{
                        code({ node, inline, className, children, ...props }) {
                            const match = /language-(\w+)/.exec(className || '');
                            const language = match ? match[1] : '';

                            if (inline) {
                                return (
                                    <code className="bg-slate-950/60 text-cyan-400 px-1.5 py-0.5 rounded text-sm font-mono border border-white/5" {...props}>
                                        {children}
                                    </code>
                                );
                            }

                            return (
                                <CodeBlock
                                    language={language}
                                    value={String(children).replace(/\n$/, '')}
                                />
                            );
                        }
                    }}
                >
                    {mainContent}
                </ReactMarkdown>

                {/* Streaming Indicator */}
                {isStreaming && (
                    <span className="inline-block w-2 h-4 ml-1 bg-cyan-500/50 animate-pulse align-middle" />
                )}
            </div>
        </div>
    );
};

/**
 * Sub-component for code blocks with Header and Copy button
 */
const CodeBlock = ({ language, value }) => {
    const [copied, setCopied] = useState(false);

    const handleCopy = () => {
        navigator.clipboard.writeText(value);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    return (
        <div className="my-6 rounded-xl overflow-hidden border border-slate-700/50 shadow-2xl bg-[#1e1e1e]">
            {/* Header */}
            <div className="flex items-center justify-between px-4 py-2 bg-slate-800/80 border-b border-slate-700/50">
                <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest font-bold">
                    {language || 'code'}
                </span>
                <button
                    onClick={handleCopy}
                    className="flex items-center gap-1.5 px-2 py-1 text-[10px] font-medium text-slate-300 hover:text-cyan-400 transition-colors rounded-md hover:bg-white/5"
                >
                    {copied ? (
                        <>
                            <Check size={12} className="text-green-400" />
                            <span className="text-green-400 font-bold uppercase transition-all duration-300">Copiado</span>
                        </>
                    ) : (
                        <>
                            <Copy size={12} />
                            <span className="uppercase tracking-tighter">Copiar</span>
                        </>
                    )}
                </button>
            </div>

            {/* Content */}
            <div className="relative overflow-x-auto text-sm">
                <SyntaxHighlighter
                    language={language || 'text'}
                    style={vscDarkPlus}
                    customStyle={{
                        margin: 0,
                        padding: '1.25rem',
                        fontSize: '0.85rem',
                        lineHeight: '1.5',
                        backgroundColor: 'transparent',
                    }}
                    codeTagProps={{
                        style: {
                            fontFamily: 'JetBrains Mono, Fira Code, monospace',
                        }
                    }}
                >
                    {value}
                </SyntaxHighlighter>
            </div>
        </div>
    );
};

export default MessageRenderer;
