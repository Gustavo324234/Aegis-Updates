import React, { useState } from 'react';
import useSystemStore from '../store/useSystemStore';

export default function AuthScreens() {
    const { activeView, login, setupSystem, checkOllama, ollamaStatus } = useSystemStore();

    // Login State
    const [password, setPassword] = useState("");
    const [loginError, setLoginError] = useState(false);

    // Setup State
    const [masterPass, setMasterPass] = useState("");
    const [mode, setMode] = useState("Local Only (Sovereign)");

    const handleLogin = async (e) => {
        e.preventDefault();
        const success = await login(password);
        if (!success) setLoginError(true);
    };

    const handleSetup = async (e) => {
        e.preventDefault();
        if (masterPass.length < 4) return alert("La contraseña debe tener al menos 4 caracteres.");
        await setupSystem({ master_password: masterPass, mode });
    };

    if (activeView === 'login') {
        return (
            <div className="flex h-full w-full items-center justify-center bg-[#000000] bg-[radial-gradient(circle_at_50%_50%,#111_0%,#000_100%)]">
                <div className="glass-panel p-10 w-[400px] text-center shadow-[0_0_30px_rgba(0,242,254,0.1)]">
                    <h1 className="text-3xl font-bold text-cyan-400 mb-2 tracking-widest">AEGIS_OS</h1>
                    <p className="text-xs text-gray-500 mb-8 tracking-widest">SYSTEM ACCESS LOCKED</p>

                    <form onSubmit={handleLogin} className="space-y-4">
                        <input
                            type="password"
                            value={password}
                            onChange={(e) => { setPassword(e.target.value); setLoginError(false); }}
                            className="w-full bg-[#050505] border border-gray-700 focus:border-cyan-500 rounded p-3 text-center text-white outline-none tracking-widest"
                            placeholder="IDENTITY VERIFICATION"
                        />
                        {loginError && <p className="text-red-500 text-xs font-bold">ACCESS DENIED</p>}
                        <button type="submit" className="w-full bg-cyan-900/30 hover:bg-cyan-800/50 text-cyan-400 border border-cyan-500/50 p-3 rounded font-bold transition-all">
                            AUTHENTICATE
                        </button>
                    </form>
                </div>
            </div>
        );
    }

    // Onboarding (Genesis Protocol)
    return (
        <div className="flex h-full w-full items-center justify-center bg-[#000000] overflow-y-auto p-4">
            <div className="glass-panel p-10 max-w-2xl w-full border-t-2 border-t-cyan-500 shadow-[0_0_50px_rgba(0,242,254,0.1)]">
                <h1 className="text-2xl font-bold text-cyan-400 mb-1">PROTOCOLO GÉNESIS</h1>
                <p className="text-sm text-gray-400 mb-8">Inicialización del núcleo del sistema.</p>

                <form onSubmit={handleSetup} className="space-y-8">
                    <div>
                        <h2 className="text-lg text-gray-200 mb-2 border-b border-gray-800 pb-2">1. Seguridad Maestra</h2>
                        <p className="text-xs text-gray-500 mb-3">Esta llave encriptará todos tus datos y accesos API. No se puede recuperar si la pierdes.</p>
                        <input
                            type="password"
                            value={masterPass}
                            onChange={(e) => setMasterPass(e.target.value)}
                            className="w-full bg-[#050505] border border-gray-700 rounded p-3 text-white outline-none focus:border-cyan-500"
                            placeholder="Establece una contraseña fuerte..."
                        />
                    </div>

                    <div>
                        <h2 className="text-lg text-gray-200 mb-2 border-b border-gray-800 pb-2">2. Arquitectura Base</h2>
                        <div className="flex gap-4">
                            {["Local Only (Sovereign)", "Hybrid (Smart)", "Cloud Only"].map(m => (
                                <label key={m} className={`flex-1 p-3 rounded border cursor-pointer transition-all ${mode === m ? 'bg-cyan-900/20 border-cyan-500 text-cyan-400' : 'bg-[#050505] border-gray-700 text-gray-500 hover:border-gray-500'}`}>
                                    <input type="radio" className="hidden" checked={mode === m} onChange={() => setMode(m)} />
                                    <div className="text-sm font-bold text-center">{m}</div>
                                </label>
                            ))}
                        </div>
                    </div>

                    <button type="submit" className="w-full bg-cyan-500 text-black p-4 rounded font-bold tracking-widest hover:bg-cyan-400 transition-all hover:shadow-[0_0_20px_rgba(0,242,254,0.4)]">
                        INICIAR SISTEMA
                    </button>
                </form>
            </div>
        </div>
    );
}
