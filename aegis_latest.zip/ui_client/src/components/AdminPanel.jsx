import React, { useEffect } from 'react';
import useSystemStore from '../store/useSystemStore';

export default function AdminPanel() {
    const { daemons, fetchDaemons, toggleDaemon, metrics, fetchStatus, health } = useSystemStore();

    useEffect(() => {
        fetchDaemons();
        fetchStatus();
        // Refrescar cada 5 segundos
        const interval = setInterval(() => {
            fetchDaemons();
            fetchStatus();
        }, 5000);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="p-10 h-full overflow-y-auto bg-[#050505] text-gray-300 scrollbar-refined">
            <h1 className="text-3xl text-purple-400 font-bold mb-2 tracking-wider">CENTRO DE MANDO SRE</h1>
            <p className="text-gray-500 mb-8">Telemetría del sistema y control de procesos en segundo plano.</p>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">

                {/* Métricas del Sistema */}
                <div className="glass-panel p-6">
                    <h2 className="text-xl text-cyan-400 border-b border-gray-800 pb-2 mb-6 font-bold flex items-center justify-between">
                        <span>📊 Telemetría</span>
                        <span className={`text-xs px-2 py-1 rounded ${health === 'GREEN' ? 'bg-green-900/50 text-green-400' : 'bg-red-900/50 text-red-400'}`}>
                            SYS: {health}
                        </span>
                    </h2>

                    <div className="space-y-4 font-mono text-sm">
                        <div>
                            <div className="flex justify-between mb-1 text-gray-400"><span>Uso de RAM (App)</span> <span>{metrics?.app_ram_usage_mb || 0} MB</span></div>
                            <div className="w-full bg-gray-800 rounded-full h-1.5"><div className="bg-cyan-400 h-1.5 rounded-full" style={{ width: `${Math.min(100, ((metrics?.app_ram_usage_mb || 0) / 2000) * 100)}%` }}></div></div>
                        </div>
                        <div>
                            <div className="flex justify-between mb-1 text-gray-400"><span>RAM Sistema</span> <span>{metrics?.ram_used_percent || 0}%</span></div>
                            <div className="w-full bg-gray-800 rounded-full h-1.5"><div className="bg-purple-400 h-1.5 rounded-full" style={{ width: `${metrics?.ram_used_percent || 0}%` }}></div></div>
                        </div>
                        <div>
                            <div className="flex justify-between mb-1 text-gray-400"><span>CPU Global</span> <span>{metrics?.cpu_percent || 0}%</span></div>
                            <div className="w-full bg-gray-800 rounded-full h-1.5"><div className="bg-green-400 h-1.5 rounded-full" style={{ width: `${metrics?.cpu_percent || 0}%` }}></div></div>
                        </div>
                    </div>
                </div>

                {/* Gestión de Daemons */}
                <div className="glass-panel p-6">
                    <h2 className="text-xl text-purple-400 border-b border-gray-800 pb-2 mb-4 font-bold">
                        ⚙️ Daemons (Background)
                    </h2>
                    {daemons?.length === 0 ? (
                        <p className="text-sm text-gray-500">No hay procesos registrados.</p>
                    ) : (
                        <div className="space-y-3">
                            {daemons?.map((d, i) => (
                                <div key={i} className="flex items-center justify-between p-3 bg-black/40 border border-gray-800 rounded">
                                    <div>
                                        <p className="font-bold text-sm text-gray-200">{d.name}</p>
                                        <p className="text-xs text-gray-500">{d.type}</p>
                                    </div>
                                    <button
                                        onClick={() => toggleDaemon(d.name)}
                                        className={`px-3 py-1 text-xs font-bold rounded border ${d.status === 'RUNNING' ? 'bg-green-900/30 border-green-500/50 text-green-400' : 'bg-gray-800/50 border-gray-600 text-gray-400'}`}
                                    >
                                        {d.status === 'RUNNING' ? 'ACTIVO' : 'DETENIDO'}
                                    </button>
                                </div>
                            ))}
                        </div>
                    )}
                </div>

            </div>
        </div>
    );
}
