import React, { useState, useEffect } from 'react';
import { ShieldAlert, RefreshCw, Trash2, Cpu, HardDrive, User, Info, CheckCircle, AlertTriangle } from 'lucide-react';
import useSystemStore, { API_BASE } from '../store/useSystemStore';

const SystemControl = () => {
    const { metrics, health, fetchStatus } = useSystemStore();
    const [updateInfo, setUpdateInfo] = useState(null);
    const [loadingUpdate, setLoadingUpdate] = useState(false);
    const [confirmPurge, setConfirmPurge] = useState(false);
    const [purgeLoading, setPurgeLoading] = useState(false);

    useEffect(() => {
        const checkUpdates = async () => {
            try {
                const resp = await fetch(`${API_BASE}/api/system/update/check`);
                const data = await resp.json();
                setUpdateInfo(data);
            } catch (e) {
                console.error("Update check failed", e);
            }
        };
        checkUpdates();
    }, []);

    const handlePurge = async () => {
        setPurgeLoading(true);
        try {
            const resp = await fetch(`${API_BASE}/api/system/purge`, { method: 'POST' });
            const data = await resp.json();
            if (data.status === 'success') {
                alert("Protocolo de Purga Completado. El sistema se reiniciará.");
                window.location.reload();
            } else {
                alert("Error en la purga: " + data.message);
            }
        } catch (e) {
            alert("Error crítico de red durante la purga");
        }
        setPurgeLoading(false);
    };

    return (
        <div className="flex-1 overflow-y-auto p-12 bg-black scrollbar-refined animate-in fade-in duration-700">
            <header className="mb-12">
                <h1 className="text-4xl font-bold text-white mb-2 tracking-tighter">CORTEX CONTROL</h1>
                <p className="text-gray-500 font-mono text-sm uppercase tracking-[0.3em]">Operaciones de Sistema y Mantenimiento de Núcleo</p>
            </header>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Health & Metrics */}
                <section className="glass-panel border border-white/5 p-8 rounded-2xl">
                    <h2 className="text-xs font-bold text-gray-500 uppercase tracking-[0.3em] mb-8 flex items-center gap-2">
                        <Cpu size={14} className="text-cyan-400" /> Vital Stats & Health
                    </h2>

                    <div className="space-y-6">
                        <div className="flex justify-between items-center">
                            <span className="text-xs text-gray-400 uppercase tracking-widest">SRE Status</span>
                            <span className="flex items-center gap-2 text-green-400 font-bold text-xs uppercase tracking-tighter">
                                <CheckCircle size={12} /> Operational
                            </span>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <div className="p-4 bg-white/5 rounded-xl border border-white/10">
                                <div className="text-[10px] text-gray-500 uppercase mb-1">CPU Load</div>
                                <div className="text-2xl font-bold text-white">{metrics?.cpu || 0}%</div>
                            </div>
                            <div className="p-4 bg-white/5 rounded-xl border border-white/10">
                                <div className="text-[10px] text-gray-500 uppercase mb-1">RAM Available</div>
                                <div className="text-2xl font-bold text-white">{metrics?.ram?.percent || 0}%</div>
                            </div>
                        </div>
                    </div>
                </section>

                {/* Update Pipeline */}
                <section className="glass-panel border border-white/5 p-8 rounded-2xl relative overflow-hidden">
                    <h2 className="text-xs font-bold text-gray-500 uppercase tracking-[0.3em] mb-8 flex items-center gap-2">
                        <RefreshCw size={14} className="text-cyan-400" /> Provisioning Pipeline
                    </h2>

                    {updateInfo ? (
                        <div className="space-y-6 animate-in slide-in-from-bottom-4 duration-500">
                            <div className="flex justify-between items-end">
                                <div>
                                    <div className="text-[10px] text-gray-500 uppercase">Versión Actual</div>
                                    <div className="text-xl font-mono font-bold text-white">v{updateInfo.current_version}</div>
                                </div>
                                {updateInfo.update_available && (
                                    <div className="text-right">
                                        <div className="text-[10px] text-cyan-500 uppercase font-bold animate-pulse">Update Available</div>
                                        <div className="text-xl font-mono font-bold text-cyan-400 underline decoration-cyan-500/30">v{updateInfo.remote_version}</div>
                                    </div>
                                )}
                            </div>

                            {updateInfo.update_available ? (
                                <div className="p-4 bg-cyan-500/10 border border-cyan-500/30 rounded-xl">
                                    <p className="text-xs text-cyan-100 mb-4 leading-relaxed font-serif italic text-center">
                                        "{updateInfo.changelog || 'Optimizaciones de núcleo y mejoras en la sincronización neuronal.'}"
                                    </p>
                                    <button className="w-full py-3 bg-cyan-500 text-black font-bold text-xs uppercase rounded-lg hover:bg-cyan-400 transition-all">
                                        Initialize Remote Upgrade
                                    </button>
                                </div>
                            ) : (
                                <div className="flex items-center justify-center gap-2 py-8 text-gray-600 border border-dashed border-white/10 rounded-xl">
                                    <CheckCircle size={16} />
                                    <span className="text-[10px] font-bold uppercase tracking-widest">Aegis is Up to Date</span>
                                </div>
                            )}
                        </div>
                    ) : (
                        <div className="flex items-center justify-center h-32 animate-pulse text-gray-700 uppercase text-[10px] font-bold tracking-[0.3em]">
                            Verificando Repositorio...
                        </div>
                    )}
                </section>

                {/* Sanitization Zone */}
                <section className="lg:col-span-2 glass-panel border border-red-500/20 p-8 rounded-2xl bg-red-500/[0.02]">
                    <div className="flex flex-col md:flex-row items-center justify-between gap-8">
                        <div className="max-w-xl">
                            <h2 className="text-xs font-bold text-red-500 uppercase tracking-[0.3em] mb-2 flex items-center gap-2">
                                <ShieldAlert size={14} /> Protocolo de Purga Nuclear
                            </h2>
                            <p className="text-xs text-gray-500 leading-relaxed font-mono">
                                La activación de este protocolo eliminará irreversiblemente toda la base de datos (triples, gastos, tareas, historial), vaciará el Vault y los Proyectos, y restablecerá la configuración de núcleo a valores de fábrica.
                            </p>
                        </div>

                        {!confirmPurge ? (
                            <button
                                onClick={() => setConfirmPurge(true)}
                                className="px-8 py-4 border border-red-500/30 text-red-500 hover:bg-red-500/10 transition-all font-bold text-xs uppercase rounded-xl tracking-widest"
                            >
                                Execute Factory Reset
                            </button>
                        ) : (
                            <div className="flex flex-col items-center gap-4 animate-in zoom-in duration-300">
                                <div className="text-[10px] text-red-500 font-bold uppercase tracking-widest flex items-center gap-2">
                                    <AlertTriangle size={14} /> ¿Confirmar purga total?
                                </div>
                                <div className="flex gap-4">
                                    <button
                                        onClick={handlePurge}
                                        disabled={purgeLoading}
                                        className="px-6 py-3 bg-red-500 text-white font-bold text-[10px] uppercase rounded-lg hover:bg-red-400 transition-all"
                                    >
                                        {purgeLoading ? "Purging..." : "Sí, Proceder"}
                                    </button>
                                    <button
                                        onClick={() => setConfirmPurge(false)}
                                        className="px-6 py-3 bg-white/5 text-white font-bold text-[10px] uppercase rounded-lg hover:bg-white/10 transition-all border border-white/10"
                                    >
                                        Abortar
                                    </button>
                                </div>
                            </div>
                        )}
                    </div>
                </section>
            </div>
        </div>
    );
};

export default SystemControl;
