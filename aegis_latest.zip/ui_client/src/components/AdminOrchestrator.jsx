import React, { useState, useEffect } from 'react';
import useSystemStore from '../store/useSystemStore';
import {
    Users,
    Cpu,
    Network,
    Trash2,
    Play,
    Square,
    Plus,
    ShieldAlert,
    Database,
    Activity,
    UserPlus,
    RefreshCcw,
    Power,
    Terminal,
    Unplug
} from 'lucide-react';

const AdminOrchestrator = () => {
    const {
        tenants,
        daemons,
        nodes,
        health,
        fetchTenants,
        deployTenant,
        startTenant,
        stopTenant,
        deleteTenant,
        fetchDaemons,
        toggleDaemon,
        fetchNodes
    } = useSystemStore();

    const [newUsername, setNewUsername] = useState('');
    const [newPort, setNewPort] = useState('');
    const [deploying, setDeploying] = useState(false);
    const [purgeConfirm, setPurgeConfirm] = useState(0);

    useEffect(() => {
        fetchTenants();
        fetchDaemons();
        fetchNodes();

        const interval = setInterval(() => {
            fetchTenants();
            fetchDaemons();
            fetchNodes();
        }, 15000);

        return () => clearInterval(interval);
    }, []);

    const handleDeploy = async (e) => {
        e.preventDefault();
        if (!newUsername || !newPort) return;
        setDeploying(true);
        await deployTenant(newUsername, parseInt(newPort), 'standard');
        setNewUsername('');
        setNewPort('');
        setDeploying(false);
    };

    const executeNuclearPurge = () => {
        if (purgeConfirm < 2) {
            setPurgeConfirm(purgeConfirm + 1);
            return;
        }
        console.warn("CRITICAL: NUCLEAR PURGE INITIATED");
        // TODO: Link to store.nuclearPurge()
        alert("SYSTEM DATA PURGE COMMAND SENT (Simulated)");
        setPurgeConfirm(0);
    };

    return (
        <div className="p-8 h-full bg-[#05080a] text-gray-300 font-mono overflow-y-auto scrollbar-refined relative select-none">
            {/* HUD HEADER */}
            <header className="flex justify-between items-center mb-10 pb-6 border-b border-gray-800/50">
                <div className="relative">
                    <h1 className="text-3xl font-black neon-text flex items-center gap-4 tracking-tighter">
                        <Activity className="animate-pulse" size={32} />
                        SRE ORCHESTRATOR
                    </h1>
                    <p className="text-[10px] text-gray-500 mt-2 uppercase tracking-[0.3em] font-bold">
                        <span className="text-cyan-500/50">SYSTEM_ROOT:</span> /AEGIS/CORE/ORCHESTRATOR
                    </p>
                </div>

                <div className="flex gap-8 items-center bg-gray-900/40 p-4 rounded-xl border border-white/5 backdrop-blur-sm">
                    <div className="px-4 border-r border-white/10">
                        <p className="text-[9px] text-gray-500 uppercase font-black mb-1">Health Status</p>
                        <p className={`text-sm font-bold flex items-center gap-2 ${health === 'GREEN' ? 'text-green-400' : 'text-yellow-400'}`}>
                            <span className={`w-2 h-2 rounded-full ${health === 'GREEN' ? 'bg-green-400 animate-ping' : 'bg-yellow-400'}`}></span>
                            {health || 'STABLE'}
                        </p>
                    </div>
                    <div className="px-4 border-r border-white/10">
                        <p className="text-[9px] text-gray-500 uppercase font-black mb-1">Active Mesh</p>
                        <p className="text-sm font-bold text-purple-400 flex items-center gap-2">
                            <Network size={14} /> {nodes.length} NODES
                        </p>
                    </div>
                    <div className="px-4">
                        <p className="text-[9px] text-gray-500 uppercase font-black mb-1">Compute Load</p>
                        <p className="text-sm font-bold text-cyan-400">Low Latency</p>
                    </div>
                </div>
            </header>

            <div className="grid grid-cols-12 gap-8">

                {/* SECTION A: USER FACTORY */}
                <div className="col-span-12 xl:col-span-8 flex flex-col gap-8">
                    <section className="glass-panel overflow-hidden transition-all hover:border-cyan-500/20 shadow-cyan-900/20">
                        <div className="px-6 py-4 bg-white/5 border-b border-white/10 flex justify-between items-center">
                            <h2 className="flex items-center gap-3 text-sm font-black text-cyan-400 uppercase tracking-widest">
                                <Users size={18} /> User Factory / Tenants
                            </h2>
                            <div className="flex gap-2">
                                <div className="px-2 py-1 bg-cyan-500/10 border border-cyan-500/20 rounded text-[10px] font-bold text-cyan-400">
                                    {tenants.length} ACTIVE
                                </div>
                            </div>
                        </div>

                        {/* DEPLOY INTERFACE */}
                        <div className="p-6 bg-cyan-900/5 border-b border-white/5">
                            <form onSubmit={handleDeploy} className="flex flex-wrap md:flex-nowrap gap-6 items-end">
                                <div className="flex-1 space-y-2">
                                    <span className="text-[9px] text-cyan-500/70 font-black uppercase flex items-center gap-1">
                                        <Terminal size={10} /> Tenant Identifier
                                    </span>
                                    <input
                                        type="text"
                                        value={newUsername}
                                        onChange={(e) => setNewUsername(e.target.value)}
                                        placeholder="e.g. sigma_bunker"
                                        className="w-full bg-black/60 border border-white/10 rounded-lg px-4 py-3 text-sm font-mono text-cyan-300 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500/20 transition-all placeholder:text-gray-700"
                                    />
                                </div>
                                <div className="w-full md:w-32 space-y-2">
                                    <span className="text-[9px] text-cyan-500/70 font-black uppercase flex items-center gap-1">
                                        <Network size={10} /> Tunnel Port
                                    </span>
                                    <input
                                        type="number"
                                        value={newPort}
                                        onChange={(e) => setNewPort(e.target.value)}
                                        placeholder="8001"
                                        className="w-full bg-black/60 border border-white/10 rounded-lg px-4 py-3 text-sm font-mono text-cyan-300 focus:outline-none focus:border-cyan-500 transition-all"
                                    />
                                </div>
                                <button
                                    disabled={deploying}
                                    className="w-full md:w-auto bg-cyan-600 hover:bg-cyan-400 text-black px-8 py-3 rounded-lg text-xs font-black flex items-center justify-center gap-2 transition-all active:scale-95 disabled:grayscale"
                                >
                                    {deploying ? <RefreshCcw className="animate-spin" size={16} /> : <Plus size={16} strokeWidth={3} />}
                                    BOOT TENANT
                                </button>
                            </form>
                        </div>

                        {/* TENANTS DATASTREAM */}
                        <div className="overflow-x-auto">
                            <table className="w-full text-left">
                                <thead className="text-[10px] text-gray-600 uppercase font-black bg-black/20">
                                    <tr>
                                        <th className="px-8 py-4 tracking-[0.2em]">Subject Node</th>
                                        <th className="px-8 py-4 tracking-[0.2em]">Bridge</th>
                                        <th className="px-8 py-4 tracking-[0.2em]">Life-Sign</th>
                                        <th className="px-8 py-4 tracking-[0.2em] text-right">Ops</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-white/5">
                                    {tenants.map((t) => (
                                        <tr key={t.username} className="hover:bg-cyan-500/5 transition-colors group">
                                            <td className="px-8 py-6">
                                                <div className="flex items-center gap-3">
                                                    <div className="w-8 h-8 rounded bg-cyan-900/30 flex items-center justify-center text-cyan-400 font-black text-xs border border-cyan-500/20">
                                                        {t.username[0].toUpperCase()}
                                                    </div>
                                                    <span className="font-bold text-gray-200 group-hover:text-cyan-400 transition-colors uppercase tracking-tight">{t.username}</span>
                                                </div>
                                            </td>
                                            <td className="px-8 py-6">
                                                <code className="bg-gray-900 text-cyan-500/60 px-2 py-1 rounded text-xs border border-white/5">
                                                    TCP:{t.port || 'LISTENING'}
                                                </code>
                                            </td>
                                            <td className="px-8 py-6">
                                                <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-[9px] font-black tracking-widest border ${t.status === 'RUNNING'
                                                        ? 'bg-green-500/10 text-green-400 border-green-500/20'
                                                        : 'bg-red-500/10 text-red-400 border-red-500/20'
                                                    }`}>
                                                    <div className={`w-1.5 h-1.5 rounded-full ${t.status === 'RUNNING' ? 'bg-green-400 animate-pulse' : 'bg-red-500'}`}></div>
                                                    {t.status}
                                                </div>
                                            </td>
                                            <td className="px-8 py-6 text-right">
                                                <div className="flex justify-end gap-3 opacity-60 group-hover:opacity-100 transition-opacity">
                                                    {t.status === 'STOPPED' ? (
                                                        <button onClick={() => startTenant(t.username)} className="p-2 hover:bg-green-500/20 text-green-400 rounded-lg transition-all" title="Startup">
                                                            <Play size={18} fill="currentColor" />
                                                        </button>
                                                    ) : (
                                                        <button onClick={() => stopTenant(t.username)} className="p-2 hover:bg-yellow-500/20 text-yellow-500 rounded-lg transition-all" title="Sigterm">
                                                            <Square size={18} fill="currentColor" />
                                                        </button>
                                                    )}
                                                    <button onClick={() => deleteTenant(t.username)} className="p-2 hover:bg-red-500/20 text-red-500 rounded-lg transition-all" title="Deallocate">
                                                        <Trash2 size={18} />
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    ))}
                                    {tenants.length === 0 && (
                                        <tr>
                                            <td colSpan="4" className="px-8 py-20 text-center text-gray-600 text-[10px] uppercase font-bold tracking-widest italic">
                                                Empty Sector: No tenants detected in the neural field.
                                            </td>
                                        </tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </section>
                </div>

                {/* SIDE PANELS */}
                <aside className="col-span-12 xl:col-span-4 flex flex-col gap-8">

                    {/* SECTION B: BACKGROUND DAEMONS */}
                    <section className="glass-panel group">
                        <div className="px-6 py-4 border-b border-white/5 flex justify-between items-center group-hover:bg-white/5 transition-all">
                            <h2 className="text-sm font-black text-amber-500 uppercase flex items-center gap-3">
                                <Cpu size={18} /> System Daemons
                            </h2>
                            <Activity size={14} className="text-gray-700 group-hover:text-amber-500/50" />
                        </div>
                        <div className="p-6 grid gap-4">
                            {daemons.map((d) => (
                                <div key={d.name} className="flex justify-between items-center p-4 bg-white/2 border border-white/5 rounded-xl hover:bg-white/5 hover:border-white/10 transition-all">
                                    <div className="flex items-center gap-4">
                                        <div className={`p-2 rounded-lg ${d.status === 'RUNNING' ? 'bg-green-500/10 text-green-400' : 'bg-red-500/10 text-red-500'}`}>
                                            <Power size={16} className={d.status === 'RUNNING' ? 'animate-pulse' : ''} />
                                        </div>
                                        <div>
                                            <p className="text-xs font-black text-gray-200 uppercase tracking-tight">{d.name}</p>
                                            <p className={`text-[8px] font-bold uppercase tracking-widest ${d.status === 'RUNNING' ? 'text-green-500' : 'text-gray-600'}`}>{d.status}</p>
                                        </div>
                                    </div>
                                    <button
                                        onClick={() => toggleDaemon(d.name)}
                                        className={`px-3 py-1.5 rounded-lg text-[9px] font-black transition-all border ${d.status === 'RUNNING'
                                                ? 'border-red-500/30 text-red-400 hover:bg-red-500/20'
                                                : 'border-green-500/30 text-green-400 hover:bg-green-500/20'
                                            }`}
                                    >
                                        {d.status === 'RUNNING' ? 'KILL' : 'EXEC'}
                                    </button>
                                </div>
                            ))}
                        </div>
                    </section>

                    {/* SECTION C: NEURAL MESH & OPT-OUT */}
                    <section className="glass-panel relative overflow-hidden border-purple-500/10">
                        <div className="px-6 py-4 border-b border-white/5">
                            <h2 className="text-sm font-black text-purple-400 uppercase flex items-center gap-3">
                                <Network size={18} /> Neural Mesh
                            </h2>
                        </div>
                        <div className="p-6 space-y-6">
                            <div className="space-y-3">
                                {nodes.length > 0 ? nodes.map((n, i) => (
                                    <div key={n.id || i} className="flex items-center justify-between p-3 bg-purple-500/5 border border-purple-500/10 rounded-lg text-[10px]">
                                        <div className="flex items-center gap-2">
                                            <div className="w-1.5 h-1.5 bg-purple-400 rounded-full"></div>
                                            <span className="text-purple-300 font-bold uppercase tracking-tighter">Limb_{n.id?.slice(0, 6) || 'LOCAL'}</span>
                                        </div>
                                        <span className="text-gray-500 font-mono">OK / 24ms</span>
                                    </div>
                                )) : (
                                    <div className="text-center py-4 text-gray-600 text-[10px] font-bold uppercase flex flex-col items-center gap-2">
                                        <Unplug size={24} className="opacity-20" />
                                        Isolated Instance
                                    </div>
                                )}
                            </div>

                            <div className="pt-6 border-t border-white/5">
                                <button
                                    onClick={executeNuclearPurge}
                                    className={`w-full py-4 rounded-xl text-xs font-black transition-all group relative overflow-hidden flex items-center justify-center gap-3 border shadow-lg
                    ${purgeConfirm === 0 ? 'bg-red-950/20 text-red-600 border-red-900/50 hover:bg-red-900/40 hover:text-red-400' :
                                            purgeConfirm === 1 ? 'bg-orange-600 text-white border-orange-400 animate-pulse' :
                                                'bg-red-600 text-white border-red-400 shadow-[0_0_20px_rgba(239,68,68,0.4)]'}`}
                                >
                                    <ShieldAlert size={18} className={purgeConfirm > 0 ? 'animate-bounce' : ''} />
                                    {purgeConfirm === 0 && "INIT NUCLEAR PURGE"}
                                    {purgeConfirm === 1 && "CRITICAL: RE-CONFIRM"}
                                    {purgeConfirm === 2 && "EXECUTING DESTRUCTION..."}

                                    {purgeConfirm === 0 && (
                                        <div className="absolute inset-0 bg-red-500/5 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700 skew-x-[-20deg]"></div>
                                    )}
                                </button>
                                <p className="text-[8px] text-gray-700 text-center mt-3 uppercase tracking-widest font-bold">Protocol Breach // DB Wipe</p>
                            </div>
                        </div>

                        {/* Background decoration */}
                        <Database size={100} className="absolute -bottom-10 -right-10 text-white/2 pointer-events-none" />
                    </section>

                    <div className="crystal-blur p-4 rounded-xl flex items-center justify-between border-l-4 border-cyan-500">
                        <div className="flex items-center gap-3">
                            <ShieldAlert size={16} className="text-cyan-500" />
                            <span className="text-[10px] text-gray-400 font-black uppercase tracking-widest">Aegis Integrity</span>
                        </div>
                        <span className="text-[10px] text-cyan-400 font-bold">STABLE</span>
                    </div>

                </aside>
            </div>

            {/* TERMINAL OVERLAY EFFECT */}
            <div className="fixed inset-0 pointer-events-none opacity-[0.02] bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] z-[100] bg-[length:100%_2px,3px_100%]"></div>
        </div>
    );
};

export default AdminOrchestrator;
