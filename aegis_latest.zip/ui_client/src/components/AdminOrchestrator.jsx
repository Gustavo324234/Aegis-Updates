import React, { useState, useEffect, useMemo } from 'react';
import useSystemStore from '../store/useSystemStore';
import {
    Users,
    Cpu,
    Network,
    Trash2,
    Play,
    Square,
    Plus,
    ShieldAlert,
    Database,
    Activity,
    UserPlus,
    RefreshCcw,
    Power,
    Terminal,
    Unplug,
    ExternalLink,
    Search,
    Command,
    Zap
} from 'lucide-react';

const AdminOrchestrator = () => {
    const {
        tenants,
        daemons,
        nodes,
        health,
        fetchTenants,
        deployTenant,
        startTenant,
        stopTenant,
        deleteTenant,
        fetchDaemons,
        toggleDaemon,
        fetchNodes
    } = useSystemStore();

    const [newUsername, setNewUsername] = useState('');
    const [newPort, setNewPort] = useState('');
    const [deploying, setDeploying] = useState(false);
    const [purgeConfirm, setPurgeConfirm] = useState(0);
    const [searchQuery, setSearchQuery] = useState('');

    // Fetch initial data
    useEffect(() => {
        fetchTenants();
        fetchDaemons();
        fetchNodes();

        const interval = setInterval(() => {
            fetchTenants();
            fetchDaemons();
            fetchNodes();
        }, 10000);

        return () => clearInterval(interval);
    }, [fetchTenants, fetchDaemons, fetchNodes]);

    // Auto-calculate next port
    useEffect(() => {
        if (!newPort || newPort === '') {
            const ports = tenants.map(t => parseInt(t.port)).filter(p => !isNaN(p));
            const nextPort = ports.length > 0 ? Math.max(...ports) + 1 : 8001;
            setNewPort(Math.max(8001, nextPort).toString());
        }
    }, [tenants]);

    const handleDeploy = async (e) => {
        e.preventDefault();
        if (!newUsername || !newPort) return;
        setDeploying(true);
        const result = await deployTenant(newUsername.trim().toLowerCase(), parseInt(newPort), 'reactor');
        if (result.status === 'success') {
            setNewUsername('');
            setNewPort('');
        }
        setDeploying(false);
    };

    const executeNuclearPurge = () => {
        if (purgeConfirm < 2) {
            setPurgeConfirm(purgeConfirm + 1);
            return;
        }
        console.warn("CRITICAL: NUCLEAR PURGE INITIATED");
        alert("SYSTEM DATA PURGE COMMAND SENT (Simulated in this view)");
        setPurgeConfirm(0);
    };

    const filteredTenants = useMemo(() => {
        return tenants.filter(t =>
            t.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
            t.port.toString().includes(searchQuery)
        );
    }, [tenants, searchQuery]);

    return (
        <div className="p-8 h-full bg-[#05080a] text-gray-300 font-mono overflow-y-auto scrollbar-refined relative select-none">
            {/* HUD HEADER */}
            <header className="flex justify-between items-center mb-10 pb-6 border-b border-gray-800/50">
                <div className="relative">
                    <div className="flex items-center gap-3">
                        <div className="p-2 bg-cyan-500/10 rounded-lg border border-cyan-500/20">
                            <Activity className="animate-pulse text-cyan-400" size={24} />
                        </div>
                        <div>
                            <h1 className="text-3xl font-black neon-text tracking-tighter uppercase">
                                SRE Orchestrator
                            </h1>
                            <p className="text-[10px] text-gray-500 uppercase tracking-[0.3em] font-bold">
                                <span className="text-cyan-500/50">Root_Access:</span> /AEGIS/CORE/USER_FACTORY
                            </p>
                        </div>
                    </div>
                </div>

                <div className="flex gap-8 items-center bg-gray-900/40 p-4 rounded-xl border border-white/5 backdrop-blur-sm">
                    <div className="px-4 border-r border-white/10">
                        <p className="text-[9px] text-gray-500 uppercase font-black mb-1">Health Status</p>
                        <p className={`text-sm font-bold flex items-center gap-2 ${health === 'GREEN' ? 'text-green-400' : 'text-yellow-400'}`}>
                            <span className={`w-2 h-2 rounded-full ${health === 'GREEN' ? 'bg-green-400 animate-pulse' : 'bg-yellow-400'}`}></span>
                            {health || 'OPTIMAL'}
                        </p>
                    </div>
                    <div className="px-4 border-r border-white/10">
                        <p className="text-[9px] text-gray-500 uppercase font-black mb-1">Active Mesh</p>
                        <p className="text-sm font-bold text-purple-400 flex items-center gap-2">
                            <Network size={14} /> {nodes.length} NODES
                        </p>
                    </div>
                    <div className="px-4">
                        <p className="text-[9px] text-gray-500 uppercase font-black mb-1">User Factory</p>
                        <p className="text-sm font-bold text-cyan-400 flex items-center gap-2">
                            <Users size={14} /> {tenants.length} INSTANCES
                        </p>
                    </div>
                </div>
            </header>

            <div className="grid grid-cols-12 gap-8">

                {/* SECTION A: USER FACTORY (Main Area) */}
                <div className="col-span-12 xl:col-span-8 flex flex-col gap-8">

                    {/* NEW DEPLOYMENT PANEL */}
                    <section className="glass-panel overflow-hidden border-cyan-500/20 bg-cyan-900/5">
                        <div className="px-6 py-4 bg-white/5 border-b border-white/10 flex justify-between items-center">
                            <h2 className="flex items-center gap-3 text-sm font-black text-cyan-400 uppercase tracking-widest">
                                <UserPlus size={18} /> New Instance Deployment
                            </h2>
                            <span className="text-[9px] text-cyan-500/50 font-bold uppercase">Ready for allocation</span>
                        </div>
                        <div className="p-6">
                            <form onSubmit={handleDeploy} className="flex flex-wrap md:flex-nowrap gap-6 items-end">
                                <div className="flex-1 space-y-2">
                                    <label className="text-[9px] text-cyan-500/70 font-black uppercase flex items-center gap-1">
                                        <Terminal size={10} /> Username (Tenant ID)
                                    </label>
                                    <input
                                        type="text"
                                        required
                                        value={newUsername}
                                        onChange={(e) => setNewUsername(e.target.value)}
                                        placeholder="e.g. client_x_bunker"
                                        className="w-full bg-black/60 border border-white/10 rounded-lg px-4 py-3 text-sm font-mono text-cyan-300 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500/20 transition-all placeholder:text-gray-700"
                                    />
                                </div>
                                <div className="w-full md:w-40 space-y-2">
                                    <label className="text-[9px] text-cyan-500/70 font-black uppercase flex items-center gap-1">
                                        <Network size={10} /> Assigned Port
                                    </label>
                                    <input
                                        type="number"
                                        required
                                        min="1024"
                                        max="65535"
                                        value={newPort}
                                        onChange={(e) => setNewPort(e.target.value)}
                                        placeholder="8001"
                                        className="w-full bg-black/60 border border-white/10 rounded-lg px-4 py-3 text-sm font-mono text-cyan-300 focus:outline-none focus:border-cyan-500 transition-all"
                                    />
                                </div>
                                <button
                                    disabled={deploying}
                                    className="w-full md:w-auto bg-cyan-600 hover:bg-cyan-500 text-black px-8 py-3 rounded-lg text-xs font-black flex items-center justify-center gap-2 transition-all active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed group"
                                >
                                    {deploying ? (
                                        <RefreshCcw className="animate-spin" size={16} />
                                    ) : (
                                        <Zap className="group-hover:animate-bounce" size={16} fill="currentColor" />
                                    )}
                                    🚀 DESPLEGAR INSTANCIA
                                </button>
                            </form>
                        </div>
                    </section>

                    {/* ACTIVE USERS TABLE */}
                    <section className="glass-panel overflow-hidden transition-all hover:border-gray-700">
                        <div className="px-6 py-4 bg-white/5 border-b border-white/10 flex justify-between items-center">
                            <h2 className="flex items-center gap-3 text-sm font-black text-gray-400 uppercase tracking-widest">
                                <Users size={18} /> Managed Instances
                            </h2>
                            <div className="relative">
                                <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-600" />
                                <input
                                    type="text"
                                    value={searchQuery}
                                    onChange={(e) => setSearchQuery(e.target.value)}
                                    placeholder="Filter by ID/Port..."
                                    className="bg-black/40 border border-white/5 rounded-full pl-9 pr-4 py-1.5 text-[10px] focus:outline-none focus:border-cyan-500/50 transition-all"
                                />
                            </div>
                        </div>

                        <div className="overflow-x-auto">
                            <table className="w-full text-left">
                                <thead className="text-[10px] text-gray-600 uppercase font-black bg-black/20">
                                    <tr>
                                        <th className="px-8 py-4 tracking-[0.2em]">Tenant Identifier</th>
                                        <th className="px-8 py-4 tracking-[0.2em]">Access Point</th>
                                        <th className="px-8 py-4 tracking-[0.2em]">Life-Sign</th>
                                        <th className="px-8 py-4 tracking-[0.2em] text-right">Operations</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-white/5 font-mono">
                                    {filteredTenants.map((t) => (
                                        <tr key={t.username} className="hover:bg-cyan-500/5 transition-colors group">
                                            <td className="px-8 py-6">
                                                <div className="flex items-center gap-3">
                                                    <div className="w-10 h-10 rounded-lg bg-cyan-900/20 flex items-center justify-center text-cyan-400 font-black text-sm border border-cyan-500/20 shadow-inner">
                                                        {t.username[0].toUpperCase()}
                                                    </div>
                                                    <div>
                                                        <span className="font-bold text-gray-200 group-hover:text-cyan-400 transition-colors uppercase block">
                                                            {t.username}
                                                        </span>
                                                        <span className="text-[8px] text-gray-600 uppercase font-black">ID: AEGIS-{Math.random().toString(36).substr(2, 6).toUpperCase()}</span>
                                                    </div>
                                                </div>
                                            </td>
                                            <td className="px-8 py-6">
                                                <a
                                                    href={`http://${window.location.hostname}:${t.port}`}
                                                    target="_blank"
                                                    rel="noopener noreferrer"
                                                    className="inline-flex items-center gap-2 bg-gray-900 hover:bg-black text-cyan-500 px-3 py-1.5 rounded text-[11px] border border-white/5 transition-all group/link"
                                                >
                                                    <ExternalLink size={12} className="group-hover/link:translate-x-0.5 group-hover/link:-translate-y-0.5 transition-transform" />
                                                    {window.location.hostname}:{t.port}
                                                </a>
                                            </td>
                                            <td className="px-8 py-6">
                                                <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-[9px] font-black tracking-widest border ${t.status === 'RUNNING'
                                                    ? 'bg-green-500/10 text-green-400 border-green-500/20'
                                                    : 'bg-red-500/10 text-red-500 border-red-500/20'
                                                    }`}>
                                                    <span className={`w-1.5 h-1.5 rounded-full ${t.status === 'RUNNING' ? 'bg-green-400 animate-pulse' : 'bg-red-500'}`}></span>
                                                    {t.status === 'RUNNING' ? 'ONLINE' : 'OFFLINE'}
                                                </div>
                                            </td>
                                            <td className="px-8 py-6 text-right">
                                                <div className="flex justify-end gap-2 opacity-60 group-hover:opacity-100 transition-all transform translate-x-2 group-hover:translate-x-0">
                                                    {t.status === 'STOPPED' ? (
                                                        <button
                                                            onClick={() => startTenant(t.username)}
                                                            className="flex items-center gap-1.5 px-3 py-1.5 bg-green-500/10 hover:bg-green-500/20 text-green-400 rounded-lg text-[9px] font-black transition-all border border-green-500/20"
                                                            title="Iniciar Instancia"
                                                        >
                                                            <Play size={14} fill="currentColor" /> INICIAR ▶️
                                                        </button>
                                                    ) : (
                                                        <button
                                                            onClick={() => stopTenant(t.username)}
                                                            className="flex items-center gap-1.5 px-3 py-1.5 bg-yellow-500/10 hover:bg-yellow-500/20 text-yellow-500 rounded-lg text-[9px] font-black transition-all border border-yellow-500/20"
                                                            title="Parar Instancia"
                                                        >
                                                            <Square size={14} fill="currentColor" /> PARAR ⏹️
                                                        </button>
                                                    )}
                                                    <button
                                                        onClick={() => deleteTenant(t.username)}
                                                        className="flex items-center gap-1.5 px-3 py-1.5 bg-red-500/10 hover:bg-red-500/20 text-red-500 rounded-lg text-[9px] font-black transition-all border border-red-500/20"
                                                        title="Eliminar permanentemente"
                                                    >
                                                        <Trash2 size={14} /> PURGAR 🗑️
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    ))}
                                    {filteredTenants.length === 0 && (
                                        <tr>
                                            <td colSpan="4" className="px-8 py-20 text-center text-gray-600 text-[10px] uppercase font-bold tracking-widest italic">
                                                <div className="flex flex-col items-center gap-4">
                                                    <Unplug size={40} className="text-gray-800" />
                                                    <span>No active instances detected in this sector.</span>
                                                </div>
                                            </td>
                                        </tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                        <div className="px-6 py-3 bg-white/2 border-t border-white/5 flex justify-between items-center text-[9px] font-black text-gray-600 uppercase">
                            <span>Sector A-1 / Subnet Mask: 255.255.255.0</span>
                            <span className="flex items-center gap-2">
                                <Activity size={10} /> Live Telemetry Feed
                            </span>
                        </div>
                    </section>
                </div>

                {/* SIDE PANELS (Daemons & Mesh) */}
                <aside className="col-span-12 xl:col-span-4 flex flex-col gap-8">

                    {/* SECTION: ACTIVE DAEMONS */}
                    <section className="glass-panel group border-amber-500/10">
                        <div className="px-6 py-4 border-b border-white/5 flex justify-between items-center group-hover:bg-white/5 transition-all">
                            <h2 className="text-sm font-black text-amber-500 uppercase flex items-center gap-3">
                                <Cpu size={18} /> Active Daemons
                            </h2>
                            <RefreshCcw size={14} className="text-gray-700 animate-spin-slow" />
                        </div>
                        <div className="p-6 grid gap-4">
                            {daemons.map((d) => (
                                <div key={d.name} className="flex justify-between items-center p-4 bg-white/2 border border-white/5 rounded-xl hover:bg-white/5 hover:border-white/10 transition-all group/daemon">
                                    <div className="flex items-center gap-4">
                                        <div className={`p-2 rounded-lg ${d.status === 'RUNNING' ? 'bg-green-500/10 text-green-400 shadow-[0_0_10px_rgba(74,222,128,0.1)]' : 'bg-red-500/10 text-red-500'}`}>
                                            <Power size={16} className={d.status === 'RUNNING' ? 'animate-pulse' : ''} />
                                        </div>
                                        <div>
                                            <p className="text-xs font-black text-gray-200 uppercase tracking-tight group-hover/daemon:text-amber-400 transition-colors">{d.name}</p>
                                            <p className={`text-[8px] font-bold uppercase tracking-widest ${d.status === 'RUNNING' ? 'text-green-500' : 'text-gray-600'}`}>
                                                {d.status === 'RUNNING' ? 'EXECUTING' : 'IDLE'}
                                            </p>
                                        </div>
                                    </div>
                                    <button
                                        onClick={() => toggleDaemon(d.name)}
                                        className={`px-3 py-1.5 rounded-lg text-[9px] font-black transition-all border ${d.status === 'RUNNING'
                                            ? 'border-red-500/30 text-red-400 hover:bg-red-500/20'
                                            : 'border-green-500/30 text-green-400 hover:bg-green-500/20'
                                            }`}
                                    >
                                        {d.status === 'RUNNING' ? 'HALT' : 'INIT'}
                                    </button>
                                </div>
                            ))}
                        </div>
                    </section>

                    {/* SECTION: NETWORK MESH & CONTROL */}
                    <section className="glass-panel relative overflow-hidden border-purple-500/10">
                        <div className="px-6 py-4 border-b border-white/5 flex justify-between items-center">
                            <h2 className="text-sm font-black text-purple-400 uppercase flex items-center gap-3">
                                <Network size={18} /> Network Mesh
                            </h2>
                            <div className="flex h-2 w-2">
                                <span className="animate-ping absolute inline-flex h-2 w-2 rounded-full bg-purple-400 opacity-75"></span>
                                <span className="relative inline-flex rounded-full h-2 w-2 bg-purple-500"></span>
                            </div>
                        </div>
                        <div className="p-6 space-y-6">
                            <div className="space-y-3">
                                {nodes.length > 0 ? nodes.map((n, i) => (
                                    <div key={n.id || i} className="flex items-center justify-between p-3 bg-purple-500/5 border border-purple-500/10 rounded-lg text-[10px] group/node transition-all hover:bg-purple-500/10">
                                        <div className="flex items-center gap-2">
                                            <div className="w-1.5 h-1.5 bg-purple-400 rounded-full group-hover/node:bg-cyan-400 transition-colors"></div>
                                            <span className="text-purple-300 font-bold uppercase tracking-tighter">NODE_{n.id?.slice(0, 8) || 'AEGIS_LOCAL'}</span>
                                        </div>
                                        <div className="flex gap-4">
                                            <span className="text-[8px] text-gray-600 font-black uppercase">Lat: 12ms</span>
                                            <span className="text-green-500 font-mono text-[9px]">ENCRYPTED</span>
                                        </div>
                                    </div>
                                )) : (
                                    <div className="text-center py-6 text-gray-600 text-[10px] font-bold uppercase flex flex-col items-center gap-3 border border-dashed border-white/10 rounded-xl">
                                        <Unplug size={24} className="opacity-20 translate-y-1" />
                                        <span>Standalone Architecture</span>
                                    </div>
                                )}
                            </div>

                            {/* CRITICAL ACTIONS */}
                            <div className="pt-6 border-t border-white/5 bg-red-950/5 -mx-6 px-6 pb-6">
                                <div className="flex items-center gap-2 mb-4">
                                    <ShieldAlert size={14} className="text-red-500" />
                                    <span className="text-[9px] font-black text-red-500 uppercase tracking-[0.2em]">Damage Colateral Control</span>
                                </div>
                                <button
                                    onClick={executeNuclearPurge}
                                    className={`w-full py-4 rounded-xl text-[10px] font-black transition-all group relative overflow-hidden flex items-center justify-center gap-3 border shadow-lg uppercase tracking-widest
                                    ${purgeConfirm === 0 ? 'bg-red-950/20 text-red-600 border-red-900/50 hover:bg-red-900/40 hover:text-red-400' :
                                            purgeConfirm === 1 ? 'bg-orange-600 text-white border-orange-400 animate-pulse' :
                                                'bg-red-600 text-white border-red-400 shadow-[0_0_30px_rgba(239,68,68,0.5)]'}`}
                                >
                                    <Command size={18} className={purgeConfirm > 0 ? 'animate-spin-slow' : ''} />
                                    {purgeConfirm === 0 && "Nuclear Purge (DANGER)"}
                                    {purgeConfirm === 1 && "Confirm Protocol Delta"}
                                    {purgeConfirm === 2 && "Executing Wipe..."}

                                    {purgeConfirm === 0 && (
                                        <div className="absolute inset-0 bg-white/5 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000 skew-x-[-20deg]"></div>
                                    )}
                                </button>
                                <p className="text-[7px] text-gray-700 text-center mt-3 uppercase tracking-widest font-bold font-mono">
                                    Auth_Token: xFS-982-Ω // Irreversible Operation
                                </p>
                            </div>
                        </div>

                        {/* Decoration */}
                        <Database size={120} className="absolute -bottom-10 -right-10 text-white/5 pointer-events-none" />
                    </section>
            </div>
        </div>

            {/* CRT OVERLAY EFFECT */ }
    <div className="fixed inset-0 pointer-events-none opacity-[0.03] bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] z-[100] bg-[length:100%_2px,3px_100%]"></div>

    {/* AMBIENT LIGHTING */ }
            <div className="fixed top-0 right-0 w-[500px] h-[500px] bg-cyan-500/5 rounded-full blur-[120px] pointer-events-none -z-10 translate-x-1/2 -translate-y-1/2"></div>
            <div className="fixed bottom-0 left-0 w-[400px] h-[400px] bg-purple-500/5 rounded-full blur-[100px] pointer-events-none -z-10 -translate-x-1/2 translate-y-1/2"></div>
        </div >
    );
};

export default AdminOrchestrator;
