# modules/system_tools.py
import subprocess
import os
import platform
import psutil
import json
from modules.utils import get_user_root

DESCRIPTION = """
Module: system_tools
Purpose: Interact with the underlying OS (Terminal, File System).
Safety: Command execution is sandboxed to the user's workspace.
Actions:
- terminal: Execute shell commands within the workspace.
- sysinfo: Get system stats.
- shutdown: EMERGENCY ONLY. Revoke all and kill system.
Usage format:
    "module": "system_tools", "action": "terminal", "args": {"command": "ls -la"}}
    {"module": "system_tools", "action": "sysinfo", "args": {}}
    {"module": "system_tools", "action": "apply_patch", "args": {"filename": "test.py", "search_block": "def foo():\\n    pass", "replace_block": "def foo():\\n    print('Hello')"}}
    """

SAFE_ROOT = get_user_root()

def execute_command(command):
    try:
        # TERMINAL MIRROR & AUTO-DIAGNOSIS (Phase 12)
        # We capture STDERR separately to allow "auto-diagnosis" in UI
        
        # TIMEOUT PROTECTION: Prevent infinite loops
        # CWD SANDBOX: Force execution in SAFE_ROOT
        result = subprocess.run(
            command, 
            shell=True, 
            capture_output=True, 
            text=True, 
            cwd=SAFE_ROOT, 
            timeout=30
        )
        output = result.stdout
        
        if result.stderr:
            # TERMINAL MIRROR: Tag for UI
            output += f"\n[STDERR_DETECTED]\n{result.stderr}"
            
        return f"Output (in {SAFE_ROOT}):\n{output}"
    except subprocess.TimeoutExpired:
        return "Error: Command timed out (Limit: 30s)."
    except Exception as e:
        return f"Execution Failed: {str(e)}"

def get_system_info():
    try:
        info = {
            "OS": platform.system(),
            "Release": platform.release(),
            "CPU": psutil.cpu_count(),
            "RAM_Total_GB": round(psutil.virtual_memory().total / (1024**3), 2),
            "CWD": SAFE_ROOT  # Report safe root, not necessarily process CWD
        }
        return json.dumps(info, indent=2)
        return f"SysInfo Error: {str(e)}"

def emergency_shutdown(reason="Protocol 0 Invoked"):
    """
    PROTOCOL 0: Final Safety Layer.
    Revokes sessions, kills connections, logs black box event, and exits.
    """
    print(f"🚨 INITIATING EMERGENCY SHUTDOWN: {reason}")
    
    # 1. Black Box Log
    try:
        from modules.utils import get_user_root
        import datetime
        box_path = os.path.join(get_user_root(), ".aegis", "black_box.log")
        with open(box_path, "a") as f:
            f.write(f"[{datetime.datetime.now()}] EMERGENCY SHUTDOWN. Reason: {reason}\n")
    except: pass
    
    # 2. Kill Gateway (Port 8000) - Naive Windows approach
    try:
        if platform.system() == "Windows":
            subprocess.run("taskkill /F /IM uvicorn.exe", shell=True)
            subprocess.run("taskkill /F /IM python.exe", shell=True) # Dangerous but effective
        else:
             subprocess.run("pkill -f uvicorn", shell=True)
             # subprocess.run("pkill -f python", shell=True) 
    except: pass
    
    # 3. Exit Self
    os._exit(1)

def apply_patch(filename, search_block, replace_block):
    """Surgical Editing: Replaces exact block in file."""
    if not filename or not search_block or not replace_block:
        return "Error: Missing arguments for patch."
        
    path = os.path.abspath(os.path.join(SAFE_ROOT, filename))
    if not path.startswith(os.path.abspath(SAFE_ROOT)):
        return "Security Error: Path traversal detected."
        
    if not os.path.exists(path):
         return f"Error: File {filename} not found."
         
    try:
        with open(path, "r", encoding="utf-8") as f:
            content = f.read()
            
        # Normalize line endings
        search_norm = search_block.replace("\r\n", "\n").strip()
        replace_norm = replace_block.replace("\r\n", "\n").strip()
        content_norm = content.replace("\r\n", "\n")
        
        # Exact match check
        if search_norm not in content_norm:
             # Fuzzy fallback? No, surgical must be precise.
             return f"Error: Search block not found in {filename}. Please verify context."
             
        new_content = content_norm.replace(search_norm, replace_norm)
        
        with open(path, "w", encoding="utf-8") as f:
            f.write(new_content)
            
        return f"Patch applied successfully to {filename}."
        
    except Exception as e:
        return f"Patch Failed: {e}"

def execute(query):
    """Entry point for the module."""
    action = query.get("action")
    args = query.get("args", {})
    
    if action == "terminal":
        command = args.get("command")
        if not command: return "Error: Command required."
        
        # Block dangerous commands
        blacklist = ["rm -rf /", ":(){ :|:& };:", "wget http", "curl http", "nc -e"]
        if any(b in command for b in blacklist):
            return "Security Alert: Command blocked by Aegis Firewall."
            
        return execute_command(command)
    
    elif action == "apply_patch":
        return apply_patch(
            args.get("filename"), 
            args.get("search_block"), 
            args.get("replace_block")
        )

    elif action == "sysinfo":
        return get_system_info()
        
    elif action == "shutdown":
        args = query.get("args", {})
        confirmation = args.get("confirmation")
        if confirmation == "PROTOCOL_0_CONFIRMED":
             emergency_shutdown(args.get("reason", "Manual Invoke"))
        return "Error: Protocol 0 requires confirmation code."
    
    return f"Error: Unknown action '{action}' in system_tools."
