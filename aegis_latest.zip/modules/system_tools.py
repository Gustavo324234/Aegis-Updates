# modules/system_tools.py
import subprocess
import os
import platform
import psutil
import json

DESCRIPTION = """
Use this module to interact with the underlying operating system.
Commands must be sent as a JSON object with the following structure:
{
    "module": "system_tools",
    "action": "terminal" | "file" | "sysinfo",
    "command": "terminal_command" (only for action='terminal'),
    "operation": "read" | "write" | "delete" (only for action='file'),
    "path": "/path/to/file" (only for action='file'),
    "content": "text content" (optional, for action='file' write)
}
"""

def execute_command(command):
    try:
        result = subprocess.run(command, shell=True, capture_output=True, text=True)
        return f"Output:\n{result.stdout}\nError:\n{result.stderr}"
    except Exception as e:
        return f"Execution Failed: {str(e)}"

def manage_files(action, path, content=None):
    try:
        if action == "read":
            if os.path.exists(path):
                with open(path, 'r', encoding='utf-8') as f:
                    return f.read()
            return "Error: File not found."
        elif action == "write":
            os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
            with open(path, 'w', encoding='utf-8') as f:
                f.write(content or "")
            return f"Success: Written to {path}"
        elif action == "delete":
            if os.path.exists(path):
                os.remove(path)
                return f"Success: Deleted {path}"
            return "Error: File not found."
        return "Unknown file operation."
    except Exception as e:
        return f"File Error: {str(e)}"

def get_system_info():
    try:
        info = {
            "OS": platform.system(),
            "Release": platform.release(),
            "CPU": psutil.cpu_count(),
            "RAM_Total_GB": round(psutil.virtual_memory().total / (1024**3), 2),
            "CWD": os.getcwd()
        }
        return json.dumps(info, indent=2)
    except Exception as e:
        return f"SysInfo Error: {str(e)}"

def execute(query):
    """Entry point for the module."""
    if isinstance(query, str):
        try:
            query = json.loads(query)
        except:
            return "Error: Query must be valid JSON."
            
    action = query.get("action")
    
    if action == "terminal":
        return execute_command(query.get("command", ""))
    elif action == "file":
        return manage_files(
            query.get("operation"), 
            query.get("path"), 
            query.get("content")
        )
    elif action == "sysinfo":
        return get_system_info()
    
    return "Error: Unknown action in system_tools."
