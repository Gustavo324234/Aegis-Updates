# modules/system_tools.py
import subprocess
import os
import platform
import psutil
import json
from modules.utils import get_user_root

DESCRIPTION = """
Module: system_tools
Purpose: Interact with the underlying OS (Terminal, File System).
Safety: Command execution is sandboxed to the user's workspace.
Actions:
- terminal: Execute shell commands within the workspace.
- sysinfo: Get system stats.
Usage format:
{"module": "system_tools", "action": "terminal", "args": {"command": "ls -la"}}
{"module": "system_tools", "action": "sysinfo", "args": {}}
"""

SAFE_ROOT = get_user_root()

def execute_command(command):
    try:
        # TIMEOUT PROTECTION: Prevent infinite loops
        # CWD SANDBOX: Force execution in SAFE_ROOT
        result = subprocess.run(
            command, 
            shell=True, 
            capture_output=True, 
            text=True, 
            cwd=SAFE_ROOT, 
            timeout=30
        )
        output = result.stdout
        if result.stderr:
            output += f"\nSTDERR:\n{result.stderr}"
        return f"Output (in {SAFE_ROOT}):\n{output}"
    except subprocess.TimeoutExpired:
        return "Error: Command timed out (Limit: 30s)."
    except Exception as e:
        return f"Execution Failed: {str(e)}"

def get_system_info():
    try:
        info = {
            "OS": platform.system(),
            "Release": platform.release(),
            "CPU": psutil.cpu_count(),
            "RAM_Total_GB": round(psutil.virtual_memory().total / (1024**3), 2),
            "CWD": SAFE_ROOT  # Report safe root, not necessarily process CWD
        }
        return json.dumps(info, indent=2)
    except Exception as e:
        return f"SysInfo Error: {str(e)}"

def execute(query):
    """Entry point for the module."""
    action = query.get("action")
    args = query.get("args", {})
    
    if action == "terminal":
        command = args.get("command")
        if not command: return "Error: Command required."
        
        # Block dangerous commands
        blacklist = ["rm -rf /", ":(){ :|:& };:", "wget http", "curl http", "nc -e"]
        if any(b in command for b in blacklist):
            return "Security Alert: Command blocked by Aegis Firewall."
            
        return execute_command(command)

    elif action == "sysinfo":
        return get_system_info()
    
    return f"Error: Unknown action '{action}' in system_tools."
