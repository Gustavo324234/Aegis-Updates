# modules/system_tools.py
# Fix Applied: 2026-02-21 (Auto-Detach & Hybrid Logic)
import subprocess
import os
import platform
import psutil
import json
import threading
import uuid
import time
import database
from modules.utils import get_user_root

DESCRIPTION = """
Module: system_tools
Purpose: Interact with the underlying OS (Terminal, File System).
Safety: Command execution is sandboxed to the user's workspace.
Actions:
- terminal: Execute shell commands. Commands longer than 3s auto-detach to background.
- poll_process: Check progress of a background Job ID. Args: {"job_id": "..."}
- sysinfo: Get system stats.
- shutdown: EMERGENCY ONLY.
Usage format:
    {"module": "system_tools", "action": "terminal", "args": {"command": "npm install"}}
    {"module": "system_tools", "action": "poll_process", "args": {"job_id": "abc12345"}}
"""

SAFE_ROOT = get_user_root()
ACTIVE_JOBS = {}


def execute_command(
    command, allow_background=True, yield_window=3.0, stream_callback=None
):
    """
    Executes a command with a short wait window.
    If it exceeds yield_window, it detachs and returns a Job ID.
    Routes through DockerSandbox if Docker is available.
    """
    job_id = str(uuid.uuid4())[:8]

    try:
        from modules.docker_sandbox import DockerSandbox

        try:
            sandbox = DockerSandbox(SAFE_ROOT)
            if sandbox.is_docker_available():
                final_command = sandbox.wrap_command(command)
                shell_flag = False
                sandbox_active = True
                print("[Sandbox] Enrutando comando via Docker CLI.")
            else:
                final_command = command
                shell_flag = True
                sandbox_active = False
        except Exception as e:
            final_command = command
            shell_flag = True
            sandbox_active = False
            print(f"[Sandbox] Fallback local host: {e}")

        # Start the process with non-blocking pipes
        process = subprocess.Popen(
            final_command,
            shell=shell_flag,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            cwd=SAFE_ROOT if not sandbox_active else None,
            universal_newlines=True,
            bufsize=1,
        )

        job_info = {
            "process": process,
            "stdout": [],
            "stderr": [],
            "status": "running",
            "start_time": time.time(),
            "command": command,
        }
        ACTIVE_JOBS[job_id] = job_info

        # Helper to read stream in background thread
        def monitor_stream(stream, target_list, stream_type="stdout"):
            try:
                for line in iter(stream.readline, ""):
                    if line:
                        target_list.append(line)
                        if stream_callback:
                            stream_callback(line, stream_type)
                stream.close()
            except Exception:
                pass

        # Start monitoring threads for both pipes
        t_out = threading.Thread(
            target=monitor_stream,
            args=(process.stdout, job_info["stdout"], "stdout"),
            daemon=True,
        )
        t_err = threading.Thread(
            target=monitor_stream,
            args=(process.stderr, job_info["stderr"], "stderr"),
            daemon=True,
        )
        t_out.start()
        t_err.start()

        # Wait for the process within the yield window
        try:
            process.wait(timeout=yield_window)
            # Process finished early
            t_out.join(timeout=0.5)
            t_err.join(timeout=0.5)

            output = "".join(job_info["stdout"])
            stderr = "".join(job_info["stderr"])
            if stderr:
                output += f"\n[STDERR_DETECTED]\n{stderr}"

            # Clean up immediately
            if job_id in ACTIVE_JOBS:
                del ACTIVE_JOBS[job_id]

            return f"Output (in {SAFE_ROOT}):\n{output}"

        except subprocess.TimeoutExpired:
            # Command is taking long -> Auto-Detach
            if not allow_background:
                process.kill()
                if job_id in ACTIVE_JOBS:
                    del ACTIVE_JOBS[job_id]
                return "Error: Command timed out."

            # Background monitor for the final Push
            def bg_finalizer():
                process.wait()
                job_info["status"] = "finished"
                # Wait a bit for threads to flush
                time.sleep(1)

                final_output = "".join(job_info["stdout"])
                final_stderr = "".join(job_info["stderr"])
                exit_code = process.returncode

                report = final_output
                if final_stderr:
                    report += f"\n[STDERR_DETECTED]\n{final_stderr}"

                # Push Notification to memory
                database.save_message(
                    "system",
                    f"[BACKGROUND_JOB_FINISHED] Job {job_id} completado con código {exit_code}.\nSalida final:\n{report}",
                    "Aegis",
                    "general",
                )
                # Keep it in ACTIVE_JOBS for a bit? Or purge.
                # Let's keep for 10 mins then purge.
                time.sleep(600)
                if job_id in ACTIVE_JOBS:
                    del ACTIVE_JOBS[job_id]

            threading.Thread(target=bg_finalizer, daemon=True).start()

            return f"[Comando pasado a segundo plano. Job ID: {job_id}. Usa la acción 'poll_process' para ver el progreso o espera la notificación de finalización.]"

    except Exception as e:
        if job_id in ACTIVE_JOBS:
            del ACTIVE_JOBS[job_id]
        return f"Execution Failed: {str(e)}"


def poll_process(job_id):
    """Retrieves current buffer and status for a background job."""
    if job_id not in ACTIVE_JOBS:
        return f"Error: Job ID {job_id} no encontrado. Puede que ya haya terminado y expirado."

    info = ACTIVE_JOBS[job_id]
    output = "".join(info["stdout"])
    stderr = "".join(info["stderr"])

    is_running = info["process"].poll() is None
    status = "RUNNING" if is_running else "FINISHED"

    res = f"Status: {status} (Job: {job_id})\nCommand: {info['command']}\n"
    if output:
        res += f"\n--- STDOUT BUFFER ---\n{output}"
    if stderr:
        res += f"\n--- STDERR BUFFER ---\n{stderr}"

    return res


def get_system_info():
    try:
        info = {
            "OS": platform.system(),
            "Release": platform.release(),
            "CPU": psutil.cpu_count(),
            "RAM_Total_GB": round(psutil.virtual_memory().total / (1024**3), 2),
            "CWD": SAFE_ROOT,
        }
        return json.dumps(info, indent=2)
    except Exception as e:
        return f"SysInfo Error: {str(e)}"


def emergency_shutdown(reason="Protocol 0 Invoked"):
    print(f"🚨 INITIATING EMERGENCY SHUTDOWN: {reason}")
    try:
        import datetime

        box_path = os.path.join(SAFE_ROOT, ".aegis", "black_box.log")
        os.makedirs(os.path.dirname(box_path), exist_ok=True)
        with open(box_path, "a") as f:
            f.write(
                f"[{datetime.datetime.now()}] EMERGENCY SHUTDOWN. Reason: {reason}\n"
            )
    except Exception:
        pass

    try:
        if platform.system() == "Windows":
            subprocess.run("taskkill /F /IM uvicorn.exe", shell=True)
            subprocess.run("taskkill /F /IM python.exe", shell=True)
        else:
            subprocess.run("pkill -f uvicorn", shell=True)
    except Exception:
        pass
    os._exit(1)


def apply_patch(filename, search_block, replace_block):
    if not filename or not search_block or not replace_block:
        return "Error: Missing arguments for patch."
    path = os.path.abspath(os.path.join(SAFE_ROOT, filename))
    if not path.startswith(os.path.abspath(SAFE_ROOT)):
        return "Security Error: Path traversal detected."
    if not os.path.exists(path):
        return f"Error: File {filename} not found."
    try:
        with open(path, "r", encoding="utf-8") as f:
            content = f.read()
        search_norm = search_block.replace("\r\n", "\n").strip()
        replace_norm = replace_block.replace("\r\n", "\n").strip()
        content_norm = content.replace("\r\n", "\n")
        if search_norm not in content_norm:
            return f"Error: Search block not found in {filename}."
        new_content = content_norm.replace(search_norm, replace_norm)
        with open(path, "w", encoding="utf-8") as f:
            f.write(new_content)
        return f"Patch applied successfully to {filename}."
    except Exception as e:
        return f"Patch Failed: {e}"


def execute(query, stream_callback=None, **kwargs):
    action = query.get("action")
    args = query.get("args", {})

    if action == "terminal":
        command = args.get("command")
        if not command:
            return "Error: Command required."
        blacklist = ["rm -rf /", ":(){ :|:& };:", "wget http", "curl http", "nc -e"]
        if any(b in command for b in blacklist):
            return "Security Alert: Command blocked by Aegis Firewall."
        return execute_command(command, stream_callback=stream_callback)

    elif action == "poll_process":
        return poll_process(args.get("job_id"))

    elif action == "apply_patch":
        return apply_patch(
            args.get("filename"), args.get("search_block"), args.get("replace_block")
        )

    elif action == "sysinfo":
        return get_system_info()

    elif action == "shutdown":
        if args.get("confirmation") == "PROTOCOL_0_CONFIRMED":
            emergency_shutdown(args.get("reason", "Manual Invoke"))
        return "Error: Protocol 0 requires confirmation code."

    return f"Error: Unknown action '{action}' in system_tools."
