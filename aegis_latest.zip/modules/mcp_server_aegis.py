import asyncio
import os
import sys
import json
import traceback
import mcp.types as types
from mcp.server import Server, NotificationOptions
from mcp.server.models import InitializationOptions
from mcp.server.stdio import stdio_server

# Ensure project root is in sys.path for direct module imports
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if PROJECT_ROOT not in sys.path:
    sys.path.append(PROJECT_ROOT)

# Aegis Imports
try:
    import database
    from modules.system_tools import execute_command
    from modules.file_writer import write_file
    from modules.resource_monitor import monitor
except ImportError as e:
    print(f"Error importing Aegis modules: {e}", file=sys.stderr)
    sys.exit(1)

server = Server("aegis-mcp-server")


@server.list_tools()
async def handle_list_tools() -> list[types.Tool]:
    """Exponemos las herramientas de Aegis-IA al ecosistema MCP."""
    return [
        types.Tool(
            name="read_aegis_file",
            description="Lee el contenido de cualquier archivo del proyecto. La ruta debe ser relativa a la raíz.",
            inputSchema={
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Ruta relativa del archivo (ej: 'app_web.py', 'modules/utils.py').",
                    }
                },
                "required": ["path"],
            },
        ),
        types.Tool(
            name="write_aegis_code",
            description="Modifica o crea archivos en la estructura de Aegis. Utiliza validación de ruta segura.",
            inputSchema={
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Ruta relativa del archivo.",
                    },
                    "content": {
                        "type": "string",
                        "description": "Contenido completo del archivo.",
                    },
                },
                "required": ["path", "content"],
            },
        ),
        types.Tool(
            name="execute_aegis_terminal",
            description="Ejecuta comandos en el sistema. Utiliza el sandbox de Aegis si está activo.",
            inputSchema={
                "type": "object",
                "properties": {
                    "command": {
                        "type": "string",
                        "description": "Comando de terminal a ejecutar.",
                    }
                },
                "required": ["command"],
            },
        ),
        types.Tool(
            name="query_aegis_memory",
            description="Ejecuta SQL directo sobre aegis_memory.db para consultar Tenants, Auditoría o el Grafo.",
            inputSchema={
                "type": "object",
                "properties": {
                    "sql_query": {
                        "type": "string",
                        "description": "Consulta SQL válida para SQLite.",
                    }
                },
                "required": ["sql_query"],
            },
        ),
        types.Tool(
            name="get_system_status",
            description="Obtiene métricas en tiempo real de RAM/CPU/GPU directamente del monitor de recursos de Aegis.",
            inputSchema={"type": "object", "properties": {}},
        ),
    ]


@server.call_tool()
async def handle_call_tool(
    name: str, arguments: dict | None
) -> list[types.TextContent]:
    """Maneja la ejecución de herramientas solicitadas por el cliente MCP."""
    if not arguments:
        arguments = {}

    try:
        if name == "read_aegis_file":
            path = arguments.get("path")
            # Forzamos que la ruta sea relativa al PROJECT_ROOT
            abs_path = os.path.normpath(os.path.join(PROJECT_ROOT, path))

            if not abs_path.startswith(PROJECT_ROOT):
                return [
                    types.TextContent(
                        type="text",
                        text="Error: Acceso denegado. La ruta está fuera de la raíz del proyecto.",
                    )
                ]

            if not os.path.exists(abs_path):
                return [
                    types.TextContent(
                        type="text", text=f"Error: Archivo no encontrado: {path}"
                    )
                ]

            if os.path.isdir(abs_path):
                return [
                    types.TextContent(
                        type="text",
                        text=f"Error: '{path}' es un directorio. Indica un archivo.",
                    )
                ]

            with open(abs_path, "r", encoding="utf-8") as f:
                content = f.read()
            return [types.TextContent(type="text", text=content)]

        elif name == "write_aegis_code":
            path = arguments.get("path")
            content = arguments.get("content")
            # Reutilizamos la lógica nativa del file_writer
            result = write_file(path, content)
            return [types.TextContent(type="text", text=result)]

        elif name == "execute_aegis_terminal":
            command = arguments.get("command")
            # Ejecución en un executor para evitar bloquear el loop de eventos
            loop = asyncio.get_event_loop()
            result = await loop.run_in_executor(None, execute_command, command)

            if isinstance(result, dict):
                msg = f"Job ID: {result.get('job_id')}\nOutput: {result.get('output', '')}"
            else:
                msg = str(result)
            return [types.TextContent(type="text", text=msg)]

        elif name == "query_aegis_memory":
            sql_query = arguments.get("sql_query")
            conn = database.get_connection()
            try:
                cursor = conn.cursor()
                cursor.execute(sql_query)
                if sql_query.strip().upper().startswith("SELECT"):
                    columns = [column[0] for column in cursor.description]
                    rows = cursor.fetchall()
                    results = [dict(zip(columns, row)) for row in rows]
                    return [
                        types.TextContent(
                            type="text",
                            text=json.dumps(results, indent=2, ensure_ascii=False),
                        )
                    ]
                else:
                    conn.commit()
                    return [
                        types.TextContent(
                            type="text",
                            text=f"Consulta ejecutada. Filas afectadas: {cursor.rowcount}",
                        )
                    ]
            finally:
                conn.close()

        elif name == "get_system_status":
            metrics = monitor.get_metrics()
            tier_num, tier_name, model_rec, ctx_rec = monitor.get_hardware_tier()

            report = {
                "metrics": metrics,
                "hardware_info": {
                    "tier": tier_name,
                    "recommended_models": model_rec,
                    "context_window_limit": ctx_rec,
                },
                "server_status": "READY",
            }
            return [
                types.TextContent(
                    type="text", text=json.dumps(report, indent=2, ensure_ascii=False)
                )
            ]

        else:
            return [
                types.TextContent(
                    type="text", text=f"Error: Herramienta '{name}' no existe."
                )
            ]

    except Exception as e:
        # Devolvemos el error detallado al cliente MCP
        error_msg = (
            f"Error en la herramienta '{name}': {str(e)}\n{traceback.format_exc()}"
        )
        return [types.TextContent(type="text", text=error_msg)]


async def main():
    """Lazo principal para el servidor MCP via stdio."""
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            InitializationOptions(
                server_name="aegis-mcp",
                server_version="1.0.0",
                capabilities=server.get_capabilities(
                    notification_options=NotificationOptions(),
                    experimental_capabilities={},
                ),
            ),
        )


if __name__ == "__main__":
    asyncio.run(main())
