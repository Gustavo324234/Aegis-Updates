import threading
import time
import json
import logging
import requests
import database

# Standard Libraries that are safe to import
from modules.resource_monitor import monitor
from modules import notifier

# Safe imports for optional libraries
try:
    import schedule
except ImportError:
    schedule = None
    logging.getLogger("DaemonManager").warning("Module 'schedule' not found. Daily Briefing daemon will be disabled.")

try:
    from gtts import gTTS
except ImportError:
    gTTS = None
    logging.getLogger("DaemonManager").warning("Module 'gTTS' not found. Audio features disabled.")


class DaemonManager:
    def __init__(self):
        self.active_threads = {} # daemon_id -> thread
        self._brain = None
        self.stop_event = threading.Event()
        self.logger = logging.getLogger("DaemonManager")
        self.started = False

    @property
    def brain(self):
        """Lazy Load AegisBrain to prevent circular imports."""
        if self._brain is None:
            # CIRCULAR IMPORT FIX: Import inside method
            try:
                from core import AegisBrain
                self._brain = AegisBrain()
            except ImportError:
                self.logger.critical("Failed to import AegisBrain from core. Application structure invalid.")
                return None
        return self._brain

    def start(self):
        """Starts the main management loop in a background thread."""
        if not self.started:
            manager_thread = threading.Thread(target=self._manager_loop, daemon=True)
            manager_thread.start()
            self.started = True
            self.logger.info("Daemon Manager started.")

    def stop(self):
        """Stops the manager and all daemons."""
        self.stop_event.set()

    # --- API Methods for UI/Other Modules ---
    def register_daemon(self, name, task_type, config, interval=60):
        """Registers a new daemon in the database and starts it."""
        try:
            config_str = json.dumps(config)
            result = database.register_daemon_db(name, task_type, interval, config_str)
            return result
        except Exception as e:
            return f"Error registering daemon: {e}"

    def list_daemons(self):
        """Returns list of daemons as dicts."""
        try:
            rows = database.get_daemons()
            daemons = []
            for r in rows:
                # id, name, task_type, status, interval, config, last_run
                daemons.append({
                    "id": r[0],
                    "name": r[1],
                    "type": r[2], # task_type
                    "status": r[3],
                    "interval": r[4],
                    "config": r[5],
                    "last_run": r[6]
                })
            return daemons
        except Exception as e:
            self.logger.error(f"Error listing daemons: {e}")
            return []

    def stop_daemon(self, name):
        """Stops a daemon by name."""
        try:
            database.set_daemon_status(name, "STOPPED")
            return f"Daemon {name} stopped."
        except Exception as e:
            return f"Error stopping daemon: {e}"

    def start_daemon(self, name):
        """Starts a daemon by name."""
        try:
            database.set_daemon_status(name, "RUNNING")
            return f"Daemon {name} started."
        except Exception as e:
            return f"Error starting daemon: {e}"

    # --- Internal Management Logic ---
    def _manager_loop(self):
        """Polls database every 5s to manage daemon threads."""
        while not self.stop_event.is_set():
            try:
                # [(id, name, task_type, status, interval, config, last_run), ...]
                daemons = database.get_daemons() 
                
                for d in daemons:
                    d_id = d[0]
                    name = d[1]
                    status = d[3]
                    
                    if status == 'RUNNING':
                        if d_id not in self.active_threads or not self.active_threads[d_id].is_alive():
                            # Start new thread
                            self.logger.info(f"Starting daemon {name} (ID: {d_id})")
                            t = threading.Thread(target=self.run_loop, args=(d_id,), daemon=True)
                            self.active_threads[d_id] = t
                            t.start()
                    else:
                        # Ensure it's not in active threads (handled by run_loop check usually)
                        pass

            except Exception as e:
                self.logger.error(f"Error in manager loop: {e}")
            
            # Wait 5s (check frequently for UI responsiveness)
            if self.stop_event.wait(5):
                break

    def run_loop(self, daemon_id):
        """Executes the specific task loop for a daemon."""
        self.logger.info(f"Daemon {daemon_id} loop started.")
        
        # Initial Check for Scheduler Logic
        d_info = database.get_daemon(daemon_id)
        if not d_info: return
        d_id, name, task_type, status, interval, config_str = d_info
        
        if task_type == 'daily_briefing':
            if schedule:
                self._run_scheduler_loop(daemon_id, config_str)
            else:
                self.logger.error("Daemon 'daily_briefing' cannot run: 'schedule' library missing.")
            return

        # Standard Interval Loop
        while not self.stop_event.is_set():
            # Refresh info to check status
            d_info = database.get_daemon(daemon_id)
            if not d_info: break 
            _, _, _, status, interval, config_str = d_info
            
            if status != 'RUNNING': break
                
            # Execute Task
            try:
                self._execute_task(task_type, config_str)
                database.update_daemon_last_run(daemon_id)
            except Exception as e:
                self.logger.error(f"Error in daemon {name}: {e}")
            
            # Wait interval
            if self.stop_event.wait(interval): break
        
        # Cleanup
        if daemon_id in self.active_threads:
            del self.active_threads[daemon_id]

    def _run_scheduler_loop(self, daemon_id, config_str):
        """Dedicated loop for Schedule-based tasks."""
        config = json.loads(config_str) if config_str else {}
        target_time = config.get("time", "08:00")
        
        # Create local scheduler instance
        local_scheduler = schedule.Scheduler()
        
        def job():
            self.logger.info(f"Executing Scheduled Task for Daemon {daemon_id}")
            try:
                self._execute_task('daily_briefing', config_str)
                database.update_daemon_last_run(daemon_id)
            except Exception as e:
                self.logger.error(f"Scheduled Job Failed: {e}")

        try:
             local_scheduler.every().day.at(target_time).do(job)
             self.logger.info(f"Protocol Daemon Scheduled at {target_time}")
        except Exception as e:
             self.logger.error(f"Failed to schedule job: {e}")
             return
        
        while not self.stop_event.is_set():
            d_info = database.get_daemon(daemon_id)
            if not d_info or d_info[3] != 'RUNNING': break
            
            try:
                local_scheduler.run_pending()
            except Exception as e:
                self.logger.error(f"Scheduler Tick Error: {e}")
                
            if self.stop_event.wait(1): break
            
        if daemon_id in self.active_threads:
            del self.active_threads[daemon_id]

    def _execute_task(self, task_type, config_str):
        """Dispatches to specific logic based on task_type."""
        config = json.loads(config_str) if config_str else {}
        
        if task_type == 'resource_watcher':
            self._task_resource_watcher(config)
        elif task_type == 'folder_guard':
            self._task_folder_guard(config)
        elif task_type == 'web_sentinel':
            self._task_web_sentinel(config)
        elif task_type == 'daily_briefing':
            self._task_daily_briefing(config)
        else:
            self.logger.warning(f"Unknown daemon task type: {task_type}")

    def _task_daily_briefing(self, config):
        """Protocol Dawn: Daily Briefing Generator."""
        
        if not gTTS:
            self.logger.warning("Daily Briefing skipped: gTTS not installed.")
            return

        self.logger.info("☀️ Generating Daily Briefing...")
        
        # 1. Weather
        try:
            weather = requests.get('https://wttr.in/?format=3', timeout=5).text.strip()
        except:
            weather = "Clima no disponible."
            
        # 2. Tasks
        pending = database.get_pending_tasks(limit=3)
        if pending:
            task_summary = f"Tienes {len(pending)} tareas pendientes. Prioridad alta: {pending[0]['task']}."
        else:
            task_summary = "No hay tareas pendientes."
            
        # 3. System
        health = monitor.check_health()
        mem = monitor.get_metrics()['app_ram_usage_mb']
        
        # 4. Projects
        projects = database.get_active_projects()
        proj_text = f"Proyectos activos: {', '.join(projects)}." if projects else "Sin proyectos activos."

        # Script
        script = f"Buenos días. Protocolo Amanecer iniciado. {weather}. Estado del sistema: {health}, uso de RAM {mem} megabytes. {task_summary} {proj_text} Que tengas un día productivo."
        
        # TTS
        try:
            tts = gTTS(text=script, lang='es')
            audio_file = "briefing_today.mp3"
            try: 
                 tts.save(audio_file)
            except PermissionError:
                 # Fallback if file is locked
                 audio_file = f"briefing_{int(time.time())}.mp3"
                 tts.save(audio_file)

            # Send via Telegram
            notifier.send_telegram_audio(audio_file, caption=f"☀️ **Briefing del Día**\n{weather}\nTasks: {len(pending)}")
            self.logger.info(f"Briefing sent. Script: {script[:50]}...")
            
        except Exception as e:
            self.logger.error(f"Briefing Generation Failed: {e}")

    def _task_resource_watcher(self, config):
        metrics = monitor.get_metrics()
        limit = config.get("min_ram_mb", 500) 
        available_mb = metrics['ram_available_gb'] * 1024
        
        # CRITICAL CHECK (The Hive Protocol 21)
        critical_ram = 200 # MB
        
        if available_mb < critical_ram:
            prompt = f"SYSTEM CRITICAL ALERT: Available RAM is extremely low ({available_mb:.2f}MB). Risk of system crash. As The Hive, analyze processes and propose IMMEDIATE REMEDIATION."
            # Invoke The Hive
            if self.brain:
                 response = self.brain.query(prompt, [], model_choice_arg="gemini-1.5-pro", hive_override=True)
                 notifier.send_telegram_alert(f"⚠️ **CRITICAL RAM FAILURE** ⚠️\n\n{response}")
                 database.log_audit_event("ResourceWatcher", "CRITICAL_RAM", "Hive Protocol Invoked", True)
            else:
                 self.logger.error("Brain unavailable for Critical RAM Alert.")
            
        elif available_mb < limit:
            # Standard Low RAM Logic
            if self.brain:
                prompt = f"Available RAM is low: {available_mb:.2f}MB (Limit: {limit}MB). Suggest 1 immediate action."
                response = self.brain.query(prompt, [], model_choice_arg="gemini-1.5-flash", profile="Efficient")
                database.log_audit_event("ResourceWatcher", "Low RAM Alert", response, True)

    def _task_folder_guard(self, config):
        import os
        path = config.get("path", ".")
        if os.path.exists(path):
            try:
                files = os.listdir(path)
                file_count = len(files)
                
                # CRITICAL INTRUSION / CLUTTER
                if file_count > 100:
                    if self.brain:
                        prompt = f"SECURITY ALERT: Directory '{path}' has {file_count} files. This exceeds safe thresholds. As The Hive (Security & Engineering), analyze if this is a malicious intrusion or data dump and propose CLEANUP."
                        response = self.brain.query(prompt, [], model_choice_arg="gemini-1.5-pro", hive_override=True)
                        
                        notifier.send_telegram_alert(f"🚨 **FILE INTRUSION DETECTED** 🚨\n\n{response}")
                        database.log_audit_event("FolderGuard", "CRITICAL_INTRUSION", "Hive Protocol Invoked", True)
                    
                elif file_count > 50:
                    # Standard Warning
                    if self.brain:
                        prompt = f"Dir {path} has {file_count} files. Analyze if this is clutter. Reply Yes/No."
                        response = self.brain.query(prompt, [], model_choice_arg="gemini-1.5-flash")
                        if "Yes" in response:
                            database.log_audit_event("FolderGuard", "Clutter Detected", f"{path}: {file_count} files", True)
            except Exception as e:
                self.logger.error(f"Folder Guard Error: {e}")

    def _task_web_sentinel(self, config):
        url = config.get("url", "https://google.com")
        try:
            r = requests.get(url, timeout=10)
            if r.status_code != 200:
                if self.brain:
                    prompt = f"URL {url} status {r.status_code}. Diagnose briefly."
                    response = self.brain.query(prompt, [], model_choice_arg="gemini-1.5-flash")
                    database.log_audit_event("WebSentinel", "Error", response, True)
        except Exception as e:
             database.log_audit_event("WebSentinel", "Connection Fail", str(e), True)

# Global Instance & Auto-Start
daemon_manager = DaemonManager()
