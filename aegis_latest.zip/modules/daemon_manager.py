import threading
import time
import base64
import json
import logging
import requests
import database
import os
import re
from modules.utils import get_user_root

# Standard Libraries that are safe to import
from modules.resource_monitor import monitor
from modules import notifier

# Safe imports for optional libraries
try:
    import schedule
except ImportError:
    schedule = None
    logging.getLogger("DaemonManager").warning(
        "Module 'schedule' not found. Daily Briefing daemon will be disabled."
    )

try:
    from gtts import gTTS
except ImportError:
    gTTS = None
    logging.getLogger("DaemonManager").warning(
        "Module 'gTTS' not found. Audio features disabled."
    )


class DaemonManager:
    def __init__(self):
        self.active_threads = {}  # daemon_id -> thread
        self._brain = None
        self.stop_event = threading.Event()
        self.logger = logging.getLogger("DaemonManager")
        self.started = False
        self.watchdog_cache = {}  # path -> content (for diff generation)

    @property
    def brain(self):
        """Lazy Load AegisBrain to prevent circular imports."""
        if self._brain is None:
            # CIRCULAR IMPORT FIX: Import inside method
            try:
                from core import AegisBrain

                self._brain = AegisBrain()
            except ImportError:
                self.logger.critical(
                    "Failed to import AegisBrain from core. Application structure invalid."
                )
                return None
        return self._brain

    def start(self):
        """Starts the main management loop in a background thread."""
        if os.getenv("AEGIS_NO_DAEMONS") == "true":
            self.logger.info("Daemon Manager disabled via AEGIS_NO_DAEMONS.")
            return

        if not self.started:
            # --- THE FORGE PROTOCOL: Auto-Sync AI State ---
            try:
                import modules.ide_bridge

                res = modules.ide_bridge.sync_ai_config()
                if res.get("status") == "success":
                    self.logger.info(f"Forge Bridge Synced: {res.get('path')}")
                else:
                    self.logger.warning(f"Forge Bridge: {res.get('message')}")
            except Exception as e:
                self.logger.error(f"Forge Bridge Init Failed: {e}")

            manager_thread = threading.Thread(target=self._manager_loop, daemon=True)
            manager_thread.start()
            self.started = True

            # Protocolo Lázaro: Resurrección de misiones interrumpidas
            self._resurrect_missions()

            self.logger.info("Daemon Manager started.")

    def stop(self):
        """Stops the manager and all daemons."""
        self.stop_event.set()

    # --- API Methods for UI/Other Modules ---
    def register_daemon(self, name, task_type, config, interval=60):
        """Registers a new daemon in the database and starts it."""
        try:
            config_str = json.dumps(config)
            result = database.register_daemon_db(name, task_type, interval, config_str)
            return result
        except Exception as e:
            return f"Error registering daemon: {e}"

    def list_daemons(self):
        """Returns list of daemons as dicts."""
        try:
            rows = database.get_daemons()
            daemons = []
            for r in rows:
                # id, name, task_type, status, interval, config, last_run
                daemons.append(
                    {
                        "id": r[0],
                        "name": r[1],
                        "type": r[2],  # task_type
                        "status": r[3],
                        "interval": r[4],
                        "config": r[5],
                        "last_run": r[6],
                    }
                )
            return daemons
        except Exception as e:
            self.logger.error(f"Error listing daemons: {e}")
            return []

    def stop_daemon(self, name):
        """Stops a daemon by name."""
        try:
            database.set_daemon_status(name, "STOPPED")
            return f"Daemon {name} stopped."
        except Exception as e:
            return f"Error stopping daemon: {e}"

    def start_daemon(self, name):
        """Starts a daemon by name."""
        try:
            database.set_daemon_status(name, "RUNNING")
            return f"Daemon {name} started."
        except Exception as e:
            return f"Error starting daemon: {e}"

    def _resurrect_missions(self):
        """
        Protocolo Lázaro: Retoma misiones interrumpidas tras un reinicio del sistema.
        Consulta la base de datos buscando misiones con estado 'running' o 'pending'.
        """
        try:
            missions = database.get_active_missions()
            if not missions:
                return

            interrupted_found = False
            for m in missions:
                mid = m["id"]
                self.logger.info(
                    f"Protocolo Lázaro: Detectada misión interrumpida [{mid}]. Analizando punto de retorno..."
                )

                # Inyección de log de sistema
                resumption_log = "[SYSTEM] Misión reanudada automáticamente tras reinicio del sistema."

                # Lógica de Resurrección: Si tiene pasos completados, forzar estado 'pending'
                new_status = m["status"]
                if m.get("step_idx", 0) > 0:
                    new_status = "pending"

                # Actualizar progreso con el log inyectado
                database.update_mission_progress(
                    mid, m["step_idx"], log_entry=resumption_log, status=new_status
                )
                interrupted_found = True

            if interrupted_found:
                # Habilitación automática del worker si hay misiones pendientes
                database.set_daemon_status("mission_worker", "RUNNING")
                self.logger.info(
                    "Protocolo Lázaro: Daemon 'mission_worker' habilitado automáticamente."
                )

        except Exception as e:
            self.logger.error(f"Error en Protocolo Lázaro: {e}")

    def _task_neural_mirror(self, config):
        """Captura la pantalla, la analiza con visión y guarda en el Grafo."""
        import io

        # 1. Intentar captura de pantalla (Requiere entorno gráfico)
        try:
            import pyautogui

            screenshot = pyautogui.screenshot()

            # Comprimir para ahorrar ancho de banda
            buffered = io.BytesIO()
            screenshot.save(buffered, format="JPEG", quality=50)
            img_str = base64.b64encode(buffered.getvalue()).decode("utf-8")
        except Exception as e:
            self.logger.debug(f"Mirror: Captura no disponible (Entorno CLI?): {e}")
            return

        # 2. Consultar a Moondream (Ollama) para resumir el contexto
        ollama_url = database.get_setting("ollama_url") or "http://127.0.0.1:11434"
        vision_model = database.get_setting("local_vision_model") or "moondream"

        payload = {
            "model": vision_model,
            "prompt": "Describe brevemente qué hay en esta pantalla. ¿Qué aplicaciones, sitios web o errores se ven? Sé técnico y conciso.",
            "images": [img_str],
            "stream": False,
        }

        try:
            resp = requests.post(f"{ollama_url}/api/generate", json=payload, timeout=60)
            if resp.status_code == 200:
                summary = resp.json().get("response", "")

                # 3. Extraer Triples para el Grafo
                # Guardamos la relación: (usuario, esta_viendo, resumen_visual)
                if hasattr(database, "add_graph_triple"):
                    database.add_graph_triple("usuario", "observa_en_pantalla", summary)
                else:
                    # Fallback if add_graph_triple is not available (though it should be per Phase 7 requirements)
                    self.logger.warning(
                        "Mirror: database.add_graph_triple not found. Saving to audit log."
                    )
                    database.log_audit_event(
                        "NeuralMirror", "Visual Context", "INFO", details=summary
                    )

                self.logger.info(
                    "👁️ Neural Mirror: Contexto visual sincronizado al Grafo."
                )
        except Exception as e:
            self.logger.error(f"Mirror Vision Error: {e}")

    # --- Internal Management Logic ---
    def _manager_loop(self):
        """Polls database every 5s to manage daemon threads."""
        while not self.stop_event.is_set():
            try:
                # [(id, name, task_type, status, interval, config, last_run), ...]
                daemons = database.get_daemons()

                for d in daemons:
                    d_id = d[0]
                    name = d[1]
                    status = d[3]

                    if status == "RUNNING":
                        if (
                            d_id not in self.active_threads
                            or not self.active_threads[d_id].is_alive()
                        ):
                            # Start new thread
                            self.logger.info(f"Starting daemon {name} (ID: {d_id})")
                            t = threading.Thread(
                                target=self.run_loop, args=(d_id,), daemon=True
                            )
                            self.active_threads[d_id] = t
                            t.start()
                    else:
                        # Ensure it's not in active threads (handled by run_loop check usually)
                        pass

            except Exception as e:
                self.logger.error(f"Error in manager loop: {e}")

            # Wait 5s (check frequently for UI responsiveness)
            if self.stop_event.wait(5):
                break

    def run_loop(self, daemon_id):
        """Executes the specific task loop for a daemon."""
        self.logger.info(f"Daemon {daemon_id} loop started.")

        # Initial Check for Scheduler Logic
        d_info = database.get_daemon(daemon_id)
        if not d_info:
            return
        d_id, name, task_type, status, interval, config_str, last_run = d_info

        if task_type == "daily_briefing":
            if schedule:
                self._run_scheduler_loop(daemon_id, config_str)
            else:
                self.logger.error(
                    "Daemon 'daily_briefing' cannot run: 'schedule' library missing."
                )
            return

        # Special Case: Mission Worker (High Frequency)
        if task_type == "mission_worker":
            self._run_mission_worker_loop(daemon_id, config_str)
            return

        # Standard Interval Loop
        while not self.stop_event.is_set():
            # Refresh info to check status
            # Refresh info to check status
            d_info = database.get_daemon(daemon_id)
            if not d_info:
                break
            _, _, _, status, interval, config_str, _ = d_info

            if status != "RUNNING":
                break

            # Execute Task
            try:
                self._execute_task(task_type, config_str)
                database.update_daemon_last_run(daemon_id)
            except Exception as e:
                self.logger.error(f"Error in daemon {name}: {e}")

            # Wait interval
            # Wait interval
            if self.stop_event.wait(interval):
                break

        # Cleanup
        if daemon_id in self.active_threads:
            del self.active_threads[daemon_id]

    def _run_scheduler_loop(self, daemon_id, config_str):
        """Dedicated loop for Schedule-based tasks."""
        config = json.loads(config_str) if config_str else {}
        target_time = config.get("time", "08:00")

        # Create local scheduler instance
        local_scheduler = schedule.Scheduler()

        def job():
            self.logger.info(f"Executing Scheduled Task for Daemon {daemon_id}")
            try:
                self._execute_task("daily_briefing", config_str)
                database.update_daemon_last_run(daemon_id)
            except Exception as e:
                self.logger.error(f"Scheduled Job Failed: {e}")

        try:
            local_scheduler.every().day.at(target_time).do(job)
            self.logger.info(f"Protocol Daemon Scheduled at {target_time}")
        except Exception as e:
            self.logger.error(f"Failed to schedule job: {e}")
            return

        while not self.stop_event.is_set():
            d_info = database.get_daemon(daemon_id)
            if not d_info or d_info[3] != "RUNNING":
                break

            try:
                local_scheduler.run_pending()
            except Exception as e:
                self.logger.error(f"Scheduler Tick Error: {e}")

            if self.stop_event.wait(1):
                break

        if daemon_id in self.active_threads:
            del self.active_threads[daemon_id]

    def _execute_task(self, task_type, config_str):
        """Dispatches to specific logic based on task_type."""
        config = json.loads(config_str) if config_str else {}

        if task_type == "resource_watcher":
            self._task_resource_watcher(config)
        elif task_type == "folder_guard":
            self._task_folder_guard(config)
        elif task_type == "web_sentinel":
            self._task_web_sentinel(config)
        elif task_type == "daily_briefing":
            self._task_daily_briefing(config)
        elif task_type == "chronos_optimizer":
            self._task_chronos_optimizer(config)
        elif task_type == "vision_watchdog":
            self._task_vision_watchdog(config)
        elif task_type == "workspace_watchdog":
            self._task_workspace_watchdog(config)
        elif task_type == "security_sentinel":
            self._task_security_sentinel(config)
        elif task_type == "soul_sync":
            self._task_soul_sync()
        elif task_type == "auto_cron":
            self._task_auto_cron(config)
        elif task_type == "neural_mirror":
            self._task_neural_mirror(config)
        elif task_type == "chronos_evolution":
            self._task_chronos_evolution(config)
        else:
            self.logger.warning(f"Unknown daemon task type: {task_type}")

    def _task_vision_watchdog(self, config):
        """Active Vision: Monitors /workspace/screenshots for new images."""
        import glob
        # time imported globally

        # Path logic
        watch_dir = os.path.join(get_user_root(), "workspace", "screenshots")
        if not os.path.exists(watch_dir):
            return  # Nothing to watch yet

        # Get all png/jpg
        files = glob.glob(os.path.join(watch_dir, "*.*"))
        images = [
            f
            for f in files
            if f.lower().endswith((".png", ".jpg", ".jpeg"))
            and "processed_" not in os.path.basename(f)
        ]

        if not images:
            return

        # Process 1 image per tick to avoid overload
        target_img = images[0]
        filename = os.path.basename(target_img)
        self.logger.info(f"👁️ Vision Watchdog: Analyzing {filename}...")

        try:
            # 1. Image Analysis
            if self.brain:
                # Determine Model (Cloud vs Local)
                # We check raw settings directly to avoid overhead
                op_mode = database.get_setting("operation_mode") or "Hybrid"

                # Default to Cloud for speed/quality if allowed
                use_local = "Local" in op_mode

                description = ""

                if not use_local:
                    # CLOUD (Gemini)
                    try:
                        import google.generativeai as genai
                        from PIL import Image

                        img_obj = Image.open(target_img)

                        api_key = database.get_setting("api_key_gemini")
                        if api_key and str(api_key).startswith("AI"):
                            genai.configure(api_key=api_key)
                            model = genai.GenerativeModel("gemini-2.0-flash")
                            resp = model.generate_content(
                                [
                                    "Describe this image specifically for an AI assistant. Key elements, text, context.",
                                    img_obj,
                                ]
                            )
                            description = resp.text
                    except Exception as e:
                        self.logger.error(f"Cloud Vision Failed: {e}")
                        use_local = True  # Fallback

                if use_local or not description:
                    # LOCAL (Llava / Moondream)
                    # Use Ollama via Brain
                    # We need to read image bytes or path? Ollama API takes base64 usually
                    # But core.py query_ollama doesn't support images natively yet in this version unless updated.
                    # Current core.py `query_ollama` payload structure: "model", "prompt", "stream".
                    # It DOES NOT handle 'images' key in payload in the viewed version.
                    # Workaround: Use 'ollama' CLI directly or assume core update?
                    # Phase 10 implies we add this.
                    # Let's use `subprocess` to call `ollama run list` to check model
                    # and then `ollama run moondream "Describe this image" < path`? No, CLI is interactive.
                    # We can use the HTTP API manually here.

                    import base64

                    with open(target_img, "rb") as img_file:
                        b64_data = base64.b64encode(img_file.read()).decode("utf-8")

                    local_model = (
                        database.get_setting("local_vision_model") or "moondream"
                    )  # Dynamic model selection
                    # Check if installed?
                    # payload
                    payload = {
                        "model": local_model,
                        "prompt": "Describe this image in detail.",
                        "images": [b64_data],
                        "stream": False,
                    }
                    try:
                        res = requests.post(
                            f"{self.brain.ollama_host}/api/generate",
                            json=payload,
                            timeout=60,
                        )
                        if res.status_code == 200:
                            description = res.json().get("response", "")
                        else:
                            description = f"Local Vision Error: {res.text}"
                    except Exception:
                        description = "Vision unavailable (Cloud failed, Local Moondream unreachable)."

                # 2. Inject to Session RAG (Vault)
                from modules.vault_manager import vault

                vault.index_text(
                    f"Image Analysis [{filename}]: {description}",
                    "session_rag",
                    {"source": "vision_watchdog", "file": filename},
                )

                # 3. Notify User
                # We use a system message with a specific tag that the UI can pick up as a toast
                # Or just a general "Vision" tag
                database.save_message(
                    "system",
                    f"👁️ **Detección Visual**: {description[:150]}...",
                    "Vision",
                    "general",
                )

                # 4. Mark Processed (Rename)
                new_path = os.path.join(watch_dir, f"processed_{filename}")
                os.rename(target_img, new_path)
                self.logger.info(f"Vision Complete: {description[:50]}...")

        except Exception as e:
            self.logger.error(f"Vision Watchdog Error: {e}")

    def _task_daily_briefing(self, config):
        """Protocol Dawn: Daily Briefing Generator."""

        if not gTTS:
            self.logger.warning("Daily Briefing skipped: gTTS not installed.")
            return

        self.logger.info("☀️ Generating Daily Briefing...")

        # 1. Weather
        try:
            weather = requests.get("https://wttr.in/?format=3", timeout=5).text.strip()
        except Exception:
            weather = "Clima no disponible."

        # 2. Tasks
        pending = database.get_pending_tasks(limit=3)
        if pending:
            task_summary = f"Tienes {len(pending)} tareas pendientes. Prioridad alta: {pending[0]['task']}."
        else:
            task_summary = "No hay tareas pendientes."

        # 3. System
        health = monitor.check_health()
        mem = monitor.get_metrics()["app_ram_usage_mb"]

        # 4. Projects
        projects = database.get_active_projects()
        proj_text = (
            f"Proyectos activos: {', '.join(projects)}."
            if projects
            else "Sin proyectos activos."
        )

        # Script
        script = f"Buenos días. Protocolo Amanecer iniciado. {weather}. Estado del sistema: {health}, uso de RAM {mem} megabytes. {task_summary} {proj_text} Que tengas un día productivo."

        # TTS
        try:
            tts = gTTS(text=script, lang="es")

            # SAFE TMP PATH
            # SAFE TMP PATH
            tmp_dir = os.path.join(get_user_root(), "tmp")
            os.makedirs(tmp_dir, exist_ok=True)

            audio_file = os.path.join(tmp_dir, "briefing_today.mp3")
            try:
                tts.save(audio_file)
            except PermissionError:
                # Fallback if file is locked
                audio_file = os.path.join(tmp_dir, f"briefing_{int(time.time())}.mp3")
                tts.save(audio_file)

            # Send via Telegram
            notifier.send_telegram_audio(
                audio_file,
                caption=f"☀️ **Briefing del Día**\n{weather}\nTasks: {len(pending)}",
            )
            self.logger.info(f"Briefing sent. Script: {script[:50]}...")

        except Exception as e:
            self.logger.error(f"Briefing Generation Failed: {e}")

    def _task_chronos_optimizer(self, config):
        """Protocol Chronos: Background Memory Consolidation (Self-Healing)."""
        # 1. Check Idle Time (Simulated via last_run or database timestamp)
        # In a real app, we'd check 'last_user_interaction' in DB settings
        last_interact_str = database.get_setting("last_interaction_ts")
        if not last_interact_str:
            return

        try:
            import datetime

            last_ts = datetime.datetime.fromisoformat(last_interact_str)
            minutes_idle = (datetime.datetime.now() - last_ts).total_seconds() / 60

            if minutes_idle < 10:
                return  # Not idle enough

        except Exception:
            return

        self.logger.info(
            "⏳ ChronosOptimizer: System Idle > 10m. Consolidating Memory..."
        )

        # 2. Fetch recent Audit Logs & Chat
        logs = database.get_audit_logs(limit=20)
        history = database.get_history(limit=10)

        # 3. Generate Summary
        if self.brain:
            prompt = f"""
            [ROLE: SYSTEM MAINTAINER]
            Analyze these recent logs and chats:
            LOGS: {json.dumps([lg[1] + ":" + lg[2] for lg in logs])}
            CHATS: {str([(h[1], h[2]) for h in history])}
            
            Generate a brief 'State of Consciousness' summary (1 sentence) for when the user returns.
            Example: 'Optimized 12 memory fragments and detecting coding patterns in recent sessions.'
            """
            try:
                summary = self.brain.query(prompt, [], "gemini-2.0-flash")

                # 4. Store in User Metadata (to be read by UI on wakeup)
                database.add_user_fact("system_state_summary", summary, "chronos", 1.0)

                # Log action
                database.log_audit_event(
                    "Chronos",
                    "Memory Optimization",
                    "SUCCESS",
                    details=summary,
                    approved=True,
                )
                self.logger.info(f"Chronos Complete: {summary}")

            except Exception as e:
                self.logger.error(f"Chronos Failed: {e}")

    def _task_chronos_evolution(self, config):
        """Protocolo Chronos: Introspección proactiva del sistema."""
        import database
        from datetime import datetime

        # 1. Verificar inactividad (IDLE)
        # Si hubo un mensaje en los últimos 30 min, posponer
        last_msg = database.get_history(limit=1)
        if last_msg:
            try:
                # (role, content, timestamp, model)
                last_ts = datetime.fromisoformat(last_msg[0][2])
                diff = datetime.now() - last_ts
                if diff.total_seconds() < 1800:  # 30 minutes
                    self.logger.info(
                        "⏳ Chronos: Sistema no lo suficientemente inactivo. Postponiendo..."
                    )
                    return
            except Exception as e:
                self.logger.error(f"Chronos Time Check Error: {e}")

        self.logger.info("⏳ Chronos: Iniciando fase de introspección...")

        # 2. Consultar al Grafo y al Workspace por "cabos sueltos"
        # Pedimos al Juez (Logic) que encuentre algo que mejorar
        discovery_prompt = """
        [SISTEMA DE INTROSPECCIÓN CHRONOS]
        Revisa las últimas conexiones del Grafo de Conocimiento y los proyectos activos.
        Identifica UN área de mejora (un bug potencial, una falta de documentación o una optimización de código).
        Genera una PROPUESTA EVOLUTIVA para el usuario.
        Responde DIRECTAMENTE con la propuesta, sin introducciones.
        """
        try:
            # Usamos el debate neural para asegurar que la propuesta sea brillante
            if self.brain:
                # We use a specialist model (logic) as requested
                model_logic = self.brain.resolve_model_by_role("logic")
                proposal = self.brain.query(
                    discovery_prompt, [], model_logic, stream=False
                )

                if (
                    "propuesta" in proposal.lower()
                    or "optimización" in proposal.lower()
                ):
                    msg = f"✨ **Chronos (Auto-Evolución)**: He estado analizando tu entorno mientras no estabas.\n\n{proposal}"
                    # Guardamos con el modelo "Chronos" para que el UI lo pinte diferente
                    database.save_message("assistant", msg, "Chronos", "general")
                    self.logger.info("✅ Chronos: Propuesta evolutiva generada.")
            else:
                self.logger.error("Chronos Error: Brain not available.")
        except Exception as e:
            self.logger.error(f"Chronos Error: {e}")

    def _proactive_awaken(self, daemon_name, event_description):
        """Inicia una conversación proactiva con el usuario basándose en un evento del sistema."""
        if not self.brain:
            return

        try:
            prompt = f"[EVENTO DE ENTORNO: El demonio {daemon_name} reporta lo siguiente: {event_description}. Inicia la conversación con el usuario para informarle o proponerle una acción de forma natural y breve. Usa el tag <final> para tu respuesta.]"
            response = self.brain.query(prompt, [], "gemini-2.0-flash")

            # Limpiar posible basura de etiquetas si las usa
            import re

            final_match = re.search(
                r"<final>(.*?)</final>", response, flags=re.DOTALL | re.IGNORECASE
            )
            if final_match:
                response = final_match.group(1).strip()

            database.save_message(
                "assistant",
                f"🔔 **{daemon_name}**: {response}",
                "Aegis Daemon",
                "general",
            )
            self.logger.info(f"Proactive Awakening triggered by {daemon_name}.")
        except Exception as e:
            self.logger.error(f"Failed to proactively awaken: {e}")

    def _task_resource_watcher(self, config):
        metrics = monitor.get_metrics()
        limit = config.get("min_ram_mb", 500)
        available_mb = metrics["ram_available_gb"] * 1024

        # CRITICAL CHECK (The Hive Protocol 21)
        critical_ram = 200  # MB

        if available_mb < critical_ram:
            prompt = f"SYSTEM CRITICAL ALERT: Available RAM is extremely low ({available_mb:.2f}MB). Risk of system crash. As The Hive, analyze processes and propose IMMEDIATE REMEDIATION."
            # Invoke The Hive
            if self.brain:
                response = self.brain.query(
                    prompt, [], model_choice_arg="gemini-1.5-pro", hive_override=True
                )
                notifier.send_telegram_alert(
                    f"⚠️ **CRITICAL RAM FAILURE** ⚠️\n\n{response}"
                )
                database.log_audit_event(
                    "ResourceWatcher",
                    "CRITICAL_RAM",
                    "ALARM",
                    details="Hive Protocol Invoked",
                    approved=True,
                )
                self._proactive_awaken(
                    "Resource Watcher",
                    f"Nivel crítico de memoria RAM disponible: {available_mb:.2f}MB. Riesgo inminente de fallo del sistema.",
                )
            else:
                self.logger.error("Brain unavailable for Critical RAM Alert.")

        elif available_mb < limit:
            # Standard Low RAM Logic
            if self.brain:
                prompt = f"Available RAM is low: {available_mb:.2f}MB (Limit: {limit}MB). Suggest 1 immediate action."
                response = self.brain.query(
                    prompt, [], model_choice_arg="gemini-2.0-flash", profile="Efficient"
                )
                database.log_audit_event(
                    "ResourceWatcher",
                    "Low RAM Alert",
                    "WARNING",
                    details=response,
                    approved=True,
                )
                self._proactive_awaken(
                    "Resource Watcher",
                    f"Queda poca memoria RAM ({available_mb:.2f}MB). Actuar pronto.",
                )

    def _task_folder_guard(self, config):
        path = config.get("path", ".")
        if os.path.exists(path):
            try:
                files = os.listdir(path)
                file_count = len(files)

                # CRITICAL INTRUSION / CLUTTER
                if file_count > 100:
                    if self.brain:
                        prompt = f"SECURITY ALERT: Directory '{path}' has {file_count} files. This exceeds safe thresholds. As The Hive (Security & Engineering), analyze if this is a malicious intrusion or data dump and propose CLEANUP."
                        response = self.brain.query(
                            prompt,
                            [],
                            model_choice_arg="gemini-1.5-pro",
                            hive_override=True,
                        )

                        notifier.send_telegram_alert(
                            f"🚨 **FILE INTRUSION DETECTED** 🚨\n\n{response}"
                        )
                        database.log_audit_event(
                            "FolderGuard",
                            "CRITICAL_INTRUSION",
                            "ALARM",
                            details="Hive Protocol Invoked",
                            approved=True,
                        )
                        self._proactive_awaken(
                            "Folder Guard",
                            f"Se detectó un exceso anómalo de archivos ({file_count}) en '{path}'. Posible intrusión o acumulación de basura tecnológica.",
                        )

                elif file_count > 50:
                    # Standard Warning
                    if self.brain:
                        prompt = f"Dir {path} has {file_count} files. Analyze if this is clutter. Reply Yes/No."
                        response = self.brain.query(
                            prompt, [], model_choice_arg="gemini-2.0-flash"
                        )
                        if "Yes" in response:
                            database.log_audit_event(
                                "FolderGuard",
                                "Clutter Detected",
                                "WARNING",
                                details=f"{path}: {file_count} files",
                                approved=True,
                            )
                            self._proactive_awaken(
                                "Folder Guard",
                                f"Hay demasiados archivos ({file_count}) en la carpeta '{path}'. Podría requerir orden.",
                            )
            except Exception as e:
                self.logger.error(f"Folder Guard Error: {e}")

    def _task_web_sentinel(self, config):
        url = config.get("url", "https://google.com")
        try:
            r = requests.get(url, timeout=10)
            if r.status_code != 200:
                if self.brain:
                    prompt = f"URL {url} status {r.status_code}. Diagnose briefly."
                    response = self.brain.query(
                        prompt, [], model_choice_arg="gemini-2.0-flash"
                    )
                    database.log_audit_event(
                        "WebSentinel",
                        "Error",
                        "FAILURE",
                        details=response,
                        approved=True,
                    )
        except Exception as e:
            database.log_audit_event(
                "WebSentinel",
                "Connection Fail",
                "FAILURE",
                details=str(e),
                approved=True,
            )

    def _task_security_sentinel(self, config):
        """Monitors dependencies for vulnerabilities (Tech Watchdog)."""
        import os
        from modules.utils import get_user_root

        workspace = os.path.join(get_user_root(), "workspace")
        if not os.path.exists(workspace):
            return

        # 1. Scan requirements.txt / package.json
        req_file = os.path.join(workspace, "requirements.txt")
        # pkg_file = os.path.join(workspace, "package.json")

        vuln_report = []

        # Simple Logic: Check for known ancient versions or explicit TODOs
        # In a real scenario, this would import 'safety' or query an API

        if os.path.exists(req_file):
            try:
                with open(req_file, "r") as f:
                    reqs = f.readlines()
                    for r in reqs:
                        if "==" in r and "flask" in r.lower():
                            ver = r.split("==")[1].strip()
                            if ver.startswith("0.") or ver.startswith(
                                "1.0"
                            ):  # Archaic example
                                vuln_report.append(
                                    f"Flask v{ver} is deprecated. Upgrade to 2.x+"
                                )
            except Exception:
                pass

        if vuln_report:
            if self.brain:
                # Ingest to System
                alert_msg = (
                    f"⚠️ **SECURITY SENTINEL**: Detected {len(vuln_report)} risks:\n"
                    + "\n".join(vuln_report)
                )
                database.save_message("system", alert_msg, "Sentinel", "general")
                self.logger.warning(alert_msg)

    def _run_mission_worker_loop(self, daemon_id, config_str):
        """Worker loop for executing autonomous missions in background. Supports persistent state & sleeping."""
        self.logger.info("🤖 MissionWorker Started (Persistent Mode).")
        import time

        last_check_in = time.time()

        while not self.stop_event.is_set():
            # Check Status
            d_info = database.get_daemon(daemon_id)
            if not d_info or d_info[3] != "RUNNING":
                break

            try:
                # 0. TELEGRAM CHECK-IN (Every 4 Hours)
                if time.time() - last_check_in > 14400:  # 4h in seconds
                    active_count = len(database.get_active_missions())
                    if active_count > 0:
                        try:
                            # Notifier import safety
                            from modules import notifier

                            notifier.send_telegram_alert(
                                f"🛡️ **Pixel Sentinel Status**\nActive Missions: {active_count}\nSystem Uptime: OK."
                            )
                            self.logger.info("Sent 4h Check-in.")
                        except Exception:
                            pass
                    last_check_in = time.time()

                # 1. Fetch Active Missions (Running OR Sleeping)
                # We need to fetch 'sleeping' ones too to check wake conditions
                missions = database.get_active_missions()

                if not missions:
                    time.sleep(5)  # Idle backoff
                    continue

                for m in missions:
                    mid = m["id"]

                    # SLEEP LOGIC
                    if m.get("status") == "sleeping":
                        # Check wake condition (e.g. time passed, or event)
                        # For now, simple time-based sleep in metadata?
                        # Assuming metadata stores 'wake_time'
                        meta = m.get("metadata", {})
                        wake_time = meta.get("wake_time", 0)

                        if time.time() > wake_time:
                            self.logger.info(f"⏰ Waking Mission {mid}...")
                            database.update_mission_status(mid, "running")
                        else:
                            continue  # Still sleeping

                    # Execution Logic
                    goal = m["goal"]
                    steps = m["steps"]
                    curr_step_idx = m["step_idx"]
                    logs_json = m["logs"]

                    if curr_step_idx >= len(steps):
                        database.complete_mission(mid)
                        self.logger.info(f"Mission {mid} Complete")

                        # --- SUBAGENT ANNOUNCE FLOW ---
                        subagent_match = re.search(
                            r"\[SUBAGENT_MISSION\]\[(.*?)\]", goal
                        )
                        if subagent_match:
                            parent_thread = subagent_match.group(1)
                            final_output = (
                                logs_json[-1] if logs_json else "Completado sin logs."
                            )
                            database.save_message(
                                "system",
                                f"[SUBAGENT_ANNOUNCE] Tarea delegada completada. Resultados técnicos: {final_output}. Traduce esto y avísale al usuario.",
                                "Aegis",
                                parent_thread,
                            )
                            # Despertarle proactivamente
                            self._proactive_awaken(
                                "Orchestrator",
                                "Un subagente ha terminado su tarea. Revisa el resultado técnico y anúncialo al usuario orgánicamente.",
                            )
                        else:
                            # Notificar al Chat Web (Normal)
                            database.save_message(
                                "system",
                                f"🌙 **NIGHT SHIFT COMPLETADO**\nLa misión en segundo plano ha finalizado con éxito.\n*Objetivo:* `{goal}`",
                                "MissionWorker",
                                "general",
                            )

                        # SCRIBE HOOK (Auto-Documentation)
                        try:
                            scribe_summary = (
                                f"## Mission {mid}: {goal}\nCompleted at {time.ctime()}\n\n### Steps:\n"
                                + "\n".join(steps)
                            )
                            log_path = os.path.join(
                                get_user_root(), "workspace", "DEVELOPMENT_LOG.md"
                            )
                            with open(log_path, "a", encoding="utf-8") as f:
                                f.write(f"\n\n{scribe_summary}")
                        except Exception as e:
                            self.logger.error(f"Scribe Failed: {e}")

                        continue

                    step_text = steps[curr_step_idx]
                    self.logger.info(
                        f"Executing Mission {mid} Step {curr_step_idx + 1}: {step_text}"
                    )

                    # Log Start
                    database.update_mission_progress(
                        mid,
                        curr_step_idx,
                        f"STARTED Step {curr_step_idx + 1}: {step_text}",
                        "running",
                    )

                    # BUILD CONTEXT FROM LOGS
                    context_str = "\n".join(logs_json[-5:])  # Last 5 logs

                    if self.brain:
                        self.logger.info("NightShift: Procesando Paso")

                        is_repair = "auto-reparación" in goal.lower()
                        is_subagent = "[SUBAGENT_MISSION]" in goal

                        if is_subagent:
                            worker_model = "specialist:coder"
                            worker_prompt = f"Eres un subagente técnico anónimo. Tu única misión es: {step_text}. No hables con el usuario. Usa herramientas. Tu respuesta final será reportada al agente orquestador.\nLOG: {context_str}"
                        elif is_repair:
                            # Inyectamos el prompt de reparación
                            try:
                                from core_engine.prompts import get_repair_prompt

                                worker_model = "specialist:logic"
                                worker_prompt = get_repair_prompt(
                                    step_text, context_str
                                )
                            except (ImportError, Exception):
                                worker_model = "specialist:logic"
                                worker_prompt = (
                                    f"REPAIR MODE: {step_text}\nLOG: {context_str}"
                                )
                        else:
                            worker_model = "specialist:coder"
                            worker_prompt = (
                                f"MISSION MODE: {step_text}\nLOG: {context_str}"
                            )

                        try:
                            # Ejecutar query con el modelo y prompt seleccionados
                            action_resp = self.brain.query(
                                worker_prompt, [], worker_model
                            )

                            result_str = str(action_resp)

                            # Auto-ejecución de JSON si el modelo generó uno
                            json_match = re.search(r"(\{.*\})", result_str, re.DOTALL)
                            tdd_failed = False
                            if json_match:
                                t_data = json.loads(json_match.group(1))
                                if "module" in t_data:
                                    mod = t_data["module"]
                                    self.logger.info(f"NightShift Tool Invoked: {mod}")
                                    res = self.brain.module_manager.execute_module(
                                        mod, t_data, brain_instance=self.brain
                                    )
                                    result_str = f"Tool Result: {str(res)}"

                                    # --- TDD FORCED CYCLE ---
                                    action_name = t_data.get("action", "")
                                    args = t_data.get("args", {})
                                    filename = t_data.get("filename", "") or t_data.get(
                                        "path", ""
                                    )
                                    if not filename and isinstance(args, dict):
                                        filename = args.get("filename", "") or args.get(
                                            "path", ""
                                        )

                                    if (
                                        (
                                            "write" in action_name
                                            or "create" in action_name
                                        )
                                        and filename
                                        and filename.endswith(".py")
                                    ):
                                        import subprocess

                                        ws_root = os.path.join(
                                            get_user_root(), "workspace"
                                        )
                                        full_path = (
                                            os.path.join(ws_root, filename)
                                            if not os.path.isabs(filename)
                                            else filename
                                        )

                                        if os.path.exists(full_path):
                                            chk = subprocess.run(
                                                [
                                                    "python",
                                                    "-m",
                                                    "py_compile",
                                                    full_path,
                                                ],
                                                capture_output=True,
                                                text=True,
                                            )
                                            if chk.returncode != 0:
                                                error_msg = f"[SYSTEM: Syntax Error Detected. Stderr: {chk.stderr}. FIX THIS IMMEDIATELY.]"
                                                database.update_mission_progress(
                                                    mid,
                                                    curr_step_idx,  # No avanza paso
                                                    error_msg,
                                                    "running",
                                                )
                                                tdd_failed = True

                            if not tdd_failed:
                                # Avanzar de paso
                                database.update_mission_progress(
                                    mid,
                                    curr_step_idx + 1,
                                    f"OK: {result_str}...",
                                    "running",
                                )

                        except Exception as e:
                            self.logger.error(f"Mission Step Failed: {e}")
                            # Auto-Retry log
                            database.update_mission_progress(
                                mid,
                                curr_step_idx,
                                f"⚠️ Retry needed: {str(e)}",
                                "running",
                            )

                    time.sleep(2)

            except Exception as e:
                self.logger.error(f"MissionWorker Loop Error: {e}")

            if self.stop_event.wait(5):
                break

        if daemon_id in self.active_threads:
            del self.active_threads[daemon_id]

    def _task_workspace_watchdog(self, config):
        """
        Oracle Live: Monitors /workspace for file changes (The Forge Uplink).
        Smart indexing: Only re-indexes files changed since last check.
        """
        from modules.utils import get_user_root
        # os and time imported globally

        workspace_root = os.path.join(get_user_root(), "workspace")
        if not os.path.exists(workspace_root):
            return

        # State persistence (simple dict in memory or file?)
        # For robustness across restarts, file is better, but memory is faster for daemon loop.
        # We'll use a hidden JSON in .aegis/
        state_file = os.path.join(get_user_root(), ".aegis", "oracle_watch_state.json")

        known_state = {}
        if os.path.exists(state_file):
            try:
                with open(state_file, "r") as f:
                    known_state = json.load(f)
            except Exception:
                pass

        current_state = {}
        changes_detected = []

        # Recursive scan (limit depth/files for performance?)
        # We'll stick to top 2 levels or just walk all but exclude git/deps
        for root, dirs, files in os.walk(workspace_root):
            if ".git" in dirs:
                dirs.remove(".git")
            if "node_modules" in dirs:
                dirs.remove("node_modules")
            if "__pycache__" in dirs:
                dirs.remove("__pycache__")
            if "venv" in dirs:
                dirs.remove("venv")

            for file in files:
                if file.endswith(
                    (".py", ".js", ".ts", ".html", ".css", ".md", ".json", ".txt")
                ):
                    filepath = os.path.join(root, file)
                    mtime = os.path.getmtime(filepath)
                    rel_path = os.path.relpath(filepath, workspace_root)

                    current_state[rel_path] = mtime

                    # Check change
                    last_mtime = known_state.get(rel_path)

                    if last_mtime is None:
                        # New File -> Index
                        changes_detected.append((rel_path, "NEW"))
                    elif mtime > last_mtime:
                        # Modified -> Re-Index
                        changes_detected.append((rel_path, "MODIFIED"))

        # Limit processing per tick
        processed_count = 0
        # from modules.vault_manager import vault

        import difflib

        for path, change_type in changes_detected:
            if processed_count > 5:
                break  # Throttle

            full_path = os.path.join(workspace_root, path)
            try:
                # Read content
                content = ""
                with open(full_path, "r", encoding="utf-8", errors="ignore") as f:
                    content = f.read()

                # THE SCRIBE: Generate Diff if Modified
                diff_summary = "Content Loaded."
                if change_type == "MODIFIED":
                    old_content = self.watchdog_cache.get(path, "")
                    if old_content:
                        # Generate Unified Diff
                        diff = difflib.unified_diff(
                            old_content.splitlines(),
                            content.splitlines(),
                            fromfile=f"a/{path}",
                            tofile=f"b/{path}",
                            lineterm="",
                        )
                        # Simple summary: First 10 lines of diff
                        diff_lines = list(diff)
                        diff_summary = "\n".join(diff_lines[:15])
                        if len(diff_lines) > 15:
                            diff_summary += "\n(truncated...)"

                # Update Cache
                self.watchdog_cache[path] = content

                # Index into Session RAG (Live Memory)
                # vault.index_text(content, "session_rag", {"source": "oracle_live", "file": path, "type": change_type})

                # FEEDBACK UI: Insert into Unifying History
                msg_text = f"User edited **{path}**.\nDiff Summary:\n```diff\n{diff_summary}\n```"
                database.save_message("system", msg_text, "IDE_SYNC", "general")

                processed_count += 1

                # Custom logging already handled above
                self.logger.info(
                    f"📄 Oracle: {path} ({change_type}) synced (Diff logged)."
                )
            except Exception as e:
                self.logger.error(f"Oracle Index Error {path}: {e}")

        # Save new state
        if changes_detected:
            with open(state_file, "w") as f:
                json.dump(current_state, f)

    def _task_soul_sync(self):
        """
        Cross-Backup Daemon: Syncs the Hub's soul to active satellites.
        """
        self.logger.info("🌀 Daemon: Checking for Soul Sync opportunities...")
        try:
            nodes = database.get_all_nodes()
            online_nodes = [
                n for n in nodes if n["status"] == "online" and "limb" in n["node_id"]
            ]

            if not online_nodes:
                return

            from modules.soul_sync import soul_sync

            for node in online_nodes:
                self.logger.info(
                    f"🌀 Daemon: Initiating Cross-Backup to {node['node_id']}..."
                )
                success, msg = soul_sync.perform_cross_backup(node["node_id"])
                if success:
                    self.logger.info(
                        f"✅ Daemon: Cross-Backup to {node['node_id']} successful."
                    )
                else:
                    self.logger.error(
                        f"❌ Daemon: Cross-Backup to {node['node_id']} failed: {msg}"
                    )

        except Exception as e:
            self.logger.error(f"Daemon Soul Sync Error: {e}")

    def _task_auto_cron(self, config):
        """Ejecuta una tarea recurrente definida por lenguaje natural."""
        goal = config.get("goal")
        self.logger.info(f"⏰ AutoCron Executing: {goal}")

        if self.brain:
            # Reutilizamos la lógica de Misión: Crear una misión efímera
            # Esto permite que use herramientas, escriba código, etc.

            # 1. Planificar (Simple)
            steps = [f"Execute: {goal}"]

            # 2. Inyectar en tabla de misiones
            database.create_mission(f"[RECURRING] {goal}", steps)

            # 3. Despertar al worker principal para que la procese
            database.set_daemon_status("mission_worker", "RUNNING")


# Global Instance & Auto-Start
daemon_manager = DaemonManager()
