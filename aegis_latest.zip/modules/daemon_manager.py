import threading
import time
import json
import logging
import requests
import database
import os
from modules.utils import get_user_root

# Standard Libraries that are safe to import
from modules.resource_monitor import monitor
from modules import notifier

# Safe imports for optional libraries
try:
    import schedule
except ImportError:
    schedule = None
    logging.getLogger("DaemonManager").warning(
        "Module 'schedule' not found. Daily Briefing daemon will be disabled."
    )

try:
    from gtts import gTTS
except ImportError:
    gTTS = None
    logging.getLogger("DaemonManager").warning(
        "Module 'gTTS' not found. Audio features disabled."
    )


class DaemonManager:
    def __init__(self):
        self.active_threads = {}  # daemon_id -> thread
        self._brain = None
        self.stop_event = threading.Event()
        self.logger = logging.getLogger("DaemonManager")
        self.started = False
        self.watchdog_cache = {}  # path -> content (for diff generation)

    @property
    def brain(self):
        """Lazy Load AegisBrain to prevent circular imports."""
        if self._brain is None:
            # CIRCULAR IMPORT FIX: Import inside method
            try:
                from core import AegisBrain

                self._brain = AegisBrain()
            except ImportError:
                self.logger.critical(
                    "Failed to import AegisBrain from core. Application structure invalid."
                )
                return None
        return self._brain

    def start(self):
        """Starts the main management loop in a background thread."""
        if not self.started:
            # --- THE FORGE PROTOCOL: Auto-Sync AI State ---
            try:
                import modules.ide_bridge

                res = modules.ide_bridge.sync_ai_config()
                if res.get("status") == "success":
                    self.logger.info(f"Forge Bridge Synced: {res.get('path')}")
                else:
                    self.logger.warning(f"Forge Bridge: {res.get('message')}")
            except Exception as e:
                self.logger.error(f"Forge Bridge Init Failed: {e}")

            manager_thread = threading.Thread(target=self._manager_loop, daemon=True)
            manager_thread.start()
            self.started = True

            # RECOVERY: Restart Pending Missions (that died during crash)
            try:
                missions = database.get_active_missions()
                for m in missions:
                    if m["status"] == "running":
                        self.logger.info(
                            f"[MISSION RECOVERY] Resuming Mission {m['id']}..."
                        )
                        # Ensure daemon running
                        database.set_daemon_status("mission_worker", "RUNNING")
            except Exception:
                pass

            self.logger.info("Daemon Manager started.")

    def stop(self):
        """Stops the manager and all daemons."""
        self.stop_event.set()

    # --- API Methods for UI/Other Modules ---
    def register_daemon(self, name, task_type, config, interval=60):
        """Registers a new daemon in the database and starts it."""
        try:
            config_str = json.dumps(config)
            result = database.register_daemon_db(name, task_type, interval, config_str)
            return result
        except Exception as e:
            return f"Error registering daemon: {e}"

    def list_daemons(self):
        """Returns list of daemons as dicts."""
        try:
            rows = database.get_daemons()
            daemons = []
            for r in rows:
                # id, name, task_type, status, interval, config, last_run
                daemons.append(
                    {
                        "id": r[0],
                        "name": r[1],
                        "type": r[2],  # task_type
                        "status": r[3],
                        "interval": r[4],
                        "config": r[5],
                        "last_run": r[6],
                    }
                )
            return daemons
        except Exception as e:
            self.logger.error(f"Error listing daemons: {e}")
            return []

    def stop_daemon(self, name):
        """Stops a daemon by name."""
        try:
            database.set_daemon_status(name, "STOPPED")
            return f"Daemon {name} stopped."
        except Exception as e:
            return f"Error stopping daemon: {e}"

    def start_daemon(self, name):
        """Starts a daemon by name."""
        try:
            database.set_daemon_status(name, "RUNNING")
            return f"Daemon {name} started."
        except Exception as e:
            return f"Error starting daemon: {e}"

    # --- Internal Management Logic ---
    def _manager_loop(self):
        """Polls database every 5s to manage daemon threads."""
        while not self.stop_event.is_set():
            try:
                # [(id, name, task_type, status, interval, config, last_run), ...]
                daemons = database.get_daemons()

                for d in daemons:
                    d_id = d[0]
                    name = d[1]
                    status = d[3]

                    if status == "RUNNING":
                        if (
                            d_id not in self.active_threads
                            or not self.active_threads[d_id].is_alive()
                        ):
                            # Start new thread
                            self.logger.info(f"Starting daemon {name} (ID: {d_id})")
                            t = threading.Thread(
                                target=self.run_loop, args=(d_id,), daemon=True
                            )
                            self.active_threads[d_id] = t
                            t.start()
                    else:
                        # Ensure it's not in active threads (handled by run_loop check usually)
                        pass

            except Exception as e:
                self.logger.error(f"Error in manager loop: {e}")

            # Wait 5s (check frequently for UI responsiveness)
            if self.stop_event.wait(5):
                break

    def run_loop(self, daemon_id):
        """Executes the specific task loop for a daemon."""
        self.logger.info(f"Daemon {daemon_id} loop started.")

        # Initial Check for Scheduler Logic
        d_info = database.get_daemon(daemon_id)
        if not d_info:
            return
        d_id, name, task_type, status, interval, config_str = d_info

        if task_type == "daily_briefing":
            if schedule:
                self._run_scheduler_loop(daemon_id, config_str)
            else:
                self.logger.error(
                    "Daemon 'daily_briefing' cannot run: 'schedule' library missing."
                )
            return

        # Special Case: Mission Worker (High Frequency)
        if task_type == "mission_worker":
            self._run_mission_worker_loop(daemon_id, config_str)
            return

        # Standard Interval Loop
        while not self.stop_event.is_set():
            # Refresh info to check status
            # Refresh info to check status
            d_info = database.get_daemon(daemon_id)
            if not d_info:
                break
            _, _, _, status, interval, config_str = d_info

            if status != "RUNNING":
                break

            # Execute Task
            try:
                self._execute_task(task_type, config_str)
                database.update_daemon_last_run(daemon_id)
            except Exception as e:
                self.logger.error(f"Error in daemon {name}: {e}")

            # Wait interval
            # Wait interval
            if self.stop_event.wait(interval):
                break

        # Cleanup
        if daemon_id in self.active_threads:
            del self.active_threads[daemon_id]

    def _run_scheduler_loop(self, daemon_id, config_str):
        """Dedicated loop for Schedule-based tasks."""
        config = json.loads(config_str) if config_str else {}
        target_time = config.get("time", "08:00")

        # Create local scheduler instance
        local_scheduler = schedule.Scheduler()

        def job():
            self.logger.info(f"Executing Scheduled Task for Daemon {daemon_id}")
            try:
                self._execute_task("daily_briefing", config_str)
                database.update_daemon_last_run(daemon_id)
            except Exception as e:
                self.logger.error(f"Scheduled Job Failed: {e}")

        try:
            local_scheduler.every().day.at(target_time).do(job)
            self.logger.info(f"Protocol Daemon Scheduled at {target_time}")
        except Exception as e:
            self.logger.error(f"Failed to schedule job: {e}")
            return

        while not self.stop_event.is_set():
            d_info = database.get_daemon(daemon_id)
            if not d_info or d_info[3] != "RUNNING":
                break

            try:
                local_scheduler.run_pending()
            except Exception as e:
                self.logger.error(f"Scheduler Tick Error: {e}")

            if self.stop_event.wait(1):
                break

        if daemon_id in self.active_threads:
            del self.active_threads[daemon_id]

    def _execute_task(self, task_type, config_str):
        """Dispatches to specific logic based on task_type."""
        config = json.loads(config_str) if config_str else {}

        if task_type == "resource_watcher":
            self._task_resource_watcher(config)
        elif task_type == "folder_guard":
            self._task_folder_guard(config)
        elif task_type == "web_sentinel":
            self._task_web_sentinel(config)
        elif task_type == "daily_briefing":
            self._task_daily_briefing(config)
        elif task_type == "chronos_optimizer":
            self._task_chronos_optimizer(config)
        elif task_type == "vision_watchdog":
            self._task_vision_watchdog(config)
        elif task_type == "workspace_watchdog":
            self._task_workspace_watchdog(config)
        elif task_type == "security_sentinel":
            self._task_security_sentinel(config)
        elif task_type == "soul_sync":
            self._task_soul_sync()
        else:
            self.logger.warning(f"Unknown daemon task type: {task_type}")

    def _task_vision_watchdog(self, config):
        """Active Vision: Monitors /workspace/screenshots for new images."""
        import glob
        # time imported globally

        # Path logic
        watch_dir = os.path.join(get_user_root(), "workspace", "screenshots")
        if not os.path.exists(watch_dir):
            return  # Nothing to watch yet

        # Get all png/jpg
        files = glob.glob(os.path.join(watch_dir, "*.*"))
        images = [
            f
            for f in files
            if f.lower().endswith((".png", ".jpg", ".jpeg"))
            and "processed_" not in os.path.basename(f)
        ]

        if not images:
            return

        # Process 1 image per tick to avoid overload
        target_img = images[0]
        filename = os.path.basename(target_img)
        self.logger.info(f"👁️ Vision Watchdog: Analyzing {filename}...")

        try:
            # 1. Image Analysis
            if self.brain:
                # Determine Model (Cloud vs Local)
                # We check raw settings directly to avoid overhead
                op_mode = database.get_setting("operation_mode") or "Hybrid"

                # Default to Cloud for speed/quality if allowed
                use_local = "Local" in op_mode

                description = ""

                if not use_local:
                    # CLOUD (Gemini)
                    try:
                        import google.generativeai as genai
                        from PIL import Image

                        img_obj = Image.open(target_img)

                        api_key = database.get_setting("api_key_gemini")
                        if api_key and str(api_key).startswith("AI"):
                            genai.configure(api_key=api_key)
                            model = genai.GenerativeModel("gemini-1.5-flash")
                            resp = model.generate_content(
                                [
                                    "Describe this image specifically for an AI assistant. Key elements, text, context.",
                                    img_obj,
                                ]
                            )
                            description = resp.text
                    except Exception as e:
                        self.logger.error(f"Cloud Vision Failed: {e}")
                        use_local = True  # Fallback

                if use_local or not description:
                    # LOCAL (Llava / Moondream)
                    # Use Ollama via Brain
                    # We need to read image bytes or path? Ollama API takes base64 usually
                    # But core.py query_ollama doesn't support images natively yet in this version unless updated.
                    # Current core.py `query_ollama` payload structure: "model", "prompt", "stream".
                    # It DOES NOT handle 'images' key in payload in the viewed version.
                    # Workaround: Use 'ollama' CLI directly or assume core update?
                    # Phase 10 implies we add this.
                    # Let's use `subprocess` to call `ollama run list` to check model
                    # and then `ollama run moondream "Describe this image" < path`? No, CLI is interactive.
                    # We can use the HTTP API manually here.

                    import base64

                    with open(target_img, "rb") as img_file:
                        b64_data = base64.b64encode(img_file.read()).decode("utf-8")

                    local_model = (
                        database.get_setting("local_vision_model") or "moondream"
                    )  # Dynamic model selection
                    # Check if installed?
                    # payload
                    payload = {
                        "model": local_model,
                        "prompt": "Describe this image in detail.",
                        "images": [b64_data],
                        "stream": False,
                    }
                    try:
                        res = requests.post(
                            f"{self.brain.ollama_host}/api/generate",
                            json=payload,
                            timeout=60,
                        )
                        if res.status_code == 200:
                            description = res.json().get("response", "")
                        else:
                            description = f"Local Vision Error: {res.text}"
                    except Exception:
                        description = "Vision unavailable (Cloud failed, Local Moondream unreachable)."

                # 2. Inject to Session RAG (Vault)
                from modules.vault_manager import vault

                vault.index_text(
                    f"Image Analysis [{filename}]: {description}",
                    "session_rag",
                    {"source": "vision_watchdog", "file": filename},
                )

                # 3. Notify User
                # We use a system message with a specific tag that the UI can pick up as a toast
                # Or just a general "Vision" tag
                database.save_message(
                    "system",
                    f"👁️ **Detección Visual**: {description[:150]}...",
                    "Vision",
                    "general",
                )

                # 4. Mark Processed (Rename)
                new_path = os.path.join(watch_dir, f"processed_{filename}")
                os.rename(target_img, new_path)
                self.logger.info(f"Vision Complete: {description[:50]}...")

        except Exception as e:
            self.logger.error(f"Vision Watchdog Error: {e}")

    def _task_daily_briefing(self, config):
        """Protocol Dawn: Daily Briefing Generator."""

        if not gTTS:
            self.logger.warning("Daily Briefing skipped: gTTS not installed.")
            return

        self.logger.info("☀️ Generating Daily Briefing...")

        # 1. Weather
        try:
            weather = requests.get("https://wttr.in/?format=3", timeout=5).text.strip()
        except Exception:
            weather = "Clima no disponible."

        # 2. Tasks
        pending = database.get_pending_tasks(limit=3)
        if pending:
            task_summary = f"Tienes {len(pending)} tareas pendientes. Prioridad alta: {pending[0]['task']}."
        else:
            task_summary = "No hay tareas pendientes."

        # 3. System
        health = monitor.check_health()
        mem = monitor.get_metrics()["app_ram_usage_mb"]

        # 4. Projects
        projects = database.get_active_projects()
        proj_text = (
            f"Proyectos activos: {', '.join(projects)}."
            if projects
            else "Sin proyectos activos."
        )

        # Script
        script = f"Buenos días. Protocolo Amanecer iniciado. {weather}. Estado del sistema: {health}, uso de RAM {mem} megabytes. {task_summary} {proj_text} Que tengas un día productivo."

        # TTS
        try:
            tts = gTTS(text=script, lang="es")

            # SAFE TMP PATH
            # SAFE TMP PATH
            tmp_dir = os.path.join(get_user_root(), "tmp")
            os.makedirs(tmp_dir, exist_ok=True)

            audio_file = os.path.join(tmp_dir, "briefing_today.mp3")
            try:
                tts.save(audio_file)
            except PermissionError:
                # Fallback if file is locked
                audio_file = os.path.join(tmp_dir, f"briefing_{int(time.time())}.mp3")
                tts.save(audio_file)

            # Send via Telegram
            notifier.send_telegram_audio(
                audio_file,
                caption=f"☀️ **Briefing del Día**\n{weather}\nTasks: {len(pending)}",
            )
            self.logger.info(f"Briefing sent. Script: {script[:50]}...")

        except Exception as e:
            self.logger.error(f"Briefing Generation Failed: {e}")

    def _task_chronos_optimizer(self, config):
        """Protocol Chronos: Background Memory Consolidation (Self-Healing)."""
        # 1. Check Idle Time (Simulated via last_run or database timestamp)
        # In a real app, we'd check 'last_user_interaction' in DB settings
        last_interact_str = database.get_setting("last_interaction_ts")
        if not last_interact_str:
            return

        try:
            import datetime

            last_ts = datetime.datetime.fromisoformat(last_interact_str)
            minutes_idle = (datetime.datetime.now() - last_ts).total_seconds() / 60

            if minutes_idle < 10:
                return  # Not idle enough

        except Exception:
            return

        self.logger.info(
            "⏳ ChronosOptimizer: System Idle > 10m. Consolidating Memory..."
        )

        # 2. Fetch recent Audit Logs & Chat
        logs = database.get_audit_logs(limit=20)
        history = database.get_history(limit=10)

        # 3. Generate Summary
        if self.brain:
            prompt = f"""
            [ROLE: SYSTEM MAINTAINER]
            Analyze these recent logs and chats:
            LOGS: {json.dumps([lg[1] + ":" + lg[2] for lg in logs])}
            CHATS: {str([(h[1], h[2]) for h in history])}
            
            Generate a brief 'State of Consciousness' summary (1 sentence) for when the user returns.
            Example: 'Optimized 12 memory fragments and detecting coding patterns in recent sessions.'
            """
            try:
                summary = self.brain.query(prompt, [], "gemini-1.5-flash")

                # 4. Store in User Metadata (to be read by UI on wakeup)
                database.add_user_fact("system_state_summary", summary, "chronos", 1.0)

                # Log action
                database.log_audit_event(
                    "Chronos",
                    "Memory Optimization",
                    "SUCCESS",
                    details=summary,
                    approved=True,
                )
                self.logger.info(f"Chronos Complete: {summary}")

            except Exception as e:
                self.logger.error(f"Chronos Failed: {e}")

    def _task_resource_watcher(self, config):
        metrics = monitor.get_metrics()
        limit = config.get("min_ram_mb", 500)
        available_mb = metrics["ram_available_gb"] * 1024

        # CRITICAL CHECK (The Hive Protocol 21)
        critical_ram = 200  # MB

        if available_mb < critical_ram:
            prompt = f"SYSTEM CRITICAL ALERT: Available RAM is extremely low ({available_mb:.2f}MB). Risk of system crash. As The Hive, analyze processes and propose IMMEDIATE REMEDIATION."
            # Invoke The Hive
            if self.brain:
                response = self.brain.query(
                    prompt, [], model_choice_arg="gemini-1.5-pro", hive_override=True
                )
                notifier.send_telegram_alert(
                    f"⚠️ **CRITICAL RAM FAILURE** ⚠️\n\n{response}"
                )
                database.log_audit_event(
                    "ResourceWatcher",
                    "CRITICAL_RAM",
                    "ALARM",
                    details="Hive Protocol Invoked",
                    approved=True,
                )
            else:
                self.logger.error("Brain unavailable for Critical RAM Alert.")

        elif available_mb < limit:
            # Standard Low RAM Logic
            if self.brain:
                prompt = f"Available RAM is low: {available_mb:.2f}MB (Limit: {limit}MB). Suggest 1 immediate action."
                response = self.brain.query(
                    prompt, [], model_choice_arg="gemini-1.5-flash", profile="Efficient"
                )
                database.log_audit_event(
                    "ResourceWatcher",
                    "Low RAM Alert",
                    "WARNING",
                    details=response,
                    approved=True,
                )

    def _task_folder_guard(self, config):
        path = config.get("path", ".")
        if os.path.exists(path):
            try:
                files = os.listdir(path)
                file_count = len(files)

                # CRITICAL INTRUSION / CLUTTER
                if file_count > 100:
                    if self.brain:
                        prompt = f"SECURITY ALERT: Directory '{path}' has {file_count} files. This exceeds safe thresholds. As The Hive (Security & Engineering), analyze if this is a malicious intrusion or data dump and propose CLEANUP."
                        response = self.brain.query(
                            prompt,
                            [],
                            model_choice_arg="gemini-1.5-pro",
                            hive_override=True,
                        )

                        notifier.send_telegram_alert(
                            f"🚨 **FILE INTRUSION DETECTED** 🚨\n\n{response}"
                        )
                        database.log_audit_event(
                            "FolderGuard",
                            "CRITICAL_INTRUSION",
                            "ALARM",
                            details="Hive Protocol Invoked",
                            approved=True,
                        )

                elif file_count > 50:
                    # Standard Warning
                    if self.brain:
                        prompt = f"Dir {path} has {file_count} files. Analyze if this is clutter. Reply Yes/No."
                        response = self.brain.query(
                            prompt, [], model_choice_arg="gemini-1.5-flash"
                        )
                        if "Yes" in response:
                            database.log_audit_event(
                                "FolderGuard",
                                "Clutter Detected",
                                "WARNING",
                                details=f"{path}: {file_count} files",
                                approved=True,
                            )
            except Exception as e:
                self.logger.error(f"Folder Guard Error: {e}")

    def _task_web_sentinel(self, config):
        url = config.get("url", "https://google.com")
        try:
            r = requests.get(url, timeout=10)
            if r.status_code != 200:
                if self.brain:
                    prompt = f"URL {url} status {r.status_code}. Diagnose briefly."
                    response = self.brain.query(
                        prompt, [], model_choice_arg="gemini-1.5-flash"
                    )
                    database.log_audit_event(
                        "WebSentinel",
                        "Error",
                        "FAILURE",
                        details=response,
                        approved=True,
                    )
        except Exception as e:
            database.log_audit_event(
                "WebSentinel",
                "Connection Fail",
                "FAILURE",
                details=str(e),
                approved=True,
            )

    def _task_security_sentinel(self, config):
        """Monitors dependencies for vulnerabilities (Tech Watchdog)."""
        import os
        from modules.utils import get_user_root

        workspace = os.path.join(get_user_root(), "workspace")
        if not os.path.exists(workspace):
            return

        # 1. Scan requirements.txt / package.json
        req_file = os.path.join(workspace, "requirements.txt")
        # pkg_file = os.path.join(workspace, "package.json")

        vuln_report = []

        # Simple Logic: Check for known ancient versions or explicit TODOs
        # In a real scenario, this would import 'safety' or query an API

        if os.path.exists(req_file):
            try:
                with open(req_file, "r") as f:
                    reqs = f.readlines()
                    for r in reqs:
                        if "==" in r and "flask" in r.lower():
                            ver = r.split("==")[1].strip()
                            if ver.startswith("0.") or ver.startswith(
                                "1.0"
                            ):  # Archaic example
                                vuln_report.append(
                                    f"Flask v{ver} is deprecated. Upgrade to 2.x+"
                                )
            except Exception:
                pass

        if vuln_report:
            if self.brain:
                # Ingest to System
                alert_msg = (
                    f"⚠️ **SECURITY SENTINEL**: Detected {len(vuln_report)} risks:\n"
                    + "\n".join(vuln_report)
                )
                database.save_message("system", alert_msg, "Sentinel", "general")
                self.logger.warning(alert_msg)

    def _run_mission_worker_loop(self, daemon_id, config_str):
        """Worker loop for executing autonomous missions in background. Supports persistent state & sleeping."""
        self.logger.info("🤖 MissionWorker Started (Persistent Mode).")
        import time

        last_check_in = time.time()

        while not self.stop_event.is_set():
            # Check Status
            d_info = database.get_daemon(daemon_id)
            if not d_info or d_info[3] != "RUNNING":
                break

            try:
                # 0. TELEGRAM CHECK-IN (Every 4 Hours)
                if time.time() - last_check_in > 14400:  # 4h in seconds
                    active_count = len(database.get_active_missions())
                    if active_count > 0:
                        try:
                            # Notifier import safety
                            from modules import notifier

                            notifier.send_telegram_alert(
                                f"🛡️ **Pixel Sentinel Status**\nActive Missions: {active_count}\nSystem Uptime: OK."
                            )
                            self.logger.info("Sent 4h Check-in.")
                        except Exception:
                            pass
                    last_check_in = time.time()

                # 1. Fetch Active Missions (Running OR Sleeping)
                # We need to fetch 'sleeping' ones too to check wake conditions
                missions = database.get_active_missions()

                if not missions:
                    time.sleep(5)  # Idle backoff
                    continue

                for m in missions:
                    mid = m["id"]

                    # SLEEP LOGIC
                    if m.get("status") == "sleeping":
                        # Check wake condition (e.g. time passed, or event)
                        # For now, simple time-based sleep in metadata?
                        # Assuming metadata stores 'wake_time'
                        meta = m.get("metadata", {})
                        wake_time = meta.get("wake_time", 0)

                        if time.time() > wake_time:
                            self.logger.info(f"⏰ Waking Mission {mid}...")
                            database.update_mission_status(mid, "running")
                        else:
                            continue  # Still sleeping

                    # Execution Logic
                    goal = m["goal"]
                    steps = m["steps"]
                    curr_step_idx = m["step_idx"]
                    logs_json = m["logs"]

                    if curr_step_idx >= len(steps):
                        database.complete_mission(mid)
                        self.logger.info(f"Mission {mid} Complete")

                        database.save_message(
                            "system",
                            f"🏁 Misión Finalizada: {goal}",
                            "MissionWorker",
                            "general",
                        )

                        # SCRIBE HOOK (Auto-Documentation)
                        try:
                            scribe_summary = (
                                f"## Mission {mid}: {goal}\nCompleted at {time.ctime()}\n\n### Steps:\n"
                                + "\n".join(steps)
                            )
                            log_path = os.path.join(
                                get_user_root(), "workspace", "DEVELOPMENT_LOG.md"
                            )
                            with open(log_path, "a", encoding="utf-8") as f:
                                f.write(f"\n\n{scribe_summary}")
                        except Exception as e:
                            self.logger.error(f"Scribe Failed: {e}")

                        continue

                    step_text = steps[curr_step_idx]
                    self.logger.info(
                        f"Executing Mission {mid} Step {curr_step_idx + 1}: {step_text}"
                    )

                    # Log Start
                    database.update_mission_progress(
                        mid,
                        curr_step_idx,
                        f"STARTED Step {curr_step_idx + 1}: {step_text}",
                        "running",
                    )

                    # BUILD CONTEXT FROM LOGS
                    context_str = "\n".join(logs_json[-5:])  # Last 5 logs

                    if self.brain:
                        # ENHANCED PROMPT FOR LONG-DURATION
                        prompt = f"""
                        [SYSTEM_AUTO_EXEC | MISSION ID: {mid}]
                        Goal: {goal}
                        Step {curr_step_idx + 1}/{len(steps)}: {step_text}
                        Recent Logs: {context_str}
                        
                        INSTRUCTION: Return JSON action.
                        If you need to wait for a long process (e.g. API response, file download, human input), return:
                        {{"module": "system", "action": "sleep", "args": {{"minutes": 60, "reason": "Waiting for X"}}}}
                        
                        If step complete, return result or next action.
                        """
                        try:
                            # Use logic model for plan
                            action_resp = self.brain.query(
                                prompt, [], "specialist:logic"
                            )

                            # Parse JSON
                            import re

                            tm = re.search(r"\{.*\}", str(action_resp), re.DOTALL)
                            result_str = "No action."

                            if tm:
                                t_data = json.loads(tm.group(0))

                                # HANDLE SLEEP
                                if t_data.get("action") == "sleep":
                                    mins = t_data.get("args", {}).get("minutes", 60)
                                    reason = t_data.get("args", {}).get(
                                        "reason", "Sleeping"
                                    )
                                    wake_ts = time.time() + (mins * 60)

                                    # Update Metadata with wake_time
                                    # (Requires DB support for metadata update, simulating via logic)
                                    # We will just use 'logs' to store wake info or add column.
                                    # For v1, we hack status update with payload if possible, or just hold thread?
                                    # No, must be async. We update status to 'sleeping' and store wake_time in metadata/logs.
                                    # Assuming update_mission_status can take metadata or we use a separate call.
                                    # We'll set status 'sleeping' and modify logic to read last log for wake time if needed,
                                    # OR better: add wake_time to mission table?
                                    # Let's keep it simple: Store wake_time in logs for now, loop checks it.

                                    # Implementation: Update status to 'sleeping', log the wake time
                                    database.update_mission_progress(
                                        mid,
                                        curr_step_idx,
                                        f"SLEEPING until {wake_ts}: {reason}",
                                        "sleeping",
                                        metadata={"wake_time": wake_ts},
                                    )
                                    self.logger.info(
                                        f"Mission {mid} sleeping for {mins}m."
                                    )
                                    continue

                                # HANDLE MODULE EXEC
                                if "module" in t_data:
                                    mod = t_data["module"]
                                    self.logger.info(f"Invoking Tool: {mod}")
                                    res = self.brain.module_manager.execute_module(
                                        mod, t_data, brain_instance=self.brain
                                    )
                                    result_str = str(res)
                                else:
                                    result_str = str(action_resp)
                            else:
                                result_str = str(action_resp)

                            # LOG RESULT & ADVANCE
                            # Only advance step if not sleeping/waiting
                            if "error" not in result_str.lower():
                                database.update_mission_progress(
                                    mid,
                                    curr_step_idx + 1,
                                    f"Result: {result_str[:200]}",
                                    "running",
                                )
                            else:
                                # Retry same step?
                                database.update_mission_progress(
                                    mid,
                                    curr_step_idx,
                                    f"Retrying due to error: {result_str[:100]}",
                                    "running",
                                )

                        except Exception as e:
                            self.logger.error(f"Mission Step Failed: {e}")
                            database.update_mission_progress(
                                mid, curr_step_idx, f"Error: {str(e)}", "running"
                            )

                    time.sleep(2)

            except Exception as e:
                self.logger.error(f"MissionWorker Loop Error: {e}")

            if self.stop_event.wait(5):
                break

        if daemon_id in self.active_threads:
            del self.active_threads[daemon_id]

    def _task_workspace_watchdog(self, config):
        """
        Oracle Live: Monitors /workspace for file changes (The Forge Uplink).
        Smart indexing: Only re-indexes files changed since last check.
        """
        from modules.utils import get_user_root
        # os and time imported globally

        workspace_root = os.path.join(get_user_root(), "workspace")
        if not os.path.exists(workspace_root):
            return

        # State persistence (simple dict in memory or file?)
        # For robustness across restarts, file is better, but memory is faster for daemon loop.
        # We'll use a hidden JSON in .aegis/
        state_file = os.path.join(get_user_root(), ".aegis", "oracle_watch_state.json")

        known_state = {}
        if os.path.exists(state_file):
            try:
                with open(state_file, "r") as f:
                    known_state = json.load(f)
            except Exception:
                pass

        current_state = {}
        changes_detected = []

        # Recursive scan (limit depth/files for performance?)
        # We'll stick to top 2 levels or just walk all but exclude git/deps
        for root, dirs, files in os.walk(workspace_root):
            if ".git" in dirs:
                dirs.remove(".git")
            if "node_modules" in dirs:
                dirs.remove("node_modules")
            if "__pycache__" in dirs:
                dirs.remove("__pycache__")
            if "venv" in dirs:
                dirs.remove("venv")

            for file in files:
                if file.endswith(
                    (".py", ".js", ".ts", ".html", ".css", ".md", ".json", ".txt")
                ):
                    filepath = os.path.join(root, file)
                    mtime = os.path.getmtime(filepath)
                    rel_path = os.path.relpath(filepath, workspace_root)

                    current_state[rel_path] = mtime

                    # Check change
                    last_mtime = known_state.get(rel_path)

                    if last_mtime is None:
                        # New File -> Index
                        changes_detected.append((rel_path, "NEW"))
                    elif mtime > last_mtime:
                        # Modified -> Re-Index
                        changes_detected.append((rel_path, "MODIFIED"))

        # Limit processing per tick
        processed_count = 0
        # from modules.vault_manager import vault

        import difflib

        for path, change_type in changes_detected:
            if processed_count > 5:
                break  # Throttle

            full_path = os.path.join(workspace_root, path)
            try:
                # Read content
                content = ""
                with open(full_path, "r", encoding="utf-8", errors="ignore") as f:
                    content = f.read()

                # THE SCRIBE: Generate Diff if Modified
                diff_summary = "Content Loaded."
                if change_type == "MODIFIED":
                    old_content = self.watchdog_cache.get(path, "")
                    if old_content:
                        # Generate Unified Diff
                        diff = difflib.unified_diff(
                            old_content.splitlines(),
                            content.splitlines(),
                            fromfile=f"a/{path}",
                            tofile=f"b/{path}",
                            lineterm="",
                        )
                        # Simple summary: First 10 lines of diff
                        diff_lines = list(diff)
                        diff_summary = "\n".join(diff_lines[:15])
                        if len(diff_lines) > 15:
                            diff_summary += "\n(truncated...)"

                # Update Cache
                self.watchdog_cache[path] = content

                # Index into Session RAG (Live Memory)
                # vault.index_text(content, "session_rag", {"source": "oracle_live", "file": path, "type": change_type})

                # FEEDBACK UI: Insert into Unifying History
                msg_text = f"User edited **{path}**.\nDiff Summary:\n```diff\n{diff_summary}\n```"
                database.save_message("system", msg_text, "IDE_SYNC", "general")

                processed_count += 1

                # Custom logging already handled above
                self.logger.info(
                    f"📄 Oracle: {path} ({change_type}) synced (Diff logged)."
                )
            except Exception as e:
                self.logger.error(f"Oracle Index Error {path}: {e}")

        # Save new state
        if changes_detected:
            with open(state_file, "w") as f:
                json.dump(current_state, f)

    def _task_soul_sync(self):
        """
        Cross-Backup Daemon: Syncs the Hub's soul to active satellites.
        """
        self.logger.info("🌀 Daemon: Checking for Soul Sync opportunities...")
        try:
            nodes = database.get_all_nodes()
            online_nodes = [
                n for n in nodes if n["status"] == "online" and "limb" in n["node_id"]
            ]

            if not online_nodes:
                return

            from modules.soul_sync import soul_sync

            for node in online_nodes:
                self.logger.info(
                    f"🌀 Daemon: Initiating Cross-Backup to {node['node_id']}..."
                )
                success, msg = soul_sync.perform_cross_backup(node["node_id"])
                if success:
                    self.logger.info(
                        f"✅ Daemon: Cross-Backup to {node['node_id']} successful."
                    )
                else:
                    self.logger.error(
                        f"❌ Daemon: Cross-Backup to {node['node_id']} failed: {msg}"
                    )

        except Exception as e:
            self.logger.error(f"Daemon Soul Sync Error: {e}")


# Global Instance & Auto-Start
daemon_manager = DaemonManager()
