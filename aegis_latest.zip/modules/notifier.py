import os
import requests
import database
import logging

logger = logging.getLogger("Notifier")

def send_telegram_alert(message):
    """Sends a critical alert via Telegram Bot API."""
    try:
        # Prio 1: Database Setting
        token = database.get_setting("telegram_token")
        chat_id = database.get_setting("telegram_chat_id")
        
        # Prio 2: Env Vars (Fallbacks)
        if not token:
            token = os.getenv("TELEGRAM_TOKEN")
        if not chat_id:
            chat_id = os.getenv("TELEGRAM_CHAT_ID")
            
        if not token or not chat_id:
            logger.warning("Telegram settings (token/chat_id) missing. Cannot send alert.")
            return False

        url = f"https://api.telegram.org/bot{token}/sendMessage"
        payload = {
            "chat_id": chat_id,
            "text": f"🚨 *HIVE PROTOCOL ALERT* 🚨\n\n{message}",
            "parse_mode": "Markdown"
        }
        
        resp = requests.post(url, json=payload, timeout=10)
        return resp.status_code == 200
        
    except Exception as e:
        logger.error(f"Failed to send Telegram alert: {e}")
        return False

def send_telegram_audio(audio_path, caption="Briefing"):
    """Sends an audio file via Telegram."""
    try:
        token = database.get_setting("telegram_token") or os.getenv("TELEGRAM_TOKEN")
        chat_id = database.get_setting("telegram_chat_id") or os.getenv("TELEGRAM_CHAT_ID")
        
        if not token or not chat_id: return False

        url = f"https://api.telegram.org/bot{token}/sendAudio"
        
        with open(audio_path, 'rb') as audio_file:
            files = {'audio': audio_file}
            data = {'chat_id': chat_id, 'caption': caption}
            resp = requests.post(url, data=data, files=files, timeout=60)
            return resp.status_code == 200
            
    except Exception as e:
        logger.error(f"Failed to send Telegram audio: {e}")
        return False
