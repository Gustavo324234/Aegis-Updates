# modules/resource_monitor.py
import psutil
import gc


class ResourceMonitor:
    def __init__(self):
        self.process = psutil.Process()
        import os

        # Read limit from env (Hypervisor injected) or default to 2000MB
        try:
            self.ram_limit_mb = int(os.environ.get("AEGIS_RAM_LIMIT_MB", 2000))
        except ValueError:
            self.ram_limit_mb = 2000

    def set_ram_limit(self, limit_mb):
        self.ram_limit_mb = limit_mb

    def get_gpu_info(self):
        """Detects presence of GPU and returns a factor."""
        gpu_factor = 0
        try:
            # Check for NVIDIA via torch if available
            import torch

            if torch.cuda.is_available():
                gpu_factor = 500
        except ImportError:
            # Fallback to checking nvidia-smi via subprocess
            import subprocess

            try:
                subprocess.check_output(["nvidia-smi"], stderr=subprocess.STDOUT)
                gpu_factor = 500
            except (subprocess.CalledProcessError, FileNotFoundError):
                pass
        return gpu_factor

    def get_metrics(self):
        """Returns a dict with current system metrics."""
        mem = psutil.virtual_memory()
        cpu_percent = psutil.cpu_percent(interval=None)  # Non-blocking
        cpu_count = psutil.cpu_count() or 1
        ram_total_gb = mem.total / (1024**3)

        # Current Process Memory
        proc_mem = self.process.memory_info().rss / (1024 * 1024)  # MB

        # GPU info
        gpu_factor = self.get_gpu_info()

        # Compute Score: (Cores * 100) + (RAM_GB * 50) + GPU_Factor
        compute_score = (cpu_count * 100) + (ram_total_gb * 50) + gpu_factor

        # Temperature (Best effort, mostly Linux/macOS, rare on Windows without admin/specific implementation)
        temp = "N/A"
        try:
            if hasattr(psutil, "sensors_temperatures"):
                temps = psutil.sensors_temperatures()
                if temps:
                    # Just grab the first available temp
                    for name, entries in temps.items():
                        if entries:
                            temp = f"{entries[0].current}°C"
                            break
        except Exception:
            pass

        return {
            "cpu_percent": cpu_percent,
            "ram_total_gb": round(ram_total_gb, 2),
            "ram_available_gb": round(mem.available / (1024**3), 2),
            "ram_used_percent": mem.percent,
            "app_ram_usage_mb": round(proc_mem, 2),
            "temperature": temp,
            "compute_score": round(compute_score, 2),
            "has_gpu": gpu_factor > 0,
        }

    def get_hardware_tier(self):
        """
        Classifies the PC into three tiers based on RAM:
        TIER 1 (Eco - <8GB RAM): Models 1B-3B. Context 2k.
        TIER 2 (Balanced - 8-16GB RAM): Models 7B-8B. Context 8k.
        TIER 3 (High-Perf - >16GB RAM): Models 14B-32B. Context 16k+.
        """
        mem = psutil.virtual_memory()
        total_ram_gb = mem.total / (1024**3)

        if total_ram_gb < 8:
            return 1, "TIER 1 (Eco)", "1B-3B", 2048
        elif total_ram_gb <= 16:
            return 2, "TIER 2 (Balanced)", "7B-8B", 8192
        else:
            return 3, "TIER 3 (High-Perf)", "14B-32B", 16384

    def get_status_metadata(self, profile="Balanced"):
        """Returns a string description of system health for the AI Context."""
        from modules.env_probe import probe

        metrics = self.get_metrics()

        sys_context = probe.get_system_context()

        status_str = f"""
[RESOURCE STATUS]
System: {sys_context}
Profile: {profile}
CPU: {metrics["cpu_percent"]}%
RAM Usage (App): {metrics["app_ram_usage_mb"]} MB (Limit: {self.ram_limit_mb} MB)
System RAM Available: {metrics["ram_available_gb"]} GB
Temperature: {metrics["temperature"]}
"""
        return status_str

    def check_health(self):
        """
        Checks system health and returns process status.
        Priority:
        1. Process Limit Reached -> HIBERNATE (Red)
        2. System Low -> RED/YELLOW
        """
        metrics = self.get_metrics()

        # 1. Check Process Quota (Hypervisor Limit)
        app_mem = metrics["app_ram_usage_mb"]
        if app_mem > self.ram_limit_mb:
            # Overdraft Protection
            self.emergency_cleanup()
            return "HIBERNATE"

        # 2. Check Global System Health
        available_gb = metrics["ram_available_gb"]
        status = "GREEN"

        # Thresholds (GB)
        # Red: < 0.15 GB (150MB)
        # Yellow: < 0.5 GB (500MB)
        if available_gb < 0.15:
            self.emergency_cleanup()
            return "RED"
        elif available_gb < 0.5:
            return "YELLOW"

        return status

    def emergency_cleanup(self):
        """Aggressively frees memory."""
        # 1. Python GC
        gc.collect()

        # 2. Streamlit Cache (if available)
        try:
            import streamlit as st

            st.cache_resource.clear()
            st.cache_data.clear()
        except ImportError:
            pass
        except Exception:
            # Streamlit might not be initialized or running
            pass


def flush_ollama_cache(host="http://127.0.0.1:11434"):
    """
    Sends a request to Ollama to unload all models from memory and clear context.
    Uses /api/ps to find active models and /api/generate with keep_alive: 0 to unload.
    """
    import requests
    import database

    if not host:
        host = database.get_setting("ollama_url") or "http://127.0.0.1:11434"

    if host.endswith("/"):
        host = host[:-1]

    try:
        # 1. Try to get currently loaded models via /api/ps (Modern Ollama)
        ps_url = f"{host}/api/ps"
        resp = requests.get(ps_url, timeout=2)

        models_to_unload = []
        if resp.status_code == 200:
            models_to_unload = [m["name"] for m in resp.json().get("models", [])]

        # 2. Fallback or Supplementary: Get all known tags if ps is empty or fails
        if not models_to_unload:
            tags_url = f"{host}/api/tags"
            resp_tags = requests.get(tags_url, timeout=2)
            if resp_tags.status_code == 200:
                models_to_unload = [
                    m["name"] for m in resp_tags.json().get("models", [])
                ]

        # 3. Execution: Send unload signal (keep_alive: 0) for each target
        for model in models_to_unload:
            # We send an empty generate request with keep_alive: 0 to force immediate unload
            # and context descriptor clearing.
            try:
                requests.post(
                    f"{host}/api/generate",
                    json={"model": model, "prompt": "", "keep_alive": 0},
                    timeout=2,
                )
            except Exception:
                pass

        print(
            f"[OLLAMA] SRE Purge: {len(models_to_unload)} models signaled for unload & context wipe."
        )
    except Exception as e:
        print(f"[OLLAMA] Flush failed: {e}")


# Instance for easy import
monitor = ResourceMonitor()
