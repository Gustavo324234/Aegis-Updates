import os
import shutil
import datetime
import tarfile
import logging
from modules.utils import get_user_root


class SoulSync:
    """
    Protocol Soul Sync: Disaster Recovery & Immutable Backup.
    Safeguards the 'Soul' (Memory + Vault) of Aegis to external targets.
    """

    def __init__(self):
        self.logger = logging.getLogger("SoulSync")
        self.root = get_user_root()
        self.backup_dir = os.path.join(self.root, "backups")
        if not os.path.exists(self.backup_dir):
            os.makedirs(self.backup_dir)

    def perform_sync(self, target_path=None, encrypt_func=None):
        """
        Creates a compressed, optionally encrypted dump of critical data.
        """
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"aegis_soul_{timestamp}.tar.gz"
        local_path = os.path.join(self.backup_dir, filename)

        try:
            # 1. Create Tarball
            with tarfile.open(local_path, "w:gz") as tar:
                # Add Database (The Memory)
                db_path = os.path.join(self.root, "aegis_memory.db")
                if os.path.exists(db_path):
                    tar.add(db_path, arcname="aegis_memory.db")

                # Add Vault (The Knowledge)
                vault_path = os.path.join(self.root, "vault")
                if os.path.exists(vault_path):
                    tar.add(vault_path, arcname="vault")

                # Add Config (The Personality)
                config_path = os.path.join(self.root, "config")
                if os.path.exists(config_path):
                    tar.add(config_path, arcname="config")

            self.logger.info(f"Soul Dump created: {local_path}")

            # 2. Encryption (Optional but requested)
            final_path = local_path
            if encrypt_func:
                enc_path = local_path + ".enc"
                with open(local_path, "rb") as f_in:
                    data = f_in.read()
                    enc_data = encrypt_func(data)

                with open(enc_path, "wb") as f_out:
                    f_out.write(enc_data)

                # Remove unencrypted tar
                os.remove(local_path)
                final_path = enc_path
                self.logger.info(f"Soul Dump encrypted: {final_path}")

            # 3. Sync to Target (Teleportation)
            if target_path and os.path.exists(target_path):
                shutil.copy2(final_path, target_path)
                self.logger.info(f"Soul Sync successful to: {target_path}")
                return True, f"Synced to {target_path}"

            return True, f"Local Backup: {final_path}"

        except Exception as e:
            self.logger.error(f"Soul Sync Failed: {e}")
            return False, str(e)

    def perform_cross_backup(self, node_id):
        """
        Implementation of 'Respaldo Circular'.
        Sends the Hub's soul to a Satellite node.
        """
        try:
            from modules.satellite_bridge import pack_and_send

            # 1. Generate local dump
            success, msg = self.perform_sync()
            if not success:
                return False, f"Failed local dump: {msg}"

            # The local dump is in self.backup_dir
            # We find the latest one
            backups = sorted(
                [
                    os.path.join(self.backup_dir, f)
                    for f in os.listdir(self.backup_dir)
                    if "aegis_soul" in f
                ]
            )
            if not backups:
                return False, "No soul dump found to sync"

            latest_soul = backups[-1]

            # 2. Send via Satellite Bridge
            # We use a special target_subdir 'soul_backups' on the satellite
            res = pack_and_send(
                latest_soul, node_id, target_subdir=".aegis_nexus/soul_backups"
            )
            self.logger.info(f"Cross-Backup initiated to {node_id}: {res}")
            return True, res
        except Exception as e:
            self.logger.error(f"Cross-Backup Failed: {e}")
            return False, str(e)

    def handle_incoming_soul(self, sender_id, soul_data_b64):
        """
        Saves a soul backup received from a Satellite.
        """
        import base64

        try:
            dest_dir = os.path.join(self.backup_dir, "remote_souls", sender_id)
            os.makedirs(dest_dir, exist_ok=True)

            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"satellite_soul_{sender_id}_{timestamp}.tar.gz"
            dest_path = os.path.join(dest_dir, filename)

            with open(dest_path, "wb") as f:
                f.write(base64.b64decode(soul_data_b64))

            self.logger.info(f"Remote Soul from {sender_id} stored at {dest_path}")
            return True
        except Exception as e:
            self.logger.error(f"Failed to store remote soul: {e}")
            return False


soul_sync = SoulSync()
