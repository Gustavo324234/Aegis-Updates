import os
import shutil
import datetime
import tarfile
import logging
from modules.utils import get_user_root

class SoulSync:
    """
    Protocol Soul Sync: Disaster Recovery & Immutable Backup.
    Safeguards the 'Soul' (Memory + Vault) of Aegis to external targets.
    """
    def __init__(self):
        self.logger = logging.getLogger("SoulSync")
        self.root = get_user_root()
        self.backup_dir = os.path.join(self.root, "backups")
        if not os.path.exists(self.backup_dir):
            os.makedirs(self.backup_dir)

    def perform_sync(self, target_path=None, encrypt_func=None):
        """
        Creates a compressed, optionally encrypted dump of critical data.
        """
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"aegis_soul_{timestamp}.tar.gz"
        local_path = os.path.join(self.backup_dir, filename)
        
        try:
            # 1. Create Tarball
            with tarfile.open(local_path, "w:gz") as tar:
                # Add Database (The Memory)
                db_path = os.path.join(self.root, "aegis_memory.db")
                if os.path.exists(db_path):
                    tar.add(db_path, arcname="aegis_memory.db")
                
                # Add Vault (The Knowledge)
                vault_path = os.path.join(self.root, "vault")
                if os.path.exists(vault_path):
                    tar.add(vault_path, arcname="vault")
                    
                # Add Config (The Personality)
                config_path = os.path.join(self.root, "config")
                if os.path.exists(config_path):
                    tar.add(config_path, arcname="config")
            
            self.logger.info(f"Soul Dump created: {local_path}")
            
            # 2. Encryption (Optional but requested)
            final_path = local_path
            if encrypt_func:
                enc_path = local_path + ".enc"
                with open(local_path, "rb") as f_in:
                    data = f_in.read()
                    enc_data = encrypt_func(data)
                
                with open(enc_path, "wb") as f_out:
                    f_out.write(enc_data)
                
                # Remove unencrypted tar
                os.remove(local_path)
                final_path = enc_path
                self.logger.info(f"Soul Dump encrypted: {final_path}")

            # 3. Sync to Target (Teleportation)
            if target_path and os.path.exists(target_path):
                shutil.copy2(final_path, target_path)
                self.logger.info(f"Soul Sync successful to: {target_path}")
                return True, f"Synced to {target_path}"
                
            return True, f"Local Backup: {final_path}"

        except Exception as e:
            self.logger.error(f"Soul Sync Failed: {e}")
            return False, str(e)

soul_sync = SoulSync()
