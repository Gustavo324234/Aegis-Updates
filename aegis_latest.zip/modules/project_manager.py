import time
import subprocess
import threading
import sys
import re
import importlib.util
import socket
from playwright.sync_api import sync_playwright
import database
import os
import json
import zipfile
import io
import base64
import hashlib
import requests
import shutil
from cryptography.fernet import Fernet

# modules/project_manager.py

PROJECTS_ROOT = os.path.abspath("workspace/projects")


def get_projects_root():
    if not os.path.exists(PROJECTS_ROOT):
        os.makedirs(PROJECTS_ROOT)
    return PROJECTS_ROOT


def init_project(name, description=""):
    """
    Creates a new project folder and manifest.
    """
    root = get_projects_root()
    safe_name = (
        "".join([c for c in name if c.isalnum() or c in (" ", "_", "-")])
        .strip()
        .replace(" ", "_")
    )
    project_path = os.path.join(root, safe_name)

    if not os.path.exists(project_path):
        os.makedirs(project_path)

    # Register Project in Database
    try:
        database.add_user_fact(name, project_path, "project_active")
    except Exception:
        pass

    manifest = {
        "name": name,
        "id": safe_name,
        "description": description,
        "created_at": time.time(),
        "files": [],
    }

    with open(os.path.join(project_path, "project_manifest.json"), "w") as f:
        json.dump(manifest, f, indent=2)

    return f"Project '{name}' initialized at {project_path}"


def write_project_file(project_name, filename, code):
    """
    Writes a file to a specific project.
    """
    root = get_projects_root()
    # Normalize inputs
    safe_name = (
        "".join([c for c in project_name if c.isalnum() or c in (" ", "_", "-")])
        .strip()
        .replace(" ", "_")
    )
    target_dir = os.path.join(root, safe_name)

    if not os.path.exists(target_dir):
        init_project(project_name)

    file_path = os.path.join(target_dir, filename)

    # Security check
    if not os.path.commonpath([file_path, target_dir]) == target_dir:
        return "Error: Path traversal attempt."

    # --- DATA SAFETY PROTOCOL ---
    # Before overwriting, create a .bak copy to prevent accidental data loss.
    backup_created = False
    backup_filename = filename + ".bak"
    if os.path.exists(file_path):
        backup_path = os.path.join(target_dir, backup_filename)
        try:
            shutil.copy2(file_path, backup_path)  # Preserves metadata
            backup_created = True
        except Exception as e:
            # Non-fatal: log and continue without blocking the write.
            print(f"[WARN] Could not create backup for '{filename}': {e}")
    # --- END DATA SAFETY PROTOCOL ---

    with open(file_path, "w", encoding="utf-8") as f:
        f.write(code)

    # Update manifest
    manifest_path = os.path.join(target_dir, "project_manifest.json")
    if os.path.exists(manifest_path):
        try:
            with open(manifest_path, "r") as f:
                data = json.load(f)
            if filename not in data.get("files", []):
                data["files"].append(filename)
                with open(manifest_path, "w") as f:
                    json.dump(data, f, indent=2)
        except Exception:
            pass

    if backup_created:
        return f"File '{filename}' updated (Backup saved as {backup_filename})."
    return f"File '{filename}' created in Project '{project_name}'."


def wait_for_port(port, timeout=30):
    """Waits for a local port to be active."""
    start_time = time.time()
    while time.time() - start_time < timeout:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            if sock.connect_ex(("127.0.0.1", port)) == 0:
                return True
        time.sleep(1)
    return False


def capture_project_snapshot(project_path, url):
    """Uses Playwright to capture a snapshot of the UI."""
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            page = browser.new_page()
            page.goto(url)
            time.sleep(2)  # Wait for rendering
            snapshot_path = os.path.join(project_path, "ui_snapshot.png")
            page.screenshot(path=snapshot_path)
            browser.close()
            return snapshot_path
    except Exception as e:
        print(f"[DEBUG] Snapshot Capture Failed: {e}")
        return None


def execute_project(project_name):
    """
    Launches a project, intercepting logs and monitoring for crashes.
    """
    safe_name = (
        "".join([c for c in project_name if c.isalnum() or c in (" ", "_", "-")])
        .strip()
        .replace(" ", "_")
    )
    proj_root = os.path.join(get_projects_root(), safe_name)

    if not os.path.exists(proj_root):
        return f"Error: Project '{project_name}' not found."

    # Entry point detection
    entry_point = "main.py"
    if not os.path.exists(os.path.join(proj_root, entry_point)):
        entry_point = "app.py"
    if not os.path.exists(os.path.join(proj_root, entry_point)):
        entry_point = f"{safe_name}.py"
    if not os.path.exists(os.path.join(proj_root, entry_point)):
        entry_point = "index.html"

    script_path = os.path.join(proj_root, entry_point)
    if not os.path.exists(script_path):
        return f"Error: No entry point (main.py/app.py/index.html) found in {proj_root}"

    is_html = entry_point.endswith(".html")
    is_streamlit = False
    is_flask = False
    is_web = is_html

    # Dependency check & Web Detection
    try:
        if not is_html:
            with open(script_path, "r", encoding="utf-8") as f:
                code_content = f.read()

            if "import streamlit" in code_content:
                is_streamlit = True
                is_web = True
            if "import flask" in code_content or "from flask import" in code_content:
                is_flask = True
                is_web = True

            imports = re.findall(
                r"^\s*(?:import|from)\s+([a-zA-Z0-9_]+)", code_content, re.MULTILINE
            )
            common_stdlib = [
                "os",
                "sys",
                "json",
                "time",
                "datetime",
                "re",
                "math",
                "random",
                "subprocess",
                "threading",
                "collections",
                "itertools",
                "io",
            ]

            missing_pkgs = []
            for imp in set(imports):
                if imp in common_stdlib:
                    continue
                try:
                    if not importlib.util.find_spec(imp):
                        missing_pkgs.append(imp)
                except Exception:
                    pass

            if missing_pkgs:
                for pkg in missing_pkgs:
                    subprocess.run(
                        [sys.executable, "-m", "pip", "install", pkg],
                        capture_output=True,
                    )
    except Exception:
        pass

    # Launch with Log Interceptor
    log_path = os.path.join(proj_root, ".aegis_debug.log")

    def run_process():
        with open(log_path, "w", encoding="utf-8") as log_file:
            cmd = [sys.executable, script_path]
            if is_streamlit:
                cmd = [
                    sys.executable,
                    "-m",
                    "streamlit",
                    "run",
                    script_path,
                    "--server.port",
                    "8501",
                    "--server.headless",
                    "true",
                ]
            elif is_html:
                # Use http.server for HTML
                cmd = [sys.executable, "-m", "http.server", "8000"]

            process = subprocess.Popen(
                cmd,
                cwd=proj_root,
                stdout=log_file,
                stderr=log_file,
                creationflags=subprocess.CREATE_NEW_CONSOLE if os.name == "nt" else 0,
            )

            # Web App Snapshot Protocol
            if is_web:
                port = (
                    8501
                    if is_streamlit
                    else (8000 if is_html else (5000 if is_flask else 8000))
                )
                if wait_for_port(port):
                    url = f"http://localhost:{port}"
                    capture_project_snapshot(proj_root, url)
                    # Trigger Visual Reviewer in Brain (will be handled by brain calling this)
                    report = f"[VISUAL_REVIEW_REQUEST] {project_name}"
                    database.save_message("system", report, "Aegis", "general")

            process.wait()

            if process.returncode != 0:
                # Trigger Auto-Fix: Read stderr (which is in log_file)
                try:
                    with open(log_path, "r", encoding="utf-8") as f:
                        logs = f.read()
                    # Extract last 20 lines of logs for brevity
                    log_tail = "\n".join(logs.splitlines()[-20:])

                    crash_report = (
                        f"[SYSTEM_CRASH_REPORT] Project '{project_name}' exited with code {process.returncode}.\n"
                        f"Traceback / Logs:\n{log_tail}"
                    )
                    database.save_message("system", crash_report, "Aegis", "general")
                except Exception:
                    pass

    thread = threading.Thread(target=run_process, daemon=True)
    thread.start()

    return f"Project '{project_name}' launched in background. Monitoring logs at {log_path}."


def teleport_project(project_name, target_node_id):
    """
    Compresses, encrypts, and sends a project to a target Nexus node.
    """
    safe_name = (
        "".join([c for c in project_name if c.isalnum() or c in (" ", "_", "-")])
        .strip()
        .replace(" ", "_")
    )
    proj_root = os.path.join(get_projects_root(), safe_name)

    if not os.path.exists(proj_root):
        return f"Error: Project '{project_name}' not found."

    # 1. Fetch Target Node Key
    try:
        target_key = database.get_node_key(target_node_id)
        if not target_key:
            return f"Error: No encryption key found for node '{target_node_id}'."
    except Exception as e:
        return f"Error fetching node key: {e}"

    # 2. Compress Project to Memory
    try:
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
            for root, dirs, files in os.walk(proj_root):
                # Skip debug logs and snapshots if preferred, or include them
                for file in files:
                    abs_path = os.path.join(root, file)
                    rel_path = os.path.relpath(abs_path, proj_root)
                    zf.write(abs_path, rel_path)

        zip_data = buf.getvalue()
        checksum = hashlib.md5(zip_data).hexdigest()
    except Exception as e:
        return f"Compression Error: {e}"

    # 3. Encrypt ZIP
    try:
        cipher = Fernet(target_key.encode())
        encrypted_zip = cipher.encrypt(zip_data)
        payload_b64 = base64.b64encode(encrypted_zip).decode("utf-8")
    except Exception as e:
        return f"Encryption Error: {e}"

    # 4. Wrap in Nexus Command
    command = {
        "target_node": target_node_id,
        "content": {
            "cmd": "sync_entire_project",
            "args": {
                "project_name": project_name,
                "target_subdir": os.path.join("workspace/projects", safe_name),
                "payload": payload_b64,
                "checksum": checksum,
                "force": True,
            },
        },
    }

    # 5. Send via Gateway
    try:
        # Detectar Gateway: Prioridad ENV VAR (Satélite) -> Localhost (Hub)
        base_url = os.getenv("AEGIS_GATEWAY_URL", "http://localhost:8000")

        # Asegurar formato correcto (limpiar barras finales si existen)
        if base_url.endswith("/"):
            base_url = base_url[:-1]

        # Manejar caso si la URL base ya incluye /send_message o no
        if "/send_message" not in base_url:
            gateway_url = f"{base_url}/send_message"
        else:
            gateway_url = base_url

        resp = requests.post(gateway_url, json=command, timeout=30)
        if resp.status_code == 200:
            return (
                f"Teleport complete: Project '{project_name}' sent to {target_node_id}."
            )
        else:
            return f"Gateway Error: {resp.text}"
    except Exception as e:
        return f"Transmission Error: {e}"


def get_tooling_schema():
    """
    Returns the schema for the Project Manager.
    """
    return json.dumps(
        {
            "tools": [
                {
                    "name": "project_manager",
                    "description": "Manage User Projects (Private Apps/Scripts). Use this for 'Mission: Project'.",
                    "functions": [
                        {"name": "init_project", "args": ["name", "description"]},
                        {
                            "name": "write_project_file",
                            "args": ["project_name", "filename", "code"],
                        },
                        {
                            "name": "execute_project",
                            "args": ["project_name"],
                        },
                        {
                            "name": "capture_project_snapshot",
                            "args": ["project_name"],
                        },
                        {
                            "name": "teleport_project",
                            "args": ["project_name", "target_node_id"],
                        },
                    ],
                }
            ]
        },
        indent=2,
    )


DESCRIPTION = "Active Project Manager for User Private Workspace."


def execute(query):
    """
    Dispatcher for Project Manager actions.
    Query expected format: {"action": "...", "args": {...}} or flat format.
    """
    action = query.get("action") or query.get("function_name")

    # Hybrid Support: Extract parameters from 'args' if present
    args = query.get("args") if isinstance(query.get("args"), dict) else query

    # Helper to get keys from either root or args
    def get_val(key, default=None):
        return args.get(key, query.get(key, default))

    if action == "init_project":
        return init_project(
            get_val("name") or get_val("project_name"), get_val("description", "")
        )

    if action == "write_project_file":
        return write_project_file(
            get_val("project_name"), get_val("filename"), get_val("code")
        )

    if action == "execute_project":
        return execute_project(get_val("project_name") or get_val("name"))

    if action == "capture_project_snapshot":
        # Helper for explicit snapshot requests
        safe_name = (
            "".join(
                [
                    c
                    for c in (get_val("project_name") or "")
                    if c.isalnum() or c in (" ", "_", "-")
                ]
            )
            .strip()
            .replace(" ", "_")
        )
        proj_root = os.path.join(get_projects_root(), safe_name)
        # We don't know the URL here so we guess based on common ports if not provided
        port = get_val("port", 8501)
        return capture_project_snapshot(proj_root, f"http://localhost:{port}")

    if action == "teleport_project":
        return teleport_project(
            get_val("project_name") or get_val("name"),
            get_val("target_node_id") or get_val("target"),
        )

    return f"Error: Unknown action '{action}' for project_manager."
