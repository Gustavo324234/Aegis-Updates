import logging
import threading
import traceback
import time

import database

# ---------------------------------------------------------------------------
# Flood Guard — prevents alert storms if a loop is crashing repeatedly.
# Stores the monotonic timestamp of the last alert sent.
# ---------------------------------------------------------------------------
_last_alert_sent: float = 0.0  # epoch seconds (time.monotonic)
_ALERT_COOLDOWN_SECONDS: int = 1800  # 30 minutes
_flood_guard_lock = threading.Lock()


def _should_send_alert() -> bool:
    """
    Thread-safe check + update of the flood guard.
    Returns True (and updates the timestamp) only if the cooldown has elapsed.
    """
    global _last_alert_sent
    with _flood_guard_lock:
        now = time.monotonic()
        if now - _last_alert_sent >= _ALERT_COOLDOWN_SECONDS:
            _last_alert_sent = now
            return True
    return False


def _dispatch_critical_alert(subject: str, body: str) -> None:
    """
    Executed inside a daemon thread.
    Performs the lazy import of uplink to avoid circular-import issues
    (uplink → database ← db_logger) and calls send_architect_proposal.
    """
    try:
        # Lazy import: uplink is only resolved at call-time, not at module load.
        # This breaks the potential circular-import chain:
        #   db_logger loads → uplink loads → logging/database, which are already cached.
        import importlib
        import sys

        # uplink lives in modules/, which may or may not already be on sys.path.
        # We import it by locating it relative to this file if needed.
        if "uplink" in sys.modules:
            uplink = sys.modules["uplink"]
        else:
            uplink = importlib.import_module("uplink")

        result = uplink.send_architect_proposal(subject=subject, body=body)
        if result.get("success"):
            print(f"[DB_LOGGER] Critical alert dispatched → {subject}")
        else:
            print(f"[DB_LOGGER] Alert dispatch failed: {result.get('message')}")
    except Exception as exc:
        # Never raise from a background thread — just print to stderr.
        print(f"[DB_LOGGER] Exception in alert thread: {exc}")


def _build_alert_body(record: logging.LogRecord, formatted_msg: str) -> str:
    """
    Composes the alert email body with error context, traceback and resource snapshot.
    """
    # --- Traceback -----------------------------------------------------------
    tb_section = ""
    if record.exc_info:
        tb_section = "\n\n--- Traceback ---\n" + "".join(
            traceback.format_exception(*record.exc_info)
        )

    # --- Resource snapshot (best-effort) -------------------------------------
    resource_section = ""
    try:
        import psutil

        cpu = psutil.cpu_percent(interval=0.2)
        ram = psutil.virtual_memory()
        resource_section = (
            f"\n\n--- Resource Snapshot ---\n"
            f"CPU  : {cpu:.1f}%\n"
            f"RAM  : {ram.percent:.1f}%  "
            f"({ram.used / 1024**2:.0f} MB used / {ram.total / 1024**2:.0f} MB total)"
        )
    except Exception:
        resource_section = "\n\n--- Resource Snapshot ---\n[psutil not available]"

    body = (
        f"⚠️  AEGIS has detected a CRITICAL / ERROR-level event requiring your attention.\n\n"
        f"--- Error Details ---\n"
        f"Level   : {record.levelname}\n"
        f"Logger  : {record.name}\n"
        f"Location: {getattr(record, 'filename', '?')}:{record.lineno}\n\n"
        f"Message :\n{formatted_msg}"
        f"{tb_section}"
        f"{resource_section}\n\n"
        f"--- End of Alert ---\n"
        f"Timestamp (UTC+0): {time.strftime('%Y-%m-%d %H:%M:%S', time.gmtime())}"
    )
    return body


class SQLiteHandler(logging.Handler):
    """
    Custom Logging Handler to Route Python Logs to SQLite Audit Log.
    Captures system errors, warnings, and critical failures in real-time.

    Proactive Alerts (Uplink Integration)
    ──────────────────────────────────────
    When `database.get_setting("proactive_alerts") == "true"` AND the event
    level is CRITICAL (or ERROR if flood-guard permits), a background thread
    fires `uplink.send_architect_proposal` so the Architect is notified
    without blocking the main process.
    """

    def __init__(self):
        super().__init__()
        self.setLevel(logging.WARNING)  # Capture WARNING and above by default

    def emit(self, record):
        """
        Log the record to the database and optionally fire a critical alert.
        """
        try:
            # Format message
            msg = self.format(record)

            # ── Level → Audit Status ─────────────────────────────────────────
            status = "INFO"
            if record.levelno >= logging.ERROR:
                status = "FAILURE"
            elif record.levelno >= logging.WARNING:
                status = "WARNING"

            # Filter: Ignorar INFO genéricos de librerías, salvo que sea 'audit' explícito
            if (
                record.levelno < logging.WARNING
                and getattr(record, "name", "") != "audit"
            ):
                return

            # ── Determinar Módulo ────────────────────────────────────────────
            module = record.name if record.name else "root"
            if hasattr(record, "filename"):
                module = f"{record.filename}:{record.lineno}"

            # ── Persist to SQLite ────────────────────────────────────────────
            try:
                database.log_audit_event(
                    module,
                    "LOG_EVENT",
                    status,
                    details=msg,
                    user="SYSTEM",
                    approved=False,
                )
            except Exception as db_err:
                print(f"FAILED TO LOG TO DB: {msg} | ERR: {db_err}")

            # ── Proactive Alert via Uplink ───────────────────────────────────
            # Only fires for CRITICAL events (or ERROR, subject to flood-guard).
            if record.levelno >= logging.CRITICAL:
                self._maybe_send_alert(record, msg, module)

        except Exception:
            # Prevent infinite loops if this handler itself fails
            self.handleError(record)

    # ------------------------------------------------------------------
    def _maybe_send_alert(
        self, record: logging.LogRecord, formatted_msg: str, module: str
    ) -> None:
        """
        Checks configuration and flood-guard, then launches a daemon thread
        to send the proactive alert via Uplink.
        """
        try:
            # 1. Check if proactive alerts are enabled in configuration
            proactive_enabled = database.get_setting("proactive_alerts")
            if str(proactive_enabled).strip().lower() != "true":
                return

            # 2. Check flood-guard (max 1 alert per 30 minutes)
            if not _should_send_alert():
                print(
                    "[DB_LOGGER] Proactive alert suppressed by flood-guard "
                    f"(cooldown: {_ALERT_COOLDOWN_SECONDS // 60} min)."
                )
                return

            # 3. Build alert content
            module_label = module.split(":")[0]  # strip line number for subject
            subject = f"🚨 AEGIS CRITICAL ALERT: {module_label}"
            body = _build_alert_body(record, formatted_msg)

            # 4. Fire in a daemon thread — never blocks the main process
            alert_thread = threading.Thread(
                target=_dispatch_critical_alert,
                args=(subject, body),
                daemon=True,
                name="AegisUplinkAlert",
            )
            alert_thread.start()
            print(f"[DB_LOGGER] Proactive alert thread launched for: {subject}")

        except Exception as alert_err:
            # Swallow errors silently — alerting must never crash the logger
            print(f"[DB_LOGGER] Could not launch alert: {alert_err}")


def setup_db_logger():
    """
    Initializes the SQLite Logger and attaches it to Root.
    Call this once at application startup.
    """
    root_logger = logging.getLogger()

    # Check if handler already added to avoid duplicates
    for h in root_logger.handlers:
        if isinstance(h, SQLiteHandler):
            return

    # Create and add handler
    handler = SQLiteHandler()
    formatter = logging.Formatter(
        "%(message)s"
    )  # Just message, metadata handled separately
    handler.setFormatter(formatter)

    root_logger.addHandler(handler)

    # Ensure root logger captures warnings
    # Note: Streamlit sets its own handlers, this appends to them
    root_logger.setLevel(logging.INFO)

    print(
        "[DB_LOGGER] SQLite Logging Handler Attached. Proactive Uplink alerts: ARMED."
    )
