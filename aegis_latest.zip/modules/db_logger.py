import logging
import database

class SQLiteHandler(logging.Handler):
    """
    Custom Logging Handler to Route Python Logs to SQLite Audit Log.
    Captures system errors, warnings, and critical failures in real-time.
    """
    def __init__(self):
        super().__init__()
        self.setLevel(logging.WARNING) # Capture WARNING and above by default

    def emit(self, record):
        """
        Log the record to the database.
        """
        try:
            # Format message
            msg = self.format(record)
            
            # Mapeo de Niveles a Estados de Auditoría
            status = "INFO"
            if record.levelno >= logging.ERROR:
                status = "FAILURE"
            elif record.levelno >= logging.WARNING:
                status = "WARNING"
            
            # Filter: Ignorar INFO genéricos de librerías, salvo que sea 'audit' explícito
            if record.levelno < logging.WARNING and getattr(record, 'name', '') != 'audit':
                return

            # Determinar Módulo (Nombre de archivo o logger)
            module = record.name if record.name else "root"
            if hasattr(record, 'filename'):
                 # Use filename:line for location precision
                 module = f"{record.filename}:{record.lineno}"

            # Log to Database via existing
            import datetime
            try:
                 # Use threading/async safe call if needed, but for now direct is fine as sqlite handles concurrency (WAL)
                 # New Signature: module, action, status, details=None, user="SYSTEM", approved=False
                 database.log_audit_event(module, "LOG_EVENT", status, details=msg, user="SYSTEM", approved=False)
            except Exception as e:
                 # Failsafe to print if DB fails
                 print(f"FAILED TO LOG TO DB: {msg} | ERR: {e}")
        except Exception:
            # Prevent infinite loops if logging fails
            self.handleError(record)

def setup_db_logger():
    """
    Initializes the SQLite Logger and attaches it to Root.
    Call this once at application startup.
    """
    root_logger = logging.getLogger()
    
    # Check if handler already added to avoid duplicates
    for h in root_logger.handlers:
        if isinstance(h, SQLiteHandler):
            return
            
    # Create and add handler
    handler = SQLiteHandler()
    formatter = logging.Formatter('%(message)s') # Just message, metadata handled separately
    handler.setFormatter(formatter)
    
    root_logger.addHandler(handler)
    
    # Ensure root logger captures warnings
    # Note: Streamlit sets its own handlers, this appends to them
    root_logger.setLevel(logging.INFO) 
    
    # Force capture of uncaught exceptions?
    # sys.excepthook override is aggressive but effective for "Realtime error visibility"
    # logging already catches mostly handled stuff.
    
    print("[DB_LOGGER] SQLite Logging Handler Attached.")
