import os
import fnmatch
from modules.utils import get_user_root, is_safe_path, SENSITIVE_FILES

DESCRIPTION = """
Module: project_oracle
Purpose: Workspace Awareness. Allows the AI to read, search, and understand the project structure and file contents.
Actions:
- list_structure: Scans the current directory tree (ignoring git/cache) to generate a file map.
- read_files: Reads the content of a list of specific files.
- search_code: Searches for a keyword or regex in the project files.
Usage format:
{"module": "project_oracle", "action": "list_structure", "args": {"root_path": "."}}
{"module": "project_oracle", "action": "read_files", "args": {"file_paths": ["main.py", "utils.py"]}}
{"module": "project_oracle", "action": "search_code", "args": {"query": "def my_func", "root_path": "."}}
"""

IGNORE_PATTERNS = [
    ".git", "__pycache__", ".venv", "venv", "node_modules", ".idea", ".vscode", 
    "dist", "build", "*.pyc", "*.spec", "package-lock.json", "yarn.lock", 
    ".DS_Store", "Thumbs.db", "site-packages", ".streamlit"
]

MAX_FILE_SIZE = 50000  # 50KB limit per file to avoid context overflow
TOTAL_CONTEXT_LIMIT = 200000 # 200KB total return limit

SAFE_ROOT = get_user_root()

def execute(query):
    action = query.get("action")
    args = query.get("args", {})
    
    # Validation
    root_arg = args.get("root_path", ".")
    
    if action == "list_structure":
        if not is_safe_path(root_arg): return "Error: Access Denied (Path outside workspace)"
        return list_structure(root_arg)
        
    elif action == "read_files":
        paths = args.get("file_paths", [])
        safe_paths = []
        for p in paths:
             if is_safe_path(p): safe_paths.append(p)
             else: print(f"[ORACLE] Security blocked access to: {p}")
        return read_files(safe_paths)
        
    elif action == "search_code":
        if not is_safe_path(root_arg): return "Error: Access Denied (Path outside workspace)"
        return search_code(args.get("query"), root_arg)
    else:
        return f"Oracle Error: Unknown action '{action}'"

def should_ignore(path):
    name = os.path.basename(path)
    # Check ignore patterns
    for pattern in IGNORE_PATTERNS:
        if fnmatch.fnmatch(name, pattern):
            return True
            
    # Check sensitive files (Redundancy)
    if name in SENSITIVE_FILES:
        return True
        
    return False

def list_structure(relative_root):
    structure = []
    # Resolve full path safely
    target_path = os.path.abspath(os.path.join(SAFE_ROOT, relative_root))
    
    try:
        for root, dirs, files in os.walk(target_path):
            # Modify dirs in-place to skip ignored directories
            dirs[:] = [d for d in dirs if not should_ignore(os.path.join(root, d))]
            
            level = root.replace(target_path, '').count(os.sep)
            indent = ' ' * 4 * (level)
            structure.append(f"{indent}[DIR] {os.path.basename(root)}/")
            subindent = ' ' * 4 * (level + 1)
            
            for f in files:
                if not should_ignore(f):
                    structure.append(f"{subindent}{f}")
                    
        return "\n".join(structure) if structure else "Empty Directory or Access Denied."
    except Exception as e:
        return f"Error listing structure: {str(e)}"

def read_files(file_paths):
    result = "### FILE CONTENTS ###\n"
    total_chars = 0
    
    for relative_path in file_paths:
        try:
            # Full Security Resolution
            target_path = os.path.abspath(os.path.join(SAFE_ROOT, relative_path))
            
            if not os.path.exists(target_path):
                result += f"\n--- FILE: {relative_path} (NOT FOUND) ---\n"
                continue
                
            if os.path.getsize(target_path) > MAX_FILE_SIZE:
                result += f"\n--- FILE: {relative_path} (SKIPPED - TOO LARGE > 50KB) ---\n"
                continue
            
            # Binary Check (Simple heuristic)
            try:
                with open(target_path, 'r', encoding='utf-8') as f:
                    content = f.read()
            except UnicodeDecodeError:
                result += f"\n--- FILE: {relative_path} (SKIPPED - BINARY FILE) ---\n"
                continue

            result += f"\n--- FILE: {relative_path} ---\n{content}\n"
            total_chars += len(content)
            
            if total_chars > TOTAL_CONTEXT_LIMIT:
                result += "\n\n[SYSTEM] CONTEXT LIMIT REACHED. STOPPING READ."
                break
                
        except Exception as e:
            result += f"\n--- FILE: {relative_path} (ERROR: {str(e)}) ---\n"
            
    return result

def search_code(query, relative_root):
    matches = []
    target_path = os.path.abspath(os.path.join(SAFE_ROOT, relative_root))
    
    try:
        for root, dirs, files in os.walk(target_path):
            dirs[:] = [d for d in dirs if not should_ignore(os.path.join(root, d))]
            
            for f in files:
                if should_ignore(f): continue
                
                full_path = os.path.join(root, f)
                try:
                    with open(full_path, 'r', encoding='utf-8', errors='ignore') as f_obj:
                        lines = f_obj.readlines()
                        for i, line in enumerate(lines):
                            if query.lower() in line.lower():
                                relative = os.path.relpath(full_path, target_path)
                                matches.append(f"{relative}:{i+1}: {line.strip()[:100]}")
                                if len(matches) > 50:
                                    matches.append("... (Too many matches, truncating)")
                                    return "\n".join(matches)
                except:
                    pass
                    
        return "\n".join(matches) if matches else "No matches found."
    except Exception as e:
        return f"Search Error: {str(e)}"
