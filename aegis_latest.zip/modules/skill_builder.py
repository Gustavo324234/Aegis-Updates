# modules/skill_builder.py
import os
import json
import shutil

from modules.validator import sentinel

DESCRIPTION = """
Use this module to CREATE or MODIFY SKILLS (Self-Programming).
If you encounter a problem you cannot solve with current modules, propose a new module code.
CRITICAL FOR "APPS": If user asks for an App (e.g. Astrology), CREATE A STANDALONE SCRIPT.
- Use standard libraries (random, datetime, math) or propose `pip install` (e.g. `flatlib`) in instructions.
- Do NOT invent modules. WRITE THE CODE.

Commands:
1. Propose New Skill:
   {"module": "skill_builder", "action": "propose_skill", "filename": "new_skill.py", "code": "full_python_code"}

2. Read Existing Skill (for Refactoring):
   {"module": "skill_builder", "action": "read_skill", "filename": "existing_skill.py"}

3. Rollback Skill (Restore Backup):
   {"module": "skill_builder", "action": "rollback_skill", "filename": "broken_skill.py"}

Rules:
- The 'code' must include a DESCRIPTION string and an execute(query) function.
- The system will validation with Sentinel before installation.
- Refactoring: Use 'read_skill' to get current code, then 'propose_skill' with improved code.
"""


def get_tooling_schema():
    """
    Returns the technical schema for the Skill Builder and available libraries (Flatlib).
    Used for 'Mission' context injection.
    """
    return json.dumps(
        {
            "tools": [
                {
                    "name": "propose_skill",
                    "description": "Create a new Python file/module in the 'skills' directory.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "filename": {
                                "type": "string",
                                "description": "e.g., 'astronomy_calc.py'",
                            },
                            "code": {
                                "type": "string",
                                "description": "Complete, valid Python code.",
                            },
                        },
                        "required": ["filename", "code"],
                    },
                },
                {
                    "name": "flatlib_reference",
                    "description": "Library for Astronomical Calculations. Use this for astrology/planet positions.",
                    "usage_guide": {
                        "import": "from flatlib.datetime import Datetime\nfrom flatlib.geopos import GeoPos\nfrom flatlib.chart import Chart\nfrom flatlib.const import LIST_SEVEN_PLANETS",
                        "example": "date = Datetime('2024/01/01', '12:00', '+00:00')\npos = GeoPos(38.9, -77.0)\nchart = Chart(date, pos)\nfor body in LIST_SEVEN_PLANETS:\n    obj = chart.get(body)\n    print(f'{body}: {obj.sign} {obj.signlon}')",
                    },
                },
            ]
        },
        indent=2,
    )


def execute(query):
    # Ensure query is dict
    if isinstance(query, str):
        try:
            query = json.loads(query)
        except Exception:
            return "Error: Query must be valid JSON."

    action = query.get("action")
    filename = query.get("filename")

    # Common Path Security
    skills_dir = os.path.abspath("skills")
    if not os.path.exists(skills_dir):
        os.makedirs(skills_dir)

    if filename:
        target_path = os.path.abspath(os.path.join(skills_dir, filename))
        if not os.path.commonpath([target_path, skills_dir]) == skills_dir:
            return "Security Error: Invalid file path."

    # --- ACTION 1: PROPOSE ---
    if action == "propose_skill":
        code = query.get("code")
        if not filename or not code:
            return "Error: filename and code required."
        return f"SKILL_PROPOSAL:{json.dumps({'filename': filename, 'code': code})}"

    # --- ACTION 2: READ (Refactoring) ---
    elif action == "read_skill":
        if not filename:
            return "Error: filename required."
        if not os.path.exists(target_path):
            return f"Error: Skill '{filename}' not found."

        try:
            with open(target_path, "r", encoding="utf-8") as f:
                return f.read()
        except Exception as e:
            return f"Read Error: {e}"

    # --- ACTION 3: INSTALL (With Backup) ---
    elif action == "install_skill_confirmed":
        code = query.get("code")
        if not filename or not code:
            return "Error: Missing filename or code."

        # 1. Filename Validation
        if not filename.endswith(".py"):
            return "Error: Must be .py file."

        # 2. Syntax Check (Double Check)
        try:
            is_valid, msg = sentinel.check_syntax(code)
            if not is_valid:
                return msg
        except Exception as e:
            return f"Syntax Check Error: {e}"

        # 3. Create Backup (Versioning)
        if os.path.exists(target_path):
            backup_path = target_path + ".bak"
            try:
                shutil.copy2(target_path, backup_path)
            except Exception as e:
                return f"Backup Failed: {e}. Installation aborted."

        # 4. Write File
        try:
            with open(target_path, "w", encoding="utf-8") as f:
                f.write(code)
            return f"Success: Skill '{filename}' installed. Backup saved as .bak."
        except Exception as e:
            # Attempt Rollback if write fails halfway (unlikely for text write but safe)
            return f"Write Error: {e}"

    # --- ACTION 4: ROLLBACK ---
    elif action == "rollback_skill":
        if not filename:
            return "Error: filename required."
        backup_path = target_path + ".bak"

        if not os.path.exists(backup_path):
            return "Error: No backup found for this skill."

        try:
            shutil.copy2(backup_path, target_path)
            return f"Success: Rolled back '{filename}' to previous version."
        except Exception as e:
            return f"Rollback Error: {e}"

    return "Error: Unknown action."
