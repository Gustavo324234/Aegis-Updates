import database
import json

DESCRIPTION = """
Module: system_doctor
Purpose: Self-diagnosis and troubleshooting. Allows Aegis to inspect internal logs.
Actions:
- check_logs: Retrieves the latest error or failure logs from the audit table.
- status: Returns detailed system status report.
Usage format:
{"module": "system_doctor", "action": "check_logs", "args": {"limit": 10}}
{"module": "system_doctor", "action": "status", "args": {}}
"""

def execute(query):
    action = query.get("action")
    args = query.get("args", {})
    
    if action == "check_logs":
        limit = args.get("limit", 10)
        logs = database.get_audit_logs(limit)
        
        # Format logs for readability
        report = "### SYSTEM AUDIT LOG (Recent Failures) ###\n"
        count = 0
        for log in logs:
            # log tuple: timestamp, module, action, status, approved, details, user
            # We filter for non-success to be useful, unless requested otherwise
            status = log[3]
            if status not in ["SUCCESS", "INFO", "RUNNING"]:
                count += 1
                report += f"[{log[0]}] {log[1]} -> {log[2]} ({status})\n"
                report += f"User: {log[6]} | Approved: {log[4]}\n"
                report += f"Details: {log[5]}\n---\n"
                
        if count == 0:
            return "System Doctor: No recent errors found in the last batch."
            
        return report

    elif action == "status":
        # Combine resource monitor and daemon status
        from modules.resource_monitor import monitor
        health = monitor.get_metrics()
        
        daemons = database.get_all_daemons()
        daemon_status = "\nDAEMON STATUS:\n"
        for d in daemons:
            daemon_status += f"- {d['name']} ({d['type']}): {d['status']} (Last Run: {d['last_run']})\n"
            
        return f"### SYSTEM HEALTH REPORT ###\nRAM: {health.get('ram_percent')}% | CPU: {health.get('cpu_percent')}%\n{daemon_status}"

    else:
        return f"System Doctor Error: Unknown action '{action}'"
