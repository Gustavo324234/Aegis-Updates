import os
import io
import datetime
import json

def prepare_studio_context(history_data, vault_dir="vault"):
    """
    Generates a full context dump for Google AI Studio or similar LLM interfaces.
    Includes active project structure from Vault if available.
    """
    buffer = io.StringIO()
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    buffer.write(f"AEGIS-IA WORKSPACE EXPORT\nTIMESTAMP: {timestamp}\n\n")
    buffer.write("========================================\n")
    buffer.write("              CONTEXTO ACTUAL           \n")
    buffer.write("========================================\n\n")
    
    # 1. Chat Logs
    buffer.write("--- CHAT HISTORY ---\n")
    for row in history_data:
        # Check tuple length
        if len(row) >= 2:
            role = row[0]
            content = row[1]
            buffer.write(f"[{str(role).upper()}]:\n{str(content)}\n\n")
        
    buffer.write("\n========================================\n")
    buffer.write("   ESTRUCTURA DEL WORKSPACE REMOTO (ANTIGRAVITY)\n")
    buffer.write("========================================\n\n")
    
    # 2. Project Maps
    try:
        if os.path.exists(vault_dir):
            found_maps = False
            for f in os.listdir(vault_dir):
                if f.startswith("project_map_") and f.endswith(".json"):
                    found_maps = True
                    node_id = f.replace("project_map_", "").replace(".json", "")
                    buffer.write(f"\n[NODE MAP: {node_id}]\n")
                    
                    try:
                        with open(os.path.join(vault_dir, f), "r") as pf:
                            data = json.load(pf)
                            if isinstance(data, list):
                                for item in data:
                                    path_str = item.get("path", "unknown")
                                    size_str = f"({item.get('size', 0)} bytes)"
                                    buffer.write(f"- {path_str} {size_str}\n")
                            else:
                                buffer.write("[Error: Invalid Map Format]\n")
                    except Exception as e:
                        buffer.write(f"[Read Error: {e}]\n")
                            
            if not found_maps:
                buffer.write("[No Active Satellite Maps Found in Vault]\n")
        else:
            buffer.write("[Vault Directory Missing]\n")
            
    except Exception as e:
        buffer.write(f"\n[Error Assembling Remote Context: {str(e)}]\n")
        
    return buffer.getvalue()
