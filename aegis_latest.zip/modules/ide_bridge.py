import os
import json
import platform
import database
from modules.utils import get_user_root

# Try to import auth_vault, harmless if fails (fallback to database keys)
try:
    from modules.auth_vault import auth
except ImportError:
    auth = None

def get_config_path():
    """Determines the 'Continue' extension config path based on OS."""
    system = platform.system()
    home = os.path.expanduser("~")
    
    if system == "Linux":
        # Standard Code-Server path on Linux
        return os.path.join(home, ".local", "share", "code-server", "User", "globalStorage", "continue.continue", "config.json")
    elif system == "Windows":
        # Visual Studio Code path on Windows
        return os.path.join(os.getenv("APPDATA"), "Code", "User", "globalStorage", "continue.continue", "config.json")
    elif system == "Darwin":
        # macOS path (VS Code)
        return os.path.join(home, "Library", "Application Support", "Code", "User", "globalStorage", "continue.continue", "config.json")
    return None

def sync_ai_config(master_password=None):
    """
    Reads Aegis AI configuration and injects it into the IDE (Code-Server/VSCode).
    TARGET: 'Continue' extension config.json.
    """
    target_path = get_config_path()
    if not target_path:
        return {"status": "error", "message": f"Bridge not supported on {platform.system()}"}
        
    # 1. Read Aegis State
    active_model = database.get_setting("active_model") or "gemini-1.5-flash"
    ollama_url = database.get_setting("ollama_url") or "http://localhost:11434"
    
    # 2. Resolve Keys (Try DB first, then Vault if password provided)
    gemini_key = database.get_setting("api_key_gemini")
    if not gemini_key and auth and master_password:
        gemini_key = auth.get_api_key(master_password)
        
    openai_key = database.get_setting("api_key_openai")
    anthropic_key = database.get_setting("api_key_anthropic")

    # 3. Build 'Continue' Configuration
    models = []
    tab_model = None
    
    # Helper to check provider
    model_lower = active_model.lower()
    
    # A. STRICT OLLAMA FORGE CONFIGURATION (User Requirement)
    # The Forge (VS Code) MUST use the local coder model to handle codebase.
    local_coder = database.get_setting("local_coder_model") or "qwen2.5-coder" # Default to strong coder
    # Clean model name (remove ollama- prefix if exists)
    local_coder = local_coder.replace("ollama-", "")
    
    # Tab Autocomplete Model (Lightweight)
    local_tab = "qwen2.5-coder:1.5b" # Hardcoded lightweight preference for speed
    
    models = [{
        "title": f"Aegis Forge ({local_coder})",
        "provider": "ollama",
        "model": local_coder,
        "apiBase": "http://127.0.0.1:11434"
    }]
    
    tab_model = {
        "title": "Tab Autocomplete",
        "provider": "ollama",
        "model": local_tab,
        "apiBase": "http://127.0.0.1:11434"
    }

    # Construct Final JSON
    config = {
        "models": models,
        "tabAutocompleteModel": tab_model,
        "allowAnonymousTelemetry": False,
        "systemMessage": "You are Aegis-IA, a Senior Engineer embedded in The Forge. You answer concisely, technically, and without social pleasantries. Focus on the code." # Forced Persona
    }
    
    # 4. Write Configuration
    try:
        # A. Primary Target (VS Code / Code-Server Global Storage)
        os.makedirs(os.path.dirname(target_path), exist_ok=True)
        with open(target_path, "w") as f:
            json.dump(config, f, indent=4)
            
        # B. Legacy/Fallback (~/.continue/config.json)
        if platform.system() == "Linux":
            legacy_path = os.path.expanduser("~/.continue/config.json")
            os.makedirs(os.path.dirname(legacy_path), exist_ok=True)
            with open(legacy_path, "w") as f:
                 json.dump(config, f, indent=4)

        return {"status": "success", "path": target_path, "model": local_coder}
    except Exception as e:
        return {"status": "error", "message": str(e)}

if __name__ == "__main__":
    # Test run
    print(sync_ai_config())
