# modules/docker_sandbox.py
import subprocess
import os


class DockerSandbox:
    def __init__(self, safe_root):
        self.safe_root = os.path.abspath(safe_root)
        self.image = "aegis-sandbox:latest"
        self.forbidden_mounts = [
            "/etc",
            "/var/run/docker.sock",
            "/",
            "/var",
            "/usr",
            "/sys",
            "/dev",
        ]
        self.ensure_image()

    def ensure_image(self):
        if not self.is_docker_available():
            return
        try:
            res = subprocess.run(
                ["docker", "image", "inspect", self.image],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
            if res.returncode != 0:
                print(f"[Sandbox] Construyendo imagen base {self.image}...")
                dockerfile = 'FROM python:3.11-slim\nRUN apt-get update && apt-get install -y curl git jq build-essential\nWORKDIR /workspace\nRUN pip install requests pandas numpy matplotlib scikit-learn\nCMD ["tail", "-f", "/dev/null"]'
                import tempfile

                with tempfile.NamedTemporaryFile(
                    mode="w", suffix=".Dockerfile", delete=False
                ) as f:
                    f.write(dockerfile)
                    tpath = f.name
                try:
                    b_res = subprocess.run(
                        ["docker", "build", "-t", self.image, "-f", tpath, "."],
                        capture_output=True,
                        text=True,
                    )
                    if b_res.returncode == 0:
                        print(f"✅ Sandbox Image Built: {self.image}")
                    else:
                        print(f"❌ Error construyendo sandbox: {b_res.stderr}")
                finally:
                    os.remove(tpath)
        except Exception as e:
            print(f"[Sandbox] Auto-Build Error: {e}")

    def _is_safe_mount(self, path):
        abs_path = os.path.abspath(path)
        for forbidden in self.forbidden_mounts:
            if abs_path == os.path.abspath(forbidden):
                return False
        return True

    def is_docker_available(self):
        try:
            result = subprocess.run(
                ["docker", "--version"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
            )
            return result.returncode == 0
        except Exception:
            return False

    def wrap_command(self, command):
        if not self._is_safe_mount(self.safe_root):
            raise PermissionError(
                "Intento de montaje prohibido bloqueado por DockerSandbox."
            )

        # Retorna el comando empaquetado como lista para subprocess
        return [
            "docker",
            "run",
            "--rm",
            "--memory=1g",
            "--cpu-period=100000",
            "--cpu-quota=50000",
            "--storage-opt",
            "size=2G",
            "-v",
            f"{self.safe_root}:/workspace",
            "-w",
            "/workspace",
            self.image,
            "sh",
            "-c",
            command,
        ]
