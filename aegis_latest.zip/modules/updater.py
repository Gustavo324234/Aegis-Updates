import os
import sys
import json
import logging
import requests
import subprocess

# --- CONFIG ---
# --- CONFIG ---
# URL for the manifest file (version.json)
UPDATE_MANIFEST_URL = (
    "https://raw.githubusercontent.com/Gustavo324234/Aegis-Updates/main/version.json"
)
# Fixed Artifact URL (Always download 'latest' zip)
DEFAULT_ZIP_URL = "https://raw.githubusercontent.com/Gustavo324234/Aegis-Updates/main/aegis_latest.zip"

# Setup Logger
logger = logging.getLogger("Updater")
logger.setLevel(logging.INFO)
if not logger.handlers:
    ch = logging.StreamHandler()
    formatter = logging.Formatter("%(asctime)s - [UPDATER] - %(message)s")
    ch.setFormatter(formatter)
    logger.addHandler(ch)


def get_local_version():
    """Reads the local version.json if it exists."""
    if os.path.exists("version.json"):
        try:
            with open("version.json", "r") as f:
                return json.load(f)
        except Exception:
            pass
    return {"version": "0.0.0"}


def check_for_updates():
    """
    Checks remote manifest against local version.
    Returns: (bool update_available, str message)
    """
    logger.info(f"Checking updates against {UPDATE_MANIFEST_URL}...")
    try:
        # 1. Fetch Manifest
        r = requests.get(UPDATE_MANIFEST_URL, timeout=10)
        if r.status_code != 200:
            return False, f"Manifest fetch failed: {r.status_code}"

        remote_data = r.json()
        local_data = get_local_version()

        remote_ver = remote_data.get("version", "0.0.0")
        local_ver = local_data.get("version", "0.0.0")

        logger.info(f"Local: {local_ver} vs Remote: {remote_ver}")

        # Simple string comparison (for now)
        if remote_ver != local_ver:
            changelog = remote_data.get("changelog", "Updated.")
            msg = f"New Version {remote_ver} Available!\n{changelog}"
            return True, msg

        return False, "System is up to date."

    except Exception as e:
        logger.error(f"Check failed: {e}")
        return False, str(e)


def perform_update(daemon_manager):
    """
    Downloads ZIP, verifies, and launches external installer
    to preserve user data (users/, vault/) via shutil.
    """
    logger.info("Initiating Update Protocol (Git-Free)...")

    # 1. Stop Services
    try:
        if daemon_manager:
            daemon_manager.stop()
    except Exception:
        pass

    # 2. Get Download URL
    try:
        r = requests.get(UPDATE_MANIFEST_URL, timeout=10)
        manifest = r.json() if r.status_code == 200 else {}
        # Prioritize manifest URL, fallback to Repo Zip
        zip_url = manifest.get("zip_url", DEFAULT_ZIP_URL)

        logger.info(f"Downloading Update Package from: {zip_url}")

        # 3. Download ZIP
        update_pkg = "update_pkg.zip"
        with requests.get(zip_url, stream=True) as r:
            r.raise_for_status()
            with open(update_pkg, "wb") as f:
                for chunk in r.iter_content(chunk_size=8192):
                    f.write(chunk)

        logger.info("Download complete. Verifying integrity...")

        # 4. Verify Integrity (Optional Hash Check)
        if "zip_hash" in manifest:
            # TODO: Implement hash verification
            pass

    except Exception as e:
        logger.error(f"Download Error: {e}")
        return False

    # 5. Generate External Installer (The "Surgeon")
    installer_path = "_update_installer.py"
    installer_code = r'''import os
import sys
import shutil
import time
import zipfile
import subprocess

def kill_aegis_processes():
    """Kills other python processes to release file locks."""
    pid = os.getpid()
    if os.name == 'nt':
        subprocess.run(f"taskkill /F /FI \"IMAGENAME eq python.exe\" /FI \"PID ne {pid}\"", shell=True)
    else:
        subprocess.run("pkill -9 -f 'python.*app_web.py'", shell=True)

def install():
    print("🔵 [INSTALLER] Waiting for Aegis to close...")
    time.sleep(3)
    
    print("🔪 [INSTALLER] Cleaning active processes...")
    kill_aegis_processes()
    time.sleep(2)
    
    update_zip = "update_pkg.zip"
    extract_temp = "_temp_update_extract"
    
    try:
        print("📦 [INSTALLER] Extracting Package...")
        if os.path.exists(extract_temp):
            shutil.rmtree(extract_temp)
        os.makedirs(extract_temp)
        
        with zipfile.ZipFile(update_zip, 'r') as zf:
            zf.extractall(extract_temp)
            
        # Determine Source Root (Handle GitHub 'Main' folder nesting)
        source_root = extract_temp
        items = os.listdir(extract_temp)
        if len(items) == 1 and os.path.isdir(os.path.join(extract_temp, items[0])):
            print(f"   Detected nested root: {items[0]}")
            source_root = os.path.join(extract_temp, items[0])
            
        print(f"🚀 [INSTALLER] Installing updates to {os.getcwd()}...")
        print("   🛡️ PRESERVING: users/, vault/, databases...")
        
        # CRITICAL: shutil.copytree with dirs_exist_ok=True
        # This overwrites ONLY files present in the update.
        # Since update_pkg.zip is built with filtered excluded folders (users, vault),
        # those local folders remain untouched.
        shutil.copytree(source_root, ".", dirs_exist_ok=True)
        
        print("✅ Update Applied.")
        
        # Cleanup
        try:
            shutil.rmtree(extract_temp)
            os.remove(update_zip)
            print("🧹 Cleanup complete.")
        except: pass
        
        # Restart
        print("🔥 [INSTALLER] Rebooting Aegis...")
        if os.path.exists("process_watchdog.py"):
            subprocess.Popen([sys.executable, "process_watchdog.py"], creationflags=subprocess.CREATE_NEW_CONSOLE)
        else:
             subprocess.Popen([sys.executable, "-m", "streamlit", "run", "app_web.py"], creationflags=subprocess.CREATE_NEW_CONSOLE)

    except Exception as e:
        print(f"❌ CRITICAL UPDATE FAILURE: {e}")
        input("Press Enter to exit...")

if __name__ == "__main__":
    install()
'''
    try:
        with open(installer_path, "w", encoding="utf-8") as f:
            f.write(installer_code)
    except Exception as e:
        logger.error(f"Installer Gen Failed: {e}")
        return False

    # 6. Execute Handover
    logger.warning("Handing over to Installer. Process ending.")
    subprocess.Popen(
        [sys.executable, installer_path], creationflags=subprocess.CREATE_NEW_CONSOLE
    )
    os._exit(0)
