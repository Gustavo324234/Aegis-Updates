# modules/subagent_spawner.py
import json
import database
import uuid

DESCRIPTION = """
Use this module to delegate tasks to a Background Subagent.
A subagent works silently, has a fresh memory context to save tokens, and can use tools independently.
When finished, it will report back to you via an [SUBAGENT_ANNOUNCE] event.
Commands:
- spawn_subagent: {"module": "subagent_spawner", "action": "spawn", "task_description": "Create a python script that does X...", "tools_needed": ["system_tools", "file_writer"]}
"""


def execute(query, brain_instance=None):
    try:
        if isinstance(query, str):
            data = json.loads(query)
        else:
            data = query

        action = data.get("action")
        if action != "spawn":
            return f"Error: Unknown action '{action}'"

        task_description = data.get("task_description")
        tools_needed = data.get("tools_needed", [])

        if not task_description:
            return "Error: task_description is strictly required."

        # Fetch active thread tag from brain or assume single user instance
        # For this version we use a global tag or fetch from environment:
        # database.save_message uses 'general' by default, or parent_thread_tag
        parent_thread_tag = "general"

        sub_id = str(uuid.uuid4())[:6]
        goal = f"[SUBAGENT_MISSION][{parent_thread_tag}] Subagent ID-{sub_id}: {task_description}"

        # Subagent instructions Step 1
        steps = [
            f"Ejecuta la misión delegada y usa las herramientas autorizadas ({tools_needed}) si es necesario."
        ]

        # Insert into Mision DB
        database.create_mission(goal, steps)

        # Wake up the daemon automatically to serve this subagent
        database.set_daemon_status("mission_worker", "RUNNING")

        return f"Subagent Deployed (ID-{sub_id}). El subagente está trabajando en background. Se te notificará cuando termine con un [SUBAGENT_ANNOUNCE]."

    except Exception as e:
        return f"Subagent Spawn Error: {e}"
