import os
import fnmatch

DESCRIPTION = """
Module: file_writer
Purpose: Controlled File Writing. Allows the AI to write text or code to a file in the workspace.
Actions:
- write_file: Writes content to a specific file path. Will overwrite if exists.
Usage format:
{"module": "file_writer", "action": "write_file", "args": {"path": "main.py", "content": "print('Hello World')"}}
"""

IGNORE_PATTERNS = [
    ".git", "__pycache__", ".venv", "venv", "node_modules", ".idea", ".vscode", 
    "dist", "build", "*.pyc", "*.spec", "package-lock.json", "yarn.lock", 
    ".DS_Store", "Thumbs.db", "site-packages", ".streamlit"
]

SENSITIVE_FILES = [
    "secrets.json", ".env", "aegis_memory.db", "users.db", 
    "master_key.key", "id_rsa", "id_rsa.pub", "app_web.py", "database.py", "core.py", "module_manager.py"
]

MAX_FILE_SIZE = 500000  # 500KB limit per file

# --- SECURITY: CHROOT LOGIC ---
def get_user_root():
    """Determines the safe root directory for file operations."""
    # 1. Try Environment Variable (Multi-Tenant)
    user_root = os.getenv('AEGIS_USER_ROOT')
    if user_root:
        return os.path.abspath(user_root)
    
    # 2. Fallback to Current Working Directory (Local/Dev)
    return os.path.abspath(os.getcwd())

SAFE_ROOT = get_user_root()

def is_safe_path(path):
    """
    Validates that a path is securely inside the SAFE_ROOT.
    Prevents Directory Traversal (../../etc/passwd).
    """
    try:
        # Resolve absolute path
        abs_path = os.path.abspath(os.path.join(SAFE_ROOT, path))
        
        # Check against Sensitive Files Blacklist
        filename = os.path.basename(abs_path)
        if filename in SENSITIVE_FILES:
            return False

        # Check prefix to ensure containment
        return os.path.commonpath([SAFE_ROOT]) == os.path.commonpath([SAFE_ROOT, abs_path])
    except:
        return False

def execute(query):
    action = query.get("action")
    args = query.get("args", {})
    
    if action == "write_file":
        path = args.get("path")
        content = args.get("content")
        
        if not path or not content:
            return "Error: Path and Content required."
            
        if not is_safe_path(path):
            print(f"[FILE_WRITER] Prevented write to unsafe path: {path}")
            return "Error: Access Denied (Path outside workspace or restricted file)"
            
        return write_file(path, content)
            
    else:
        return f"File Writer Error: Unknown action '{action}'"

def write_file(relative_path, content):
    try:
        target_path = os.path.abspath(os.path.join(SAFE_ROOT, relative_path))
        
        # Ensure directory exists
        os.makedirs(os.path.dirname(target_path), exist_ok=True)
        
        # Validate size before writing (if amending, not fully implemented here, assumes new content)
        if len(content) > MAX_FILE_SIZE:
             return f"Error: Content too large (>500KB). Split into smaller files."
             
        with open(target_path, 'w', encoding='utf-8') as f:
            f.write(content)
            
        return f"File Written Successfully: {relative_path}"
    except Exception as e:
        return f"Write Error: {str(e)}"
