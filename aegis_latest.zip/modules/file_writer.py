import os

from modules.utils import get_user_root, is_safe_path

DESCRIPTION = """
Module: file_writer
Purpose: Controlled File Writing. Allows the AI to write text or code to a file in the workspace.
Actions:
- write_file: Writes content to a specific file path. Will overwrite if exists.
Usage format:
{"module": "file_writer", "action": "write_file", "args": {"path": "main.py", "content": "print('Hello World')"}}
"""

IGNORE_PATTERNS = [
    ".git",
    "__pycache__",
    ".venv",
    "venv",
    "node_modules",
    ".idea",
    ".vscode",
    "dist",
    "build",
    "*.pyc",
    "*.spec",
    "package-lock.json",
    "yarn.lock",
    ".DS_Store",
    "Thumbs.db",
    "site-packages",
    ".streamlit",
]

MAX_FILE_SIZE = 500000  # 500KB limit per file

SAFE_ROOT = get_user_root()


def execute(query):
    action = query.get("action")
    args = query.get("args", {})

    if action == "write_file":
        path = args.get("path")
        content = args.get("content")

        if not path or not content:
            return "Error: Path and Content required."

        if not is_safe_path(path):
            print(f"[FILE_WRITER] Prevented write to unsafe path: {path}")
            return "Error: Access Denied (Path outside workspace or restricted file)"

        return write_file(path, content)

    else:
        return f"File Writer Error: Unknown action '{action}'"


def write_file(relative_path, content):
    try:
        target_path = os.path.abspath(os.path.join(SAFE_ROOT, relative_path))

        # Ensure directory exists
        os.makedirs(os.path.dirname(target_path), exist_ok=True)

        # Validate size before writing (if amending, not fully implemented here, assumes new content)
        if len(content) > MAX_FILE_SIZE:
            return "Error: Content too large (>500KB). Split into smaller files."

        with open(target_path, "w", encoding="utf-8") as f:
            f.write(content)

        return f"File Written Successfully: {relative_path}"
    except Exception as e:
        return f"Write Error: {str(e)}"
