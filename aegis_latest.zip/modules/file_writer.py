import os
import logging
from datetime import datetime

from modules.utils import get_user_root, is_safe_path

logger = logging.getLogger(__name__)

DESCRIPTION = """
Module: file_writer
Purpose: Controlled File Writing. Allows the AI to write text or code to a file in the workspace.
Actions:
- write_file: Writes content to a specific file path inside the workspace. Will overwrite if exists.
- submit_system_improvement: Submits a proposal to improve a core/sensitive file.
  The AI cannot modify sensitive files directly; this action writes a proposal report to
  workspace/proposals/ and emails it to the Architect for manual review and approval.

Usage format:
  write_file:
    {"module": "file_writer", "action": "write_file", "args": {"path": "main.py", "content": "print('Hello World')"}}
  submit_system_improvement:
    {"module": "file_writer", "action": "submit_system_improvement", "args": {"filename": "brain.py", "description": "Improve context handling", "proposed_code": "..."}}
"""

IGNORE_PATTERNS = [
    ".git",
    "__pycache__",
    ".venv",
    "venv",
    "node_modules",
    ".idea",
    ".vscode",
    "dist",
    "build",
    "*.pyc",
    "*.spec",
    "package-lock.json",
    "yarn.lock",
    ".DS_Store",
    "Thumbs.db",
    "site-packages",
    ".streamlit",
]

MAX_FILE_SIZE = 500000  # 500KB limit per file

SAFE_ROOT = get_user_root()


def execute(query):
    action = query.get("action")
    args = query.get("args", {})

    if action == "write_file":
        path = args.get("path")
        content = args.get("content")

        if not path or not content:
            return "Error: Path and Content required."

        if not is_safe_path(path):
            logger.warning(f"[FILE_WRITER] Prevented write to unsafe path: {path}")
            return "Error: Access Denied (Path outside workspace or restricted file)"

        return write_file(path, content)

    elif action == "submit_system_improvement":
        filename = args.get("filename")
        description = args.get("description")
        proposed_code = args.get("proposed_code")

        if not filename or not description or not proposed_code:
            return (
                "Error: 'filename', 'description' and 'proposed_code' are all required."
            )

        return submit_system_improvement(filename, description, proposed_code)

    else:
        return f"File Writer Error: Unknown action '{action}'"


def write_file(relative_path, content):
    try:
        target_path = os.path.abspath(os.path.join(SAFE_ROOT, relative_path))

        # Ensure directory exists
        os.makedirs(os.path.dirname(target_path), exist_ok=True)

        # Validate size before writing
        if len(content) > MAX_FILE_SIZE:
            return "Error: Content too large (>500KB). Split into smaller files."

        with open(target_path, "w", encoding="utf-8") as f:
            f.write(content)

        return f"File Written Successfully: {relative_path}"
    except Exception as e:
        return f"Write Error: {str(e)}"


def submit_system_improvement(
    filename: str, description: str, proposed_code: str
) -> str:
    """
    Human-in-the-Loop improvement channel.

    The AI uses this action to propose changes to sensitive/core files.
    It CANNOT modify those files directly. Instead it:
      1. Writes a structured Markdown report to workspace/proposals/
      2. Emails the report to the Architect for manual review.

    Args:
        filename (str):      Name of the core file to be improved (e.g. 'brain.py').
        description (str):   Human-readable explanation of the proposed change.
        proposed_code (str): The new/improved code to be reviewed.

    Returns:
        str: Status message for the AI to relay to the user.
    """
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    safe_name = os.path.basename(filename)  # Strip any path — only the filename matters

    # ── 1. Write the proposal report ────────────────────────────────────────
    proposals_dir = os.path.join(SAFE_ROOT, "proposals")
    os.makedirs(proposals_dir, exist_ok=True)

    report_filename = f"{timestamp}_{safe_name}.md"
    report_path = os.path.join(proposals_dir, report_filename)

    report_content = f"""# 🤖 Aegis System Improvement Proposal

**Date:** {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
**Target File:** `{safe_name}`
**Status:** ⏳ Pending Architect Review

---

## 📋 Description of Proposed Change

{description}

---

## 💡 Sensitivity Notice

`{safe_name}` is listed as a **SENSITIVE_FILE**. Aegis cannot modify it directly.
This proposal must be reviewed and applied **manually** by the Architect.

---

## 📝 Proposed Code

```python
{proposed_code}
```

---

*This proposal was generated automatically by the Aegis Uplink Protocol.*
*No core files were modified. Human approval is required before any change takes effect.*
"""

    try:
        with open(report_path, "w", encoding="utf-8") as f:
            f.write(report_content)
        logger.info(f"[FILE_WRITER] Proposal report written: {report_path}")
    except Exception as e:
        return f"Uplink Error: Could not write proposal report. {e}"

    # ── 2. Send via Uplink (email) ───────────────────────────────────────────
    email_status_msg = ""
    try:
        from modules.uplink import send_architect_proposal

        subject = f"Improvement Proposal for `{safe_name}`"
        result = send_architect_proposal(
            subject=subject,
            body=report_content,
            attachment_path=report_path,
        )

        if result.get("success"):
            email_status_msg = f"✅ Email sent to Architect ({result['message']})"
        else:
            email_status_msg = f"⚠️  Email could not be sent: {result['message']}"
            logger.warning(f"[FILE_WRITER] Uplink email failed: {result['message']}")

    except Exception as e:
        email_status_msg = f"⚠️  Email module unavailable: {e}"
        logger.error(f"[FILE_WRITER] Uplink import error: {e}")

    # ── 3. Return structured feedback ────────────────────────────────────────
    return (
        f"📤 System Improvement Proposal submitted for `{safe_name}`.\n"
        f"📄 Report saved to: workspace/proposals/{report_filename}\n"
        f"{email_status_msg}\n"
        f"⏳ Awaiting Architect approval. No core files were modified."
    )
