# modules/backup_manager.py

import os
import datetime
import zipfile


class BackupManager:
    def __init__(self):
        self.backup_dir = "backups"
        if not os.path.exists(self.backup_dir):
            os.makedirs(self.backup_dir)

    def create_full_backup(self):
        """Creates a zip archive of the entire system state (DB, Skills, Vault)."""
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"aegis_backup_{timestamp}.aegis"  # Custom extension for flair
        filepath = os.path.join(self.backup_dir, filename)

        try:
            with zipfile.ZipFile(filepath, "w", zipfile.ZIP_DEFLATED) as zipf:
                # 1. Database
                if os.path.exists("aegis_memory.db"):
                    zipf.write("aegis_memory.db", arcname="aegis_memory.db")

                # 2. Skills Registry
                if os.path.exists("skills_registry.json"):
                    zipf.write("skills_registry.json", arcname="skills_registry.json")

                # 3. Skills Folder
                if os.path.exists("skills"):
                    for root, dirs, files in os.walk("skills"):
                        for file in files:
                            zipf.write(
                                os.path.join(root, file),
                                os.path.relpath(
                                    os.path.join(root, file),
                                    os.path.join("skills", ".."),
                                ),
                            )

                # 4. Vault Folder
                if os.path.exists("vault"):
                    for root, dirs, files in os.walk("vault"):
                        for file in files:
                            zipf.write(
                                os.path.join(root, file),
                                os.path.relpath(
                                    os.path.join(root, file),
                                    os.path.join("vault", ".."),
                                ),
                            )

            return True, filepath
        except Exception as e:
            return False, str(e)

    def restore_backup(self, backup_path):
        """Restores system state from a backup file."""
        # This is dangerous as it overwrites current state.
        # In a real app, we'd verify integrity first.
        try:
            with zipfile.ZipFile(backup_path, "r") as zipf:
                zipf.extractall(".")
            return True, "System restored successfully."
        except Exception as e:
            return False, str(e)


backup = BackupManager()
