import json
import database
from datetime import datetime

DESCRIPTION = """
Module: cron_manager
Purpose: Schedule recurring tasks using natural language.
Actions:
- schedule_task: Registers a new repeating task.
Usage: {"module": "cron_manager", "action": "schedule_task", "args": {"natural_time": "every day at 9am", "task_description": "check disk space"}}
"""


def execute(query, brain_instance=None):
    action = query.get("action")
    args = query.get("args", {})

    if action == "schedule_task":
        nat_time = args.get("natural_time")
        desc = args.get("task_description")

        if not brain_instance:
            return "Error: Brain required for temporal translation."

        # 1. Usar el modelo Logic para traducir a formato HH:MM o Intervalo
        # Simplificación para el DaemonManager existente (Daily Briefing style)
        # Ojo: DaemonManager actual soporta "interval" (segundos) o "time" (HH:MM para daily)

        prompt = f"""
        Translate this schedule '{nat_time}' into a JSON config for a python scheduler.
        Formats allowed:
        1. Daily specific time: {{"type": "daily", "time": "HH:MM"}}
        2. Interval seconds: {{"type": "interval", "seconds": 3600}}
        
        Return ONLY JSON.
        """
        try:
            resp = brain_instance.query(
                prompt, [], "specialist:logic", require_json=True
            )
            import re

            match = re.search(r"(\{.*\})", str(resp), re.DOTALL)
            if match:
                config = json.loads(match.group(1))

                # Crear nombre único
                safe_name = f"AutoCron_{int(datetime.now().timestamp())}"

                # Inyectar instrucción para el Worker
                # El worker usará 'mission_worker' logic pero programado
                # Truco: Registramos un Daemon tipo 'mission_worker' con config especial

                final_config = {
                    "goal": desc,
                    "mode": "recurring",
                    "schedule_type": config.get("type"),
                    "schedule_val": config.get("time")
                    if config.get("type") == "daily"
                    else config.get("seconds"),
                }

                # Nota: DaemonManager necesita una actualización para leer este config custom,
                # pero primero registramos.
                database.register_daemon(safe_name, "auto_cron", final_config)

                return f"✅ Tarea programada: '{desc}' ({nat_time})."
        except Exception as e:
            return f"Error de traducción temporal: {e}"

    return "Unknown Action"
