import database
import re
import io


class Codex:
    def __init__(self):
        pass

    def save_snippet(self, title, code, tags, language="text"):
        """Saves a code snippet to the Codex."""
        database.add_codex_snippet(title, language, code, tags)

        # Codex 2.0: Semantic Embedding
        try:
            from modules.vault_manager import vault

            content = (
                f"Title: {title}\nLanguage: {language}\nTags: {tags}\nCode:\n{code}"
            )
            # Use a reserved collection for Code Memory
            vault.index_file(
                f"codex_{title}_{language}.txt",
                collection="codex_memory",
                file_bytes=io.BytesIO(content.encode("utf-8")),
            )
        except Exception:
            pass

        return True

    def search(self, query):
        """Searches Codex by tags, title, or content (Hybrid)."""
        # 1. DB Search (Tags/Keyword)
        db_results = database.search_codex(query)

        # 2. Semantic Search (Vault)
        try:
            from modules.vault_manager import vault

            semantic = vault.search(query, collection="codex_memory")
            # Merge logic could go here, for now return DB results prioritized
            if semantic:
                pass  # Placeholder for merge logic
        except Exception:
            pass

        return db_results

    def extract_from_history(self, history):
        """Finds the most recent code block in conversation history."""
        # Iterate backwards
        for role, msg in reversed(history):
            if role == "assistant" and "```" in msg:
                matches = re.findall(r"```(\w+)?\n(.*?)```", msg, re.DOTALL)
                if matches:
                    # Return the LAST match of the message
                    lang, code = matches[-1]
                    return lang or "text", code.strip()
        return None, None


codex_system = Codex()
