import database
import re
import io
import requests
import threading
import json


class Codex:
    def __init__(self):
        pass

    def save_snippet(self, title, code, tags, language="text"):
        """Saves a code snippet to the Codex and triggers Neural Pulse sync."""
        # Anti-Loop: If already synced from another node, don't broadcast again
        is_synced = "synced:true" in (tags or "")

        # Use the correct database method name
        database.save_codex_snippet(title, code, tags, language)

        # Codex 2.0: Semantic Embedding
        try:
            from modules.vault_manager import vault

            content = (
                f"Title: {title}\nLanguage: {language}\nTags: {tags}\nCode:\n{code}"
            )
            # Use a reserved collection for Code Memory
            vault.index_file(
                f"codex_{title}_{language}.txt",
                collection="codex_memory",
                file_bytes=io.BytesIO(content.encode("utf-8")),
            )
        except Exception:
            pass

        # Neural Pulse: Knowledge Broadcast
        if not is_synced:
            # Add sync tag for transmission
            broadcast_tags = f"{tags},synced:true" if tags else "synced:true"
            threading.Thread(
                target=self._broadcast_pulse,
                args=(title, code, broadcast_tags, language),
                daemon=True,
            ).start()

        return True

    def _broadcast_pulse(self, title, code, tags, language):
        """Broadcasts knowledge to peered nodes via the Nexus Gateway."""
        try:
            nodes = database.get_all_nodes()
            target_nodes = []

            for node in nodes:
                try:
                    # Filter: Hub Peers or Satellites with contribution mode active
                    caps = json.loads(node.get("caps", "{}"))
                    is_hub = caps.get("client_type") == "hub_connector"
                    # Check both 'contribution' and 'contribution_mode' for flexibility
                    is_contributor = caps.get("contribution") or caps.get(
                        "contribution_mode"
                    )

                    if (is_hub or is_contributor) and node.get("status") == "online":
                        target_nodes.append(node.get("node_id"))
                except (json.JSONDecodeError, TypeError):
                    continue

            if not target_nodes:
                return

            # Identify this hub
            my_node_id = database.get_setting("node_id") or "Hub"

            # Prepare codex_sync payload
            # Based on nexus_gateway.py, it expects a nested 'result' for sync messages
            payload = {
                "type": "hub_vault",
                "msg": {
                    "sender": my_node_id,
                    "result": {
                        "codex_sync": [
                            {
                                "title": title,
                                "code": code,
                                "tags": tags,
                                "language": language,
                            }
                        ]
                    },
                },
            }

            shared_count = 0
            gateway_url = "http://localhost:8000/send_message"

            for node_id in target_nodes:
                try:
                    msg_data = {"target_node": node_id, "content": payload}
                    resp = requests.post(gateway_url, json=msg_data, timeout=5)
                    if resp.status_code == 200:
                        shared_count += 1
                except Exception:
                    continue

            if shared_count > 0:
                database.log_audit_event(
                    module="CODEX",
                    action="Neural Pulse",
                    status="INFO",
                    details=f"Neural Pulse: Shared snippet '{title}' with {shared_count} nodes.",
                )
        except Exception:
            # Silent failure for background broadcast to avoid breaking main flow
            pass

    def search(self, query):
        """Searches Codex by tags, title, or content (Hybrid)."""
        # 1. DB Search (Tags/Keyword)
        db_results = database.search_codex(query)

        # 2. Semantic Search (Vault)
        try:
            from modules.vault_manager import vault

            semantic = vault.search(query, collection="codex_memory")
            # Merge logic could go here, for now return DB results prioritized
            if semantic:
                pass  # Placeholder for merge logic
        except Exception:
            pass

        return db_results

    def extract_from_history(self, history):
        """Finds the most recent code block in conversation history."""
        # Iterate backwards
        for role, msg in reversed(history):
            if role == "assistant" and "```" in msg:
                matches = re.findall(r"```(\w+)?\n(.*?)```", msg, re.DOTALL)
                if matches:
                    # Return the LAST match of the message
                    lang, code = matches[-1]
                    return lang or "text", code.strip()
        return None, None


codex_system = Codex()
