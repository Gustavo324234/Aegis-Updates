import database
import re

class Codex:
    def __init__(self):
        pass

    def save_snippet(self, title, code, tags, language="text"):
        """Saves a code snippet to the Codex."""
        # Future: Generate embeddings here if needed for semantic search
        database.add_codex_snippet(title, language, code, tags)
        return True

    def search(self, query):
        """Searches Codex by tags, title, or content."""
        return database.search_codex(query)

    def extract_from_history(self, history):
        """Finds the most recent code block in conversation history."""
        # Iterate backwards
        for role, msg in reversed(history):
            if role == "assistant" and "```" in msg:
                matches = re.findall(r'```(\w+)?\n(.*?)```', msg, re.DOTALL)
                if matches:
                    # Return the LAST match of the message
                    lang, code = matches[-1]
                    return lang or "text", code.strip()
        return None, None

codex_system = Codex()
