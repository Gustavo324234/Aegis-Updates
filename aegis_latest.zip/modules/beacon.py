import socket
import io
import qrcode
import platform


class Beacon:
    def __init__(self):
        self.public_url = None

    def start_tunnel(self, port=8501):
        """
        Starts a secure tunnel.
        Note: Using a free service like localtunnel or similar might be flaky.
        Here we implement a generic placeholder or use pyngrok if available.
        """
        try:
            from pyngrok import ngrok

            # SRE Fix: Atom CPU / Legacy Hardware Check
            machine = platform.machine().lower()
            if "i386" in machine or "i686" in machine:
                # 32-bit systems often struggle with modern compiled ngrok binaries
                pass  # Just a warning internally

            # Configure ngrok to be less verbose or use specific region if needed
            # conf.get_default().region = "us"

            # Start tunnel with robust error handling
            # We explicitly catch the specific termination errors
            tunnel = ngrok.connect(port)
            self.public_url = tunnel.public_url
            return self.public_url

        except ImportError:
            return "Error: 'pyngrok' not installed. Run setup.py."

        except Exception as e:
            err_str = str(e)
            # Detect Atom/Old CPU crashess
            if (
                "illegal instruction" in err_str.lower()
                or "core dumped" in err_str.lower()
                or "process finished with exit code" in err_str.lower()
            ):
                local_ip = self.get_local_ip()
                return f"""
⛔ CRITICAL: Ngrok Binary Incompatible (Illegal Instruction).
Your CPU is likely too old for the modern Ngrok build (common on Atom processsors).

ALTERNATIVES:
1. **Local WiFi**: Access via {local_ip} (Ensure Firewall allows Port {port})
2. **SSH Tunneling**: ssh -R 80:localhost:{port} serveo.net
"""

            return f"Tunnel Failed: {err_str}"

    def get_local_ip(self, port=8501):
        """Returns the local LAN IP address."""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return f"http://{ip}:{port}"
        except Exception:
            return f"http://localhost:{port}"

    def generate_qr(self, url):
        """Generates a QR code image for the URL."""
        qr = qrcode.QRCode(version=1, box_size=10, border=5)
        qr.add_data(url)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")

        # Convert to bytes for Streamlit
        img_byte_arr = io.BytesIO()
        img.save(img_byte_arr, format="PNG")
        return img_byte_arr.getvalue()


# Instance
beacon = Beacon()
