import os
import json
from modules.utils import get_user_root
import modules.system_tools as system_tools

DESCRIPTION = """
Module: synapse
Purpose: Ejecuta integraciones externas (Skills) pasándole comandos REST/CLI generados o parametrizados en base a archivos Markdown.
"""


def extract_frontmatter(file_path):
    """Extrae el bloque YAML inicial de un Markdown y luego el body"""
    metadata = {}
    content_body = ""
    with open(file_path, "r", encoding="utf-8") as f:
        lines = f.readlines()

    in_frontmatter = False
    fm_lines = []
    body_lines = []

    for line in lines:
        if line.strip() == "---":
            if not in_frontmatter and not body_lines:
                in_frontmatter = True
                continue
            elif in_frontmatter:
                in_frontmatter = False
                continue

        if in_frontmatter:
            fm_lines.append(line)
        else:
            body_lines.append(line)

    # Simple fallback parser if yaml is not installed
    try:
        import yaml

        metadata = yaml.safe_load("".join(fm_lines)) or {}
    except ImportError:
        for fl in fm_lines:
            if ":" in fl:
                k, v = fl.split(":", 1)
                metadata[k.strip()] = v.strip()

    content_body = "".join(body_lines).strip()
    return metadata, content_body


def discover_synapse_skills(module_manager_instance):
    """
    Called during ModuleManager init.
    Scans skills/external/ for .md files and dynamically registers them.
    """
    target_dir = os.path.join(get_user_root(), "skills", "external")
    if not os.path.exists(target_dir):
        os.makedirs(target_dir, exist_ok=True)

    # Phase 2: Sembrado de Synapse
    if not os.listdir(target_dir):
        demofile = os.path.join(target_dir, "github_issues.md")
        try:
            with open(demofile, "w", encoding="utf-8") as f:
                f.write(
                    '---\nname: github_issues\ndescription: Lee issues de un repositorio de GitHub\nauth_env: GITHUB_TOKEN\n---\n\n# GitHub Issues API\n\nUsa esta API para obtener los issues de un repo. \nComando curl de ejemplo:\n`curl -L -H "Accept: application/vnd.github+json" -H "Authorization: Bearer $GITHUB_TOKEN" -H "X-GitHub-Api-Version: 2022-11-28" https://api.github.com/repos/OWNER/REPO/issues`\n\nReemplaza OWNER y REPO con los reales.'
                )
            print("[SYNAPSE] Seeded github_issues.md")
        except Exception as e:
            print(f"Failed to seed external skills: {e}")

    for file in os.listdir(target_dir):
        if file.endswith(".md"):
            try:
                # 1. Parse Markdown
                path = os.path.join(target_dir, file)
                meta, body = extract_frontmatter(path)

                skill_name = meta.get("name", file.replace(".md", ""))
                desc = meta.get("description", "External API Skill")
                auth_req = meta.get("auth_env", None)

                # 2. Forge Tool Description
                # Inyectamos el body del MD en la descripcion para que el LLM sepa usar la API
                tool_full_desc = f"""
Synapse Skill: {skill_name}
Context: {desc}
Instructions: Para usar esta herramienta, genera un comando shell válido (ej. curl) basándote en esta info:
{body[:2000]} # Truncado para evitar explotar el contexto
Usa la accion 'execute' del modulo 'synapse' y pasa el 'command'.
Variables requeridas (Serán inyectadas automáticamente): {auth_req if auth_req else "Ninguna"}
"""

                # 3. Dynamic Registration (We create a dummy class/module in memory)
                class DynamicSynapseModule:
                    DESCRIPTION = tool_full_desc

                    @staticmethod
                    def execute(query, brain_instance=None):
                        # Redirect to the central Synapse executor
                        if isinstance(query, str):
                            data = json.loads(query)
                        else:
                            data = query

                        # Override args to include skill info
                        data["action"] = "execute"
                        data["skill_name"] = skill_name
                        data["auth_env"] = auth_req
                        return execute_synapse(data)

                # Register in Module Manager
                module_manager_instance.modules[f"synapse_{skill_name}"] = (
                    DynamicSynapseModule
                )
                print(f"[+] Loaded Synapse Skill: {skill_name}")

            except Exception as e:
                print(f"[Synapse Error] Failed to load {file}: {e}")


def execute_synapse(query):
    """Executes the generated shell command, injecting secrets."""
    if isinstance(query, str):
        data = json.loads(query)
    else:
        data = query

    action = data.get("action")
    if action != "execute":
        return f"Unknown action: {action}"

    cmd = data.get("command", "")
    if not cmd:
        return "Error: Requieres generar un 'command' (ej curl) basado en la documentación de la skill."

    skill_name = data.get("skill_name")
    auth_env = data.get("auth_env")

    # Inyección de Secretos
    if auth_env:
        from modules.auth_vault import auth

        # Requiere el password maestro en memoria o session para descifrar in-flight.
        # By design of authVault usually it depends on user input or session_state.
        # Assuming database has some access pattern or the user entered it avoiding UI freeze.
        import streamlit as st

        # CUIDADO: En demonios asíncronos st.session_state puede fallar.
        pwd = ""
        try:
            if "master_password" in st.session_state:
                pwd = st.session_state["master_password"]
        except Exception:
            pass

        secret = auth.get_secret(auth_env, pwd) if pwd else None

        if not secret:
            return f"Error: Synapse no puede ejecutar '{skill_name}'. Requieres configurar el secreto para '{auth_env}' en Configuración de la Bóveda, o Desbloquear tu sesión."

        # Reemplazar placeholder clásico o inyectar ENV
        if f"${auth_env}" in cmd:
            cmd = cmd.replace(f"${auth_env}", secret)
        elif "AUTH_TOKEN" in cmd:
            cmd = cmd.replace("AUTH_TOKEN", secret)

        # Se podría usar os.environ para pasarlo de forma segura al sandbox

    # Ejecutamos usando el sistema de herramientas (Sandbox)
    # Por seguridad, Synapse siempre enruta por el DockerSandbox si existe
    print(f"[SYNAPSE] Executing skill '{skill_name}'...")
    return system_tools.execute_command(cmd, allow_background=False)
