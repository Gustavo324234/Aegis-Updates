# modules/browser_tools.py
import json
from playwright.sync_api import sync_playwright

DESCRIPTION = """
Use this module to interact with the web (Browser Automation).

Commands:
1. Navigate & Extract:
   {"module": "browser_tools", "action": "scrape", "url": "https://example.com"}
   
2. Screenshot:
   {"module": "browser_tools", "action": "screenshot", "url": "https://example.com"}

Rules:
- Returns text summary or path to screenshot.
- Useful for researching real-time information.
"""

def scrape(url):
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            page = browser.new_page()
            page.goto(url)
            title = page.title()
            # Extract main text (simple body text for now)
            text = page.evaluate("document.body.innerText")
            browser.close()
            # Truncate text to avoid context overflow
            return f"Title: {title}\nContent Snippet:\n{text[:2000]}..."
    except Exception as e:
        return f"Browser Error: {str(e)}"

def screenshot(url):
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            page = browser.new_page()
            page.goto(url)
            path = f"screenshot_{url.replace('https://','').replace('/','_')}.png"
            page.screenshot(path=path)
            browser.close()
            return f"Screenshot saved to {path}"
    except Exception as e:
        return f"Browser Error: {str(e)}"

def execute(query):
    if isinstance(query, str):
        try:
            query = json.loads(query)
        except:
            return "Error: Query must be valid JSON."

    action = query.get("action")
    url = query.get("url")
    
    if not url:
        return "Error: URL is required."

    if action == "scrape":
        return scrape(url)
    elif action == "screenshot":
        return screenshot(url)
        
    return "Error: Unknown action."
