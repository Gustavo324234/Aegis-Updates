import json
import time
import os
from playwright.sync_api import sync_playwright

DESCRIPTION = """
Use this module to interact with the web (Deep Web Operator).
Supports advanced navigation, clicking, typing, and visual browsing.

Commands:
1. Navigate:
   {"module": "browser_tools", "action": "navigate", "url": "https://google.com", "headless": false}
   
2. Click Element:
   {"module": "browser_tools", "action": "click", "selector": "#submit-button"}
   
3. Type Text:
   {"module": "browser_tools", "action": "type", "selector": "input[name='q']", "text": "Aegis AI"}
   
4. Press Key:
   {"module": "browser_tools", "action": "press", "key": "Enter"}
   
5. Scrape Content:
   {"module": "browser_tools", "action": "scrape", "selector": "body"}

6. Screenshot:
   {"module": "browser_tools", "action": "screenshot", "filename": "evidence.png"}

Rules:
- 'headless': false enables "God Mode" (User sees the browser).
- Selectors must be valid CSS or XPath.
"""

# Global Session State (Singleton Pattern for Persistence)
# In a real production env, this would be managed per-user-session.
class BrowserSession:
    def __init__(self):
        self.playwright = None
        self.browser = None
        self.page = None
        self.is_active = False

    def start(self, headless=False):
        if not self.is_active:
            self.playwright = sync_playwright().start()
            # Use a persistent context to simulate a real user profile if needed, 
            # but for now standard launch is fine.
            self.browser = self.playwright.chromium.launch(headless=headless, slow_mo=500)
            self.page = self.browser.new_page()
            self.is_active = True
            print("[BROWSER] Session Started.")

    def stop(self):
        if self.is_active:
            self.browser.close()
            self.playwright.stop()
            self.is_active = False
            self.playwright = None
            self.browser = None
            self.page = None
            print("[BROWSER] Session Ended.")

    def get_page(self):
        if not self.is_active:
            self.start(headless=False) # Default to visible if auto-starting
        return self.page

# Initialize Global Session
session = BrowserSession()

def execute(query):
    # Parse Query
    try:
        if isinstance(query, str):
            data = json.loads(query)
        else:
            data = query
    except:
        return "Error: Invalid JSON format."

    action = data.get("action")
    
    try:
        # 1. NAVIGATION
        if action == "navigate":
            url = data.get("url")
            headless = data.get("headless", False)
            
            # Restart if headless mode changes significantly or if not active
            if not session.is_active:
                session.start(headless=headless)
            
            page = session.get_page()
            page.goto(url)
            title = page.title()
            return f"Navigated to: {title} ({url})"

        # 2. CLICK
        elif action == "click":
            selector = data.get("selector")
            page = session.get_page()
            page.click(selector)
            return f"Clicked: {selector}"

        # 3. TYPE
        elif action == "type":
            selector = data.get("selector")
            text = data.get("text")
            page = session.get_page()
            page.fill(selector, text)
            return f"Typed '{text}' into {selector}"

        # 4. PRESS KEY
        elif action == "press":
            key = data.get("key")
            page = session.get_page()
            page.keyboard.press(key)
            return f"Pressed Key: {key}"

        # 5. SCRAPE
        elif action == "scrape":
            selector = data.get("selector", "body")
            page = session.get_page()
            content = page.inner_text(selector)
            return f"Content ({selector}):\n{content[:2000]}..." # Truncate

        # 6. SCREENSHOT
        elif action == "screenshot":
            filename = data.get("filename", f"screenshot_{int(time.time())}.png")
            path = os.path.join("workspace", "screenshots", filename)
            os.makedirs(os.path.dirname(path), exist_ok=True)
            
            page = session.get_page()
            page.screenshot(path=path)
            return f"Screenshot saved: {path}"

        # 7. CLOSE
        elif action == "close":
            session.stop()
            return "Browser Session Closed."

        else:
            return f"Unknown Browser Action: {action}"

    except Exception as e:
        return f"Browser Error: {e}"
