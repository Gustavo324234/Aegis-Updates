import json
import time
import os
import base64
import requests
import database
from playwright.sync_api import sync_playwright

DESCRIPTION = """
Use this module to interact with the web.
Commands:
1. Navigate: {"module": "browser_tools", "action": "navigate", "url": "https://example.com"}
2. Click: {"module": "browser_tools", "action": "click", "selector": "#btn"}
3. Type: {"module": "browser_tools", "action": "type", "selector": "#input", "text": "hello"}
4. Visual Query (NEW): {"module": "browser_tools", "action": "visual_query", "url": "https://example.com", "question": "What is the account balance shown?"}
"""


# Global Session State (Singleton Pattern for Persistence)
# In a real production env, this would be managed per-user-session.
class BrowserSession:
    def __init__(self):
        self.playwright = None
        self.browser = None
        self.page = None
        self.is_active = False

    def start(self, headless=False):
        if not self.is_active:
            self.playwright = sync_playwright().start()
            # Use a persistent context to simulate a real user profile if needed,
            # but for now standard launch is fine.
            self.browser = self.playwright.chromium.launch(
                headless=headless, slow_mo=500
            )
            self.page = self.browser.new_page()
            self.is_active = True
            print("[BROWSER] Session Started.")

    def stop(self):
        if self.is_active:
            self.browser.close()
            self.playwright.stop()
            self.is_active = False
            self.playwright = None
            self.browser = None
            self.page = None
            print("[BROWSER] Session Ended.")

    def get_page(self):
        if not self.is_active:
            self.start(headless=False)  # Default to visible if auto-starting
        return self.page


# Initialize Global Session
session = BrowserSession()


def execute(query):
    # Parse Query
    try:
        if isinstance(query, str):
            data = json.loads(query)
        else:
            data = query
    except Exception:
        return "Error: Invalid JSON format."

    action = data.get("action")

    try:
        # 1. NAVIGATION
        if action == "navigate":
            url = data.get("url")
            headless = data.get("headless", False)

            # Restart if headless mode changes significantly or if not active
            if not session.is_active:
                session.start(headless=headless)

            page = session.get_page()
            page.goto(url)
            title = page.title()
            return f"Navigated to: {title} ({url})"

        # 2. CLICK
        elif action == "click":
            selector = data.get("selector")
            page = session.get_page()
            page.click(selector)
            return f"Clicked: {selector}"

        # 3. TYPE
        elif action == "type":
            selector = data.get("selector")
            text = data.get("text")
            page = session.get_page()
            page.fill(selector, text)
            return f"Typed '{text}' into {selector}"

        # 4. PRESS KEY
        elif action == "press":
            key = data.get("key")
            page = session.get_page()
            page.keyboard.press(key)
            return f"Pressed Key: {key}"

        # 5. SCRAPE
        elif action == "scrape":
            selector = data.get("selector", "body")
            page = session.get_page()
            content = page.inner_text(selector)
            return f"Content ({selector}):\n{content[:2000]}..."  # Truncate

        # 6. SCREENSHOT
        elif action == "screenshot":
            filename = data.get("filename", f"screenshot_{int(time.time())}.png")
            path = os.path.join("workspace", "screenshots", filename)
            os.makedirs(os.path.dirname(path), exist_ok=True)

            page = session.get_page()
            page.screenshot(path=path)
            return f"Screenshot saved: {path}"

        # 8. VISUAL QUERY (Fusión Navegación + Visión)
        elif action == "visual_query":
            url = data.get("url")
            question = data.get("question", "Describe the main content of this page.")

            # 1. Navegar y Tomar Foto
            if not session.is_active:
                session.start(headless=True)

            page = session.get_page()
            if url:
                page.goto(url, wait_until="networkidle")

            # Esperar a que renderice contenido dinámico
            time.sleep(3)

            # Capturar imagen en memoria
            screenshot_bytes = page.screenshot()
            b64_img = base64.b64encode(screenshot_bytes).decode("utf-8")

            # 2. Consultar al Motor Visual (Ollama)
            vision_model = database.get_setting("local_vision_model") or "moondream"
            ollama_url = database.get_setting("ollama_url") or "http://127.0.0.1:11434"
            ollama_url = ollama_url.rstrip("/")

            payload = {
                "model": vision_model,
                "prompt": f"System: Eres el Ojo de Aegis. Responde brevemente a la pregunta basada en la imagen de la web.\nPregunta: {question}",
                "images": [b64_img],
                "stream": False,
            }

            try:
                print(f" Analyzing visual data with {vision_model}...")
                resp = requests.post(
                    f"{ollama_url}/api/generate", json=payload, timeout=60
                )
                if resp.status_code == 200:
                    vision_text = resp.json().get("response", "")
                    return f"Visual Analysis of {url}: {vision_text}"
                else:
                    return f"Vision Error: {resp.text}"
            except Exception as e:
                return f"Vision Service Offline: {e}"

        # 7. CLOSE
        elif action == "close":
            session.stop()
            return "Browser Session Closed."

        else:
            return f"Unknown Browser Action: {action}"

    except Exception as e:
        return f"Browser Error: {e}"
