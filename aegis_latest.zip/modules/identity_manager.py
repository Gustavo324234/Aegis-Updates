import database

DESCRIPTION = """
Module: identity_manager
Purpose: Active memory management. Allows the AI to save user preferences and facts to long-term memory.
Actions:
- update_preference: Saves a key-value pair as a user fact.
Usage format:
{"module": "identity_manager", "action": "update_preference", "args": {"key": "user_name", "value": "Diego", "category": "identity"}}
{"module": "identity_manager", "action": "update_preference", "args": {"key": "coding_style", "value": "concise", "category": "preference"}}
"""

def execute(query):
    action = query.get("action")
    args = query.get("args", {})
    
    if action == "update_preference":
        key = args.get("key")
        value = args.get("value")
        category = args.get("category", "preference")
        
        if not key or not value:
            return "Error: Key and Value required."
            
        try:
            # We use a high confidence (1.0) because this is an explicit instruction
            database.add_user_fact(key, value, category, confidence=1.0)
            return f"Memory Updated: {key} = {value}"
        except Exception as e:
            return f"Error updating memory: {str(e)}"
            
    else:
        return f"Identity Manager Error: Unknown action '{action}'"
