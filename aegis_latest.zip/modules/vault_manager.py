# modules/vault_manager.py
import os
import sqlite3
import datetime
import json
import pickle
from pathlib import Path

# Multi-Tenancy Support
import database

DB_NAME = database.DB_NAME
USER_ROOT = os.getenv('AEGIS_USER_ROOT', '.')
if USER_ROOT != '.' and not os.path.exists(USER_ROOT):
    try: os.makedirs(USER_ROOT)
    except: pass

VAULT_DIR = os.path.join(USER_ROOT, "vault")

# --- DEPENDENCY CHECK ---
try:
    from sentence_transformers import SentenceTransformer
    import numpy as np
    HAS_SEMANTIC = True
except ImportError:
    HAS_SEMANTIC = False
    print("Warning: 'sentence-transformers' or 'numpy' missing. Semantic search disabled.")

try: import pypdf 
except ImportError: pypdf = None

try: import pandas as pd
except ImportError: pd = None

try: import google.generativeai as genai
except ImportError: genai = None

class VaultManager:
    def __init__(self):
        # Ensure vault directory exists
        if not os.path.exists(VAULT_DIR):
            os.makedirs(VAULT_DIR)
            
        self.model = None
        if HAS_SEMANTIC:
            try:
                # Load a lightweight model
                self.model = SentenceTransformer('all-MiniLM-L6-v2')
            except Exception as e:
                print(f"Error loading embedding model: {e}")
                
        self._init_embedding_table()
        
        # TIER 1: HOT MEMORY (RAM CACHE)
        # Stores last N accessed embeddings for instant retrieval
        self.hot_memory = {} 
        self.hot_capacity = 20
        
    def _touch_memory(self, filename, collection):
         """Promotes item to Hot Memory and updates timestamps."""
         ts = datetime.datetime.now().isoformat()
         try:
             # Update DB stats (Async ideally, but sync for now)
             conn = sqlite3.connect(DB_NAME)
             conn.execute("UPDATE vault_embeddings SET access_count = access_count + 1, last_accessed = ? WHERE filename=? AND collection=?", (ts, filename, collection))
             conn.commit()
             conn.close()
             
             # Load to RAM if not present
             if (filename, collection) not in self.hot_memory:
                 # Fetch
                 conn = sqlite3.connect(DB_NAME)
                 cur = conn.cursor()
                 cur.execute("SELECT embedding FROM vault_embeddings WHERE filename=? AND collection=?", (filename, collection))
                 row = cur.fetchone()
                 conn.close()
                 
                 if row and row[0]:
                     vec = pickle.loads(row[0])
                     # LRU Eviction
                     if len(self.hot_memory) >= self.hot_capacity:
                         # Simple random eviction for speed, or pop first
                         self.hot_memory.pop(next(iter(self.hot_memory)))
                     self.hot_memory[(filename, collection)] = vec
         except Exception as e:
             print(f"Hot Memory Error: {e}")

    def _init_embedding_table(self):
        """Creates table for vector embeddings if not exists."""
        conn = sqlite3.connect(DB_NAME)
        c = conn.cursor()
        c.execute('''
            CREATE TABLE IF NOT EXISTS vault_embeddings (
                filename TEXT,
                collection TEXT DEFAULT 'vault',
                embedding BLOB,
                last_updated TEXT,
                access_count INTEGER DEFAULT 0,
                last_accessed TEXT,
                PRIMARY KEY (filename, collection)
            )
        ''')
        try:
             c.execute("ALTER TABLE vault_embeddings ADD COLUMN access_count INTEGER DEFAULT 0")
             c.execute("ALTER TABLE vault_embeddings ADD COLUMN last_accessed TEXT")
        except: pass
        ''')
        try:
            c.execute("ALTER TABLE vault_embeddings ADD COLUMN collection TEXT DEFAULT 'vault'")
        except: pass
        conn.commit()
        conn.close()

    def _get_api_key(self):
        """Fetches Gemini API Key from DB for Audio processing."""
        try:
            conn = sqlite3.connect(DB_NAME)
            c = conn.cursor()
            c.execute("SELECT value FROM settings WHERE key = 'api_key_gemini'")
            row = c.fetchone()
            conn.close()
            return row[0] if row else None
        except:
            return None

    def _extract_pdf(self, path):
        """Extracts text from PDF."""
        if not pypdf: return "Error: pypdf not installed."
        try:
            reader = pypdf.PdfReader(path)
            text = f"[PDF SOURCE: {os.path.basename(path)}]\n"
            text += f"Pages: {len(reader.pages)}\n\n"
            for page in reader.pages:
                text += page.extract_text() + "\n"
            return text
        except Exception as e:
            return f"PDF Error: {e}"

    def _extract_tabular(self, path):
        """Extracts summary from Excel/CSV."""
        if not pd: return "Error: pandas not installed."
        try:
            if path.endswith('.csv'):
                df = pd.read_csv(path)
            else:
                df = pd.read_excel(path)
            
            text = f"[TABULAR DATA: {os.path.basename(path)}]\n"
            text += f"Columns: {', '.join(df.columns)}\n"
            text += f"Rows: {len(df)}\n\n"
            text += "Sample Data (Head):\n"
            text += df.head(5).to_markdown(index=False)
            return text
        except Exception as e:
            return f"Tabular Error: {e}"

    def _transcribe_audio(self, path):
        """Transcribes Audio using Gemini 1.5 Pro."""
        if not genai: return "Error: google-generativeai not installed."
        api_key = self._get_api_key()
        if not api_key: return "Error: No Gemini API Key in Settings."
        
        try:
            genai.configure(api_key=api_key)
            # Upload file
            print(f"Uploading audio {os.path.basename(path)} to Gemini...")
            audio_file = genai.upload_file(path)
            
            model = genai.GenerativeModel("gemini-1.5-pro")
            prompt = "Transcribe this audio and provide an executive summary."
            
            response = model.generate_content([prompt, audio_file])
            return f"[AUDIO TRANSCRIPT: {os.path.basename(path)}]\n\n{response.text}"
        except Exception as e:
            return f"Audio Transcription Error: {e}"

    def scan_vault(self):
        """Scans the vault directory for supported files."""
        files = []
        extensions = ('.txt', '.md', '.csv', '.json', '.pdf', '.xlsx', '.xls', '.mp3', '.wav')
        if os.path.exists(VAULT_DIR):
            for file in os.listdir(VAULT_DIR):
                if file.endswith(extensions):
                    files.append(file)
        return files

    def index_file(self, filename, collection="vault", file_bytes=None):
        """Reads a file, extracts content (Smart Detect), and embeds.
           If file_bytes is provided, writes it to Vault/Session dir first."""
        
        target_dir = VAULT_DIR
        if collection == "session_rag":
            target_dir = os.path.join(USER_ROOT, "tmp", "session_rag")
            if not os.path.exists(target_dir): os.makedirs(target_dir)
        
        path = os.path.join(target_dir, filename)
        
        # If bytes provided, save first
        if file_bytes:
             with open(path, "wb") as f:
                 f.write(file_bytes.getvalue())

        if not os.path.exists(path):
            return f"Error: File {filename} not found."
            
        try:
            content = ""
            ext = os.path.splitext(filename)[1].lower()
            
            # Universal Bridge Extraction Logic
            if ext in ['.pdf']:
                content = self._extract_pdf(path)
            elif ext in ['.xlsx', '.xls', '.csv']:
                content = self._extract_tabular(path)
            elif ext in ['.mp3', '.wav', '.m4a']:
                content = self._transcribe_audio(path)
            else:
                # Default Text
                with open(path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
            
            # 1. Store Content
            conn = sqlite3.connect(DB_NAME)
            c = conn.cursor()
            timestamp = datetime.datetime.now().isoformat()
            
            # Upsert
            # Upsert (Modify to support collection in future, acting as tag for now)
            # We add a 'collection' column to vault_content if possible, or just store in same table with prefix?
            # Ideally we should migrate the table, but for now let's just use the filename uniqueness for simplicity in this interaction
            # Or better, let's update the schema if we can. 
            
            # Since we can't easily run migrations here without risk, let's use the 'filename' to encode collection if it's session
            # Actually, let's try to add the column dynamically or just assume the user accepts a schema update command?
            # User "The user wants to...".
            # Let's add the column via 'CREATE TABLE IF NOT EXISTS' for new tables, but for existing...
            # We will use a separate table for session_content to avoid breaking existing vault_content?
            # Or just hack it: 
            
            # 1. Update Schema Check (Lazy Migration)
            try:
                c.execute("ALTER TABLE vault_content ADD COLUMN collection TEXT DEFAULT 'vault'")
            except: pass # Already exists

            c.execute("INSERT INTO vault_content (filename, content, last_indexed, collection) VALUES (?, ?, ?, ?) ON CONFLICT(filename) DO UPDATE SET content=excluded.content, last_indexed=excluded.last_indexed, collection=excluded.collection",
                      (filename, content, timestamp, collection))
            
            # 2. Embed
            if self.model and HAS_SEMANTIC:
                try:
                    # Embed first 2000 chars of extracted content
                    vector = self.model.encode(content[:2000])
                    blob = pickle.dumps(vector)
                    c.execute("INSERT INTO vault_embeddings (filename, collection, embedding, last_updated) VALUES (?, ?, ?, ?) ON CONFLICT(filename, collection) DO UPDATE SET embedding=excluded.embedding, last_updated=excluded.last_updated",
                              (filename, collection, blob, timestamp))
                except Exception as em_err:
                    print(f"Embedding Error: {em_err}")

            conn.commit()
            conn.close()
            return f"Indexed ({ext}): {filename}"
            
        except Exception as e:
            return f"Indexing Skipped: {str(e)}"

    def _cosine_similarity(self, vec_a, vec_b):
        return np.dot(vec_a, vec_b) / (np.linalg.norm(vec_a) * np.linalg.norm(vec_b))

    def search_semantic(self, query, collection="vault", top_k=5):
        """Performs vector search using TIERED MEMORY (Hot -> Warm -> Cold)."""
        if not self.model or not HAS_SEMANTIC: return []
        
        try:
            query_vec = self.model.encode(query)
            scores = []
            
            # 1. HOT MEMORY SCAN (RAM)
            # Extremely fast, no DB call
            hot_hits = []
            for (fname, col), vec in self.hot_memory.items():
                if col == collection:
                    sim = self._cosine_similarity(query_vec, vec)
                    if sim > 0.3: # Threshold
                        hot_hits.append((sim, fname))
            
            # 2. WARM/COLD MEMORY SCAN (DB)
            # Fetch remaining from DB
            conn = sqlite3.connect(DB_NAME)
            c = conn.cursor()
            
            # Optimization: Only fetch items accessed in last 7 days for "Warm" query if needed
            # For now, we do full scan but we could filter by last_accessed
            
            c.execute("SELECT filename, embedding FROM vault_embeddings WHERE collection = ?", (collection,))
            rows = c.fetchall()
            conn.close()
            
            for filename, blob in rows:
                # Skip if already in hot hits to avoid duplication?
                # Actually, precise score needed.
                if not blob: continue
                
                # Check Hot Cache first before unpickling
                if (filename, collection) in self.hot_memory:
                     vec = self.hot_memory[(filename, collection)]
                else:
                     vec = pickle.loads(blob)
                
                scores.append((self._cosine_similarity(query_vec, vec), filename))
            
            scores.sort(key=lambda x: x[0], reverse=True)
            
            results = []
            for score, fname in scores[:top_k]:
                # Promote top hits to Hot Memory
                self._touch_memory(fname, collection)
                
                content = self.get_file_content(fname)
                snippet = content[:200] + "..." if content else "No content"
                results.append({"filename": fname, "snippet": f"[Match: {score:.2f}] {snippet}", "score": score})
                
            return results
        except Exception as e:
            print(f"Semantic Error: {e}")
            return []

    def search(self, query, collection="vault", mode="hybrid"):
        """The Oracle: Hybrid Search (FTS5 + Semantic)."""
        if not query or not query.strip(): return []
            
        # 1. Keyword Search
        fts_results = []
        try:
            conn = sqlite3.connect(DB_NAME)
            conn.row_factory = sqlite3.Row
            c = conn.cursor()
            safe_query = query.replace('"', '').replace("'", "")
            # FTS doesn't have collection column usually unless we add it to the virtual table. 
            # Virtual tables are tricky to alter. We might skip FTS for session_rag or use a different strategy.
            # For now, let's trust semantic for session_rag or filter FTS results if possible.
            # Actually, standard FTS query doesn't allow filtering by other columns easily without join.
            # Simplified: If collection is vault, use FTS. If session, use Semantic Only (safer).
            if collection == "vault":
                c.execute("""SELECT filename, snippet(vault_fts, 1, '<b>', '</b>', '...', 64) as snippet 
                             FROM vault_fts WHERE vault_fts MATCH ? ORDER BY rank LIMIT 10""", (safe_query,))
                for row in c.fetchall():
                    fts_results.append({"filename": row['filename'], "snippet": row['snippet'], "score": 1.0})
            conn.close()
        except: pass
            
        # 2. Semantic Search
        semantic_results = []
        if mode != "keyword_only":
            semantic_results = self.search_semantic(query, collection=collection, top_k=5)
            
        # 3. Merge
        seen = set()
        final = []
        for res in fts_results:
            final.append(res)
            seen.add(res['filename'])
        for res in semantic_results:
            if res['filename'] not in seen:
                final.append(res)
                seen.add(res['filename'])
                
        return final[:15]

    def get_file_content(self, filename):
        conn = sqlite3.connect(DB_NAME)
        c = conn.cursor()
        c.execute("SELECT content FROM vault_content WHERE filename = ?", (filename,))
        row = c.fetchone()
        conn.close()
        return row[0] if row else None
        
    def rebuild_index(self):
        """Rebuilds FTS and Semantic Index for all files."""
        log = []
        try:
            conn = sqlite3.connect(DB_NAME)
            conn.execute("INSERT INTO vault_fts(vault_fts) VALUES('rebuild')")
            conn.commit()
            conn.close()
            log.append("FTS Rebuilt.")
        except: log.append("FTS Failed.")
            
        for f in self.scan_vault():
            log.append(self.index_file(f))
        return "\n".join(log)

vault = VaultManager()
