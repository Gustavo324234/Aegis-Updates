# modules/vault_manager.py
import os
import sqlite3
import datetime
import json
import pickle
from pathlib import Path

# Multi-Tenancy Support
import database

DB_NAME = database.DB_NAME
USER_ROOT = os.getenv('AEGIS_USER_ROOT', '.')
if USER_ROOT != '.' and not os.path.exists(USER_ROOT):
    try: os.makedirs(USER_ROOT)
    except: pass

VAULT_DIR = os.path.join(USER_ROOT, "vault")

# --- DEPENDENCY CHECK ---
try:
    from sentence_transformers import SentenceTransformer
    import numpy as np
    HAS_SEMANTIC = True
except ImportError:
    HAS_SEMANTIC = False
    print("Warning: 'sentence-transformers' or 'numpy' missing. Semantic search disabled.")

try: import pypdf 
except ImportError: pypdf = None

try: import pandas as pd
except ImportError: pd = None

try: import google.generativeai as genai
except ImportError: genai = None

class VaultManager:
    def __init__(self):
        # Ensure vault directory exists
        if not os.path.exists(VAULT_DIR):
            os.makedirs(VAULT_DIR)
            
        self.model = None
        if HAS_SEMANTIC:
            try:
                # Load a lightweight model
                self.model = SentenceTransformer('all-MiniLM-L6-v2')
            except Exception as e:
                print(f"Error loading embedding model: {e}")
                
        self._init_embedding_table()

    def _init_embedding_table(self):
        """Creates table for vector embeddings if not exists."""
        conn = sqlite3.connect(DB_NAME)
        c = conn.cursor()
        c.execute('''
            CREATE TABLE IF NOT EXISTS vault_embeddings (
                filename TEXT PRIMARY KEY,
                embedding BLOB,
                last_updated TEXT
            )
        ''')
        conn.commit()
        conn.close()

    def _get_api_key(self):
        """Fetches Gemini API Key from DB for Audio processing."""
        try:
            conn = sqlite3.connect(DB_NAME)
            c = conn.cursor()
            c.execute("SELECT value FROM settings WHERE key = 'api_key_gemini'")
            row = c.fetchone()
            conn.close()
            return row[0] if row else None
        except:
            return None

    def _extract_pdf(self, path):
        """Extracts text from PDF."""
        if not pypdf: return "Error: pypdf not installed."
        try:
            reader = pypdf.PdfReader(path)
            text = f"[PDF SOURCE: {os.path.basename(path)}]\n"
            text += f"Pages: {len(reader.pages)}\n\n"
            for page in reader.pages:
                text += page.extract_text() + "\n"
            return text
        except Exception as e:
            return f"PDF Error: {e}"

    def _extract_tabular(self, path):
        """Extracts summary from Excel/CSV."""
        if not pd: return "Error: pandas not installed."
        try:
            if path.endswith('.csv'):
                df = pd.read_csv(path)
            else:
                df = pd.read_excel(path)
            
            text = f"[TABULAR DATA: {os.path.basename(path)}]\n"
            text += f"Columns: {', '.join(df.columns)}\n"
            text += f"Rows: {len(df)}\n\n"
            text += "Sample Data (Head):\n"
            text += df.head(5).to_markdown(index=False)
            return text
        except Exception as e:
            return f"Tabular Error: {e}"

    def _transcribe_audio(self, path):
        """Transcribes Audio using Gemini 1.5 Pro."""
        if not genai: return "Error: google-generativeai not installed."
        api_key = self._get_api_key()
        if not api_key: return "Error: No Gemini API Key in Settings."
        
        try:
            genai.configure(api_key=api_key)
            # Upload file
            print(f"Uploading audio {os.path.basename(path)} to Gemini...")
            audio_file = genai.upload_file(path)
            
            model = genai.GenerativeModel("gemini-1.5-pro")
            prompt = "Transcribe this audio and provide an executive summary."
            
            response = model.generate_content([prompt, audio_file])
            return f"[AUDIO TRANSCRIPT: {os.path.basename(path)}]\n\n{response.text}"
        except Exception as e:
            return f"Audio Transcription Error: {e}"

    def scan_vault(self):
        """Scans the vault directory for supported files."""
        files = []
        extensions = ('.txt', '.md', '.csv', '.json', '.pdf', '.xlsx', '.xls', '.mp3', '.wav')
        if os.path.exists(VAULT_DIR):
            for file in os.listdir(VAULT_DIR):
                if file.endswith(extensions):
                    files.append(file)
        return files

    def index_file(self, filename):
        """Reads a file, extracts content (Smart Detect), and embeds."""
        path = os.path.join(VAULT_DIR, filename)
        if not os.path.exists(path):
            return f"Error: File {filename} not found."
            
        try:
            content = ""
            ext = os.path.splitext(filename)[1].lower()
            
            # Universal Bridge Extraction Logic
            if ext in ['.pdf']:
                content = self._extract_pdf(path)
            elif ext in ['.xlsx', '.xls', '.csv']:
                content = self._extract_tabular(path)
            elif ext in ['.mp3', '.wav', '.m4a']:
                content = self._transcribe_audio(path)
            else:
                # Default Text
                with open(path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
            
            # 1. Store Content
            conn = sqlite3.connect(DB_NAME)
            c = conn.cursor()
            timestamp = datetime.datetime.now().isoformat()
            
            # Upsert
            c.execute("INSERT INTO vault_content (filename, content, last_indexed) VALUES (?, ?, ?) ON CONFLICT(filename) DO UPDATE SET content=excluded.content, last_indexed=excluded.last_indexed",
                      (filename, content, timestamp))
            
            # 2. Embed
            if self.model and HAS_SEMANTIC:
                try:
                    # Embed first 2000 chars of extracted content
                    vector = self.model.encode(content[:2000])
                    blob = pickle.dumps(vector)
                    c.execute("INSERT INTO vault_embeddings (filename, embedding, last_updated) VALUES (?, ?, ?) ON CONFLICT(filename) DO UPDATE SET embedding=excluded.embedding, last_updated=excluded.last_updated",
                              (filename, blob, timestamp))
                except Exception as em_err:
                    print(f"Embedding Error: {em_err}")

            conn.commit()
            conn.close()
            return f"Indexed ({ext}): {filename}"
            
        except Exception as e:
            return f"Indexing Skipped: {str(e)}"

    def _cosine_similarity(self, vec_a, vec_b):
        return np.dot(vec_a, vec_b) / (np.linalg.norm(vec_a) * np.linalg.norm(vec_b))

    def search_semantic(self, query, top_k=5):
        """Performs vector search."""
        if not self.model or not HAS_SEMANTIC: return []
        try:
            query_vec = self.model.encode(query)
            conn = sqlite3.connect(DB_NAME)
            c = conn.cursor()
            c.execute("SELECT filename, embedding FROM vault_embeddings")
            rows = c.fetchall()
            conn.close()
            
            scores = []
            for filename, blob in rows:
                if not blob: continue
                vec = pickle.loads(blob)
                scores.append((self._cosine_similarity(query_vec, vec), filename))
            
            scores.sort(key=lambda x: x[0], reverse=True)
            
            results = []
            for score, fname in scores[:top_k]:
                content = self.get_file_content(fname)
                snippet = content[:200] + "..." if content else "No content"
                results.append({"filename": fname, "snippet": f"[Match: {score:.2f}] {snippet}", "score": score})
            return results
        except Exception as e:
            print(f"Semantic Error: {e}")
            return []

    def search(self, query, mode="hybrid"):
        """The Oracle: Hybrid Search (FTS5 + Semantic)."""
        if not query or not query.strip(): return []
            
        # 1. Keyword Search
        fts_results = []
        try:
            conn = sqlite3.connect(DB_NAME)
            conn.row_factory = sqlite3.Row
            c = conn.cursor()
            safe_query = query.replace('"', '').replace("'", "")
            c.execute("""SELECT filename, snippet(vault_fts, 1, '<b>', '</b>', '...', 64) as snippet 
                         FROM vault_fts WHERE vault_fts MATCH ? ORDER BY rank LIMIT 10""", (safe_query,))
            for row in c.fetchall():
                fts_results.append({"filename": row['filename'], "snippet": row['snippet'], "score": 1.0})
            conn.close()
        except: pass
            
        # 2. Semantic Search
        semantic_results = []
        if mode != "keyword_only":
            semantic_results = self.search_semantic(query, top_k=5)
            
        # 3. Merge
        seen = set()
        final = []
        for res in fts_results:
            final.append(res)
            seen.add(res['filename'])
        for res in semantic_results:
            if res['filename'] not in seen:
                final.append(res)
                seen.add(res['filename'])
                
        return final[:15]

    def get_file_content(self, filename):
        conn = sqlite3.connect(DB_NAME)
        c = conn.cursor()
        c.execute("SELECT content FROM vault_content WHERE filename = ?", (filename,))
        row = c.fetchone()
        conn.close()
        return row[0] if row else None
        
    def rebuild_index(self):
        """Rebuilds FTS and Semantic Index for all files."""
        log = []
        try:
            conn = sqlite3.connect(DB_NAME)
            conn.execute("INSERT INTO vault_fts(vault_fts) VALUES('rebuild')")
            conn.commit()
            conn.close()
            log.append("FTS Rebuilt.")
        except: log.append("FTS Failed.")
            
        for f in self.scan_vault():
            log.append(self.index_file(f))
        return "\n".join(log)

vault = VaultManager()
