import re


def repair_json(malformed_string: str) -> str:
    """
    Algorithmic and deterministic JSON healer using Regex.
    Attempts to fix common errors from small local LLMs without relying on another LLM.
    """
    s = malformed_string.strip()

    # If it's empty, return it as is or a valid empty JSON object
    if not s:
        return s

    # 1. Unify single quotes to double quotes for keys and string values, handling escaping
    # This is tricky because single quotes might be inside double quotes or vice versa.
    # We do a naive approach for standard JSON-like keys and values if unquoted or single quoted

    # 1a. Replace unquoted or single-quoted keys with double quotes:
    # Example: 'module': -> "module": or module: -> "module":
    # Let's target the word before a colon
    s = re.sub(r"""(?<!")\b([a-zA-Z_][a-zA-Z0-9_]*)\b(?=\s*:)""", r'"\1"', s)
    s = re.sub(r"""'([a-zA-Z_][a-zA-Z0-9_]*)'(?=\s*:)""", r'"\1"', s)

    # 1b. Change single-quoted string values to double-quoted
    # Find all '...' that aren't inside "..."
    # Simple replace: 'value' -> "value", taking care of \'
    # Let's substitute simple single quotes wrapped strings
    s = re.sub(r"(?<!\\)'(.*?)'(?!\\)", r'"\1"', s)

    # 2. Fix trailing commas before closing braces/brackets
    s = re.sub(r",\s*}", "}", s)
    s = re.sub(r",\s*]", "]", s)

    # 3. Handle missing closing braces if we see an unclosed structure
    # A very basic AST-like bracket balancer
    open_braces = s.count("{")
    close_braces = s.count("}")
    if open_braces > close_braces:
        s += "}" * (open_braces - close_braces)

    open_brackets = s.count("[")
    close_brackets = s.count("]")
    if open_brackets > close_brackets:
        s += "]" * (open_brackets - close_brackets)

    # 4. Remove obvious pythonic booleans and None
    s = re.sub(r"\bTrue\b", "true", s)
    s = re.sub(r"\bFalse\b", "false", s)
    s = re.sub(r"\bNone\b", "null", s)

    # 5. Sometimes the LLM escapes quotes inside JSON strings wrongly
    # (Optional) - Leave it for now to avoid breaking valid escaping

    return s
