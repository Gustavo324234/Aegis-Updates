import os

# Common Sensitive Files List (Security Blacklist)
# Combined from file_writer and project_oracle to ensure maximum safety.
SENSITIVE_FILES = [
    "secrets.json", ".env", "aegis_memory.db", "users.db", 
    "master_key.key", "id_rsa", "id_rsa.pub", "app_web.py", 
    "database.py", "core.py", "module_manager.py"
]

def get_user_root():
    """
    Determines the safe root directory for file operations.
    PROTOCOL WORKSPACE ISOLATION: Forces all I/O to be inside 'workspace/' subdirectory.
    """
    # 1. Base Root (System or Local)
    base_root = os.getenv('AEGIS_USER_ROOT') or os.getcwd()
    base_root = os.path.abspath(base_root)
    
    # 2. Workspace Isolation
    workspace_root = os.path.join(base_root, "workspace")
    
    # 3. Ensure Existence
    if not os.path.exists(workspace_root):
        try:
            os.makedirs(workspace_root, exist_ok=True)
        except: pass
        
    return workspace_root

def is_safe_path(path, strict_files=None):
    """
    Validates that a path is securely inside the SAFE_ROOT.
    Prevents Directory Traversal (../../etc/passwd).
    
    Args:
        path (str): The relative or absolute path to check.
        strict_files (list, optional): Custom list of heavily restricted filenames. 
                                       If None, uses default SENSITIVE_FILES.
    """
    safe_root = get_user_root()
    
    try:
        # Resolve absolute path
        # If path is absolute, join ignores safe_root, so we must be careful.
        # But we want to ensure the RESULT is inside safe_root.
        # Actually os.path.join(base, /abs) returns /abs on Windows too.
        # So we should use os.path.abspath of the path provided, 
        # BUT usually the input is relative. 
        # If input is absolute, we just check containment.
        
        if os.path.isabs(path):
            abs_path = os.path.abspath(path)
        else:
            abs_path = os.path.abspath(os.path.join(safe_root, path))
        
        # Check against Sensitive Files Blacklist
        filename = os.path.basename(abs_path)
        blacklist = strict_files if strict_files is not None else SENSITIVE_FILES
        
        if filename in blacklist:
            return False

        # Check prefix to ensure containment
        # os.path.commonpath raises error if drives match (Windows) or if mix relative/abs
        return os.path.commonpath([safe_root]) == os.path.commonpath([safe_root, abs_path])
    except Exception:
        return False
