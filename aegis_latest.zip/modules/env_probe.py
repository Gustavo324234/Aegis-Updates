# modules/env_probe.py
import platform
import os


class EnvProbe:
    def __init__(self):
        self.os_name = platform.system()
        self.os_release = platform.release()
        self.machine = platform.machine()
        self.python_version = platform.python_version()

    def is_headless(self):
        """Detects if the environment is headless (no GUI)."""
        # Linux: Check DISPLAY env var
        if self.os_name == "Linux":
            return os.environ.get("DISPLAY") is None
        # Windows/Mac: Harder to detect purely via env, but usually run in desktop mode.
        # However, checking if running via SSH or service might be a clue.
        # For now, simple check is adequate.
        return False

    def get_system_context(self):
        """Returns a string describing the system context."""
        headless = "Headless" if self.is_headless() else "Desktop"
        return f"{self.os_name} {self.os_release} ({self.machine}) - {headless}"

    def get_capabilities(self):
        """Returns a dict of capabilities based on environment."""
        caps = {
            "os": self.os_name,
            "arch": self.machine,
            "headless": self.is_headless(),
            "shell": "powershell" if self.os_name == "Windows" else "bash",
        }
        return caps


# Instance
probe = EnvProbe()
