# modules/bridge_browser.py
import os
import json
import time
from playwright.sync_api import sync_playwright

SESSION_DIR = "vault/sessions"

class BridgeBrowser:
    def __init__(self):
        if not os.path.exists(SESSION_DIR):
            os.makedirs(SESSION_DIR)

    def _get_storage_state_path(self, site_name):
        return os.path.join(SESSION_DIR, f"{site_name}.json")

    def perform_sync(self, site_name, url):
        """
        Launches browser, waits for user login if needed, and scrapes recent context.
        Returns: (success: bool, message: str, scraped_content: str)
        """
        state_path = self._get_storage_state_path(site_name)
        
        try:
            with sync_playwright() as p:
                # Launch non-headless to allow user interaction
                browser = p.chromium.launch(headless=False)
                
                # Create context with storage state if exists
                if os.path.exists(state_path):
                    context = browser.new_context(storage_state=state_path)
                else:
                    context = browser.new_context()
                    
                page = context.new_page()
                page.goto(url)
                
                # Check for login heuristic (simple wait/check)
                # We'll valid by checking URL or wait for user input
                # Ideally, we wait for a specific element that indicates 'Logged In'
                # For generic approach, we wait a bit and ask user to login if needed.
                # Since this is "Human-Assisted", we rely on the user doing the work in the window.
                # But since this is a backend call, we can't easily wait ideally unless we block.
                # V9 Implementation: Wait for 30s max for user to login if URL redirects to login.
                
                # Simple check: Wait for user to navigate to main chat area
                # For automation, we just wait a fixed time or specific selector
                # If we are scraping 'Active Conversation', we assume user navigates to it.
                
                # FOR DEMO/MVP: We wait 5 seconds for page load. 
                # If 'login' in url, we wait longer for user to login (e.g. 60s).
                page.wait_for_timeout(5000)
                
                if "login" in page.url or "auth" in page.url:
                    # Wait for user to login manually
                    print("Waiting for user login...")
                    # We can use a loop checking for url change
                    for _ in range(12): # Wait up to 60s
                        page.wait_for_timeout(5000)
                        if "chat" in page.url or "talk" in page.url:
                            break
                
                # Save Session State
                context.storage_state(path=state_path)
                
                # Scrape Content
                # Heuristic selectors for common AI chats
                content = ""
                
                # ChatGPT / Claude / Gemini selectors (Approximate)
                # This is fragile and needs updates as UI changes.
                # V9 Strategy: Dump body text or specific article/main text
                try:
                    # Attempt detailed extraction
                    elements = page.query_selector_all("div.text-base, div.prose, .markdown")
                    for el in elements:
                        content += el.inner_text() + "\n\n"
                except:
                    pass
                
                if not content:
                    # Fallback to body text
                    content = page.evaluate("document.body.innerText")

                # Close
                browser.close()
                
                if len(content) < 100:
                    return False, "Sync Incomplete: Content too short or login failed.", ""
                
                return True, "Sync Successful", content

        except Exception as e:
            return False, f"Browser Error: {str(e)}", ""

bridge = BridgeBrowser()
