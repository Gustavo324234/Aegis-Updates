import os
import sys
import platform

def install_auto_start_windows(watchdog_path):
    """
    Creates a Windows Scheduled Task to run process_watchdog.py at logon.
    Uses 'schtasks' command.
    """
    try:
        task_name = "AegisAI_Watchdog"
        python_exe = sys.executable
        # We use pythonw.exe if available to avoid a console window for the task wrapper,
        # BUT process_watchdog.py itself spawns visible consoles, so python.exe is fine 
        # as the root process. Actually, better pythonw.exe for the watchdog so IT doesn't
        # hold a useless window, and IT spawns the visible windows.
        
        # Check for pythonw
        pythonw = python_exe.replace("python.exe", "pythonw.exe")
        if not os.path.exists(pythonw):
            pythonw = python_exe

        # Command to create task
        # /SC ONLOGON -> Run when user logs on
        # /RL HIGHEST -> Run with highest privileges (Admin often needed for services)
        # /TR -> Task Run command
        # /F -> Force overwrite
        
        # We need to wrap it to set CWD correctly. Scheduled tasks default to system32.
        # Let's create a small VBS or BAT wrapper that sets path?
        # Simpler: Create a .bat in the Aegis folder that cd's and runs.
        
        root_dir = os.path.dirname(watchdog_path)
        launcher_bat = os.path.join(root_dir, "start_watchdog_service.bat")
        
        with open(launcher_bat, "w") as f:
            f.write("@echo off\n")
            f.write(f'cd /d "{root_dir}"\n')
            f.write(f'"{python_exe}" "{watchdog_path}"\n')
            
        cmd = f'schtasks /Create /TN "{task_name}" /TR "{launcher_bat}" /SC ONLOGON /RL HIGHEST /F'
        
        # Run command
        result = os.system(cmd)
        
        if result == 0:
            return f"Success: Scheduled Task '{task_name}' created. It will start on next login.\nYou can also run '{launcher_bat}' manually."
        else:
            return "Error: Failed to create Scheduled Task. Try running as Administrator."
            
    except Exception as e:
        return f"Error creating Windows Task: {str(e)}"

def generate_systemd_service(watchdog_path):
    try:
        user = os.getlogin()
    except:
        user = "root" # Fallback if getlogin fails in some envs

    service_content = f"""[Unit]
Description=Aegis AI Watchdog Service
After=network.target

[Service]
User={user}
WorkingDirectory={os.path.dirname(watchdog_path)}
ExecStart={sys.executable} {watchdog_path}
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
"""
    install_script = os.path.join(os.path.dirname(watchdog_path), "install_linux.sh")

    try:
        # 1. Service File
        with open(service_file, "w") as f:
            f.write(service_content)
            
        # 2. Install Script
        with open(install_script, "w") as f:
            f.write("#!/bin/bash\n")
            f.write("echo 'Installing Aegis Service...'\n")
            f.write(f"sudo cp {service_file} /etc/systemd/system/\n")
            f.write("sudo systemctl daemon-reload\n")
            f.write("sudo systemctl enable aegis.service\n")
            f.write("sudo systemctl start aegis.service\n")
            f.write("sudo systemctl status aegis.service --no-pager\n")
            f.write("echo 'Service Installed and Started! Check status with: sudo systemctl status aegis'\n")
        
        # Make script executable
        os.chmod(install_script, 0o755)
            
        return f"Success: Service definitions generated at {install_script}.\nTo install, run: ./install_linux.sh"
    except Exception as e:
        return f"Error generating service files: {str(e)}"

def install_auto_start():
    """Detects OS and installs/generates auto-start mechanism."""
    # Assuming process_watchdog.py is in the root where app is running or parallel to modules
    # This module is in modules/, so root is up one level
    root_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    watchdog_path = os.path.join(root_dir, "process_watchdog.py")
    
    if not os.path.exists(watchdog_path):
        return f"Error: process_watchdog.py not found at {watchdog_path}"
        
    os_name = platform.system()
    
    if os_name == "Windows":
        return install_auto_start_windows(watchdog_path)
    elif os_name == "Linux":
        return generate_systemd_service(watchdog_path)
    else:
        return f"OS {os_name} not supported for auto-start setup."
