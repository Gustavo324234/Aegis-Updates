import os
import sys
import platform
import getpass


def install_auto_start_windows(watchdog_path):
    """
    Creates a Windows Scheduled Task to run process_watchdog.py at logon.
    Uses 'schtasks' command.
    """
    try:
        task_name = "AegisAI_Watchdog"
        python_exe = sys.executable

        # Check for pythonw
        pythonw = python_exe.replace("python.exe", "pythonw.exe")
        if not os.path.exists(pythonw):
            pythonw = python_exe

        # Command to create task
        # /SC ONLOGON -> Run when user logs on
        # /RL HIGHEST -> Run with highest privileges (Admin often needed for services)
        # /TR -> Task Run command
        # /F -> Force overwrite

        root_dir = os.path.dirname(watchdog_path)

        # --- DATA ROOT CALCULATION (WINDOWS) ---
        # Code: E:\Aegis-IA
        # Data: E:\Aegis-Data
        # We assume sibling structure
        parent_dir = os.path.dirname(root_dir)
        data_root = os.path.join(parent_dir, "Aegis-Data")

        launcher_bat = os.path.join(root_dir, "start_watchdog_service.bat")

        with open(launcher_bat, "w") as f:
            f.write("@echo off\n")
            # Set environment variable for this session
            f.write(f"set AEGIS_USER_ROOT={data_root}\n")
            f.write(f'cd /d "{root_dir}"\n')
            f.write(f'"{python_exe}" "{watchdog_path}"\n')

        cmd = f'schtasks /Create /TN "{task_name}" /TR "{launcher_bat}" /SC ONLOGON /RL HIGHEST /F'

        # Run command
        result = os.system(cmd)

        if result == 0:
            return f"Success: Scheduled Task '{task_name}' created.\nData Root: {data_root}"
        else:
            return (
                "Error: Failed to create Scheduled Task. Try running as Administrator."
            )

    except Exception as e:
        return f"Error creating Windows Task: {str(e)}"


def generate_systemd_service(watchdog_path, data_root=None):
    try:
        user = getpass.getuser()
    except Exception:
        user = "root"

    # Detect VENV Python for reliability on Linux
    venv_python = os.path.join(
        os.path.dirname(watchdog_path), ".venv", "bin", "python3"
    )
    if os.path.exists(venv_python):
        exec_cmd = f"{venv_python} {watchdog_path}"
    else:
        exec_cmd = f"{sys.executable} {watchdog_path}"

    # --- DATA ROOT CALCULATION (POSIX) ---
    if not data_root:
        # Fallback Calculation
        root_dir = os.path.dirname(watchdog_path)
        parent_dir = os.path.dirname(root_dir)
        data_root = os.path.join(parent_dir, "Aegis-Data")

    service_content = f"""[Unit]
Description=Aegis AI Watchdog Service (Gateway + Hub)
After=network.target

[Service]
User={user}
WorkingDirectory={os.path.dirname(watchdog_path)}
Environment="AEGIS_USER_ROOT={data_root}"
ExecStart={exec_cmd}
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
"""
    install_script = os.path.join(os.path.dirname(watchdog_path), "install_linux.sh")
    service_file = os.path.join(os.path.dirname(watchdog_path), "aegis.service")

    try:
        # 1. Service File
        with open(service_file, "w") as f:
            f.write(service_content)

        # 2. Install Script
        with open(install_script, "w") as f:
            f.write("#!/bin/bash\n")
            f.write("echo 'Installing Aegis Service...'\n")
            f.write(f"echo 'Data Persistency Path: {data_root}'\n")
            f.write(f"sudo cp {service_file} /etc/systemd/system/\n")
            f.write("sudo systemctl daemon-reload\n")
            f.write("sudo systemctl enable aegis.service\n")
            f.write("sudo systemctl start aegis.service\n")
            f.write("sudo systemctl status aegis.service --no-pager\n")
            f.write(
                "echo 'Service Installed! Check with: sudo systemctl status aegis'\n"
            )

        # Make script executable
        os.chmod(install_script, 0o755)

        return f"Success: Service definitions generated at {install_script}.\nData Root configured: {data_root}. Run ./install_linux.sh to apply."
    except Exception as e:
        return f"Error generating service files: {str(e)}"


def install_auto_start(code_root=None, data_root=None):
    """Detects OS and installs/generates auto-start mechanism."""

    if not code_root:
        # Fallback to relative path detection
        code_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    watchdog_path = os.path.join(code_root, "process_watchdog.py")

    if not os.path.exists(watchdog_path):
        return f"Error: process_watchdog.py not found at {watchdog_path}"

    os_name = platform.system()

    if os_name == "Windows":
        # Windows handles data_root internally via relative path calc in current implementation
        # Ideally pass it too, but sticking to existing sturdy logic for now or updating it?
        # The prompt asked for modification of generate_systemd_service mostly.
        # Let's see if install_auto_start_windows supports data_root injection easily without breaking.
        # It calculates it: parent_dir = os.path.dirname(root_dir) -> data_root = ...
        # If we pass code_root, logic holds.
        return install_auto_start_windows(watchdog_path)
    elif os_name == "Linux":
        return generate_systemd_service(watchdog_path, data_root)
    else:
        return f"OS {os_name} not supported for auto-start setup."
