import os
import sys
import platform

def install_auto_start_windows(watchdog_path):
    try:
        appdata = os.getenv('APPDATA')
        if not appdata:
            return "Error: APPDATA environment variable not found."
            
        startup_folder = os.path.join(appdata, r'Microsoft\Windows\Start Menu\Programs\Startup')
        if not os.path.exists(startup_folder):
            return f"Error: Startup folder not found at {startup_folder}"

        bat_file = os.path.join(startup_folder, "AegisWatchdog.bat")
        
        # Create bat file to run minimized
        python_exe = sys.executable
        # Use start /min to launch in minimized window
        script_cmd = f'start /min "" "{python_exe}" "{watchdog_path}"'
        
        with open(bat_file, "w") as f:
            f.write("@echo off\n")
            f.write(f"cd /d \"{os.path.dirname(watchdog_path)}\"\n")
            f.write("echo Starting Aegis Watchdog...\n")
            f.write(f"{script_cmd}\n")
            
        return f"Success: Created {bat_file}"
    except Exception as e:
        return f"Error creating startup script: {str(e)}"

def generate_systemd_service(watchdog_path):
    try:
        user = os.getlogin()
    except:
        user = "root" # Fallback if getlogin fails in some envs

    service_content = f"""[Unit]
Description=Aegis AI Watchdog Service
After=network.target

[Service]
User={user}
WorkingDirectory={os.path.dirname(watchdog_path)}
ExecStart={sys.executable} {watchdog_path}
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
"""
    service_file = os.path.join(os.path.dirname(watchdog_path), "aegis.service")
    try:
        with open(service_file, "w") as f:
            f.write(service_content)
        return f"Success: File generated at {service_file}. To install run:\nsudo cp {service_file} /etc/systemd/system/\nsudo systemctl daemon-reload\nsudo systemctl enable --now aegis"
    except Exception as e:
        return f"Error generating service file: {str(e)}"

def install_auto_start():
    """Detects OS and installs/generates auto-start mechanism."""
    # Assuming process_watchdog.py is in the root where app is running or parallel to modules
    # This module is in modules/, so root is up one level
    root_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    watchdog_path = os.path.join(root_dir, "process_watchdog.py")
    
    if not os.path.exists(watchdog_path):
        return f"Error: process_watchdog.py not found at {watchdog_path}"
        
    os_name = platform.system()
    
    if os_name == "Windows":
        return install_auto_start_windows(watchdog_path)
    elif os_name == "Linux":
        return generate_systemd_service(watchdog_path)
    else:
        return f"OS {os_name} not supported for auto-start setup."
