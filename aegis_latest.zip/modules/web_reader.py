import requests
from bs4 import BeautifulSoup


DESCRIPTION = """
Module: web_reader
Purpose: Deep analysis of web content. Extracts clean text from URLs.
Actions:
- scrape: Fetches and cleans the main content of a webpage.
Usage format:
{"module": "web_reader", "action": "scrape", "args": {"url": "https://example.com/article"}}
"""


def execute(query):
    action = query.get("action")
    args = query.get("args", {})

    if action == "scrape":
        url = args.get("url")
        if not url:
            return "Error: URL required."
        return scrape_url(url)
    else:
        return f"Web Reader Error: Unknown action '{action}'"


def scrape_url(url):
    try:
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
        }
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()

        soup = BeautifulSoup(response.text, "html.parser")

        # Remove navigation, header, footer, scripts, styles
        for element in soup(["script", "style", "nav", "header", "footer", "aside"]):
            element.decompose()

        # Get text
        text = soup.get_text(separator="\n")

        # Clean whitespace
        lines = (line.strip() for line in text.splitlines())
        chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
        clean_text = "\n".join(chunk for chunk in chunks if chunk)

        # Limit context
        if len(clean_text) > 10000:
            clean_text = clean_text[:10000] + "\n... [TRUNCATED]"

        return f"### CONTENT FROM {url} ###\n{clean_text}"

    except Exception as e:
        return f"Scraping Error: {str(e)}"
