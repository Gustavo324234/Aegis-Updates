from duckduckgo_search import DDGS
import json

DESCRIPTION = """
Module: web_search
Purpose: Connect to the Internet to find real-time information.
Actions:
- search: Perform a web search and return top 5 results with snippets.
Usage format:
{"module": "web_search", "action": "search", "args": {"query": "Bitcoin price today"}}
"""

def execute(query):
    action = query.get("action")
    args = query.get("args", {})
    
    if action == "search":
        q = args.get("query")
        if not q: return "Error: Query required."
        return search_web(q)
    else:
        return f"Web Search Error: Unknown action '{action}'"

def search_web(query):
    try:
        results = []
        # DDGS Instance
        with DDGS() as ddgs:
            # We fetch 5 results. region='wt-wt' is worldwide. 
            # safe='off' allows unfiltered, but usually 'moderate' is better.
            for r in ddgs.text(query, region='wt-wt', safesearch='moderate', max_results=5):
                results.append(r)
        
        if not results:
            return "No results found."
            
        formatted = "### WEB SEARCH RESULTS ###\n"
        for i, res in enumerate(results):
            formatted += f"[{i+1}] {res.get('title')}\n"
            formatted += f"LINK: {res.get('href')}\n"
            formatted += f"SNIPPET: {res.get('body')}\n\n"
            
        return formatted
        
    except Exception as e:
        return f"Search Failed: {str(e)}"
