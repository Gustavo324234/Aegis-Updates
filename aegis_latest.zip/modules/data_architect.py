import sqlite3
import os
import json

USER_DATA_DIR = "user_data"
if not os.path.exists(USER_DATA_DIR):
    os.makedirs(USER_DATA_DIR)

MANIFEST = {
    "name": "Data Architect",
    "description": "Design and manage SQLite databases for the user. Capable of creating tables, inserting data, and managing schemas.",
    "commands": {
        "create_database": {
            "description": "Create a new .db file with a schema.",
            "args": ["db_name (string)", "schema_sql (string: CREATE TABLE statements)"]
        },
        "execute_query": {
            "description": "Run a SQL query (INSERT, UPDATE, DELETE, SELECT).",
            "args": ["db_name (string)", "sql (string)", "params (optional list)"]
        },
        "list_databases": {
            "description": "List available user databases.",
            "args": []
        },
        "get_schema": {
            "description": "Get the schema (CREATE statements) of a database.",
            "args": ["db_name"]
        },
        "auto_log_data": {
            "description": "Intelligently inserts data into a project database from natural language text.",
            "args": ["text", "project_hint"]
        }
    }
}

import google.generativeai as genai
import database

class DataArchitect:
    def _get_db_path(self, db_name):
        # Security: Prevent traversal
        safe_name = os.path.basename(db_name)
        if not safe_name.endswith(".db"):
            safe_name += ".db"
        return os.path.join(USER_DATA_DIR, safe_name)

    def create_database(self, db_name, schema_sql):
        path = self._get_db_path(db_name)
        if os.path.exists(path):
            return f"Error: Database '{db_name}' already exists. Use 'execute_query' to modify it."
        
        try:
            conn = sqlite3.connect(path)
            cursor = conn.cursor()
            cursor.executescript(schema_sql)
            conn.commit()
            conn.close()
            return f"Success: Database '{db_name}' created at '{path}'."
        except sqlite3.Error as e:
            if os.path.exists(path):
                os.remove(path) # Cleanup on failure
            return f"SQL Error during creation: {e}"

    def execute_query(self, db_name, sql, params=None):
        path = self._get_db_path(db_name)
        if not os.path.exists(path):
            return f"Error: Database '{db_name}' does not exist."
            
        try:
            conn = sqlite3.connect(path)
            conn.row_factory = sqlite3.Row # Enable dict-like access
            cursor = conn.cursor()
            
            # Basic restrictions (very naive, assumes trust in AI generated SQL)
            # In a real scenario, we'd be more careful.
            
            if params:
                cursor.execute(sql, params)
            else:
                cursor.execute(sql)
                
            if sql.strip().upper().startswith("SELECT"):
                rows = cursor.fetchall()
                result = [dict(row) for row in rows]
                conn.close()
                return json.dumps(result, default=str)
            else:
                conn.commit()
                changes = conn.total_changes
                conn.close()
                return f"Success: Query executed. {changes} rows affected."
                
        except sqlite3.Error as e:
            return f"SQL Execution Error: {e}"

    def list_databases(self):
        files = [f for f in os.listdir(USER_DATA_DIR) if f.endswith(".db")]
        return files if files else "No databases found."

    def get_schema(self, db_name):
        path = self._get_db_path(db_name)
        if not os.path.exists(path):
            return f"Error: Database '{db_name}' does not exist."
            
        try:
            conn = sqlite3.connect(path)
            cursor = conn.cursor()
            cursor.execute("SELECT sql FROM sqlite_master WHERE type='table'")
            rows = cursor.fetchall()
            conn.close()
            
            schema = "\n".join([r[0] for r in rows if r[0]])
            return schema if schema else "Database is empty."
        except sqlite3.Error as e:
            return f"Schema Error: {e}"

    def auto_log_data(self, text, project_hint):
        """
        AI-Driven Data Logging.
        1. Find matching DB.
        2. Get Schema.
        3. GenAI -> SQL.
        4. Execute.
        """
        # 1. fuzzy find DB
        dbs = [f for f in os.listdir(USER_DATA_DIR) if f.endswith(".db")]
        if not dbs: return "No databases found. Create one first."
        
        target_db = None
        # Exact match first
        if f"{project_hint}.db" in dbs:
            target_db = project_hint
        else:
            # Simple contains check
            for db in dbs:
                if project_hint.lower() in db.lower():
                    target_db = db.replace(".db", "")
                    break
        
        if not target_db:
            # Fallback: Ask AI which DB? (Skipped for speed, just pick first if only one?)
            if len(dbs) == 1:
                target_db = dbs[0].replace(".db", "")
            else:
                return f"Error: Could not match context '{project_hint}' to any known database ({dbs})."

        # 2. Get Schema
        schema = self.get_schema(target_db)
        if "Error" in schema: return schema
        
        # 3. AI Generate SQL
        api_key = database.get_setting("api_key_gemini")
        if not api_key: return "Error: API Key required for AI generation."
        
        prompt = f"""
SYSTEM: You are a SQL Data Architect.
Review the Database Schema and the User Input.
Generate a valid SQL INSERT statement to store the data.
Return ONLY the raw SQL.

Schema ({target_db}):
{schema}

User Input:
"{text}"

SQL:
"""
        try:
            genai.configure(api_key=api_key)
            model = genai.GenerativeModel('gemini-1.5-flash')
            response = model.generate_content(prompt).text
            
            sql = response.replace("```sql", "").replace("```", "").strip()
            
            # 4. Execute
            return self.execute_query(target_db, sql)
            
        except Exception as e:
            return f"Auto-Log Error: {str(e)}"

architect = DataArchitect()

def execute(query):
    """Entry point for Module Manager."""
    try:
        action = query.get("action")
        args = query.get("args", {})
        
        if action == "create_database":
            return architect.create_database(args.get("db_name"), args.get("schema_sql"))
            
        elif action == "execute_query":
            return architect.execute_query(args.get("db_name"), args.get("sql"), args.get("params"))
            
        elif action == "list_databases":
            return architect.list_databases()
            
        elif action == "get_schema":
            return architect.get_schema(args.get("db_name"))
        
        elif action == "auto_log_data":
            return architect.auto_log_data(args.get("text"), args.get("project_hint"))
            
        else:
            return f"Error: Unknown action '{action}' for Data Architect."
            
    except Exception as e:
        return f"Data Architect Module Error: {str(e)}"
