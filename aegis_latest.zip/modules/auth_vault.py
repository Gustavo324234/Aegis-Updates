import os
import json
import hashlib
import base64
import io

try:
    from cryptography.fernet import Fernet
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

    HAS_CRYPTO = True
except ImportError:
    # This should be handled by requirements.txt, but for safety:
    HAS_CRYPTO = False

try:
    import pyotp
    import qrcode

    HAS_MFA = True
except ImportError:
    HAS_MFA = False

# Determine Configuration Path based on Multi-Tenancy (Strict Isolation)
AEGIS_USER_ROOT = os.getenv("AEGIS_USER_ROOT")

if AEGIS_USER_ROOT:
    # Tenant Mode
    CONFIG_DIR = os.path.join(AEGIS_USER_ROOT, "config")
else:
    # System Mode
    CONFIG_DIR = "config"

CONFIG_PATH = os.path.join(CONFIG_DIR, "secrets.json")


class AuthVault:
    def __init__(self):
        # Ensure config directory exists for this tenant
        if not os.path.exists(CONFIG_DIR):
            try:
                os.makedirs(CONFIG_DIR)
            except OSError:
                pass
        self.config = self._load_config()

    def _load_config(self):
        if os.path.exists(CONFIG_PATH):
            try:
                with open(CONFIG_PATH, "r") as f:
                    return json.load(f)
            except json.JSONDecodeError:
                return {}
        return {}

    def _save_config(self):
        with open(CONFIG_PATH, "w") as f:
            json.dump(self.config, f, indent=4)

    def is_setup(self):
        return "master_hash" in self.config

    def set_master_password(self, password):
        """Sets the initial master password."""
        if not HAS_CRYPTO:
            raise ImportError("cryptography library is required for secure storage.")

        salt = os.urandom(16)
        # Store salt as hex
        self.config["salt"] = salt.hex()

        # Hash password for verification (using correct salt)
        self.config["master_hash"] = self._hash_pwd(password, salt)
        self._save_config()
        return True

    def verify_password(self, password):
        """Verifies the master password."""
        if not self.is_setup():
            return False

        try:
            salt = bytes.fromhex(self.config.get("salt", ""))
            attempt_hash = self._hash_pwd(password, salt)
            return attempt_hash == self.config.get("master_hash")
        except Exception:
            return False

    def _hash_pwd(self, password, salt):
        return hashlib.pbkdf2_hmac(
            "sha256", password.encode("utf-8"), salt, 100000
        ).hex()

    # Public wrappers for external use (e.g. API Vault)
    def derive_key(self, password):
        """Derives the Fernet key from password using stored salt."""
        salt = bytes.fromhex(self.config["salt"])
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
        )
        return base64.urlsafe_b64encode(kdf.derive(password.encode()))

    def encrypt_content(self, content, key_token):
        """Encrypts content using a derived key."""
        f = Fernet(key_token)
        return f.encrypt(content.encode()).decode()

    def decrypt_content(self, encrypted_content, key_token):
        """Decrypts content using a derived key."""
        f = Fernet(key_token)
        return f.decrypt(encrypted_content.encode()).decode()

    def _hash_pwd(self, password, salt):
        return hashlib.pbkdf2_hmac(
            "sha256", password.encode("utf-8"), salt, 100000
        ).hex()

    def _derive_key(self, password, salt):
        # Legacy internal method (kept for compatibility or refactored)
        # We can just call the public one if we had salt logic here, but public one reads from config
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
        )
        return base64.urlsafe_b64encode(kdf.derive(password.encode()))

    def set_api_key(self, key, master_password):
        """Encrypts and saves the API key using the master password."""
        if not HAS_CRYPTO:
            raise ImportError("cryptography library is required.")

        if not self.verify_password(master_password):
            return False

        salt = bytes.fromhex(self.config["salt"])
        key_token = self._derive_key(master_password, salt)
        # Using new helper logic
        f = Fernet(key_token)
        encrypted_data = f.encrypt(key.encode())

        # Remove plaintext key if it exists
        if "gemini_api_key" in self.config:
            del self.config["gemini_api_key"]

        self.config["encrypted_api_key"] = encrypted_data.decode()
        self._save_config()
        return True

    def get_api_key(self, master_password=None):
        """Attempts to decrypt and return the API key."""
        # Handle legacy plaintext if exists
        if "gemini_api_key" in self.config:
            return self.config["gemini_api_key"]

        if not master_password:
            return ""

        if not self.is_setup() or "encrypted_api_key" not in self.config:
            return ""

        if not HAS_CRYPTO:
            return ""

        try:
            salt = bytes.fromhex(self.config["salt"])
            key_token = self._derive_key(master_password, salt)
            f = Fernet(key_token)
            encrypted_data = self.config["encrypted_api_key"].encode()
            decrypted_data = f.decrypt(encrypted_data)
            return decrypted_data.decode()
        except Exception:
            return ""

    # --- UNIVERSAL SECRETS MANAGER ---
    def store_secret(self, service_name, secret_value, master_password):
        """Stores a generic encrypted secret for external APIs."""
        if not HAS_CRYPTO or not self.verify_password(master_password):
            return False

        if "external_secrets" not in self.config:
            self.config["external_secrets"] = {}

        try:
            salt = bytes.fromhex(self.config["salt"])
            key_token = self._derive_key(master_password, salt)
            f = Fernet(key_token)

            encrypted_data = f.encrypt(secret_value.encode()).decode()
            self.config["external_secrets"][service_name] = encrypted_data
            self._save_config()
            return True
        except Exception as e:
            print(f"Error storing secret: {e}")
            return False

    def get_secret(self, service_name, master_password):
        """Retrieves a generic encrypted secret."""
        if (
            not HAS_CRYPTO
            or "external_secrets" not in self.config
            or not master_password
        ):
            return None

        encrypted_data = self.config["external_secrets"].get(service_name)
        if not encrypted_data:
            return None

        try:
            salt = bytes.fromhex(self.config["salt"])
            key_token = self._derive_key(master_password, salt)
            f = Fernet(key_token)

            decrypted_data = f.decrypt(encrypted_data.encode()).decode()
            return decrypted_data
        except Exception:
            return None

    # --- TOTP MFA SYSTEM ---
    def setup_mfa(self, master_password):
        """Generates a new TOTP secret and returns the provision URI and base32 secret."""
        if not HAS_MFA or not self.verify_password(master_password):
            return None, None, None

        totp_secret = pyotp.random_base32()

        # Generar 5 códigos de rescate
        import secrets
        import string

        recovery_codes = [
            "".join(
                secrets.choice(string.ascii_letters + string.digits) for _ in range(12)
            )
            for _ in range(5)
        ]

        # Store encrypted
        salt = bytes.fromhex(self.config["salt"])
        key_token = self._derive_key(master_password, salt)
        f = Fernet(key_token)

        encrypted_secret = f.encrypt(totp_secret.encode()).decode()
        self.config["mfa_secret"] = encrypted_secret

        # Encriptar códigos de rescate
        encrypted_recovery = [f.encrypt(c.encode()).decode() for c in recovery_codes]
        self.config["mfa_recovery_codes"] = encrypted_recovery

        self._save_config()

        totp = pyotp.TOTP(totp_secret)
        provision_uri = totp.provisioning_uri(
            name="Aegis-IA (Admin)", issuer_name="Singularity Citadel"
        )
        return totp_secret, provision_uri, recovery_codes

    def generate_mfa_qr(self, master_password):
        """Generates a QR code for the MFA setup."""
        if not HAS_MFA:
            return None, None

        _, provision_uri, recovery_codes = self.setup_mfa(master_password)
        if not provision_uri:
            return None, None

        # Generate QR
        qr = qrcode.QRCode(version=1, box_size=10, border=5)
        qr.add_data(provision_uri)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")

        img_byte_arr = io.BytesIO()
        img.save(img_byte_arr, format="PNG")
        return img_byte_arr.getvalue(), recovery_codes

    def verify_mfa(self, token, master_password):
        """Verifies a 6-digit TOTP token or a 12-char recovery code."""
        if (
            not HAS_MFA
            or "mfa_secret" not in self.config
            or not self.verify_password(master_password)
        ):
            return False

        try:
            salt = bytes.fromhex(self.config["salt"])
            key_token = self._derive_key(master_password, salt)
            f = Fernet(key_token)

            # Chequear si el token es un código de rescate
            if "mfa_recovery_codes" in self.config:
                valid_codes = []
                token_matched = False
                for enc_code in self.config["mfa_recovery_codes"]:
                    dec_code = f.decrypt(enc_code.encode()).decode()
                    if dec_code == token:
                        token_matched = True
                        # No lo guardamos -> se invalida (one-time use)
                    else:
                        valid_codes.append(enc_code)

                if token_matched:
                    self.config["mfa_recovery_codes"] = valid_codes
                    self._save_config()
                    return True

            encrypted_secret = self.config["mfa_secret"]
            decrypted_secret = f.decrypt(encrypted_secret.encode()).decode()

            totp = pyotp.TOTP(decrypted_secret)
            return totp.verify(token)
        except Exception:
            return False


auth = AuthVault()
