import os
import json
import hashlib
import base64

try:
    from cryptography.fernet import Fernet
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    HAS_CRYPTO = True
except ImportError:
    # This should be handled by requirements.txt, but for safety:
    HAS_CRYPTO = False

CONFIG_PATH = "config/secrets.json"

class AuthVault:
    def __init__(self):
        if not os.path.exists("config"):
            os.makedirs("config")
        self.config = self._load_config()

    def _load_config(self):
        if os.path.exists(CONFIG_PATH):
            try:
                with open(CONFIG_PATH, "r") as f:
                    return json.load(f)
            except json.JSONDecodeError:
                return {}
        return {}

    def _save_config(self):
        with open(CONFIG_PATH, "w") as f:
            json.dump(self.config, f, indent=4)

    def is_setup(self):
        return "master_hash" in self.config

    def set_master_password(self, password):
        """Sets the initial master password."""
        if not HAS_CRYPTO:
            raise ImportError("cryptography library is required for secure storage.")

        salt = os.urandom(16)
        # Store salt as hex
        self.config['salt'] = salt.hex()
        
        # Hash password for verification (using correct salt)
        self.config['master_hash'] = self._hash_pwd(password, salt)
        self._save_config()
        return True

    def verify_password(self, password):
        """Verifies the master password."""
        if not self.is_setup():
            return False
            
        try:
            salt = bytes.fromhex(self.config.get('salt', ''))
            attempt_hash = self._hash_pwd(password, salt)
            return attempt_hash == self.config.get('master_hash')
        except Exception:
            return False

    def _hash_pwd(self, password, salt):
        return hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, 100000).hex()

    # Public wrappers for external use (e.g. API Vault)
    def derive_key(self, password):
        """Derives the Fernet key from password using stored salt."""
        salt = bytes.fromhex(self.config['salt'])
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
        )
        return base64.urlsafe_b64encode(kdf.derive(password.encode()))

    def encrypt_content(self, content, key_token):
        """Encrypts content using a derived key."""
        f = Fernet(key_token)
        return f.encrypt(content.encode()).decode()

    def decrypt_content(self, encrypted_content, key_token):
        """Decrypts content using a derived key."""
        f = Fernet(key_token)
        return f.decrypt(encrypted_content.encode()).decode()

    def _hash_pwd(self, password, salt):
        return hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, 100000).hex()

    def _derive_key(self, password, salt):
        # Legacy internal method (kept for compatibility or refactored)
        # We can just call the public one if we had salt logic here, but public one reads from config
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
        )
        return base64.urlsafe_b64encode(kdf.derive(password.encode()))

    def set_api_key(self, key, master_password):
        """Encrypts and saves the API key using the master password."""
        if not HAS_CRYPTO:
             raise ImportError("cryptography library is required.")
             
        if not self.verify_password(master_password):
            return False

        salt = bytes.fromhex(self.config['salt'])
        key_token = self._derive_key(master_password, salt)
        # Using new helper logic
        f = Fernet(key_token)
        encrypted_data = f.encrypt(key.encode())
        
        # Remove plaintext key if it exists
        if 'gemini_api_key' in self.config:
            del self.config['gemini_api_key']
            
        self.config['encrypted_api_key'] = encrypted_data.decode()
        self._save_config()
        return True

    def get_api_key(self, master_password=None):
        """Attempts to decrypt and return the API key."""
        # Handle legacy plaintext if exists
        if 'gemini_api_key' in self.config:
             return self.config['gemini_api_key']

        if not master_password:
            return ""

        if not self.is_setup() or 'encrypted_api_key' not in self.config:
            return ""

        if not HAS_CRYPTO:
            return ""

        try:
            salt = bytes.fromhex(self.config['salt'])
            key_token = self._derive_key(master_password, salt)
            f = Fernet(key_token)
            encrypted_data = self.config['encrypted_api_key'].encode()
            decrypted_data = f.decrypt(encrypted_data)
            return decrypted_data.decode()
        except Exception:
            return ""

auth = AuthVault()
