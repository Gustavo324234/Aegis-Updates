import smtplib
import logging
import os
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

logger = logging.getLogger(__name__)

DESCRIPTION = """
Module: uplink
Purpose: Secure communication channel for the AI to submit improvement proposals
         to the Architect (human operator) via Email. The AI CANNOT self-modify;
         instead it uses this module to request changes that a human must review
         and apply manually.
Actions:
- submit_system_improvement: Writes a proposal file and sends it to the Architect.
Usage format:
{"module": "uplink", "action": "submit_system_improvement", "args": {"filename": "brain.py", "description": "Improve context window handling", "proposed_code": "..."}}
"""

ARCHITECT_EMAIL = "gustavoaversente@gmail.com"


def _get_smtp_config():
    """
    Reads SMTP credentials from the database settings table.
    Returns a dict with keys: smtp_server, smtp_port, smtp_user, smtp_pass.
    Returns None if any required setting is missing.
    """
    try:
        import database

        smtp_server = database.get_setting("smtp_server")
        smtp_port = database.get_setting("smtp_port")
        smtp_user = database.get_setting("smtp_user")
        smtp_pass = database.get_setting("smtp_pass")

        if not all([smtp_server, smtp_port, smtp_user, smtp_pass]):
            logger.warning(
                "[UPLINK] SMTP credentials are not fully configured. "
                "Set smtp_server, smtp_port, smtp_user and smtp_pass in Settings."
            )
            return None

        return {
            "server": smtp_server.strip(),
            "port": int(smtp_port.strip()),
            "user": smtp_user.strip(),
            "pass": smtp_pass.strip(),
        }
    except Exception as e:
        logger.error(f"[UPLINK] Could not read SMTP config from database: {e}")
        return None


def send_architect_proposal(
    subject: str, body: str, attachment_path: str = None
) -> dict:
    """
    Sends a proposal email to the Architect.

    Args:
        subject (str): Email subject line.
        body (str): Email body (plain text or markdown).
        attachment_path (str, optional): Absolute path to a file to attach.

    Returns:
        dict: {"success": bool, "message": str}
    """
    config = _get_smtp_config()
    if config is None:
        msg = (
            "UPLINK ERROR: SMTP not configured. "
            "Go to Settings and set smtp_server, smtp_port, smtp_user, smtp_pass."
        )
        logger.error(f"[UPLINK] {msg}")
        return {"success": False, "message": msg}

    try:
        # Build the message
        email_msg = MIMEMultipart()
        email_msg["From"] = config["user"]
        email_msg["To"] = ARCHITECT_EMAIL
        email_msg["Subject"] = f"[AEGIS UPLINK] {subject}"

        email_msg.attach(MIMEText(body, "plain", "utf-8"))

        # Optional attachment
        if attachment_path and os.path.isfile(attachment_path):
            with open(attachment_path, "rb") as f:
                part = MIMEBase("application", "octet-stream")
                part.set_payload(f.read())
            encoders.encode_base64(part)
            filename = os.path.basename(attachment_path)
            part.add_header("Content-Disposition", f'attachment; filename="{filename}"')
            email_msg.attach(part)

        # Send via SMTP with TLS
        with smtplib.SMTP(config["server"], config["port"], timeout=15) as server:
            server.ehlo()
            server.starttls()
            server.ehlo()
            server.login(config["user"], config["pass"])
            server.sendmail(config["user"], ARCHITECT_EMAIL, email_msg.as_string())

        logger.info(f"[UPLINK] Proposal '{subject}' sent to Architect successfully.")
        return {"success": True, "message": f"Proposal sent to {ARCHITECT_EMAIL}."}

    except smtplib.SMTPAuthenticationError:
        msg = "UPLINK ERROR: SMTP Authentication failed. Check smtp_user and smtp_pass in Settings."
        logger.error(f"[UPLINK] {msg}")
        return {"success": False, "message": msg}

    except smtplib.SMTPConnectError:
        msg = f"UPLINK ERROR: Could not connect to SMTP server '{config['server']}:{config['port']}'."
        logger.error(f"[UPLINK] {msg}")
        return {"success": False, "message": msg}

    except Exception as e:
        msg = f"UPLINK ERROR: Unexpected failure while sending proposal: {e}"
        logger.error(f"[UPLINK] {msg}")
        return {"success": False, "message": msg}
