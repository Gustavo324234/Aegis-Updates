import zipfile

import gc
import os
import datetime
import json
import sqlite3
import google.generativeai as genai
import database
from modules.vault_manager import vault, VAULT_DIR

# DB Connection (Should refactor to share with database.py but using direct connection for module autonomy)
DB_NAME = "aegis_memory.db"


class Unifier:
    def __init__(self):
        pass

    def ingest_text(self, text, source="External"):
        """Ingests a block of text (e.g. pasted chat) into the Vault."""
        timestamp = datetime.datetime.now().isoformat()

        # Parse potential title from first line
        # lines = text.split("\n")

        # Sanitize filename
        safe_source = "".join([c if c.isalnum() else "_" for c in source])
        filename = f"import_{safe_source}_{timestamp.replace(':', '-')}.txt"
        target_path = os.path.join(VAULT_DIR, filename)

        try:
            with open(target_path, "w", encoding="utf-8") as f:
                f.write(text)

            return vault.index_file(filename)
        except Exception as e:
            return f"Ingestion Error: {str(e)}"

    def ingest_bridge_content(self, content, source_name):
        """Ingests content scraped by the Bridge Browser."""
        timestamp = datetime.datetime.now().isoformat()
        filename = f"synapse_sync_{source_name}_{timestamp.replace(':', '-')}.txt"
        target_path = os.path.join(VAULT_DIR, filename)

        try:
            with open(target_path, "w", encoding="utf-8") as f:
                f.write(content)

            return vault.index_file(filename)
        except Exception as e:
            return f"Synapse Error: {str(e)}"

    def get_imported_contexts(self):
        """Returns list of imported/synced files."""
        try:
            conn = sqlite3.connect(DB_NAME)
            c = conn.cursor()
            c.execute(
                "SELECT filename, last_indexed FROM vault_content WHERE filename LIKE 'import_%' OR filename LIKE 'synapse_%' OR filename LIKE 'chatgpt_export_%' ORDER BY last_indexed DESC"
            )
            rows = c.fetchall()
            conn.close()
            return rows
        except Exception:
            return []

    def ingest_json_export(self, json_file):
        """
        Parses standard ChatGPT export (conversations.json).
        """
        try:
            data = json.load(json_file)
            count = 0
            skipped = 0

            for convo in data:
                title = convo.get("title", "Untitled Conversation")
                mapping = convo.get("mapping", {})

                full_text_buffer = []

                for key, node in mapping.items():
                    if not node:
                        continue
                    message = node.get("message")
                    if message:
                        author_role = message.get("author", {}).get("role", "unknown")
                        if author_role == "system":
                            continue

                        content = message.get("content", {})
                        parts = content.get("parts", [])

                        text_parts = []
                        for p in parts:
                            if isinstance(p, str):
                                text_parts.append(p)

                        if text_parts:
                            full_text_buffer.append(
                                f"{author_role.upper()}: {' '.join(text_parts)}"
                            )

                if full_text_buffer:
                    full_text = "\n\n".join(full_text_buffer)

                    safe_title = "".join([c if c.isalnum() else "_" for c in title])[
                        :50
                    ]
                    fn = f"chatgpt_export_{safe_title}_{count}.txt"
                    target_path = os.path.join(VAULT_DIR, fn)

                    try:
                        with open(target_path, "w", encoding="utf-8") as f:
                            f.write(full_text)

                        vault.index_file(fn)
                        count += 1

                        # Memory Optimization
                        if count % 50 == 0:
                            gc.collect()

                    except Exception as e:
                        skipped += 1
                        print(f"Error saving/indexing {fn}: {e}")

            return (
                f"Success: Imported {count} conversations ({skipped} skipped/failed)."
            )

        except Exception as e:
            return f"JSON Import Error: {str(e)}"

    def ingest_zip_export(self, zip_file):
        """Extracts and ingests supported files from a ZIP archive."""
        try:
            with zipfile.ZipFile(zip_file) as z:
                # Supported extensions from VaultManager + known ones
                exts = (
                    ".txt",
                    ".md",
                    ".json",
                    ".pdf",
                    ".csv",
                    ".xlsx",
                    ".xls",
                    ".mp3",
                    ".wav",
                )
                valid_files = [f for f in z.namelist() if f.lower().endswith(exts)]
                count = 0

                # Check for conversations.json (ChatGPT special)
                if "conversations.json" in valid_files:
                    with z.open("conversations.json") as f:
                        return self.ingest_json_export(f)

                for file_info in valid_files:
                    # Flatten path: use basename
                    base_name = os.path.basename(file_info)
                    if not base_name:
                        continue

                    target_path = os.path.join(VAULT_DIR, base_name)

                    # Extract/Write
                    with z.open(file_info) as source, open(target_path, "wb") as target:
                        target.write(source.read())

                    # Index
                    vault.index_file(base_name)
                    count += 1

                    if count % 20 == 0:
                        gc.collect()

                return f"Success: Imported {count} files from ZIP."

        except Exception as e:
            return f"ZIP Import Error: {str(e)}"

    def assimilate_project(self, project_name, api_key):
        """
        PROJECT NEXUS: Scans Vault, merges contexts, creates Master Timeline.
        """
        if not api_key:
            return "Error: API Key required."

        # 1. Search Vault (Increased limit for merging)
        results = vault.search(project_name, mode="hybrid")[:15]
        if not results:
            return f"Project '{project_name}' not found in The Vault."

        # 2. Gather Context & Analyze Sources
        context_buffer = ""
        sources = []
        for res in results:
            fname = res["filename"]
            content = vault.get_file_content(fname)
            if content:
                # Naive source detection
                src_type = "Document"
                if "chatgpt" in fname.lower():
                    src_type = "ChatGPT Chat"
                elif "claude" in fname.lower():
                    src_type = "Claude Chat"
                elif "synapse" in fname.lower():
                    src_type = "Web/Synapse"

                sources.append(src_type)
                context_buffer += (
                    f"\n--- SOURCE: {fname} ({src_type}) ---\n{content[:3000]}...\n"
                )

        # Count sources
        from collections import Counter

        src_counts = Counter(sources)
        src_summary = ", ".join(
            [f"{count} {name}" for name, count in src_counts.items()]
        )

        # 3. AI Analysis (Master Timeline & Sheet)
        prompt = f"""
[CONTEXT FUSION PROTOCOL]
Analyze the following multi-source history for project '{project_name}'.
Sources found: {src_summary}

Tasks:
1. Identify CONTRADICTIONS or repeated milestones across files.
2. Merge them into a single MASTER TIMELINE.
3. Create a JSON Project Sheet.

Output format:
JSON ONLY. Structure:
{{
  "project_name": "{project_name}",
  "status": "Active/On-Hold/Completed",
  "technologies": ["List", "of", "tech"],
  "master_timeline": [
      {{"date": "YYYY-MM-DD (approx)", "event": "Event description", "source": "ChatGPT/Claude"}},
      ...
  ],
  "objectives": "Concise goal summary",
  "pending_tasks": ["Task 1", "Task 2"],
  "fusion_summary": "I have analyzed {src_summary}. Key insight: ..."
}}

Vault Data:
{context_buffer}
"""
        try:
            genai.configure(api_key=api_key)
            model = genai.GenerativeModel("gemini-1.5-flash")
            response = model.generate_content(prompt).text

            import re

            match = re.search(r"\{.*\}", response, re.DOTALL)
            if match:
                sheet_json = match.group(0)
                data = json.loads(sheet_json)

                # Store in Nexus
                safe_key = project_name.lower().replace(" ", "_")
                database.add_user_fact(
                    f"project_{safe_key}", sheet_json, "project_sheet", 1.0
                )

                # Return User-Facing Message
                return f"✅ **Context Fusion Complete**\n\nI have analyzed {src_summary} regarding '{project_name}'.\n\n**Master Timeline Created:** {len(data.get('master_timeline', []))} milestones identified.\n**Status:** {data.get('status')}\n**Pending:** {len(data.get('pending_tasks', []))} tasks.\n\n_Nexus Memory Updated._"

            return "Error: Could not parse Project Timeline JSON."

        except Exception as e:
            return f"Fusion Error: {str(e)}"


unifier = Unifier()

MANIFEST = {
    "name": "Unifier (Project Nexus)",
    "description": "Manages memory assimilation, context fusion (merging ChatGPT/Claude histories), and project knowledge.",
    "commands": {
        "assimilate_project": {
            "description": "Merge AI contexts and create a Master Timeline for a project.",
            "args": ["project_name"],
        }
    },
}


def execute(query):
    # This requires API Key. In ModuleManager execution, we might not have it unless passed in args.
    # AegisBrain usually injects keys or we fetch from DB.
    # We'll fetch from DB here for robustness.

    action = query.get("action")
    args = query.get("args", {})

    # robust key fetch
    api_key = args.get("api_key")
    if not api_key:
        api_key = database.get_setting("api_key_gemini")

    if action == "assimilate_project" or action == "merge_ai_contexts":
        return unifier.assimilate_project(args.get("project_name"), api_key)

    return f"Unifier: Unknown action {action}"
