# modules/life_manager.py
import json
import database
import re
import requests

DESCRIPTION = """
Use this module to manage the user's personal life: Expenses, Tasks, and Contexts (Projects).

Commands:
1. Expenses:
   {"module": "life_manager", "action": "add_expense", "amount": 10.5, "category": "Food", "desc": "Lunch"}
   
2. Tasks/Calendar:
   {"module": "life_manager", "action": "add_task", "task": "Buy milk", "due_date": "Tomorrow"}
   {"module": "life_manager", "action": "schedule_event", "event": "Meeting using X", "time": "2023-10-20 10:00"}
   {"module": "life_manager", "action": "complete_task", "task_id": 1}
   {"module": "life_manager", "action": "complete_objective", "objective": "Learn to play guitar"}

3. Context/Projects:
   {"module": "life_manager", "action": "switch_context", "context": "project_name"}
   {"module": "life_manager", "action": "create_project", "name": "project_name", "content": "initial notes"}

Rules:
- If the user talks about a project, switch context to it if it exists.
- If the user wants to go back to normal chat, switch context to 'general'.
"""


def _sync_with_nexus(data_type, payload):
    """
    Tries to push data to the local Nexus Gateway for network-wide sync.
    """
    try:
        # Fetch all nodes to find Hubs/Peers
        nodes = database.get_all_nodes()
        active_peers = [n["node_id"] for n in nodes if n["status"] == "online"]

        for peer in active_peers:
            sync_command = {
                "target_node": peer,
                "content": {"life_sync": {"type": data_type, **payload}},
            }
            # Push via local gateway (Hub-to-Limb or Peer-to-Peer)
            requests.post(
                "http://localhost:8000/send_message", json=sync_command, timeout=2
            )
    except Exception:
        pass  # Silent fail for sync


def execute(query):
    if isinstance(query, str):
        try:
            query = json.loads(query)
        except Exception:
            return "Error: Query must be valid JSON."

    action = query.get("action")
    # Hybrid Support: Extract parameters from 'args' if present
    args = query.get("args") if isinstance(query.get("args"), dict) else query

    # Helper to get keys from either root or args
    def get_val(key, default=None):
        return args.get(key, query.get(key, default))

    # Expenses
    if action == "add_expense":
        amount = get_val("amount")
        category = get_val("category", "Uncategorized")
        desc = get_val("desc", "Misc")

        # NLP Fallback (Auto-Correction)
        if not amount:
            raw_text = get_val("text", desc)
            match = re.search(r"[\$€]?\s*(\d+(\.\d+)?)", str(raw_text))
            if match:
                amount = float(match.group(1))

            if category == "Uncategorized":
                lower_text = str(raw_text).lower()
                if any(
                    k in lower_text for k in ["comida", "lunch", "restaurante", "café"]
                ):
                    category = "Food"
                elif any(k in lower_text for k in ["uber", "taxi", "transporte"]):
                    category = "Transport"

        if not amount:
            return "Error: Could not determine amount."

        res = database.add_expense(amount, category, desc)

        if "success" in str(res):
            _sync_with_nexus(
                "expense", {"amount": amount, "category": category, "description": desc}
            )

        return res

    # Tasks
    elif action == "add_task":
        task_content = get_val("task")
        due_date = get_val("due_date")

        active_project = database.get_latest_project()
        if active_project:
            task_content = f"[{active_project}] {task_content}"

        res = database.add_task(task_content, due_date)

        if "success" in str(res):
            _sync_with_nexus("task", {"task": task_content, "due_date": due_date})

        return res
    elif action == "complete_task":
        return database.complete_task(get_val("task_id"))

    # Objectives (Chronos Protocol)
    elif action == "complete_objective":
        objective_text = get_val("objective") or get_val("task")
        database.add_user_fact(objective_text, "completed", "objective_status")
        return f"Objetivo '{objective_text}' marcado como completado."

    # Calendar Intelligence
    elif action == "schedule_event":
        event = get_val("event") or get_val("task")
        time_slot = get_val("time") or get_val("due_date")

        if not time_slot:
            return "Error: Time/Date required for scheduling."

        existing_tasks = database.get_tasks() or []
        conflict = False
        conflict_detail = ""

        for t in existing_tasks:
            t_date = ""
            t_name = ""
            if isinstance(t, dict):
                t_date = t.get("due_date", "")
                t_name = t.get("task", "")
            elif isinstance(t, (list, tuple)) and len(t) > 2:
                t_date = t[2]
                t_name = t[1]

            if t_date and time_slot in t_date:
                conflict = True
                conflict_detail = f"Conflict with '{t_name}' at {t_date}"
                break

        if conflict:
            return json.dumps(
                {
                    "action": "propose_alternatives",
                    "message": f"Conflict detected: {conflict_detail}",
                    "alternatives": [
                        f"{time_slot} (+1 hour)",
                        f"{time_slot} (+2 hours)",
                        "Tomorrow same time",
                    ],
                }
            )

        event_content = f"[EVENT] {event}"
        active_project = database.get_latest_project()
        if active_project:
            event_content = f"[{active_project}] {event_content}"

        res = database.add_task(event_content, time_slot)

        if "success" in str(res):
            _sync_with_nexus("task", {"task": event_content, "due_date": time_slot})

        return res

    # Projects / Context
    elif action == "create_project":
        return database.create_project(get_val("name"), get_val("content", ""))
    elif action == "switch_context":
        context = get_val("context")
        return f"CONTEXT_SWITCH:{context}"

    return "Error: Unknown action in life_manager."
