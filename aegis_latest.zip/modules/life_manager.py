# modules/life_manager.py
import json
import database

DESCRIPTION = """
Use this module to manage the user's personal life: Expenses, Tasks, and Contexts (Projects).

Commands:
1. Expenses:
   {"module": "life_manager", "action": "add_expense", "amount": 10.5, "category": "Food", "desc": "Lunch"}
   
2. Tasks:
   {"module": "life_manager", "action": "add_task", "task": "Buy milk", "due_date": "Tomorrow"}
   {"module": "life_manager", "action": "complete_task", "task_id": 1}

3. Context/Projects:
   {"module": "life_manager", "action": "switch_context", "context": "project_name"}
   {"module": "life_manager", "action": "create_project", "name": "project_name", "content": "initial notes"}

Rules:
- If the user talks about a project, switch context to it if it exists.
- If the user wants to go back to normal chat, switch context to 'general'.
"""


def execute(query):
    if isinstance(query, str):
        try:
            query = json.loads(query)
        except Exception:
            return "Error: Query must be valid JSON."

    action = query.get("action")

    # Expenses
    if action == "add_expense":
        return database.add_expense(
            query.get("amount"),
            query.get("category", "Uncategorized"),
            query.get("desc", "Misc"),
        )

    # Tasks
    elif action == "add_task":
        return database.add_task(query.get("task"), query.get("due_date"))
    elif action == "complete_task":
        return database.complete_task(query.get("task_id"))

    # Projects / Context
    elif action == "create_project":
        return database.create_project(query.get("name"), query.get("content", ""))
    elif action == "switch_context":
        # This action is special; it changes the app state.
        # The module executes it effectively by returning a success message,
        # but the actual state change needs to be handled by the frontend or
        # implied by the return value.
        # However, for the AI to "know", we can just return a confirmation.
        # But `app_web.py` needs to intercept this to update session_state.
        context = query.get("context")
        return f"CONTEXT_SWITCH:{context}"

    return "Error: Unknown action in life_manager."
