# modules/validator.py
import subprocess
import os
import sys
import tempfile

class CodeSentinel:
    def __init__(self):
        pass

    def check_syntax(self, code_str):
        """
        Validates Python syntax without execution.
        Returns: (is_valid: bool, error_msg: str)
        """
        import ast
        try:
            ast.parse(code_str)
            return True, "Syntax OK"
        except SyntaxError as e:
            return False, f"Syntax Error: {e}"
        except Exception as e:
            return False, f"Parse Error: {e}"

    # validate_code removed for security (static analysis only)

# Instance
sentinel = CodeSentinel()
