# modules/validator.py


class CodeSentinel:
    def __init__(self):
        pass

    def check_syntax(self, code_str):
        """
        Validates Python syntax without execution.
        Returns: (is_valid: bool, error_msg: str)
        """
        if not code_str:
            return False, "Empty Code"
        import ast

        try:
            ast.parse(code_str)
            return True, "Syntax OK"
        except SyntaxError as e:
            return False, f"Syntax Error: {e}"
        except Exception as e:
            return False, f"Parse Error: {e}"

    # validate_code removed for security (static analysis only)


# Instance
sentinel = CodeSentinel()
