# modules/validator.py
import subprocess
import os
import sys
import tempfile

class CodeSentinel:
    def __init__(self):
        pass

    def check_syntax(self, code_str):
        """
        Validates Python syntax without execution.
        Returns: (is_valid: bool, error_msg: str)
        """
        import ast
        try:
            ast.parse(code_str)
            return True, "Syntax OK"
        except SyntaxError as e:
            return False, f"Syntax Error: {e}"
        except Exception as e:
            return False, f"Parse Error: {e}"

    def validate_code(self, code_str):
        """
        Validates Python code by attempting to run it in a subprocess.
        Returns: (is_valid: bool, output: str)
        """
        # Create a temp file
        try:
            with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False, encoding='utf-8') as tmp:
                tmp.write(code_str)
                tmp_path = tmp.name
            
            # Run the code (timeout 5s for safety)
            # We assume the code is a module definition so it might not do anything on run,
            # but if it has syntax errors or import errors, it will fail.
            # To test logic, the code needs a test block, but for now we check for basic runtime integrity.
            result = subprocess.run(
                [sys.executable, tmp_path],
                capture_output=True,
                text=True,
                timeout=5
            )
            
            # Cleanup
            os.remove(tmp_path)
            
            if result.returncode == 0:
                return True, f"Validation Passed.\nStdout: {result.stdout}"
            else:
                return False, f"Validation Failed.\nStderr: {result.stderr}\nStdout: {result.stdout}"
                
        except subprocess.TimeoutExpired:
            os.remove(tmp_path)
            return False, "Validation Timed Out (Code took too long to execute)."
        except Exception as e:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
            return False, f"Sentinel Error: {str(e)}"

# Instance
sentinel = CodeSentinel()
