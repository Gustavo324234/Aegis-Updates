import requests
import json
import logging
import database
from cryptography.fernet import Fernet
import sys
import os
import zipfile
import io
import base64
import hashlib

# Logger
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("SatelliteBridge")

GATEWAY_URL = os.getenv("AEGIS_GATEWAY_URL", "http://localhost:8000")


def get_node_key(node_id):
    """Retrieves key from DB directly."""
    # Assuming running on server
    return database.get_node_key(node_id)


def trigger_index(node_id):
    """
    Sends command to Limb to index workspace.
    Instructs it to reply to 'hub_vault'.
    """
    logger.info(f"Triggering Workspace Index on {node_id}")

    # 1. Get Key to Encrypt Command
    secret_key = get_node_key(node_id)
    if not secret_key:
        return "Error: Node Key not found. Cannot encrypt command."

    try:
        cipher = Fernet(secret_key.encode())

        # 2. Prepare Command
        command = {
            "type": "index_remote_workspace",
            "reply_to": "hub_vault",  # Instructs Limb to reply to this target
            "id": f"idx_{os.urandom(4).hex()}",
        }

        encrypted_cmd = cipher.encrypt(json.dumps(command).encode()).decode()

        # 3. Send to Gateway
        payload = {"target_node": node_id, "content": {"encrypted_data": encrypted_cmd}}

        resp = requests.post(f"{GATEWAY_URL}/send_message", json=payload)

        if resp.status_code == 200:
            return f"Index Initiated on {node_id}. Watch Vault for updates."
        else:
            return f"Gateway Error: {resp.text}"

    except Exception as e:
        return f"Bridge Error: {e}"


def pack_and_send(source_path, target_node_id, target_subdir=""):
    """
    Compresses a local folder, encrypts it (within the command envelope),
    and sends it to the target Satellite via Gateway.
    """
    logger.info(f"Packing {source_path} for {target_node_id}...")

    if not os.path.exists(source_path):
        return f"Error: Source path '{source_path}' does not exist."

    secret_key = get_node_key(target_node_id)
    if not secret_key:
        return f"Error: No encryption key for node {target_node_id}"

    try:
        # 1. Compress to RAM (or temp file if huge, but RAM for now)
        zip_buffer = io.BytesIO()
        with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zf:
            for root, dirs, files in os.walk(source_path):
                # Optional: Filter protected files
                for file in files:
                    full_path = os.path.join(root, file)
                    rel_path = os.path.relpath(full_path, source_path)
                    zf.write(full_path, rel_path)

        zip_bytes = zip_buffer.getvalue()
        zip_md5 = hashlib.md5(zip_bytes).hexdigest()
        zip_b64 = base64.b64encode(zip_bytes).decode("utf-8")

        logger.info(f"Packed {len(zip_bytes)} bytes. Checksum: {zip_md5}")

        # 2. Prepare Command
        command = {
            "type": "sync_entire_project",
            "payload": zip_b64,
            "target_subdir": target_subdir,
            "checksum": zip_md5,  # Inner checksum for Limb
            "id": f"sync_{os.urandom(4).hex()}",
        }

        # 3. Encrypt Envelope
        cipher = Fernet(secret_key.encode())
        encrypted_data = cipher.encrypt(json.dumps(command).encode()).decode("utf-8")

        # 4. Gateway Integrity Checksum
        gateway_checksum = hashlib.md5(encrypted_data.encode()).hexdigest()

        # 5. Send
        payload = {
            "target_node": target_node_id,
            "content": {"encrypted_data": encrypted_data},
            "checksum": gateway_checksum,  # Outer checksum for Gateway
        }

        # Warning: payload might be large
        resp = requests.post(f"{GATEWAY_URL}/send_message", json=payload)

        if resp.status_code == 200:
            return f"Sync Sent! Size: {len(encrypted_data)} bytes. Gateway Resp: {resp.json()}"
        else:
            return f"Gateway Failed: {resp.text}"

    except Exception as e:
        logger.error(f"Sync Error: {e}")
        return f"Sync Error: {e}"


if __name__ == "__main__":
    if len(sys.argv) > 1:
        action = sys.argv[1]

        if action == "index" and len(sys.argv) > 2:
            print(trigger_index(sys.argv[2]))

        elif action == "sync" and len(sys.argv) > 3:
            # Usage: python satellite_bridge.py sync <node_id> <path> [target_subdir]
            node = sys.argv[2]
            path = sys.argv[3]
            subdir = sys.argv[4] if len(sys.argv) > 4 else ""
            print(pack_and_send(path, node, subdir))

        else:
            print("Usage:")
            print("  python satellite_bridge.py index <node_id>")
            print(
                "  python satellite_bridge.py sync <node_id> <local_path> [target_subdir]"
            )
    else:
        print("Usage: python satellite_bridge.py <action> ...")
