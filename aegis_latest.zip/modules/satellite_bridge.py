
import requests
import json
import logging
import database
from cryptography.fernet import Fernet
import sys
import os

# Logger
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("SatelliteBridge")

GATEWAY_URL = "http://localhost:8000"

def get_node_key(node_id):
    """Retrieves key from DB directly."""
    # Assuming running on server
    return database.get_node_key(node_id)

def trigger_index(node_id):
    """
    Sends command to Limb to index workspace.
    Instructs it to reply to 'hub_vault'.
    """
    logger.info(f"Triggering Workspace Index on {node_id}")
    
    # 1. Get Key to Encrypt Command
    secret_key = get_node_key(node_id)
    if not secret_key:
        return "Error: Node Key not found. Cannot encrypt command."
        
    try:
        cipher = Fernet(secret_key.encode())
        
        # 2. Prepare Command
        command = {
            "type": "index_remote_workspace",
            "reply_to": "hub_vault", # Instructs Limb to reply to this target
            "id": f"idx_{os.urandom(4).hex()}"
        }
        
        encrypted_cmd = cipher.encrypt(json.dumps(command).encode()).decode()
        
        # 3. Send to Gateway
        payload = {
            "target_node": node_id,
            "content": {
                "encrypted_data": encrypted_cmd
            }
        }
        
        resp = requests.post(f"{GATEWAY_URL}/send_message", json=payload)
        
        if resp.status_code == 200:
            return f"Index Initiated on {node_id}. Watch Vault for updates."
        else:
            return f"Gateway Error: {resp.text}"
            
    except Exception as e:
        return f"Bridge Error: {e}"

if __name__ == "__main__":
    if len(sys.argv) > 1:
        target = sys.argv[1]
        print(trigger_index(target))
    else:
        print("Usage: python satellite_bridge.py <node_id>")
