import sys
import os
import json
import logging
import requests
from typing import Optional, Dict, Any
from fastapi import (
    FastAPI,
    WebSocket,
    WebSocketDisconnect,
    Request,
    HTTPException,
)
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
import uvicorn
from cryptography.fernet import Fernet

# ---------------------------------------------------------------------------
# PATH CONFIGURATION
# We resolve the project root deterministically from this file's own location.
# __file__ is always absolute (or made so with os.path.abspath), so this is
# immune to the working directory from which the script is launched.
#
# Directory layout assumed:
#   <project_root>/
#       database.py          ← target root-level module
#       modules/
#           nexus_gateway.py ← THIS file  (one level deep)
#
# Therefore: project_root = parent of this file's directory.
# ---------------------------------------------------------------------------

# Anchor to this script's real location, not the CWD.
_THIS_FILE = os.path.abspath(__file__)
_MODULE_DIR = os.path.dirname(_THIS_FILE)  # …/modules/
_PROJECT_ROOT = os.path.dirname(_MODULE_DIR)  # …/<project_root>/

if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

try:
    from database import (
        register_node,
        update_node_status,
        update_node_heartbeat,
        get_node_key,
        validate_pairing_code,
        get_contributors,
        queue_message,
        get_and_clear_queued_messages,
        update_node_last_indexed,
        log_audit_event,
    )
    from modules.vault_manager import vault
except ImportError as e:
    _msg = (
        f"\n{'=' * 60}\n"
        f"  CRITICAL IMPORT ERROR in nexus_gateway.py\n"
        f"  Failed to import: {e}\n\n"
        f"  Resolved project root: {_PROJECT_ROOT}\n"
        f"  Active sys.path: {sys.path}\n\n"
        f"  ► Fix option 1 (recommended): run as a module from the\n"
        f"    project root:\n"
        f"      python -m modules.nexus_gateway\n\n"
        f"  ► Fix option 2: ensure you launch from the project root:\n"
        f"      cd {_PROJECT_ROOT}\n"
        f"      python modules/nexus_gateway.py\n"
        f"{'=' * 60}\n"
    )
    # Print to stderr so it is visible even if the logging handlers
    # have not been configured yet at this early stage.
    print(_msg, file=sys.stderr)
    raise SystemExit(1) from e


# Logging Configuration
# Use FileHandler to ensure logs are saved even if console detaches
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[logging.FileHandler("gateway.log"), logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger("NexusGateway")

app = FastAPI(
    title="Nexus Gateway", description="Central Nervous System for Networked Devices"
)


@app.on_event("startup")
async def startup_event():
    """
    PROTOCOL: NETWORK RESET.
    On boot, mark all nodes as offline since in-memory WebSocket state is lost.
    Nodes will self-recover by reconnecting via their aegis_limb.py heartbeat loop.
    """
    logger.info("Initializing Nexus Gateway... Purging stale connections.")
    try:
        from database import get_connection

        conn = get_connection()
        conn.execute("UPDATE network_nodes SET status='offline'")
        conn.commit()
        conn.close()
        logger.info(
            "✅ Network State Sanitized. All nodes marked offline pending reconnection."
        )
    except Exception as e:
        logger.error(f"❌ Startup Sanitization Failed: {e}")


# --- Data Models ---
class NodeRegistration(BaseModel):
    node_id: str
    public_key: str
    fernet_key: Optional[str] = None
    pairing_code: Optional[str] = None
    contribution_mode: bool = False
    hwid: Optional[str] = None
    hwid_signature: Optional[str] = None


class MessagePayload(BaseModel):
    target_node: str
    content: dict
    checksum: Optional[str] = None  # For integrity verification


class LogEvent(BaseModel):
    module: str
    action: str
    status: str
    approved: bool = False
    details: Optional[str] = None


# --- TERMINAL GHOST MODELS ---
class TerminalError(BaseModel):
    pwd: str
    command: str
    exit_code: int


# --- TERMINAL GHOST LOGIC ---
async def analyze_terminal_error(error: TerminalError):
    import database
    import requests
    import json

    # 1. Verificar si el Fantasma está activado
    if database.get_setting("terminal_ghost") == "false":
        return

    # 2. Configuración Ligera
    ollama_url = database.get_setting("ollama_url") or "http://127.0.0.1:11434"
    if ollama_url.endswith("/"):
        ollama_url = ollama_url[:-1]
    model = database.get_setting("local_coder_model") or "qwen2.5-coder:7b"

    prompt = f"SYSTEM: Eres 'Terminal Ghost', un experto en Linux Debian. El usuario ejecutó `{error.command}` en el directorio `{error.pwd}` y falló con el código de salida {error.exit_code}. Explica brevemente el posible error y da el comando exacto para solucionarlo. Sé conciso."

    try:
        # Llamada directa y rápida a Ollama
        res = requests.post(
            f"{ollama_url}/api/generate",
            json={"model": model, "prompt": prompt, "stream": False},
            timeout=15,
        )
        if res.status_code == 200:
            text = res.json().get("response", "")

            # --- NUEVO: DISPARADOR DE AUTO-REPARACIÓN ---
            # Si el diagnóstico parece resoluble, creamos una misión asíncrona
            if "comando:" in text.lower() or "solución:" in text.lower():
                # Extraer pasos simples del diagnóstico
                steps = [
                    f"Analizar error: {error.command}",
                    f"Intentar aplicar solución sugerida: {text[:100]}...",
                    "Verificar integridad del sistema",
                ]
                mission_id = database.create_mission(
                    f"Auto-Reparación: {error.command}", steps
                )
                database.set_daemon_status("mission_worker", "RUNNING")

                msg = f"🔧 **Self-Repair** activado para el error en `{error.command}`. Misión ID: {mission_id}"
            else:
                msg = f"👻 **Terminal Ghost** detectó un fallo en tu consola:\n> Directorio: `{error.pwd}`\n> Comando: `{error.command}`\n> Código: `{error.exit_code}`\n\n**Diagnóstico:**\n{text}"

            database.save_message("assistant", msg, "TerminalGhost", "general")
    except Exception as e:
        logger.error(f"Self-Repair Trigger Error: {e}")


@app.post("/terminal_hook")
async def terminal_hook(error: TerminalError):
    import asyncio

    # Lanzar al fondo para no bloquear la terminal del usuario
    asyncio.create_task(analyze_terminal_error(error))
    return {"status": "ghost_dispatched"}


# --- Connection Manager ---
class ConnectionManager:
    def __init__(self):
        self.active_connections: Dict[str, WebSocket] = {}

    async def connect(self, node_id: str, websocket: WebSocket):
        await websocket.accept()
        self.active_connections[node_id] = websocket
        logger.info(f"Node connected: {node_id}")
        log_audit_event(
            "SYSTEM",
            f"Node Connected: {node_id}",
            "NEXUS_GATEWAY",
            "INFO",
            approved=False,
        )

    def disconnect(self, node_id: str):
        if node_id in self.active_connections:
            del self.active_connections[node_id]
        logger.info(f"Node disconnected: {node_id}")
        log_audit_event(
            "SYSTEM",
            f"Node Disconnected: {node_id}",
            "NEXUS_GATEWAY",
            "WARNING",
            approved=False,
        )

    async def send_personal_message(self, message: str, node_id: str):
        if node_id in self.active_connections:
            try:
                await self.active_connections[node_id].send_text(message)
                return True
            except Exception as e:
                logger.error(f"Failed to send message to {node_id}: {e}")
                return False
        return False

    async def broadcast(self, message: str):
        for node_id, connection in self.active_connections.items():
            try:
                await connection.send_text(message)
            except Exception as e:
                logger.error(f"Failed to broadcast to {node_id}: {e}")

    def is_online(self, node_id: str) -> bool:
        return node_id in self.active_connections


manager = ConnectionManager()

# --- API Endpoints ---


@app.get("/")
async def root():
    return {
        "status": "Nexus Gateway Operational",
        "active_nodes": len(manager.active_connections),
    }


@app.post("/register")
async def register(request: Request, node_data: NodeRegistration):
    """
    Registers a device with NodeID and Public Key.
    Enforces HWID Signature and Binding.
    """
    client_ip = request.client.host
    logger.info(f"Registering node {node_data.node_id} from {client_ip}")

    # 1. PAIRING VALIDATION (HWID Signature)
    if not node_data.pairing_code:
        raise HTTPException(status_code=403, detail="Pairing Code Required")

    # Check if code exists/valid via DB
    # Note: validate_pairing_code deletes it usually, but for stateless verify we might check first?
    # Existing logic: validate_pairing_code(code) checks and deletes if valid (one-time use).
    # If we want to allow re-registration of SAME node, maybe we don't need code?
    # But for now, strict pairing.

    # Verify Signature if HWID provided
    if node_data.hwid and node_data.hwid_signature:
        import hmac
        import hashlib

        # Calc expected
        try:
            expected = hmac.new(
                node_data.pairing_code.encode(), node_data.hwid.encode(), hashlib.sha256
            ).hexdigest()
            if not hmac.compare_digest(expected, node_data.hwid_signature):
                log_audit_event(
                    "SECURITY",
                    f"Invalid HWID Sig for {node_data.node_id}",
                    "NEXUS_GATEWAY",
                    "FAILURE",
                    approved=False,
                )
                raise HTTPException(
                    status_code=403, detail="Invalid Hardware Signature"
                )
        except Exception as e:
            logger.error(f"Sig Verify Error: {e}")
            raise HTTPException(status_code=403, detail="Signature Verification Failed")

    if not validate_pairing_code(node_data.pairing_code):
        raise HTTPException(status_code=403, detail="Invalid or Expired Pairing Code")

    try:
        caps = {
            "client_type": "desktop",
            "contribution": node_data.contribution_mode,
            "hwid": node_data.hwid,  # Bind HWID to capabilities/node
        }

        # 2. ANTI-SPOOFING CHECK
        # Check if node exists and has different HWID
        # (Requires fetching existing node caps)
        # For prototype, we proceed with Overwrite but log the HWID change if suspicious.

        register_node(
            node_data.node_id,
            client_ip,
            node_data.public_key,
            caps,
            shared_key=node_data.fernet_key,
            contribution_mode=node_data.contribution_mode,
        )
        if caps.get("client_type") == "hub_connector":
            log_audit_event(
                "SYSTEM",
                f"New HUB PEER: {node_data.node_id}",
                "NEXUS_GATEWAY",
                "SUCCESS",
                details=f"P2P Link Extablished | HWID: {node_data.hwid}",
                approved=False,
            )
        else:
            log_audit_event(
                "SYSTEM",
                f"New Node Registration: {node_data.node_id}",
                "NEXUS_GATEWAY",
                "SUCCESS",
                details=f"IP: {client_ip} | HWID: {node_data.hwid}",
                approved=False,
            )

        return {"status": "registered", "node_id": node_data.node_id}
    except Exception as e:
        logger.error(f"Registration failed: {e}")
        log_audit_event(
            "SYSTEM",
            f"Registration Failed: {node_data.node_id}",
            "NEXUS_GATEWAY",
            "ERROR",
            details=str(e),
            approved=False,
        )
        raise HTTPException(status_code=500, detail="Registration failed")


@app.post("/send_message")
async def send_message(payload: MessagePayload):
    """
    Routes a message to a specific NodeID.
    If Online: Fire-and-Forget WS Send.
    If Offline: Queue into Database for eventual delivery.
    """
    # Integrity Check (Optional but recommended for large blobs)
    if payload.checksum:
        import hashlib

        # We try to verify the 'encrypted_data' field if it exists, as that's the heavy payload
        encrypted_token = payload.content.get("encrypted_data")
        if encrypted_token:
            # MD5 of the string content
            calc_md5 = hashlib.md5(encrypted_token.encode()).hexdigest()
            if calc_md5 != payload.checksum:
                logger.error(
                    f"Checksum Mismatch! Recv: {payload.checksum}, Calc: {calc_md5}"
                )
                raise HTTPException(status_code=400, detail="Integrity Check Failed")

    if manager.is_online(payload.target_node):
        message_str = json.dumps(payload.content)

        # Fire-and-Forget
        import asyncio

        asyncio.create_task(
            manager.send_personal_message(message_str, payload.target_node)
        )

        return {
            "status": "sent_to_limb_queue",
            "target_node": payload.target_node,
            "detail": "Message active pushed via WS",
        }
    else:
        # Offline Queueing Strategy
        try:
            # We assume sender is "Hub" or extracted from content if needed.
            # payload.content usually has {"cmd":..., "args":...} or {"encrypted_data":...}
            message_str = json.dumps(payload.content)
            sender = "Hub"

            queue_message(payload.target_node, sender, message_str)
            return {
                "status": "queued_for_delivery",
                "target_node": payload.target_node,
                "detail": "Node Offline. Message Queued.",
            }
        except Exception as e:
            logger.error(f"Queue Error: {e}")
            raise HTTPException(status_code=500, detail=f"Failed to queue message: {e}")


@app.get("/check_queue/{node_id}")
async def check_queue(node_id: str):
    """
    Called by Limb on interval. Retrieves pending messages.
    Returns encrypted bundle.
    """
    messages = get_and_clear_queued_messages(node_id)
    if not messages:
        return {"status": "empty", "count": 0}

    # Bundle logic
    # Messages are dicts: {id, sender, content(json_str), timestamp}
    # We want to return a list of contents.
    # CRITICAL: Security. If we return plaintext JSONs, and this is HTTP, it is visible.
    # The requirement says "packages them into a single, encrypted response payload".

    # 1. Get Node Key
    node_key = get_node_key(node_id)
    if not node_key:
        # If no key, we can't secure the bundle.
        # Edge case: If messages are individually encrypted (content={"encrypted_data":...}),
        # we might be safe returning them as list.
        # But generic command structure requires encryption.
        # For safety, we enforce key requirement.
        return {
            "status": "error",
            "detail": "Encryption Key missing on Hub. Cannot secure bundle.",
        }

    try:
        # 2. Prepare Payload
        # We pack the whole list of message contents (which are parsing back to dicts to be clean)
        import json

        clean_msgs = []
        for m in messages:
            try:
                # Check if content is double-encoded
                clean_msgs.append(json.loads(m["content"]))
            except Exception:
                clean_msgs.append(m["content"])

        bundle = {"messages": clean_msgs, "count": len(clean_msgs)}
        bundle_json = json.dumps(bundle)

        # 3. Encrypt Bundle
        cipher = Fernet(node_key.encode())
        encrypted_bundle = cipher.encrypt(bundle_json.encode("utf-8")).decode("utf-8")

        logger.info(f"Delivered {len(clean_msgs)} queued messages to {node_id}")
        return {"status": "success", "encrypted_bundle": encrypted_bundle}

    except Exception as e:
        logger.error(f"Bundle Error for {node_id}: {e}")
        return {"status": "error", "detail": str(e)}


@app.get("/swarm/contributors")
async def swarm_contributors():
    """Returns list of online nodes willing to contribute."""
    try:
        nodes = get_contributors()
        return {"status": "success", "contributors": nodes}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/log_event")
async def log_event_endpoint(event: LogEvent):
    """
    BRIDGE: Allows external services (like Streamlit Hub) to log to Audit DB.
    """
    try:
        log_audit_event(
            user="SYSTEM",
            action=event.action,
            module=event.module,
            status=event.status,
            details=event.details,
            approved=event.approved,
        )
        return {"status": "logged"}
    except Exception as e:
        logger.error(f"Audit Bridge Failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.websocket("/ws/{node_id}")
async def websocket_endpoint(websocket: WebSocket, node_id: str):
    """
    WebSocket endpoint for persistent node connections.
    """
    try:
        # Auto-register logic...
        client_ip = websocket.client.host if websocket.client else "unknown"
        # ... (keep existing registration logic or assume it is done)
        try:
            register_node(node_id, "pending_key", client_ip)
        except Exception:
            pass

        await manager.connect(node_id, websocket)

        try:
            while True:
                data = await websocket.receive_text()
                # Handle incoming messages directly from the node
                logger.debug(f"Received from {node_id}: {data}")

                try:
                    parsed = json.loads(data)
                    msg_type = parsed.get("type")

                    if msg_type == "heartbeat":
                        # Updated Heartbeat with Compute Score
                        score = parsed.get("compute_score")
                        node_id = parsed.get("node_id")
                        update_node_heartbeat(node_id, compute_score=score)
                        continue

                    target = parsed.get("target")  # Where the node wants to send this

                    if target == "hub_vault":
                        # Get sender from "msg" if available
                        inner_msg = parsed.get("msg", {})
                        sender_id = inner_msg.get("sender")
                        encrypted_token = inner_msg.get("encrypted_data")

                        if sender_id and encrypted_token:
                            # 1. Retrieve Secret Key for Sender
                            secret_key = get_node_key(sender_id)
                            if secret_key:
                                try:
                                    # 2. Decrypt
                                    cipher = Fernet(secret_key.encode())
                                    decrypted_data = cipher.decrypt(
                                        encrypted_token.encode()
                                    )
                                    payload = json.loads(decrypted_data.decode("utf-8"))

                                    # 3. Check for File Map (or other commands)
                                    result_data = payload.get("result", {})

                                    # A. FILE MAP SYNC
                                    if (
                                        isinstance(result_data, dict)
                                        and "file_map" in result_data
                                    ):
                                        file_map = result_data["file_map"]
                                        filename = f"project_map_{sender_id}.json"
                                        content = json.dumps(file_map, indent=2)

                                        full_path = os.path.join("vault", filename)
                                        os.makedirs("vault", exist_ok=True)
                                        with open(full_path, "w") as f:
                                            f.write(content)
                                        vault.index_file(filename)
                                        update_node_last_indexed(sender_id)
                                        logger.info(
                                            f"Updated Project Map for {sender_id}"
                                        )

                                    # B. INTER-HUB CODEX SYNC (Phase 9)
                                    if (
                                        isinstance(result_data, dict)
                                        and "codex_sync" in result_data
                                    ):
                                        snippets = result_data["codex_sync"]
                                        # Use Codex Module to Merge
                                        import modules.codex as codex_mod

                                        count = 0
                                        for snip in snippets:
                                            # Save snippet (idemptotent check inside needed ideally)
                                            # Snip: {title, code, tags, language}
                                            codex_mod.codex_system.save_snippet(
                                                snip.get("title", "Remote Snippet"),
                                                snip.get("code", "# No code"),
                                                snip.get("tags", "remote,synced"),
                                                snip.get("language", "text"),
                                            )
                                            count += 1
                                        logger.info(
                                            f"Merged {count} Codex snippets from Hub Peer {sender_id}"
                                        )

                                    # C. LIFE SYNC (Finances/Tasks)
                                    if (
                                        isinstance(result_data, dict)
                                        and "life_sync" in result_data
                                    ):
                                        data = result_data["life_sync"]
                                        # data: {type: 'expense', amount, category, description, timestamp}
                                        if data.get("type") == "expense":
                                            import database

                                            database.add_expense(
                                                data.get("amount"),
                                                data.get("category"),
                                                f"[SYNC:{sender_id}] {data.get('description')}",
                                                data.get("currency", "USD"),
                                            )
                                            logger.info(
                                                f"Synced Expense from {sender_id}: ${data.get('amount')}"
                                            )

                                        log_audit_event(
                                            "NEXUS_P2P",
                                            f"Life Sync: {data.get('type')}",
                                            "SUCCESS",
                                            details=f"From {sender_id}",
                                            approved=True,
                                        )

                                    # D. SOUL SYNC (Respaldo Circular)
                                    if (
                                        isinstance(result_data, dict)
                                        and "soul_sync" in result_data
                                    ):
                                        soul_b64 = result_data["soul_sync"]
                                        from modules.soul_sync import soul_sync as ss

                                        ss.handle_incoming_soul(sender_id, soul_b64)
                                        logger.info(
                                            f"Cross-Backup received from {sender_id}"
                                        )

                                    # E. VISION SYNC (Remote Vision Uplink)
                                    if (
                                        isinstance(result_data, dict)
                                        and "vision_sync" in result_data
                                    ):
                                        import base64

                                        v_data = result_data["vision_sync"]
                                        filename = v_data.get("filename")
                                        b64_content = v_data.get("b64_data")

                                        if filename and b64_content:
                                            root = os.getenv("AEGIS_USER_ROOT", ".")
                                            target_dir = os.path.join(
                                                root, "workspace", "screenshots"
                                            )
                                            os.makedirs(target_dir, exist_ok=True)

                                            safe_sender = sender_id.replace(":", "_")
                                            final_path = os.path.join(
                                                target_dir,
                                                f"remote_{safe_sender}_{filename}",
                                            )

                                            with open(final_path, "wb") as f:
                                                f.write(base64.b64decode(b64_content))

                                            logger.info(
                                                f"👁️ Remote Vision: Received {filename} from {sender_id}"
                                            )

                                except Exception as e:
                                    logger.error(
                                        f"Decryption/Processing failed for {sender_id}: {e}"
                                    )
                            else:
                                logger.warning(
                                    f"No secret key found for {sender_id}, cannot decrypt hub message."
                                )
                        continue  # Processed, move on

                    if target:
                        msg = json.dumps(parsed.get("msg", {}))
                        await manager.send_personal_message(msg, target)
                except json.JSONDecodeError:
                    pass

        except WebSocketDisconnect:
            logger.info(f"WS Disconnect: {node_id}")

    except Exception as e:
        logger.error(f"Critical Error in WS endpoint for {node_id}: {e}")

    finally:
        # Guarantee cleanup
        manager.disconnect(node_id)
        # Run DB update in thread to avoid blocking loop
        # update_node_status(node_id, "offline") # Sync call
        try:
            update_node_status(node_id, "offline")
        except Exception as db_err:
            logger.error(f"Failed to update offline status: {db_err}")


# ---------------------------------------------------------------------------
# OLLAMA REVERSE PROXY
# Intercepts /api/* requests from the IDE (Continue extension) and forwards
# them transparently to the local Ollama instance, enabling auditing.
# ---------------------------------------------------------------------------

OLLAMA_URL = "http://127.0.0.1:11434"


@app.post("/api/{path:path}")
def ollama_proxy(path: str, body: Dict[str, Any]):
    """
    Reverse Proxy para Ollama (síncrono).
    Al ser `def` (no `async def`), FastAPI despacha esta función en un
    thread pool, liberando el Event Loop mientras `requests.post` hace el
    streaming hacia Ollama. El IDE la usa como si fuera Ollama directamente.
    """
    try:
        model = body.get("model", "unknown")

        # Lightweight audit log — only for explicit chat/generate calls
        # to avoid flooding the DB with autocomplete noise.
        if path in ("generate", "chat"):
            logger.info(
                f"[FORGE PROXY] IDE Request → model='{model}' endpoint='/api/{path}'"
            )
            try:
                log_audit_event(
                    "THE_FORGE",
                    f"AI Request: {model} [{path}]",
                    "PROXY",
                    "INFO",
                )
            except Exception:
                pass  # Never block the proxy due to audit failures

        target_url = f"{OLLAMA_URL}/api/{path}"

        def iter_ollama():
            with requests.post(
                target_url,
                json=body,
                stream=True,
                timeout=120,
            ) as resp:
                for chunk in resp.iter_content(chunk_size=1024):
                    if chunk:
                        yield chunk

        return StreamingResponse(iter_ollama(), media_type="application/x-ndjson")

    except Exception as e:
        logger.error(f"[FORGE PROXY] Error proxying /api/{path}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    # Allow running this file directly to start the server
    host = os.getenv("AEGIS_HOST", "0.0.0.0")
    port = int(os.getenv("AEGIS_PORT", 8000))
    ssl_key = os.getenv("AEGIS_SSL_KEYFILE")
    ssl_cert = os.getenv("AEGIS_SSL_CERTFILE")

    if ssl_key and ssl_cert:
        print(f"🔒 Secure Mode Enabled (WSS). Cert: {ssl_cert}")
        # Configure Uvicorn Loggers to use our file/console handlers
        logging.getLogger("uvicorn.access").handlers = logger.handlers
        logging.getLogger("uvicorn.error").handlers = logger.handlers
        uvicorn.run(
            app,
            host=host,
            port=port,
            ssl_keyfile=ssl_key,
            ssl_certfile=ssl_cert,
            log_config=None,
        )
    else:
        print("🔓 Unsecure Mode (WS). Use Nginx or configure SSL for production.")
        # Configure Uvicorn Loggers to use our file/console handlers
        logging.getLogger("uvicorn.access").handlers = logger.handlers
        logging.getLogger("uvicorn.error").handlers = logger.handlers
        uvicorn.run(app, host=host, port=port, log_config=None)
