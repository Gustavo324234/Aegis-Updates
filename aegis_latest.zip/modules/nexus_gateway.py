import sys
import os
import json
import logging
from typing import Optional, Dict

# Add parent directory to path to import database
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

try:
    from database import register_node, update_node_status, get_node_public_key, validate_pairing_code, get_node_key, get_contributors
except ImportError:
    logging.error("Could not import database. Ensure you are running this in the correct environment.")

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Request, HTTPException, Body
from pydantic import BaseModel
import uvicorn
from cryptography.fernet import Fernet
from modules.vault_manager import vault

# Logging Configuration
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("NexusGateway")

app = FastAPI(title="Nexus Gateway", description="Central Nervous System for Networked Devices")

# --- Data Models ---
class NodeRegistration(BaseModel):
    node_id: str
    public_key: str
    fernet_key: Optional[str] = None
    pairing_code: Optional[str] = None
    contribution_mode: bool = False

class MessagePayload(BaseModel):
    target_node: str
    content: dict

# --- Connection Manager ---
class ConnectionManager:
    def __init__(self):
        self.active_connections: Dict[str, WebSocket] = {}

    async def connect(self, node_id: str, websocket: WebSocket):
        await websocket.accept()
        self.active_connections[node_id] = websocket
        logger.info(f"Node connected: {node_id}")

    def disconnect(self, node_id: str):
        if node_id in self.active_connections:
            del self.active_connections[node_id]
        logger.info(f"Node disconnected: {node_id}")

    async def send_personal_message(self, message: str, node_id: str):
        if node_id in self.active_connections:
            try:
                await self.active_connections[node_id].send_text(message)
                return True
            except Exception as e:
                logger.error(f"Failed to send message to {node_id}: {e}")
                return False
        return False

    async def broadcast(self, message: str):
        for node_id, connection in self.active_connections.items():
            try:
                await connection.send_text(message)
            except Exception as e:
                logger.error(f"Failed to broadcast to {node_id}: {e}")

    def is_online(self, node_id: str) -> bool:
        return node_id in self.active_connections

manager = ConnectionManager()

# --- API Endpoints ---

@app.get("/")
async def root():
    return {"status": "Nexus Gateway Operational", "active_nodes": len(manager.active_connections)}

@app.post("/register")
async def register(request: Request, node_data: NodeRegistration):
    """
    Registers a device with NodeID and Public Key.
    """
    client_ip = request.client.host
    logger.info(f"Registering node {node_data.node_id} from {client_ip}")
    
    # PAIRING VALIDATION
    if not node_data.pairing_code:
        raise HTTPException(status_code=403, detail="Pairing Code Required")
    
    if not validate_pairing_code(node_data.pairing_code):
        raise HTTPException(status_code=403, detail="Invalid or Expired Pairing Code")

    try:
        register_node(node_data.node_id, node_data.public_key, client_ip, node_data.fernet_key, contribution_mode=node_data.contribution_mode)
        return {"status": "registered", "node_id": node_data.node_id}
    except Exception as e:
        logger.error(f"Registration failed: {e}")
        raise HTTPException(status_code=500, detail="Registration failed")

@app.post("/send_message")
async def send_message(payload: MessagePayload):
    """
    Routes a message to a specific NodeID if online.
    """
    if manager.is_online(payload.target_node):
        message_str = json.dumps(payload.content)
        success = await manager.send_personal_message(message_str, payload.target_node)
        if success:
            return {"status": "delivered", "node_id": payload.target_node}
        else:
            raise HTTPException(status_code=500, detail="Delivery failed")
    else:
        # TODO: Here we could queue the message in DB if offline delivery is needed later.
        # For now, based on "entregarlo instantáneamente si el nodo está online", 
        # we return an error or status indicating offline.
        return {"status": "queued_or_offline", "detail": "Node is not currently connected via WebSocket"}

@app.get("/swarm/contributors")
async def swarm_contributors():
    """Returns list of online nodes willing to contribute."""
    try:
        nodes = get_contributors()
        return {"status": "success", "contributors": nodes}
    except Exception as e:
         raise HTTPException(status_code=500, detail=str(e))

@app.websocket("/ws/{node_id}")
async def websocket_endpoint(websocket: WebSocket, node_id: str):
    """
    WebSocket endpoint for persistent node connections.
    """
    try:
        # Auto-register logic...
        client_ip = websocket.client.host if websocket.client else "unknown"
        # ... (keep existing registration logic or assume it is done)
        try:
             register_node(node_id, "pending_key", client_ip)
        except Exception:
             pass

        await manager.connect(node_id, websocket)
        
        try:
            while True:
                data = await websocket.receive_text()
                # Handle incoming messages directly from the node
                logger.debug(f"Received from {node_id}: {data}")
                
                try:
                    parsed = json.loads(data)
                    target = parsed.get("target") # Where the node wants to send this
                    
                    if target == "hub_vault":
                         # Get sender from "msg" if available
                         inner_msg = parsed.get("msg", {})
                         sender_id = inner_msg.get("sender")
                         encrypted_token = inner_msg.get("encrypted_data")
                         
                         if sender_id and encrypted_token:
                             # 1. Retrieve Secret Key for Sender
                             secret_key = get_node_key(sender_id)
                             if secret_key:
                                 try:
                                     # 2. Decrypt
                                     cipher = Fernet(secret_key.encode())
                                     decrypted_data = cipher.decrypt(encrypted_token.encode())
                                     payload = json.loads(decrypted_data.decode('utf-8'))
                                     
                                     # 3. Check for File Map (or other commands)
                                     if "file_map" in payload.get("result", {}):
                                         file_map = payload["result"]["file_map"]
                                         # Save Map
                                         filename = f"project_map_{sender_id}.json"
                                         content = json.dumps(file_map, indent=2)
                                         
                                         # Write to Vaul via Manager (indexes automatically)
                                         full_path = os.path.join("vault", filename)
                                         with open(full_path, 'w') as f:
                                             f.write(content)
                                             
                                         vault.index_file(filename)
                                         logger.info(f"Updated Project Map for {sender_id}")
                                         
                                 except Exception as e:
                                     logger.error(f"Decryption/Processing failed for {sender_id}: {e}")
                             else:
                                 logger.warning(f"No secret key found for {sender_id}, cannot decrypt hub message.")
                         pass

                    if target:
                         msg = json.dumps(parsed.get("msg", {}))
                         await manager.send_personal_message(msg, target)
                except json.JSONDecodeError:
                    pass 

        except WebSocketDisconnect:
            logger.info(f"WS Disconnect: {node_id}")
            
    except Exception as e:
        logger.error(f"Critical Error in WS endpoint for {node_id}: {e}")
        
    finally:
        # Guarantee cleanup
        manager.disconnect(node_id)
        # Run DB update in thread to avoid blocking loop
        # update_node_status(node_id, "offline") # Sync call
        try:
            update_node_status(node_id, "offline")
        except Exception as db_err:
            logger.error(f"Failed to update offline status: {db_err}")

if __name__ == "__main__":
    # Allow running this file directly to start the server
    host = os.getenv("AEGIS_HOST", "0.0.0.0")
    port = int(os.getenv("AEGIS_PORT", 8000))
    ssl_key = os.getenv("AEGIS_SSL_KEYFILE")
    ssl_cert = os.getenv("AEGIS_SSL_CERTFILE")

    if ssl_key and ssl_cert:
        print(f"🔒 Secure Mode Enabled (WSS). Cert: {ssl_cert}")
        uvicorn.run(app, host=host, port=port, ssl_keyfile=ssl_key, ssl_certfile=ssl_cert)
    else:
        print("🔓 Unsecure Mode (WS). Use Nginx or configure SSL for production.")
        uvicorn.run(app, host=host, port=port)
