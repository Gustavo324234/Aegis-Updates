import sys
import os
import json
import logging
from typing import Optional, Dict

# 1. PATH CONFIGURATION: Allow importing modules from root
# This is critical because this script lives in modules/ but depends on root files
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.abspath(os.path.join(current_dir, '..'))
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

try:
    from database import (register_node, update_node_status, get_node_key, 
                          validate_pairing_code, get_contributors, 
                          queue_message, get_and_clear_queued_messages, 
                          update_node_last_indexed, log_audit_event)
except ImportError as e:
    # Fallback to prevent silent failures in logs
    logging.error(f"CRITICAL IMPORT ERROR in Nexus Gateway: {e}")
    logging.error(f"Current Sys Path: {sys.path}")
    raise e

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Request, HTTPException, Body
from pydantic import BaseModel
import uvicorn
from cryptography.fernet import Fernet
from modules.vault_manager import vault

# Logging Configuration
# Use FileHandler to ensure logs are saved even if console detaches
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("gateway.log"),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger("NexusGateway")

app = FastAPI(title="Nexus Gateway", description="Central Nervous System for Networked Devices")

# --- Data Models ---
class NodeRegistration(BaseModel):
    node_id: str
    public_key: str
    fernet_key: Optional[str] = None
    pairing_code: Optional[str] = None
    contribution_mode: bool = False

class MessagePayload(BaseModel):
    target_node: str
    content: dict

class LogEvent(BaseModel):
    module: str
    action: str
    status: str
    approved: bool = False
    details: Optional[str] = None

# --- Connection Manager ---
class ConnectionManager:
    def __init__(self):
        self.active_connections: Dict[str, WebSocket] = {}


    async def connect(self, node_id: str, websocket: WebSocket):
        await websocket.accept()
        self.active_connections[node_id] = websocket
        logger.info(f"Node connected: {node_id}")
        log_audit_event("SYSTEM", f"Node Connected: {node_id}", "NEXUS_GATEWAY", "INFO", approved=False)

    def disconnect(self, node_id: str):
        if node_id in self.active_connections:
            del self.active_connections[node_id]
        logger.info(f"Node disconnected: {node_id}")
        log_audit_event("SYSTEM", f"Node Disconnected: {node_id}", "NEXUS_GATEWAY", "WARNING", approved=False)

    async def send_personal_message(self, message: str, node_id: str):
        if node_id in self.active_connections:
            try:
                await self.active_connections[node_id].send_text(message)
                return True
            except Exception as e:
                logger.error(f"Failed to send message to {node_id}: {e}")
                return False
        return False

    async def broadcast(self, message: str):
        for node_id, connection in self.active_connections.items():
            try:
                await connection.send_text(message)
            except Exception as e:
                logger.error(f"Failed to broadcast to {node_id}: {e}")

    def is_online(self, node_id: str) -> bool:
        return node_id in self.active_connections

manager = ConnectionManager()

# --- API Endpoints ---

@app.get("/")
async def root():
    return {"status": "Nexus Gateway Operational", "active_nodes": len(manager.active_connections)}

@app.post("/register")
async def register(request: Request, node_data: NodeRegistration):
    """
    Registers a device with NodeID and Public Key.
    """
    client_ip = request.client.host
    logger.info(f"Registering node {node_data.node_id} from {client_ip}")
    
    # PAIRING VALIDATION
    if not node_data.pairing_code:
        raise HTTPException(status_code=403, detail="Pairing Code Required")
    
    if not validate_pairing_code(node_data.pairing_code):
        raise HTTPException(status_code=403, detail="Invalid or Expired Pairing Code")

    try:
        register_node(node_data.node_id, node_data.public_key, client_ip, node_data.fernet_key, contribution_mode=node_data.contribution_mode)
        log_audit_event("SYSTEM", f"New Node Registration: {node_data.node_id}", "NEXUS_GATEWAY", "SUCCESS", details=f"IP: {client_ip}", approved=False)
        return {"status": "registered", "node_id": node_data.node_id}
    except Exception as e:
        logger.error(f"Registration failed: {e}")
        log_audit_event("SYSTEM", f"Registration Failed: {node_data.node_id}", "NEXUS_GATEWAY", "ERROR", details=str(e), approved=False)
        raise HTTPException(status_code=500, detail="Registration failed")

@app.post("/send_message")
async def send_message(payload: MessagePayload):
    """
    Routes a message to a specific NodeID.
    If Online: Fire-and-Forget WS Send.
    If Offline: Queue into Database for eventual delivery.
    """
    if manager.is_online(payload.target_node):
        message_str = json.dumps(payload.content)
        
        # Fire-and-Forget
        import asyncio
        asyncio.create_task(manager.send_personal_message(message_str, payload.target_node))
        
        return {"status": "sent_to_limb_queue", "target_node": payload.target_node, "detail": "Message active pushed via WS"}
    else:
        # Offline Queueing Strategy
        try:
            # We assume sender is "Hub" or extracted from content if needed.
            # payload.content usually has {"cmd":..., "args":...} or {"encrypted_data":...}
            message_str = json.dumps(payload.content)
            sender = "Hub" 
            
            queue_message(payload.target_node, sender, message_str)
            return {"status": "queued_for_delivery", "target_node": payload.target_node, "detail": "Node Offline. Message Queued."}
        except Exception as e:
            logger.error(f"Queue Error: {e}")
            raise HTTPException(status_code=500, detail=f"Failed to queue message: {e}")

@app.get("/check_queue/{node_id}")
async def check_queue(node_id: str):
    """
    Called by Limb on interval. Retrieves pending messages.
    Returns encrypted bundle.
    """
    messages = get_and_clear_queued_messages(node_id)
    if not messages:
        return {"status": "empty", "count": 0}
        
    # Bundle logic
    # Messages are dicts: {id, sender, content(json_str), timestamp}
    # We want to return a list of contents.
    # CRITICAL: Security. If we return plaintext JSONs, and this is HTTP, it is visible.
    # The requirement says "packages them into a single, encrypted response payload".
    
    # 1. Get Node Key
    node_key = get_node_key(node_id)
    if not node_key:
         # If no key, we can't secure the bundle. 
         # Edge case: If messages are individually encrypted (content={"encrypted_data":...}), 
         # we might be safe returning them as list. 
         # But generic command structure requires encryption.
         # For safety, we enforce key requirement.
         return {"status": "error", "detail": "Encryption Key missing on Hub. Cannot secure bundle."}
         
    try:
        # 2. Prepare Payload
        # We pack the whole list of message contents (which are parsing back to dicts to be clean)
        import json
        clean_msgs = []
        for m in messages:
             try:
                 # Check if content is double-encoded
                 clean_msgs.append(json.loads(m['content']))
             except:
                 clean_msgs.append(m['content'])
                 
        bundle = {"messages": clean_msgs, "count": len(clean_msgs)}
        bundle_json = json.dumps(bundle)
        
        # 3. Encrypt Bundle
        cipher = Fernet(node_key.encode())
        encrypted_bundle = cipher.encrypt(bundle_json.encode('utf-8')).decode('utf-8')
        
        logger.info(f"Delivered {len(clean_msgs)} queued messages to {node_id}")
        return {"status": "success", "encrypted_bundle": encrypted_bundle}
        
    except Exception as e:
        logger.error(f"Bundle Error for {node_id}: {e}")
        return {"status": "error", "detail": str(e)}

@app.get("/swarm/contributors")
async def swarm_contributors():
    """Returns list of online nodes willing to contribute."""
    try:
        nodes = get_contributors()
        return {"status": "success", "contributors": nodes}
    except Exception as e:
         raise HTTPException(status_code=500, detail=str(e))

@app.post("/log_event")
async def log_event_endpoint(event: LogEvent):
    """
    BRIDGE: Allows external services (like Streamlit Hub) to log to Audit DB.
    """
    try:
        log_audit_event(
            user="SYSTEM",
            action=event.action,
            module=event.module,
            status=event.status,
            details=event.details,
            approved=event.approved
        )
        return {"status": "logged"}
    except Exception as e:
        logger.error(f"Audit Bridge Failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.websocket("/ws/{node_id}")
async def websocket_endpoint(websocket: WebSocket, node_id: str):
    """
    WebSocket endpoint for persistent node connections.
    """
    try:
        # Auto-register logic...
        client_ip = websocket.client.host if websocket.client else "unknown"
        # ... (keep existing registration logic or assume it is done)
        try:
             register_node(node_id, "pending_key", client_ip)
        except Exception:
             pass

        await manager.connect(node_id, websocket)
        
        try:
            while True:
                data = await websocket.receive_text()
                # Handle incoming messages directly from the node
                logger.debug(f"Received from {node_id}: {data}")
                
                try:
                    parsed = json.loads(data)
                    target = parsed.get("target") # Where the node wants to send this
                    
                    if target == "hub_vault":
                         # Get sender from "msg" if available
                         inner_msg = parsed.get("msg", {})
                         sender_id = inner_msg.get("sender")
                         encrypted_token = inner_msg.get("encrypted_data")
                         
                         if sender_id and encrypted_token:
                             # 1. Retrieve Secret Key for Sender
                             secret_key = get_node_key(sender_id)
                             if secret_key:
                                 try:
                                     # 2. Decrypt
                                     cipher = Fernet(secret_key.encode())
                                     decrypted_data = cipher.decrypt(encrypted_token.encode())
                                     payload = json.loads(decrypted_data.decode('utf-8'))
                                     
                                     # 3. Check for File Map (or other commands)
                                     result_data = payload.get("result", {})
                                     if isinstance(result_data, dict) and "file_map" in result_data:
                                         file_map = result_data["file_map"]
                                         # Save Map
                                         filename = f"project_map_{sender_id}.json"
                                         content = json.dumps(file_map, indent=2)
                                         
                                         # Write to Vault via Manager (indexes automatically)
                                         full_path = os.path.join("vault", filename)
                                         # Ensure dir exists
                                         os.makedirs("vault", exist_ok=True)
                                         
                                         with open(full_path, 'w') as f:
                                             f.write(content)
                                             
                                         vault.index_file(filename)
                                         update_node_last_indexed(sender_id)
                                         logger.info(f"Updated Project Map for {sender_id}")
                                         
                                 except Exception as e:
                                     logger.error(f"Decryption/Processing failed for {sender_id}: {e}")
                             else:
                                 logger.warning(f"No secret key found for {sender_id}, cannot decrypt hub message.")
                         continue # Processed, move on

                    if target:
                         msg = json.dumps(parsed.get("msg", {}))
                         await manager.send_personal_message(msg, target)
                except json.JSONDecodeError:
                    pass 

        except WebSocketDisconnect:
            logger.info(f"WS Disconnect: {node_id}")
            
    except Exception as e:
        logger.error(f"Critical Error in WS endpoint for {node_id}: {e}")
        
    finally:
        # Guarantee cleanup
        manager.disconnect(node_id)
        # Run DB update in thread to avoid blocking loop
        # update_node_status(node_id, "offline") # Sync call
        try:
            update_node_status(node_id, "offline")
        except Exception as db_err:
            logger.error(f"Failed to update offline status: {db_err}")

if __name__ == "__main__":
    # Allow running this file directly to start the server
    host = os.getenv("AEGIS_HOST", "0.0.0.0")
    port = int(os.getenv("AEGIS_PORT", 8000))
    ssl_key = os.getenv("AEGIS_SSL_KEYFILE")
    ssl_cert = os.getenv("AEGIS_SSL_CERTFILE")

    if ssl_key and ssl_cert:
        print(f"🔒 Secure Mode Enabled (WSS). Cert: {ssl_cert}")
        # Configure Uvicorn Loggers to use our file/console handlers
        logging.getLogger("uvicorn.access").handlers = logger.handlers
        logging.getLogger("uvicorn.error").handlers = logger.handlers
        uvicorn.run(app, host=host, port=port, ssl_keyfile=ssl_key, ssl_certfile=ssl_cert, log_config=None)
    else:
        print("🔓 Unsecure Mode (WS). Use Nginx or configure SSL for production.")
        # Configure Uvicorn Loggers to use our file/console handlers
        logging.getLogger("uvicorn.access").handlers = logger.handlers
        logging.getLogger("uvicorn.error").handlers = logger.handlers
        uvicorn.run(app, host=host, port=port, log_config=None)
