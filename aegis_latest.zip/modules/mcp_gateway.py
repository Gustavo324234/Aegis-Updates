import os
import sys
import json
import asyncio
import traceback
from typing import Any

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from mcp.server import Server, NotificationOptions
from mcp.server.models import InitializationOptions
from mcp.server.sse import SseServerTransport
import mcp.types as types

# Configuración de PATH para Aegis
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if PROJECT_ROOT not in sys.path:
    sys.path.append(PROJECT_ROOT)

# Imports de Aegis
import database
from modules.system_tools import execute_command
from modules.file_writer import write_file
from modules.resource_monitor import monitor

# Inicialización de FastAPI
app = FastAPI(title="Aegis-IA MCP Gateway (SSE)")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Inicialización del Servidor MCP
mcp_server = Server("aegis-mcp-lan")

# --- DEFINICIÓN DE HERRAMIENTAS (REUTILIZADAS) ---


@mcp_server.list_tools()
async def handle_list_tools() -> list[types.Tool]:
    return [
        types.Tool(
            name="read_aegis_file",
            description="Lee el contenido de cualquier archivo del proyecto. Requiere ruta relativa.",
            inputSchema={
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Ruta relativa del archivo.",
                    }
                },
                "required": ["path"],
            },
        ),
        types.Tool(
            name="write_aegis_code",
            description="Modifica o crea archivos en la estructura de Aegis de forma segura.",
            inputSchema={
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Ruta relativa."},
                    "content": {
                        "type": "string",
                        "description": "Contenido del archivo.",
                    },
                },
                "required": ["path", "content"],
            },
        ),
        types.Tool(
            name="execute_aegis_terminal",
            description="Ejecuta comandos en la terminal de Aegis (Docker Sandbox si está activo).",
            inputSchema={
                "type": "object",
                "properties": {
                    "command": {"type": "string", "description": "Comando a ejecutar."}
                },
                "required": ["command"],
            },
        ),
        types.Tool(
            name="query_aegis_memory",
            description="Ejecuta SQL directo sobre aegis_memory.db.",
            inputSchema={
                "type": "object",
                "properties": {
                    "sql_query": {"type": "string", "description": "Consulta SQLite."}
                },
                "required": ["sql_query"],
            },
        ),
        types.Tool(
            name="get_system_status",
            description="Métricas de hardware y estado del servidor central.",
            inputSchema={"type": "object", "properties": {}},
        ),
    ]


@mcp_server.call_tool()
async def handle_call_tool(
    name: str, arguments: dict | None
) -> list[types.TextContent]:
    if not arguments:
        arguments = {}
    user_agent = "REMOTE_MCP_AGENT"
    try:
        if name == "read_aegis_file":
            path = arguments.get("path")
            abs_path = os.path.normpath(os.path.join(PROJECT_ROOT, path))
            if not abs_path.startswith(PROJECT_ROOT) or not os.path.exists(abs_path):
                database.log_audit_event(
                    "mcp_gateway",
                    name,
                    "DENIED",
                    details=f"Path: {path}",
                    user=user_agent,
                )
                return [
                    types.TextContent(
                        type="text", text="Error: Ruta inválida o fuera del alcance."
                    )
                ]
            database.log_audit_event(
                "mcp_gateway", name, "SUCCESS", details=f"Path: {path}", user=user_agent
            )
            with open(abs_path, "r", encoding="utf-8") as f:
                return [types.TextContent(type="text", text=f.read())]

        elif name == "write_aegis_code":
            path = arguments.get("path")
            result = write_file(path, arguments.get("content"))
            status = "SUCCESS" if "Successfully" in result else "FAILED"
            database.log_audit_event(
                "mcp_gateway",
                name,
                status,
                details=f"File: {path} | Result: {result}",
                user=user_agent,
                approved=True,
            )
            return [types.TextContent(type="text", text=result)]

        elif name == "execute_aegis_terminal":
            command = arguments.get("command")
            database.log_audit_event(
                "mcp_gateway",
                name,
                "EXECUTING",
                details=f"Cmd: {command}",
                user=user_agent,
                approved=True,
            )
            loop = asyncio.get_event_loop()
            result = await loop.run_in_executor(None, execute_command, command)
            return [types.TextContent(type="text", text=str(result))]

        elif name == "query_aegis_memory":
            sql = arguments.get("sql_query")
            database.log_audit_event(
                "mcp_gateway", name, "QUERY", details=f"SQL: {sql}", user=user_agent
            )
            conn = database.get_connection()
            try:
                cursor = conn.cursor()
                cursor.execute(sql)
                if sql.strip().upper().startswith("SELECT"):
                    columns = [c[0] for c in cursor.description]
                    res = [dict(zip(columns, r)) for r in cursor.fetchall()]
                    return [
                        types.TextContent(
                            type="text",
                            text=json.dumps(res, indent=2, ensure_ascii=False),
                        )
                    ]
                conn.commit()
                return [
                    types.TextContent(
                        type="text", text=f"OK. Rowcount: {cursor.rowcount}"
                    )
                ]
            finally:
                conn.close()

        elif name == "get_system_status":
            metrics = monitor.get_metrics()
            t_id, t_name, _, _ = monitor.get_hardware_tier()
            report = {
                "metrics": metrics,
                "tier": t_name,
                "status": "CENTRAL_NODE_ONLINE",
            }
            return [
                types.TextContent(
                    type="text", text=json.dumps(report, indent=2, ensure_ascii=False)
                )
            ]

        return [types.TextContent(type="text", text=f"Error: Tool '{name}' not found.")]
    except Exception as e:
        database.log_audit_event(
            "mcp_gateway", name, "EXCEPTION", details=str(e), user=user_agent
        )
        return [types.TextContent(type="text", text=f"Exception: {str(e)}")]


# --- CONFIGURACIÓN DE TRANSPORTE SSE ---

sse_transport = SseServerTransport("/mcp/messages")


@app.get("/mcp/sse")
async def sse_endpoint(request: Request):
    """Endpoint que inicia la conexión SSE."""
    async with sse_transport.connect_sse(
        request.scope, request.receive, request._send
    ) as sse:
        await mcp_server.run(
            sse[0],
            sse[1],
            InitializationOptions(
                server_name="aegis-mcp-gateway",
                server_version="1.0.0",
                capabilities=mcp_server.get_capabilities(
                    notification_options=NotificationOptions(),
                    experimental_capabilities={},
                ),
            ),
            raise_exceptions=True,
        )


@app.post("/mcp/messages")
async def messages_endpoint(request: Request):
    """Endpoint que recibe mensajes POST del cliente MCP."""
    await sse_transport.handle_post_message(
        request.scope, request.receive, request._send
    )


if __name__ == "__main__":
    import uvicorn

    # Escuchamos en 0.0.0.0 para acceso LAN en puerto 7000
    uvicorn.run(app, host="0.0.0.0", port=7000)
