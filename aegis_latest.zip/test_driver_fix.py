import unittest
from core_engine import llm_drivers


class TestLLMDrivers(unittest.TestCase):
    def test_serialize_history_2_tuple(self):
        history = [("user", "hello"), ("assistant", "hi")]
        result = llm_drivers._serialize_history(history)
        expected = "User: hello\nAssistant: hi\n"
        self.assertEqual(result, expected)

    def test_serialize_history_3_tuple(self):
        history = [("user", "hello", "timestamp"), ("assistant", "hi", "timestamp")]
        result = llm_drivers._serialize_history(history)
        expected = "User: hello\nAssistant: hi\n"
        self.assertEqual(result, expected)


if __name__ == "__main__":
    unittest.main()
