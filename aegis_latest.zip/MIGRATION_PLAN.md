# Plan de Migración a Arquitectura Headless (FastAPI + React/Vite)

## 1. Visión General de la Migración
El objetivo principal es desacoplar el frontend monolítico de Streamlit (`app_web.py` y `ui/chat_manager.py`) transformando **Aegis-IA** en un backend Headless (`server_aegis.py`) con un **Action Loop** asíncrono, y un cliente ligero (Thin Client) implementado en tecnologías web modernas (por ejemplo, React o Vite).

---

## 2. Refactorización de `ui/chat_manager.py` (De UI Monolítico a Cliente/Servidor)

El archivo `ui/chat_manager.py` actualmente mezcla tres responsabilidades principales que ahora se dividen:

### A. Lógica trasladada al Servidor (`server_aegis.py`)
1. **El bucle de ejecución de Herramientas (Action Loop):**
   - **Antes:** Cuando `Brain` emitía un bloque JSON de formato `<tool_call>`, `chat_manager` lo parseaba y bloqueaba la UI principal invocando `module_manager.execute_module()`.
   - **Ahora:** El servidor recibe el `yield` de la herramienta. Escribe un registro de estado "Pending" en la nueva tabla `action_queue` (SQLite). Si la herramienta está en `SELF_MANAGED_MODULES`, ejecuta la tarea asíncronamente en un bloque de ejecución en segundo plano (`asyncio.run_in_executor`) y notifica el resultado como `"tool_result"` por WebSocket.
2. **Generación del Briefing (Genesis & Morning Protocol):**
   - **Antes:** Se calculaba el lapso de inactividad de la sesión directamente en Streamlit (usando `st.session_state`).
   - **Ahora:** Es el backend el que, mediante un endpoint REST de inicialización o un evento inicial de configuración del WebSocket, valida las últimas marcas de tiempo en la base de datos y manda proactivamente el `morning_briefing`.
3. **Gestor de Artefactos / Lógica de Hilo (Thread Tagging):**
   - **Antes:** La visualización y el filtrado por tags se hacía manipulando el componente de la UI.
   - **Ahora:** El servidor expone las funciones CRUD de `database.get_history(...)` a través del punto de entrada FastAPI (Endpoints `/api/v1/chat/history`).

### B. Funciones retenidas para el Thin Client (Futuro Frontend Vite/React)
Las siguientes piezas visuales se rescatan como Componentes React (`.jsx` o `.tsx`):
1. **El Neural Orb (Modo Zen):** Todo el layout de animaciones CSS se trasladará probablemente a un componente de Tailwind/Framer Motion.
2. **Manejo de la Conexión por WebSockets:** Un `useEffect` en el cliente montará el canal `/ws/chat/session_id` que recibirá los flujos en vivo. El Frontend mutará el estado cuando el servidor envíe `{"type": "status", "msg": "..."}`.
3. **Representación de Cargas Pendientes:** Al conectar, el cliente leerá del backend los items marcados como "Pending" y renderizará un `Spinner` de fondo (ej.: "⚙️ Executing life_manager").

---

## 3. Estructura de Carpetas Objetivo (Fase 4 - Desacoplado)

```text
Aegis-IA/
├── backend/                  <-- NUEVO ROOT PARA PYTHON
│   ├── server_aegis.py       <-- Nuevo Punto de Entrada Principal (FastAPI)
│   ├── core_engine/          <-- Lógica LLM, Prompting y Router
│   ├── modules/              <-- Herramientas de Sistema (SELF_MANAGED y Externas)
│   ├── services/
│   │   ├── db/               <-- SQLite (schema.py expandido con action_queue)
│   │   └── api/              <-- Rutas REST tradicionales (auth, metrics)
│   └── websockets/           <-- (Opcional) Gestores avanzados de conexión WS
│
├── frontend/                 <-- NUEVO ROOT PARA UI (Thin Client React/Vite)
│   ├── package.json
│   ├── src/
│   │   ├── components/
│   │   │   ├── chat/         <-- Reemplaza logicamente a chat_manager.py
│   │   │   ├── ui/           <-- Botones, contenedores
│   │   │   └── NeuralOrb/    <-- Reemplaza a 'zen_mode'
│   │   ├── hooks/
│   │   │   └── useAegisSocket.ts <-- Reemplaza la sesión de estado en Streamlit
│   │   └── views/
│   │       ├── MainConsole.tsx
│   │       └── NeuralMap.tsx     <-- Grafo D3/VisJS
│
└── tests/                    <-- Manteniendo cobertura
```

## 4. Próximos Pasos (Hoja de Ruta de Acción)
1. **Validar Resistencia WebSocket:** Probar `server_aegis.py` con un script Python o Postman desconectando la sesión para verificar la recuperación de los eventos `Pending` del `action_queue`.
2. **Scaffold del Frontend:** Usar `npx create-vite@latest frontend --template react-ts`.
3. **Retirar Dependencia Streamlit:** Gradualmente desmantelar `app_web.py` o aislar las dependencias en una rama legacy para prevenir sobrecarga de dependencias.
