# 🤖 AGENTS.md - Protocolo de Instrucciones para Agentes IA

Este archivo contiene el contexto crítico, las reglas de diseño y los protocolos operativos para cualquier inteligencia artificial (nativa o externa via MCP) que interactúe con el ecosistema **Aegis-IA**.

---

## 🏗️ 1. Arquitectura y Roles
Aegis-IA es un sistema de orquestación multi-tenant diseñado para la soberanía digital operando bajo un modelo de **Enrutamiento Estricto**:
- **Master Node (Puerto 8000)**: Rol `master`. Acceso exclusivo al `AdminPanelView`. Gestión de usuarios (Tenants) y configuraciones globales. El Onboarding aquí define la contraseña de Admin.
- **Tenant Node (Puertos 8001+)**: Rol `tenant`. Acceso exclusivo al `ChatView`. El Onboarding es individual para cada usuario. Heredan modelos de IA del Master.
- **Base de Datos**: SQLite con soporte para grafo de conocimiento semántico. Los tenants tienen sus propias DBs en sus carpetas de usuario.

## 🛠️ 2. Tooling y Capacidades
- **`remote_management/`**: Carpeta (ignorada por git) que contiene scripts de orquestación remota (`ssh_*.py`).
  - **Protocolo de Sincronización**: Al modificar código local, se debe usar `ssh_sync_restart.py` para replicar los cambios en el servidor productivo (192.168.1.9).
- **`system_tools`**: Ejecución de comandos terminales (con timeout y auto-detach).
- **`mcp_gateway`**: Puerto 7000 (SSE). Puente para agentes externos.
- **`resource_monitor`**: Vigilancia de RAM/CPU y gestión de Tiers de hardware.

## 🔄 3. Protocolo de Sincronización Dual
Cualquier cambio en la lógica del **Núcleo** (`server_aegis.py`) o la **UI** (`ui_client/`) debe aplicarse siguiendo este orden:
1. Modificar archivo local.
2. Probar en entorno local si es posible.
3. Ejecutar script de sincronización SSH para actualizar la instancia en el servidor remoto.
4. Reiniciar servicios vía systemd (`aegis-core.service`) o watchdog.

## 🎨 4. Estándares de Diseño (The Aegis Look)
Cualquier componente UI generado debe seguir estrictamente estos principios:
- **Estética**: Cyber-Punk moderno, Dark Mode profundo.
- **Efectos**: Glassmorphism (`glass-panel`), gradientes de neón (`neon-text`), micro-animaciones.
- **Colores**:
  - `aegis-cyan`: `#00f3ff` (Acción/Información)
  - `aegis-purple`: `#bc13fe` (Sistema/IA)
  - `aegis-red`: `#ff003c` (Peligro/Crítico)
- **Framework**: Tailwind CSS preferido.

## 🔒 5. Protocolos de Seguridad
- **Workspace Isolation**: No operar fuera del directorio definido en `SAFE_ROOT`.
- **Remote Access**: Las credenciales SSH están en los scripts de `remote_management/`. Usar con discreción y NUNCA exponer en logs públicos.
- **Sensitive Files**: NUNCA modificar o exponer:
  - `secrets.json`, `.env`, `master_key.key`, `aegis_memory.db` (Master).
- **Auditoría**: Todas las acciones críticas deben registrarse usando `database.log_audit_event`.

## 📝 6. Instrucciones de Programación
- **Python**: Seguir PEP8, usar `try-except` robustos y registrar errores en `logs/`.
- **React**: Usar Zustand para el estado global y Lucide-React para iconos.
- **Conectividad**: Los servicios internos deben ser monitorizados por el `Watchdog`.
- **Persistencia**: Preferir `systemd` para servicios en Linux y el `Watchdog` para supervisión de scripts.

---

*Nota para Agentes: Este entorno es SOBERANO. Si el puente MCP cae, usa los scripts en `remote_management/` para re-establecer el enlace.*
