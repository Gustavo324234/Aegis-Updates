# 🤖 AGENTS.md - Protocolo de Instrucciones para Agentes IA

Este archivo contiene el contexto crítico, las reglas de diseño y los protocolos operativos para cualquier inteligencia artificial (nativa o externa via MCP) que interactúe con el ecosistema **Aegis-IA**.

---

## 🏗️ 1. Arquitectura del Sistema
Aegis-IA es un sistema de orquestación multi-tenant diseñado para la soberanía digital.
- **Núcleo**: Python (FastAPI / Uvicorn).
- **Frontend**: React + Vite + Tailwind CSS (Estética Cyber-Dark / Glassmorphism).
- **Base de Datos**: SQLite (`aegis_memory.db`) con soporte para grafo de conocimiento semántico.
- **Aislamiento**: Docker Sandbox para ejecución de código y aislamiento de rutas vía `AEGIS_USER_ROOT`.

## 🛠️ 2. Tooling y Capacidades
Los agentes tienen acceso a un ecosistema de herramientas modulares:
- **`system_tools`**: Ejecución de comandos terminales (con timeout y auto-detach).
- **`file_writer`**: Gestión de archivos con validación de seguridad.
- **`mcp_gateway`**: Punto de entrada remoto (puerto 7000) vía Protocolo SSE.
- **`resource_monitor`**: Vigilancia de RAM/CPU y gestión de Tiers de hardware.

## 🎨 3. Estándares de Diseño (The Aegis Look)
Cualquier componente UI generado debe seguir estrictamente estos principios:
- **Estética**: Cyber-Punk moderno, Dark Mode profundo.
- **Efectos**: Glassmorphism (`glass-panel`), gradientes de neón (`neon-text`), micro-animaciones.
- **Colores**:
  - `aegis-cyan`: `#00f3ff` (Acción/Información)
  - `aegis-purple`: `#bc13fe` (Sistema/IA)
  - `aegis-red`: `#ff003c` (Peligro/Crítico)
- **Framework**: Tailwind CSS preferido.

## 🔒 4. Protocolos de Seguridad
- **Workspace Isolation**: No operar fuera del directorio definido en `SAFE_ROOT`.
- **Sensitive Files**: NUNCA modificar o exponer:
  - `secrets.json`, `.env`, `master_key.key`, `aegis_memory.db`.
- **Auditoría**: Todas las acciones críticas deben registrarse usando `database.log_audit_event`.

## 📝 5. Instrucciones de Programación
- **Python**: Seguir PEP8, usar `try-except` robustos y registrar errores en `logs/`.
- **React**: Usar Zustand para el estado global y Lucide-React para iconos.
- **Conectividad**: Los servicios internos deben ser monitorizados por el `Watchdog`.

---

*Nota para Agentes: Lee este archivo al inicio de tu sesión para sincronizarte con el estado actual del Nexo.*
