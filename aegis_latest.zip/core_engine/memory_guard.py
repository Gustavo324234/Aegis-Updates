# core_engine/memory_guard.py
import re


class MemoryGuard:
    def __init__(self, token_limit=8192):
        self.token_limit = token_limit
        self.chars_per_token = 4

    def _estimate_tokens(self, text):
        return len(text) // self.chars_per_token

    def is_orphan_split(self, message):
        """Checks if a message is an orphan tool call or system result."""
        text = (
            message[1]
            if isinstance(message, tuple)
            else list(message.values())[0]
            if isinstance(message, dict)
            else str(message)
        )
        has_tool = bool(re.search(r"<tool>.*?</tool>", text, re.DOTALL | re.IGNORECASE))
        is_result = bool(re.search(r"\[SYSTEM: RESULT.*?\]", text, re.IGNORECASE))
        return has_tool or is_result

    def compress_history(self, history, brain_instance=None):
        """
        Sliding Window + Orphan Pruning Compaction Core
        """
        # Calculate total tokens
        total_tokens = sum(self._estimate_tokens(str(msg)) for msg in history)

        # If below 70% threshold, don't touch it
        if total_tokens < self.token_limit * 0.7:
            return history

        if len(history) < 4:
            return history  # Too short to meaningful split

        # We need to compact ~50% of the history
        target_split_idx = len(history) // 2

        # --- ORPHAN PRUNING LOGIC ---
        # Ensure we don't split between a <tool> and its corresponding [SYSTEM: RESULT]

        while target_split_idx > 0 and target_split_idx < len(history) - 1:
            prev_msg = history[target_split_idx - 1]
            curr_msg = history[target_split_idx]

            prev_text = (
                prev_msg[1]
                if isinstance(prev_msg, tuple)
                else (
                    prev_msg.get("content", "")
                    if isinstance(prev_msg, dict)
                    else str(prev_msg)
                )
            )
            curr_text = (
                curr_msg[1]
                if isinstance(curr_msg, tuple)
                else (
                    curr_msg.get("content", "")
                    if isinstance(curr_msg, dict)
                    else str(curr_msg)
                )
            )

            prev_has_tool = bool(
                re.search(r"<tool>.*?</tool>", prev_text, re.DOTALL | re.IGNORECASE)
            )
            curr_is_result = bool(
                re.search(r"\[SYSTEM: RESULT.*?\]", curr_text, re.IGNORECASE)
            )

            if prev_has_tool and curr_is_result:
                # We are splitting a pair! Shift split point down to keep them together in the active window
                target_split_idx += 1
            else:
                break  # Safe split

        # Separate history
        to_summarize = history[:target_split_idx]
        to_keep = history[target_split_idx:]

        # Create Summary
        # (Foreground summary for speed to avoid complex background thread syncs before feeding to drivers)
        summary_prompt = "[SISTEMA DE COMPRESIÓN] Resume estrictamente la siguiente conversación y extrae cualquier dato clave, URL o contexto vital. Ignora los errores de herramientas, concéntrate en los hechos que el usuario dictó o las respuestas finales dadas.\n\n"
        for item in to_summarize:
            text = (
                item[1]
                if isinstance(item, tuple)
                else (item.get("content", "") if isinstance(item, dict) else str(item))
            )
            # Strip tools to save tokens in summarization
            text = re.sub(
                r"<tool>.*?</tool>",
                "[TOOL CALL HIDDEN]",
                text,
                flags=re.DOTALL | re.IGNORECASE,
            )
            summary_prompt += f"{text}\n"

        summary = (
            "Resumen anterior: (Varios mensajes consolidados para ahorrar memoria)"
        )
        if brain_instance:
            try:
                # Call gemini-1.5-flash for ultra fast summarization
                summary = brain_instance.query(summary_prompt, [], "gemini-1.5-flash")
            except Exception as e:
                summary = f"[Error compressing: {e}]"

        # Inject Summary
        new_history = [
            ("system", f"[SYSTEM: Resumen de contexto previo: {summary}]")
        ] + to_keep

        return new_history
