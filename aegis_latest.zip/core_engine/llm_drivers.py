import requests
import json
import base64
import os
import google.generativeai as genai


# --- DRIVER HELPERS ---
def _serialize_history(history):
    """Converts (role, msg, ts) tuples to clean text context."""
    context = ""
    for role, msg, ts in history:
        context += f"{role.capitalize()}: {msg}\n"
    return context


def _get_api_error_response(provider, message):
    return f"{provider} Error: {message}"


# --- GEMINI DRIVER ---
def query_gemini(
    system_instruction,
    prompt,
    history,
    api_key,
    model_name="gemini-pro",
    image_input=None,
    stream=False,
):
    """Base Gemini request implementation."""
    if not api_key or not str(api_key).startswith("AI"):
        return None

    try:
        genai.configure(api_key=api_key)

        # Handle Model Name Quirks
        if image_input and model_name == "gemini-pro":
            model_name = "gemini-1.5-flash"

        model = genai.GenerativeModel(model_name)

        # Build prompt
        context = system_instruction + "\n\n" + _serialize_history(history)
        full_prompt = f"{context}\nUser: {prompt}\nAssistant:"

        content = [full_prompt]
        if image_input:
            content.append(image_input)

        response = model.generate_content(content, stream=stream)

        if stream:
            return response
        else:
            return response.text

    except Exception as e:
        return _get_api_error_response("Gemini", str(e))


# --- OPENAI / GENERIC DRIVER ---
def query_openai_style(
    system_instruction,
    prompt,
    history,
    api_key,
    model_name,
    base_url,
    provider_name="OpenAI",
):
    """Generic OpenAI-compatible request."""
    if not api_key:
        return f"Error: {provider_name} API Key missing."

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }

    if provider_name == "OpenRouter":
        headers["HTTP-Referer"] = "https://aegis.ia"
        headers["X-Title"] = "Aegis-IA"

    messages = [{"role": "system", "content": system_instruction}]
    for role, msg, ts in history:
        messages.append(
            {"role": "user" if role == "user" else "assistant", "content": msg}
        )
    messages.append({"role": "user", "content": prompt})

    try:
        r = requests.post(
            base_url,
            json={"model": model_name, "messages": messages},
            headers=headers,
            timeout=60,
        )
        if r.status_code == 200:
            return r.json()["choices"][0]["message"]["content"]
        return _get_api_error_response(provider_name, f"{r.status_code} - {r.text}")
    except Exception as e:
        return _get_api_error_response(provider_name, f"Connection Error: {str(e)}")


# --- ANTHROPIC DRIVER ---
def query_anthropic(
    system_instruction, prompt, history, api_key, model_name="claude-3-haiku-20240307"
):
    if not api_key:
        return "Error: Anthropic API Key missing."

    headers = {
        "x-api-key": api_key,
        "anthropic-version": "2023-06-01",
        "Content-Type": "application/json",
    }

    messages = []
    for role, msg, ts in history:
        messages.append(
            {"role": "user" if role == "user" else "assistant", "content": msg}
        )
    messages.append({"role": "user", "content": prompt})

    try:
        r = requests.post(
            "https://api.anthropic.com/v1/messages",
            json={
                "model": model_name,
                "max_tokens": 1024,
                "system": system_instruction,
                "messages": messages,
            },
            headers=headers,
            timeout=30,
        )
        if r.status_code == 200:
            return r.json()["content"][0]["text"]
        return _get_api_error_response("Anthropic", r.text)
    except Exception as e:
        return _get_api_error_response("Anthropic", f"Connection Error: {str(e)}")


# --- OLLAMA DRIVER ---
def query_ollama(
    system_instruction,
    prompt,
    history,
    model="llama2",
    stream=False,
    image_input=None,
    ollama_host="http://localhost:11434",
):
    """Local Ollama with streaming support."""
    # Ensure Host is clean
    if ollama_host.endswith("/"):
        ollama_host = ollama_host[:-1]
    base_url = f"{ollama_host}/api/generate"

    # print(f"[DRIVER] 🦙 Ollama: {model} (Stream: {stream})") # Removed excessive logging for production

    try:
        # Optimization: Sliding Window Context (Last 6 turns)
        optimized_history = history[-3:] if len(history) > 3 else history

        context = system_instruction + "\n\n"
        for role, msg, ts in optimized_history:
            context += f"{role}: {msg}\n"

        full_prompt = f"{context}\nUser: {prompt}\nAssistant:"

        payload = {
            "model": model,
            "prompt": full_prompt,
            "stream": stream,
            "options": {
                "num_ctx": 8192 if "coder" in model or "mistral" in model else 4096,
                "keep_alive": "5m",
                "num_predict": 1024 if "coder" in model else 512,
            },
        }

        if image_input:
            # Image handling logic (read file or use bytes)
            b64_img = ""
            try:
                if isinstance(image_input, str) and os.path.exists(image_input):
                    with open(image_input, "rb") as img_file:
                        b64_img = base64.b64encode(img_file.read()).decode("utf-8")
                elif isinstance(image_input, (bytes, bytearray)):
                    b64_img = base64.b64encode(image_input).decode("utf-8")

                if b64_img:
                    payload["images"] = [b64_img]
            except:
                pass

        response = requests.post(base_url, json=payload, timeout=300, stream=stream)

        if response.status_code == 200:
            if stream:

                def stream_generator():
                    for line in response.iter_lines():
                        if line:
                            try:
                                json_part = json.loads(line)
                                chunk = json_part.get("response", "")
                                if chunk:
                                    yield chunk
                                if json_part.get("done"):
                                    break
                            except:
                                pass

                return stream_generator()
            else:
                full_text = ""
                for line in response.iter_lines():
                    if line:
                        try:
                            json_part = json.loads(line)
                            full_text += json_part.get("response", "")
                        except:
                            pass
                return full_text
        else:
            return f"Ollama Error: {response.status_code} - {response.text}"

    except requests.exceptions.Timeout:
        return "Ollama Timeout (300s). Model loading or hardware overload."
    except Exception as e:
        return f"Ollama Connection Error: {str(e)}"


# --- DISCOVERY ---
def get_available_ollama_models(ollama_host):
    try:
        if ollama_host.endswith("/"):
            ollama_host = ollama_host[:-1]
        url = f"{ollama_host}/api/tags"
        response = requests.get(url, timeout=2.0)
        if response.status_code == 200:
            data = response.json()
            return [m.get("name") for m in data.get("models", [])]
    except:
        pass
    return []
