import requests
import json
import base64
import os
import warnings

warnings.filterwarnings("ignore", category=FutureWarning)
import google.generativeai as genai


# --- REGISTRY ---
class LLMRegistry:
    def __init__(self):
        self._drivers = {}

    def register(self, name, func):
        self._drivers[name.lower()] = func

    def get_driver(self, name):
        driver = self._drivers.get(name.lower())
        if not driver:
            raise ValueError(f"Driver '{name}' not registered.")
        return driver

    def execute(self, name, **kwargs):
        return self.get_driver(name)(**kwargs)


llm_registry = LLMRegistry()


# --- EXCEPTIONS ---
class LLMError(Exception):
    """Base exception for LLM drivers."""

    pass


class LLMConnectionError(LLMError):
    """Raised when a connection to the model fails."""

    pass


class LLMRateLimitError(LLMError):
    """Raised when the model provider returns a rate limit error."""

    pass


class LLMAuthError(LLMError):
    """Raised when authentication fails."""

    pass


# --- DRIVER HELPERS ---
def _serialize_history(history):
    """Converts (role, msg, ts) tuples to clean text context."""
    context = ""
    for entry in history:
        # Robust unpacking for 2 or 3 element tuples
        role, msg = entry[0], entry[1]
        context += f"{role.capitalize()}: {msg}\n"
    return context


def _get_api_error_response(provider, message):
    return f"{provider} Error: {message}"


# --- GEMINI DRIVER ---
def query_gemini(
    system_instruction,
    prompt,
    history,
    api_key,
    model_name="gemini-pro",
    image_input=None,
    stream=False,
):
    """Base Gemini request implementation."""
    if not api_key or not str(api_key).startswith("AI"):
        raise LLMAuthError("Gemini API Key missing or invalid.")

    try:
        genai.configure(api_key=api_key)

        # Handle Model Name Quirks
        model_name = model_name.strip()
        if image_input and model_name == "gemini-pro":
            model_name = "gemini-1.5-flash"

        try:
            model = genai.GenerativeModel(model_name)
            # Pre-check if 404 on the name itself by doing something trivial or just letting it fail later
        except Exception as e:
            if "404" in str(e) and "gemini-1.5-flash" in model_name:
                model_name = "gemini-1.5-flash-latest"
                model = genai.GenerativeModel(model_name)
            else:
                raise

        # Build prompt
        context = system_instruction + "\n\n" + _serialize_history(history)
        full_prompt = f"{context}\nUser: {prompt}\nAssistant:"

        content = [full_prompt]
        if image_input:
            content.append(image_input)

        try:
            response = model.generate_content(content, stream=stream)
        except Exception as e:
            err_str = str(e)
            if "404" in err_str:
                # CASCADA DE MODERNIZACIÓN: Intentar versiones anteriores si la más nueva no está disponible
                fallbacks = [
                    "gemini-3.1-pro",
                    "gemini-3.1-flash",
                    "gemini-3.0-pro-preview",
                    "gemini-3.0-flash-preview",
                    "gemini-2.5-pro",
                    "gemini-2.5-flash",
                    "gemini-2.0-flash",
                    "gemini-1.5-flash-latest",
                ]

                # Encontrar dónde estamos en la cadena y saltar al siguiente
                current_idx = -1
                for i, fb in enumerate(fallbacks):
                    if fb in model_name:
                        current_idx = i
                        break

                # Si no está en la lista estándar o es el último, intentar 1.5-flash-latest como puerto seguro
                next_models = (
                    fallbacks[current_idx + 1 :]
                    if current_idx != -1
                    else ["gemini-1.5-flash-latest"]
                )

                success = False
                for next_m in next_models:
                    try:
                        model_name = next_m
                        model = genai.GenerativeModel(model_name)
                        response = model.generate_content(content, stream=stream)
                        success = True
                        break
                    except Exception:
                        continue

                if not success:
                    raise
            else:
                raise

        if stream:

            def gen():
                for chunk in response:
                    yield {"type": "text", "content": chunk.text}

            return gen()
        else:
            return {"type": "text", "content": response.text}

    except Exception as e:
        err_msg = str(e)
        if "quota" in err_msg.lower() or "429" in err_msg:
            raise LLMRateLimitError(f"Gemini Rate Limit: {err_msg}")
        if "auth" in err_msg.lower() or "api key" in err_msg.lower():
            raise LLMAuthError(f"Gemini Auth Error: {err_msg}")
        raise LLMConnectionError(f"Gemini Error: {err_msg}")


# --- OPENAI / GENERIC DRIVER ---
def query_openai_style(
    system_instruction,
    prompt,
    history,
    api_key,
    model_name,
    base_url,
    provider_name="OpenAI",
):
    """Generic OpenAI-compatible request."""
    if not api_key:
        raise LLMAuthError(f"{provider_name} API Key missing.")

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }

    if provider_name == "OpenRouter":
        headers["HTTP-Referer"] = "https://aegis.ia"
        headers["X-Title"] = "Aegis-IA"

    messages = [{"role": "system", "content": system_instruction}]
    for entry in history:
        role, msg = entry[0], entry[1]
        messages.append(
            {"role": "user" if role == "user" else "assistant", "content": msg}
        )
    messages.append({"role": "user", "content": prompt})

    try:
        r = requests.post(
            base_url,
            json={"model": model_name, "messages": messages},
            headers=headers,
            timeout=60,
        )
        if r.status_code == 200:
            return {
                "type": "text",
                "content": r.json()["choices"][0]["message"]["content"],
            }

        err_text = r.text
        if r.status_code == 429:
            raise LLMRateLimitError(f"{provider_name} Rate Limit: {err_text}")
        if r.status_code in [401, 403]:
            raise LLMAuthError(f"{provider_name} Auth Error: {err_text}")

        raise LLMError(f"{provider_name} Error: {r.status_code} - {err_text}")

    except requests.exceptions.RequestException as e:
        raise LLMConnectionError(f"{provider_name} Connection Error: {str(e)}")
    except Exception as e:
        if isinstance(e, LLMError):
            raise e
        raise LLMError(f"{provider_name} Unexpected Error: {str(e)}")


# --- ANTHROPIC DRIVER ---
def query_anthropic(
    system_instruction, prompt, history, api_key, model_name="claude-3-haiku-20240307"
):
    if not api_key:
        raise LLMAuthError("Anthropic API Key missing.")

    headers = {
        "x-api-key": api_key,
        "anthropic-version": "2023-06-01",
        "Content-Type": "application/json",
    }

    messages = []
    for entry in history:
        role, msg = entry[0], entry[1]
        messages.append(
            {"role": "user" if role == "user" else "assistant", "content": msg}
        )
    messages.append({"role": "user", "content": prompt})

    try:
        r = requests.post(
            "https://api.anthropic.com/v1/messages",
            json={
                "model": model_name,
                "max_tokens": 1024,
                "system": system_instruction,
                "messages": messages,
            },
            headers=headers,
            timeout=30,
        )
        if r.status_code == 200:
            return {"type": "text", "content": r.json()["content"][0]["text"]}

        err_text = r.text
        if r.status_code == 429:
            raise LLMRateLimitError(f"Anthropic Rate Limit: {err_text}")
        if r.status_code in [401, 403]:
            raise LLMAuthError(f"Anthropic Auth Error: {err_text}")

        raise LLMError(f"Anthropic Error: {r.status_code} - {err_text}")
    except requests.exceptions.RequestException as e:
        raise LLMConnectionError(f"Anthropic Connection Error: {str(e)}")
    except Exception as e:
        if isinstance(e, LLMError):
            raise e
        raise LLMError(f"Anthropic Unexpected Error: {str(e)}")


# --- OLLAMA DRIVER ---
def query_ollama(
    system_instruction,
    prompt,
    history,
    model="llama3.2:1b",
    stream=False,
    image_input=None,
    ollama_host="http://127.0.0.1:11434",
    require_json=False,
    tools=None,
):
    """Local Ollama with structured chat support and Tool Calling."""
    if ollama_host.endswith("/"):
        ollama_host = ollama_host[:-1]
    base_url = f"{ollama_host}/api/chat"

    # 1. Construir Array Estructurado (Estilo OpenClaw/OpenAI)
    messages = []
    if system_instruction:
        messages.append({"role": "system", "content": system_instruction})

    # Historial optimizado (últimos 6 mensajes)
    optimized_history = history[-6:] if len(history) > 6 else history
    for entry in optimized_history:
        role = entry[0]
        msg = entry[1]
        safe_role = "assistant" if role == "assistant" else "user"
        messages.append({"role": safe_role, "content": msg})

    # Prompt actual
    messages.append({"role": "user", "content": prompt})

    # 2. Configuración de Inferencia
    from modules.resource_monitor import monitor
    from core_engine.router import TIER_CONFIGS

    tier_id, _, _, _ = monitor.get_hardware_tier()
    tier_config = TIER_CONFIGS.get(tier_id, TIER_CONFIGS[2])

    payload = {
        "model": model,
        "messages": messages,
        "stream": stream,
        "keep_alive": tier_config.get("keep_alive", "15m"),
        "options": {
            "num_ctx": tier_config.get("ctx", 8192),
            "temperature": 0.3,
        },
    }

    if tools:
        payload["tools"] = tools

    # Manejo de imágenes
    if image_input:
        b64_img = ""
        try:
            if isinstance(image_input, str) and os.path.exists(image_input):
                with open(image_input, "rb") as img_file:
                    b64_img = base64.b64encode(img_file.read()).decode("utf-8")
            elif isinstance(image_input, (bytes, bytearray)):
                b64_img = base64.b64encode(image_input).decode("utf-8")

            if b64_img:
                messages[-1]["images"] = [b64_img]
        except Exception:
            pass

    # 3. Petición HTTP
    try:
        # Timeout=(connect_timeout, read_timeout)
        # 15s connection, 45s between chunks
        response = requests.post(
            base_url, json=payload, timeout=(15, 120), stream=stream
        )
        if response.status_code == 200:
            if stream:

                def stream_generator():
                    try:
                        for line in response.iter_lines():
                            if line:
                                data = json.loads(line)
                                msg = data.get("message", {})
                                chunk = msg.get("content", "")
                                if chunk:
                                    yield {"type": "text", "content": chunk}

                                tool_calls = msg.get("tool_calls")
                                if tool_calls:
                                    yield {"type": "tool", "data": tool_calls}

                                # Performance Metadata
                                if data.get("done"):
                                    total_duration = data.get("total_duration", 0) / 1e9
                                    eval_count = data.get("eval_count", 0)
                                    eval_duration = data.get("eval_duration", 1) / 1e9
                                    tps = (
                                        eval_count / eval_duration
                                        if eval_duration > 0
                                        else 0
                                    )

                                    yield {
                                        "type": "metadata",
                                        "tokens_per_second": round(tps, 2),
                                        "model_used": model,
                                        "total_duration": round(total_duration, 2),
                                    }
                                    break
                    except requests.exceptions.ReadTimeout:
                        yield {
                            "type": "text",
                            "content": "\n[Timeout del stream detectado. La conexión fue abortada para evitar bloqueo.]",
                        }

                return stream_generator()
            else:
                resp_json = response.json()
                message = resp_json.get("message", {})

                # Performance Metadata
                total_duration = resp_json.get("total_duration", 0) / 1e9
                eval_count = resp_json.get("eval_count", 0)
                eval_duration = resp_json.get("eval_duration", 1) / 1e9
                tps = eval_count / eval_duration if eval_duration > 0 else 0

                metadata = {
                    "type": "metadata",
                    "tokens_per_second": round(tps, 2),
                    "model_used": model,
                    "total_duration": round(total_duration, 2),
                }

                # Check for Tool Calls
                tool_calls = message.get("tool_calls")
                if tool_calls:
                    return [
                        {
                            "type": "tool",
                            "data": tool_calls,
                            "content": message.get("content", ""),
                        },
                        metadata,
                    ]

                return [
                    {"type": "text", "content": message.get("content", "")},
                    metadata,
                ]
        else:
            raise LLMError(f"Ollama Error: {response.status_code} - {response.text}")
    except requests.exceptions.RequestException as e:
        raise LLMConnectionError(f"Ollama Connection Error: {e}")
    except Exception as e:
        if isinstance(e, LLMError):
            raise e
        raise LLMError(f"Ollama Unexpected Error: {str(e)}")


def get_available_gemini_models(api_key):
    """Dynamically fetches models available for the provided Gemini API key."""
    if not api_key:
        return []
    try:
        genai.configure(api_key=api_key)
        models = []
        for m in genai.list_models():
            if "generateContent" in m.supported_generation_methods:
                # Clean name: 'models/gemini-1.5-flash' -> 'gemini-1.5-flash'
                name = m.name.replace("models/", "")
                models.append(name)
        return sorted(models)
    except Exception as e:
        print(f"[DRIVERS] Error fetching Gemini models: {e}")
        return []


# --- DISCOVERY ---
def get_available_ollama_models(ollama_host):
    try:
        if ollama_host.endswith("/"):
            ollama_host = ollama_host[:-1]
        url = f"{ollama_host}/api/tags"
        response = requests.get(url, timeout=2.0)
        if response.status_code == 200:
            data = response.json()
            return [m.get("name") for m in data.get("models", [])]
    except Exception:
        pass
    return []


# -- REGISTRY SETUP --
llm_registry.register("gemini", query_gemini)
llm_registry.register(
    "openai",
    lambda **k: query_openai_style(
        provider_name="OpenAI",
        base_url="https://api.openai.com/v1/chat/completions",
        **k,
    ),
)
llm_registry.register(
    "groq",
    lambda **k: query_openai_style(
        provider_name="Groq",
        base_url="https://api.groq.com/openai/v1/chat/completions",
        **k,
    ),
)
llm_registry.register(
    "openrouter",
    lambda **k: query_openai_style(
        provider_name="OpenRouter",
        base_url="https://openrouter.ai/api/v1/chat/completions",
        **k,
    ),
)
llm_registry.register(
    "cerebras",
    lambda **k: query_openai_style(
        provider_name="Cerebras",
        base_url="https://api.cerebras.ai/v1/chat/completions",
        **k,
    ),
)
llm_registry.register("anthropic", query_anthropic)
llm_registry.register("ollama", query_ollama)
