import json
import re
import database

# Use Drivers and Prompts
from core_engine import prompts, llm_drivers


def resolve_model_by_role(role="chat"):
    """Maps generic role tags to configured specific models."""
    if ":" in role:
        role = role.split(":")[1]
    role = role.lower()

    mapping = {
        "coder": database.get_setting("local_coder_model") or "qwen2.5-coder",
        "writer": database.get_setting("local_coder_model") or "qwen2.5-coder",
        "logic": database.get_setting("local_logic_model") or "deepseek-r1:8b",
        "planner": database.get_setting("local_logic_model") or "deepseek-r1:8b",
        "heavy": database.get_setting("local_heavy_model") or "mistral-nemo",
        "oracle": database.get_setting("local_heavy_model") or "mistral-nemo",
        "chat": database.get_setting("local_chat_model") or "llama3.1",
        "router": "llama3.1",
    }

    target = mapping.get(role, mapping["chat"])

    # Clean 'ollama-' prefix if present, but keep cloud names intact
    if any(x in target for x in ["gpt", "claude", "gemini"]):
        return target

    if target.startswith("ollama-"):
        target = target.replace("ollama-", "")

    return target


def route_request(
    user_input, file_metadata=None, api_key=None, source=None, ollama_host=None
):
    """
    NEURAL ROUTER: Classifies intent as 'chat' or 'mission'.
    """
    default_route = {"intent": "chat", "agents": ["chat"]}

    # 1. IDE Source Override
    if source == "ide":
        return {
            "intent": "chat",
            "agents": ["coder"],
            "system_prompt": "You are a Senior Engineer. Answer directly. Solution only.",
        }

    # 2. Simple input bypass
    if len(user_input.split()) < 3 and not file_metadata:
        if "me llamo" not in user_input.lower():
            return default_route

    # 3. Hallucination Block (System Report Interception)
    if "reporte" in user_input.lower() and (
        "estado" in user_input.lower() or "sistema" in user_input.lower()
    ):
        print("[ROUTER] 🛡️ Hallucination Block Active")
        return {"intent": "mission", "agents": ["oracle"]}

    # 4. Neural Routing
    prompt = prompts.get_router_prompt(user_input, file_metadata)

    try:
        response_text = ""

        # Try Fast Cloud first
        if api_key and str(api_key).startswith("AI"):
            # We use a dummy system prompt for router
            response_text = llm_drivers.query_gemini(
                "You are a routing classification engine. Output JSON only.",
                prompt,
                [],
                api_key,
                model_name="gemini-1.5-flash",
            )

        # Fallback to Fast Local
        if not response_text:
            local_model = resolve_model_by_role("router")
            response_text = llm_drivers.query_ollama(
                "You are a routing engine.",
                prompt,
                [],
                model=local_model,
                ollama_host=ollama_host or "http://localhost:11434",
            )

        match = re.search(r"\{.*\}", str(response_text), re.DOTALL)
        if match:
            data = json.loads(match.group(0))
            if "intent" in data:
                return data

    except Exception as e:
        print(f"[ROUTER FAIL] Defaulting to Chat. Error: {e}")

    return default_route


def extract_user_facts(history, api_key=None, ollama_host=None):
    """Analyzes history to extract permanent user facts."""
    use_local = not (api_key and str(api_key).startswith("AI"))

    # Construct context from last 10 messages
    context = ""
    for role, msg, ts in history[-10:]:
        context += f"{role}: {msg}\n"

    prompt = prompts.get_fact_extraction_prompt(context)

    try:
        response_text = ""
        if not use_local:
            response_text = llm_drivers.query_gemini(
                "Info Extractor", prompt, [], api_key, model_name="gemini-1.5-flash"
            )

        if not response_text:  # Fallback
            local_model = resolve_model_by_role("logic")
            response_text = llm_drivers.query_ollama(
                "Info Extractor", prompt, [], model=local_model, ollama_host=ollama_host
            )

        match = re.search(r"\[.*\]", str(response_text), re.DOTALL)
        if match:
            facts = json.loads(match.group(0))
            for f in facts:
                database.add_user_fact(
                    f.get("key"),
                    f.get("value"),
                    f.get("category"),
                    f.get("confidence", 0.5),
                )

    except Exception as e:
        print(f"Fact Extraction Error: {e}")


def summarize_context(history, api_key=None, ollama_host=None):
    """PROTOCOL CHRONOS: Generates executive summary."""
    use_local = not (api_key and str(api_key).startswith("AI"))

    prev_summary = database.get_latest_context_summary()
    fragment = ""
    for role, msg, ts in history:
        fragment += f"{role}: {msg}\n"

    prompt = prompts.get_chronos_summary_prompt(prev_summary, fragment)

    try:
        response_text = ""
        if not use_local:
            response_text = llm_drivers.query_gemini(
                "Summarizer", prompt, [], api_key, model_name="gemini-1.5-flash"
            )

        if not response_text:
            local_model = resolve_model_by_role("heavy")
            response_text = llm_drivers.query_ollama(
                "Summarizer", prompt, [], model=local_model, ollama_host=ollama_host
            )

        if response_text:
            database.add_user_fact(
                "chronos_summary", response_text, "context_summary", 1.0
            )

    except Exception as e:
        print(f"Chronos Error: {e}")


def decide_intent_legacy(prompt, model_choice_arg, api_key):
    """Legacy helper for Expense/Task detection (if still needed)."""
    # Simple keyword detection or small LLM call can go here
    # For now, implemented as no-op or basic heuristic to satisfy interface
    return {"intent": "chat", "args": {}}
