import json
import re
import math
import requests
import subprocess
import platform
import psutil
import threading
import time
import database
from core_engine import prompts, llm_drivers


# --- CONCEPTUAL CENTROIDS (Optimized for Action Vectors) ---
CONCEPTUAL_CENTROIDS = {
    "CHAT": "Hola, ¿cómo estás? quién eres, cuéntame un chiste, saludo, conversación casual, identidad, preguntas generales, filosofía.",
    "PROJECTS": "Crear nuevo proyecto, iniciar app, programar script, generar código, crear archivo python, estructura de carpetas, desarrollar software, web app.",
    "SYSTEM": "Analizar sistema, reporte de estado, check logs, arreglar error, debug, leer archivos del sistema, optimizar memoria, status.",
    "LIFE_FINANCE": "Registrar gasto, compré algo, gasté dinero, agregar pago, supermercado, costo, finanzas, anotar egreso, $ precio valor.",
    "AGENDA": "Agendar reunión, programar cita, recordar evento, nueva tarea, task, pendiente, calendario, meeting, entrevista a las horas.",
    "UBIQUITY": "Mover proyecto a otro nodo, enviar a escritorio, sincronizar con satélite, instalar en remoto, desplegar.",
}


class ModelHealth:
    _health_stats = {}  # { provider: { status: 'healthy'|'cooldown', until: timestamp, errors: 0 } }

    @classmethod
    def report_error(cls, provider):
        stats = cls._health_stats.get(
            provider, {"status": "healthy", "errors": 0, "until": 0}
        )
        stats["errors"] += 1

        # Exponential backoff: 1 min, 5 min, 30 min, 1 hour
        backoff = [60, 300, 1800, 3600]
        cooldown_idx = min(stats["errors"] - 1, len(backoff) - 1)

        stats["status"] = "cooldown"
        stats["until"] = time.time() + backoff[cooldown_idx]
        cls._health_stats[provider] = stats
        print(
            f"[HEALTH] 🚨 Provider {provider} entered cooldown until {time.ctime(stats['until'])}"
        )

    @classmethod
    def report_success(cls, provider):
        if provider in cls._health_stats:
            cls._health_stats[provider] = {"status": "healthy", "errors": 0, "until": 0}

    @classmethod
    def is_healthy(cls, provider):
        if provider == "ollama":
            return True  # Ollama handled by presence
        stats = cls._health_stats.get(provider)
        if not stats:
            return True
        if stats["status"] == "healthy":
            return True
        if time.time() > stats["until"]:
            stats["status"] = "healthy"
            return True
        return False


class IntentEngine:
    _cached_centroids = {}

    @classmethod
    def ensure_semantic_engine(cls, host="http://127.0.0.1:11434"):
        """
        Auto-Aprovisionamiento: Verifica si mxbai-embed-large existe localmente.
        Si no existe, inicia un subprocess para ejecutar ollama pull.
        """
        if host.endswith("/"):
            host = host[:-1]

        model = database.get_setting("router_embedding_model") or "mxbai-embed-large"

        try:
            res = requests.get(f"{host}/api/tags", timeout=2)
            if res.status_code == 200:
                models = [m["name"] for m in res.json().get("models", [])]
                if model in models or f"{model}:latest" in models:
                    print(f"[SEMANTIC] ✅ Motor de vectores '{model}' listo.")
                    return True
        except Exception:
            pass

        print(
            f"[SEMANTIC] 👂 Aegis está agudizando su oído semántico... Descargando {model}"
        )
        try:
            # Descarga asíncrona para no bloquear el arranque
            subprocess.Popen(
                ["ollama", "pull", model],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                shell=(platform.system() == "Windows"),
            )
        except Exception as e:
            print(f"[!] Error de auto-aprovisionamiento: {e}")
        return False

    @classmethod
    def initialize(cls, host="http://127.0.0.1:11434"):
        """Genera los embeddings de las Descripciones Técnicas y los guarda en caché."""
        if cls._cached_centroids:
            return

        print("[ROUTER] 🧠 Inicializando Centroides Conceptuales...")
        cls.ensure_semantic_engine(host)

        model = database.get_setting("router_embedding_model") or "mxbai-embed-large"

        for category, description in CONCEPTUAL_CENTROIDS.items():
            emb = get_embedding(description, model, host)
            if emb:
                cls._cached_centroids[category] = emb

        if cls._cached_centroids:
            print(
                f"[SEMANTIC] 🛡️ Router Profesional Activo: {len(cls._cached_centroids)} conceptos vectorizados."
            )

    @classmethod
    def classify(cls, user_input, host="http://127.0.0.1:11434"):
        """Usa Similitud del Coseno para comparar el input contra vectores pre-calculados."""
        if not cls._cached_centroids:
            cls.initialize(host)

        if not cls._cached_centroids:
            return None, 0

        model = database.get_setting("router_embedding_model") or "mxbai-embed-large"
        input_vec = get_embedding(user_input, model, host)
        if not input_vec:
            return None, 0

        scores = {}
        for cat, vec in cls._cached_centroids.items():
            scores[cat] = cosine_similarity(input_vec, vec)

        best_cat = max(scores, key=scores.get)
        return best_cat, scores[best_cat]


def get_embedding(text, model=None, host="http://127.0.0.1:11434"):
    """
    Generates embedding vector for a given text using Ollama.
    Protocolo de Seguridad: Solo permite llamadas al endpoint /api/embeddings.
    """
    if not model:
        model = database.get_setting("router_embedding_model") or "mxbai-embed-large"

    if host.endswith("/"):
        host = host[:-1]

    url = f"{host}/api/embeddings"
    try:
        # VALIDACIÓN ESTRICTA: El modelo de embeddings solo puede llamar al endpoint /api/embeddings
        # Estamos forzando el uso de este endpoint aquí.
        res = requests.post(url, json={"model": model, "prompt": text}, timeout=3.0)
        if res.status_code == 200:
            return res.json().get("embedding")
        else:
            print(
                f"[ROUTER ERROR] Endpoint /api/embeddings falló para {model}: {res.text}"
            )
    except Exception as e:
        print(f"[ROUTER EXCEPTION] Error en embeddings: {e}")
    return None


def cosine_similarity(v1, v2):
    """Calculates Cosine Similarity between two vectors."""
    if not v1 or not v2:
        return 0.0

    dot_product = sum(a * b for a, b in zip(v1, v2))
    norm_a = math.sqrt(sum(a * a for a in v1))
    norm_b = math.sqrt(sum(b * b for b in v2))

    if norm_a == 0 or norm_b == 0:
        return 0.0

    return dot_product / (norm_a * norm_b)


def get_semantic_intent(
    user_input, ollama_host="http://127.0.0.1:11434", has_attachment=False
):
    """
    Computes similarity of user_input against technical centroids.
    Returns 'chat', 'mission_system', 'mission_project', 'mission_life' or 'ambiguous'.
    """
    # MULTIMODAL BIAS SIGNAL: Si hay adjunto y poco texto, inyectamos contexto para forzar clasificación
    effective_input = user_input
    if has_attachment and (not user_input or len(user_input.strip().split()) < 4):
        # Inyectamos contexto de sesgo hacia Oracle (SYSTEM) o Finanzas (LIFE_FINANCE)
        effective_input = f"{user_input} (CONTEO VISUAL: El usuario ha subido un documento o imagen para registro de datos o análisis del sistema Oracle)"

    category, similarity = IntentEngine.classify(effective_input, ollama_host)
    print(
        f"[SEMANTIC DEBUG] Input: '{user_input}' -> Best: {category} ({similarity:.3f})"
    )
    # Manejo de Ambigüedad: Umbral de seguridad
    if similarity < 0.38:
        return "ambiguous"

    mapping = {
        "CHAT": "chat",
        "PROJECTS": "mission_project",
        "SYSTEM": "mission_system",
        "LIFE_FINANCE": "mission_life",
        "AGENDA": "mission_life",
        "UBIQUITY": "mission_project",
    }

    return mapping.get(category, "chat")


# --- MASTER RECOMMENDATION MAP (Hardware-Agnostic) ---
TIER_CONFIGS = {
    1: {  # ECO (<8GB RAM)
        "name": "TIER 1 (Eco)",
        "chat": "llama3.2:1b",
        "coder": "qwen2.5-coder:1.5b",
        "vision": "moondream",
        "logic": "llama3.2:3b",
        "heavy": "llama3.2:3b",
        "ctx": 2048,
        "keep_alive": "5m",
    },
    2: {  # BALANCED (8-16GB RAM)
        "name": "TIER 2 (Balanced)",
        "chat": "qwen2.5:7b",
        "coder": "qwen2.5-coder:7b",
        "vision": "moondream",
        "logic": "deepseek-r1:8b",
        "heavy": "mistral-nemo:12b",
        "ctx": 8192,
        "keep_alive": "15m",
    },
    3: {  # HIGH (>16GB RAM)
        "name": "TIER 3 (High-Perf)",
        "chat": "llama3.1:8b",
        "coder": "deepseek-v3",
        "vision": "moondream",
        "logic": "deepseek-v3",
        "heavy": "mistral-nemo:12b",
        "ctx": 16384,
        "keep_alive": "60m",
    },
}


def unload_model_except(target_model, ollama_host="http://127.0.0.1:11434"):
    """
    Si la RAM libre es < 15%, descarga todos los modelos de Ollama excepto el actual
    para optimizar el entorno. Se ejecuta en segundo plano para no bloquear el flujo principal.
    """

    def _async_unload():
        try:
            mem = psutil.virtual_memory()

            # Si el uso de RAM supera el 85% (menos del 15% libre)
            if mem.percent > 85:
                print(
                    f"[RAM MANAGEMENT] 🚨 RAM Crítica ({mem.percent}%). Optimizando Matriz de Especialistas..."
                )

                nonlocal ollama_host
                if ollama_host.endswith("/"):
                    ollama_host = ollama_host[:-1]

                # Obtenemos modelos cargados actualmente en Ollama
                res = requests.get(f"{ollama_host}/api/ps", timeout=2)
                if res.status_code == 200:
                    loaded_models = res.json().get("models", [])
                    for m in loaded_models:
                        model_name = m.get("name")
                        # No descargamos el que vamos a usar ni el de embeddings si está en medio
                        if model_name != target_model:
                            # En vez de matar el modelo agresivamente (0), le damos TTL suave
                            # Si la RAM está MUY crítica (>92%), lo matamos (0). Sino, 5m.
                            ttl = 0 if mem.percent > 92 else "5m"
                            requests.post(
                                f"{ollama_host}/api/generate",
                                json={"model": model_name, "keep_alive": ttl},
                                timeout=1,
                            )
                            print(
                                f"[RAM] ❄️ Especialista liberado para dar espacio: {model_name} (TTL: {ttl})"
                            )
        except Exception as e:
            print(f"[RAM] Error en protocolo de descarga asíncrona: {e}")

    threading.Thread(target=_async_unload, daemon=True).start()


def resolve_model_by_role(role="chat"):
    """Maps generic role tags to configured specific models based on Hardware Tier."""
    if ":" in role:
        role = role.split(":")[1]
    role = role.lower()

    # Consultar el Tier actual vía resource_monitor
    from modules.resource_monitor import monitor

    tier_id, _, _, _ = monitor.get_hardware_tier()
    tier_config = TIER_CONFIGS.get(tier_id, TIER_CONFIGS[2])

    # Matriz de Especialistas (Model Assignment Protocol)
    # Buscamos en DB (preferencia de usuario), si no, tomamos del Tier Config
    mapping = {
        "chat": database.get_setting("local_chat_model") or tier_config["chat"],
        "logic": database.get_setting("local_logic_model") or tier_config["logic"],
        "coder": database.get_setting("local_coder_model") or tier_config["coder"],
        "heavy": database.get_setting("local_heavy_model") or tier_config["heavy"],
        "oracle": database.get_setting("local_heavy_model") or tier_config["heavy"],
        "vision": database.get_setting("local_vision_model") or tier_config["vision"],
        "embedding": database.get_setting("router_embedding_model")
        or "mxbai-embed-large",
        "planner": database.get_setting("local_logic_model") or tier_config["logic"],
        "writer": database.get_setting("local_coder_model") or tier_config["coder"],
        "router": tier_config["chat"],
    }

    target = mapping.get(role, mapping["chat"])

    # Clean 'ollama-' prefix if present, but keep cloud names intact
    if any(x in target for x in ["gpt", "claude", "gemini"]):
        return target

    if target.startswith("ollama-"):
        target = target.replace("ollama-", "")

    # Ejecutar optimización de memoria si es necesario
    ollama_url = database.get_setting("ollama_url") or "http://127.0.0.1:11434"
    unload_model_except(target, ollama_url)

    return target


def route_request(
    user_input, file_metadata=None, api_key=None, source=None, ollama_host=None
):
    """
    NEURAL ROUTER: Classifies intent and checks for Swarm Balancing opportunities.
    """
    default_route = {"intent": "chat", "agents": ["chat"]}
    lower_input = user_input.lower()

    best_node = None

    # 1. IDE Source Override (Explicit Context)
    if source == "ide":
        res = {
            "intent": "mission",  # Force Mission for IDE
            "agents": ["coder"],
            "system_prompt": "You are a Senior Engineer. Answer directly. Solution only.",
        }
        # --- 4.1 ALTA SENSIBILIDAD (Neural Debate Trigger) ---
        critical_keywords = [
            "seguridad",
            "cifrado",
            "arquitectura",
            "crítico",
            "financiero",
            "auditoría",
            "parche",
        ]
        if any(kw in lower_input for kw in critical_keywords):
            print(" [ROUTER] ⚖️ Alta Sensibilidad Detectada. Activando Neural Debate.")
            res["debate"] = True
        return res

    # --- 0. HYBRID PATTERN MATCHING (Hard Triggers) ---
    # Prioridad absoluta a comandos de vida (Gastos/Agenda) que fallan semánticamente
    import re

    # Patrones de Finanzas estrictos (Verbo + Número o Moneda + Número)
    if re.search(r"\b(gaste|gasté|compré|pago|costó)\b.*\d+", lower_input) or re.search(
        r"(\$|€|£)\s*\d+", lower_input
    ):
        print(" ⚡ Regex Override: LIFE_FINANCE detected.")
        res = {
            "intent": "mission_life",
            "agents": ["life_manager"],
            "force_model": "coder",
        }
        # --- 4.1 ALTA SENSIBILIDAD (Neural Debate Trigger) ---
        critical_keywords = [
            "seguridad",
            "cifrado",
            "arquitectura",
            "crítico",
            "financiero",
            "auditoría",
            "parche",
        ]
        if any(kw in lower_input for kw in critical_keywords):
            print(" [ROUTER] ⚖️ Alta Sensibilidad Detectada. Activando Neural Debate.")
            res["debate"] = True
        return res

    # Patrones de Agenda: Detectar palabras temporales fuertes
    if re.search(
        r"(agend|reunión|reunion|cita|turno|dentista|médico|recorda|mañana a las|hoy a las)",
        lower_input,
    ):
        print("[ROUTER] ⚡ Regex Override: AGENDA detected.")
        res = {
            "intent": "mission_life",
            "agents": ["life_manager"],
            "force_model": "coder",
        }
        # --- 4.1 ALTA SENSIBILIDAD (Neural Debate Trigger) ---
        critical_keywords = [
            "seguridad",
            "cifrado",
            "arquitectura",
            "crítico",
            "financiero",
            "auditoría",
            "parche",
        ]
        if any(kw in lower_input for kw in critical_keywords):
            print(" [ROUTER] ⚖️ Alta Sensibilidad Detectada. Activando Neural Debate.")
            res["debate"] = True
        return res

    # 4. SEMANTIC ROUTING (Vector Similarity)
    has_attachment = file_metadata is not None
    semantic_intent = get_semantic_intent(
        user_input, ollama_host, has_attachment=has_attachment
    )
    if semantic_intent == "ambiguous":
        _user_name = database.get_user_fact("user_name", "identity") or "Usuario"
        return {
            "intent": "chat",
            "agents": ["chat"],
            "forced_response": f"{_user_name}, no estoy seguro de si esto es un registro de vida o un nuevo proyecto, ¿podrías aclararme?",
        }

    if semantic_intent:
        res = default_route
        if semantic_intent == "mission_project":
            res = {"intent": "mission_project", "agents": ["coder"]}
        elif semantic_intent == "mission_system":
            res = {"intent": "mission", "agents": ["coder"]}
        elif semantic_intent == "mission":
            res = {"intent": "mission", "agents": ["coder"]}
        elif semantic_intent == "mission_life":
            res = {
                "intent": "mission_life",
                "agents": ["life_manager"],
                "force_model": "coder",
            }
        else:
            res = {"intent": "chat", "agents": ["chat"]}

        # Apply Delegation if found
        if best_node and (
            res["intent"] in ["mission_project", "mission", "mission_life"]
        ):
            _user_name = database.get_user_fact("user_name", "identity") or "Usuario"
            res["delegate_to"] = best_node["node_id"]
            res["proactive_msg"] = (
                f"{_user_name}, he notado que tu nodo '{best_node['node_id']}' tiene un compute_score significativamente más alto ({best_node['compute_score']}). Voy a usar su potencia extra para procesar esto más rápido."
            )

        # --- 4.1 ALTA SENSIBILIDAD (Neural Debate Trigger) ---
        critical_keywords = [
            "seguridad",
            "cifrado",
            "arquitectura",
            "crítico",
            "financiero",
            "auditoría",
            "parche",
        ]
        if any(kw in lower_input for kw in critical_keywords):
            print(" [ROUTER] ⚖️ Alta Sensibilidad Detectada. Activando Neural Debate.")
            res["debate"] = True

        return res

    # 5. FALLBACK: CONSTRAINED LLM CLASSIFICATION
    # If semantics fail (no embedding model), use the small LLM with Strict JSON Output.

    # We construct a very specific prompt for JSON enforcement
    router_sys_prompt = (
        "You are a semantic classifier. You MUST output a JSON object with a single field 'intent'. \n"
        "Values: 'chat', 'mission', or 'mission_project'.\n"
        "Rules:\n"
        "- 'chat': Greetings, casual talk, jokes, general questions.\n"
        "- 'mission': Internal system tasks, refactoring existing files, fixing bugs.\n"
        "- 'mission_project': Creating NEW apps, games, scripts, or landing pages for the User.\n"
        "Output JSON ONLY."
    )

    # Input formatting
    user_prompt = f"Classify this input: '{user_input}'"
    if file_metadata:
        user_prompt += f"\nContext Files: {file_metadata}"

    try:
        response_text = ""
        local_model = resolve_model_by_role("router")

        # PROTOCOLO DE SEGURIDAD: Si el Router necesita realizar una "Clasificación de Refuerzo" (texto),
        # debe cambiar obligatoriamente al modelo definido en local_chat_model si el modelo de router es un modelo de embeddings.
        router_model_from_db = (
            database.get_setting("router_embedding_model") or "mxbai-embed-large"
        )
        if local_model == router_model_from_db or "embed" in local_model.lower():
            local_model = resolve_model_by_role("chat")

        # Call with format='json' (Handled by driver if prompt/system implies JSON)
        response_text = llm_drivers.query_ollama(
            router_sys_prompt,
            user_prompt,
            [],
            model=local_model,
            ollama_host=ollama_host or "http://127.0.0.1:11434",
            stream=False,
        )

        match = re.search(r"\{.*\}", str(response_text), re.DOTALL)
        if match:
            data = json.loads(match.group(0))
            if "intent" in data:
                # Map intent to agent config
                res = {"intent": "chat", "agents": ["chat"]}
                if data["intent"] == "mission_project":
                    res = {"intent": "mission_project", "agents": ["coder"]}
                if data["intent"] == "mission":
                    res = {"intent": "mission", "agents": ["coder"]}
                if data["intent"] == "mission_life":
                    res = {
                        "intent": "mission_life",
                        "agents": ["life_manager"],
                        "force_model": "coder",
                    }

                # --- 4.1 ALTA SENSIBILIDAD (Neural Debate Trigger) ---
                critical_keywords = [
                    "seguridad",
                    "cifrado",
                    "arquitectura",
                    "crítico",
                    "financiero",
                    "auditoría",
                    "parche",
                ]
                if any(kw in lower_input for kw in critical_keywords):
                    print(
                        " [ROUTER] ⚖️ Alta Sensibilidad Detectada. Activando Neural Debate."
                    )
                    res["debate"] = True
                return res

    except Exception as e:
        print(f"[ROUTER FAIL] Defaulting to Chat. Error: {e}")

    res = default_route
    # --- 4.1 ALTA SENSIBILIDAD (Neural Debate Trigger) ---
    critical_keywords = [
        "seguridad",
        "cifrado",
        "arquitectura",
        "crítico",
        "financiero",
        "auditoría",
        "parche",
    ]
    if any(kw in lower_input for kw in critical_keywords):
        print(" [ROUTER] ⚖️ Alta Sensibilidad Detectada. Activando Neural Debate.")
        res["debate"] = True
    return res


def extract_user_facts(history, api_key=None, ollama_host=None):
    """Analyzes history to extract graph triples and user facts."""
    context = ""
    for role, msg, ts in history[-6:]:  # Reducido a 6 para ser más preciso
        context += f"{role}: {msg}\n"

    # Nuevo prompt de extracción de grafos
    prompt = f"""
Extrae la información importante de esta conversación como una red de nodos (Sujeto, Predicado, Objeto).
FORMATO JSON OBLIGATORIO:
{{"triples": []}}
Ejemplo: Si digo "Mi proyecto Alpha usa Python", extrae: {{"triples": [["Alpha", "usa", "Python"]]}}
Conversación:
{context}
"""
    try:
        local_model = resolve_model_by_role("logic")  # Mejor para JSON estructurado
        response_text = llm_drivers.query_ollama(
            "Eres un extractor de grafos JSON puro.",
            prompt,
            [],
            model=local_model,
            ollama_host=ollama_host,
            require_json=True,
        )

        match = re.search(r"\{.*\}", str(response_text), re.DOTALL)
        if match:
            data = json.loads(match.group(0))
            triples = data.get("triples", [])
            for t in triples:
                if len(t) == 3:
                    import database

                    database.add_graph_triple(t[0], t[1], t[2])
                    database.add_user_fact(
                        f"{t[0]} {t[1]}", t[2], "graph_node", 0.9
                    )  # Guardar como fact tradicional también
    except Exception as e:
        print(f"Graph Extraction Error: {e}")


def summarize_context(history, api_key=None, ollama_host=None):
    """PROTOCOL CHRONOS: Generates executive summary."""
    use_local = not (api_key and str(api_key).startswith("AI"))

    prev_summary = database.get_latest_context_summary()
    fragment = ""
    for role, msg, ts in history:
        fragment += f"{role}: {msg}\n"

    prompt = prompts.get_chronos_summary_prompt(prev_summary, fragment)

    try:
        response_text = ""
        if not use_local:
            response_text = llm_drivers.query_gemini(
                "Summarizer", prompt, [], api_key, model_name="gemini-1.5-flash"
            )

        if not response_text:
            local_model = resolve_model_by_role("heavy")
            response_text = llm_drivers.query_ollama(
                "Summarizer", prompt, [], model=local_model, ollama_host=ollama_host
            )

        if response_text:
            database.add_user_fact(
                "chronos_summary", response_text, "context_summary", 1.0
            )

    except Exception as e:
        print(f"Chronos Error: {e}")


def decide_intent_legacy(prompt, model_choice_arg, api_key):
    """Legacy helper for Expense/Task detection (if still needed)."""
    # Simple keyword detection or small LLM call can go here
    # For now, implemented as no-op or basic heuristic to satisfy interface
    return {"intent": "chat", "args": {}}
