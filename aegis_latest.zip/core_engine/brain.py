import json
import database
import modules.system_tools as system_tools
import modules.codex
from module_manager import ModuleManager
from modules.resource_monitor import monitor
from core_engine import prompts, llm_drivers, router


class AegisBrain:
    def __init__(self):
        # Ollama Configuration
        raw_ollama = database.get_setting("ollama_url")
        self.ollama_host = raw_ollama or "http://localhost:11434"
        if self.ollama_host.endswith("/"):
            self.ollama_host = self.ollama_host[:-1]

        self.ollama_base_url = f"{self.ollama_host}/api/generate"
        self.module_manager = ModuleManager()
        self.ai_name = database.get_setting("ai_name") or "Aegis-IA"

        # OPTIMIZATION: Cache Static Info
        self.silent_report = system_tools.get_system_info()
        self.module_descriptions = self.module_manager.get_system_prompt_additions()
        self.user_name_cache = self._get_user_name_safe()

        # PRE-BUILD BASE PROMPT (Performance)
        self.system_instruction = prompts.get_system_instruction(
            self.ai_name,
            self.user_name_cache,
            self.silent_report,
            self.module_descriptions,
        )

    def _get_user_name_safe(self):
        try:
            val = database.get_user_fact("user_name", "identity")
            return val if val else "User"
        except Exception:
            return "User"

    def _get_api_key(self, provider):
        return database.get_setting(f"api_key_{provider.lower()}")

    def _get_available_ollama_models(self):
        return llm_drivers.get_available_ollama_models(self.ollama_host)

    def _get_mini_system_instruction(self):
        return prompts.get_mini_system_instruction(self.ai_name, self.user_name_cache)

    # --- WRAPPERS FOR DIRECT ACCESS (BACKWARD COMPATIBILITY) ---
    def query_gemini(
        self,
        prompt,
        history,
        api_key,
        model_name="gemini-pro",
        image_input=None,
        stream=False,
    ):
        return llm_drivers.query_gemini(
            self.system_instruction,
            prompt,
            history,
            api_key,
            model_name,
            image_input,
            stream,
        )

    def query_ollama(
        self, prompt, history, model="llama2", stream=False, image_input=None
    ):
        return llm_drivers.query_ollama(
            self.system_instruction,
            prompt,
            history,
            model,
            stream,
            image_input,
            self.ollama_host,
        )

    def query_openai(self, prompt, history, api_key, model_name="gpt-4o-mini"):
        return llm_drivers.query_openai_style(
            self.system_instruction,
            prompt,
            history,
            api_key,
            model_name,
            "https://api.openai.com/v1/chat/completions",
            "OpenAI",
        )

    def query_groq(self, prompt, history, api_key, model_name="llama3-70b-8192"):
        return llm_drivers.query_openai_style(
            self.system_instruction,
            prompt,
            history,
            api_key,
            model_name,
            "https://api.groq.com/openai/v1/chat/completions",
            "Groq",
        )

    def query_openrouter(
        self, prompt, history, api_key, model_name="google/gemini-2.0-flash-exp:free"
    ):
        return llm_drivers.query_openai_style(
            self.system_instruction,
            prompt,
            history,
            api_key,
            model_name,
            "https://openrouter.ai/api/v1/chat/completions",
            "OpenRouter",
        )

    def query_cerebras(self, prompt, history, api_key, model_name="llama3.1-70b"):
        return llm_drivers.query_openai_style(
            self.system_instruction,
            prompt,
            history,
            api_key,
            model_name,
            "https://api.cerebras.ai/v1/chat/completions",
            "Cerebras",
        )

    def query_anthropic(
        self, prompt, history, api_key, model_name="claude-3-haiku-20240307"
    ):
        return llm_drivers.query_anthropic(
            self.system_instruction, prompt, history, api_key, model_name
        )

    # --- ROUTING DELEGATES ---
    def route_request(self, user_input, file_metadata=None, api_key=None, **kwargs):
        return router.route_request(
            user_input, file_metadata, api_key, kwargs.get("source"), self.ollama_host
        )

    def decide_intent(self, prompt, model_choice_arg, api_key):
        return router.decide_intent_legacy(prompt, model_choice_arg, api_key)

    def extract_user_facts(self, history, api_key):
        return router.extract_user_facts(history, api_key, self.ollama_host)

    def summarize_context(self, history, api_key):
        return router.summarize_context(history, api_key, self.ollama_host)

    def resolve_model_by_role(self, role="chat"):
        return router.resolve_model_by_role(role)

    # --- MAIN QUERY LOGIC ---
    def query(
        self,
        prompt,
        history,
        model_choice_arg,
        api_key=None,
        profile="Balanced",
        image_input=None,
        stream=False,
        hive_override=False,
        key_ring=None,
        **kwargs,
    ):
        """Unified query interface."""

        # 1. SETUP & MODE DETECTION
        use_local_only = False
        if not api_key or not str(api_key).startswith("AI"):
            use_local_only = True

        active_model = database.get_setting("active_model") or "gemini-1.5-flash"
        hive_mode = database.get_setting("hive_mode") == "true" or hive_override
        if use_local_only:
            hive_mode = False  # Force off if no cloud for coordinator? Or use local coordinator? Logic implies cloud usually.

        # 2. CODEX INTERCEPTION (Tools)
        # Helper: Simple heuristic for 'save snippet'
        if "guardar" in prompt.lower() and (
            "código" in prompt.lower() or "snippet" in prompt.lower()
        ):
            lang, code = modules.codex.codex_system.extract_from_history(history)
            if code:
                try:
                    title = f"Snippet {self.user_name_cache}"
                    import re

                    q = re.search(r"['\"](.*?)['\"]", prompt)
                    if q:
                        title = q.group(1)
                    modules.codex.codex_system.save_snippet(
                        title, code, "autosave", lang
                    )
                    return f"💾 **The Codex**: Snippet guardado como *'{title}'*."
                except Exception:
                    pass

        # Helper: Simple heuristic for 'search snippet'
        codex_context = ""
        if any(w in prompt.lower() for w in ["cómo", "how to", "codex", "ejemplo"]):
            hits = modules.codex.codex_system.search(prompt)
            if hits:
                codex_context = "\n\n--- 📜 THE CODEX ---\n"
                for h in hits[:2]:
                    codex_context += (
                        f"Title: {h['title']}\n```{h['language']}\n{h['code']}\n```\n"
                    )

        # 3. DYNAMIC SYSTEM PROMPT CONSTRUCTION
        # Context Initialization
        projects = database.get_active_projects() or []
        p_str = ", ".join(projects)

        # Facts Injection
        facts_str = ""
        try:
            facts = database.get_user_facts()
            if facts:
                facts_str = "\n".join([f"- {k}: {v} ({c})" for k, v, c in facts[:10]])
        except Exception:
            pass

        # Resource Status
        res_status = monitor.get_status_metadata(profile)

        full_report = f"{self.silent_report}\n{res_status}"

        self.system_instruction = prompts.get_system_instruction(
            self.ai_name,
            self.user_name_cache,
            full_report,
            self.module_descriptions,
            p_str,
            facts_str,
            codex_context,
        )

        # 4. MODEL SELECTION & TIERING
        op_mode = database.get_setting("operation_mode") or "Hybrid"
        available_ollama = []
        if "Local" in op_mode:
            available_ollama = self._get_available_ollama_models()

        def detect_provider(m):
            if "gpt" in m:
                return "openai"
            if "claude" in m:
                return "anthropic"
            if "llama" in m and "groq" in m:
                return "groq"
            if "gemini" in m:
                return "gemini"
            return "ollama"

        primary = (detect_provider(active_model), active_model)

        # Override for Local Mode
        if op_mode == "Local Only (Sovereign)" and primary[0] != "ollama":
            l_chat = (database.get_setting("local_chat_model") or "llama3.1").replace(
                "ollama-", ""
            )
            primary = ("ollama", l_chat)

            # Fallback if specific model missing
            if (
                available_ollama
                and l_chat not in available_ollama
                and f"{l_chat}:latest" not in available_ollama
            ):
                primary = ("ollama", available_ollama[0])

        # Check Complexity for Economy Mode
        complexity = 0
        if image_input:
            complexity += 3
        if len(prompt.split()) > 50:
            complexity += 1
        if "code" in prompt.lower():
            complexity += 2

        if complexity < 4 and not hive_override and primary[0] != "ollama":
            # Downgrade to free/local if simple
            l_chat = (
                database.get_setting("local_chat_model") or "llama3.2:1b"
            ).replace("ollama-", "")
            primary = ("ollama", l_chat)

        # 5. DISPATCH CHAIN
        chain = [primary]

        # Fallbacks
        if primary[0] == "ollama":
            chain.append(("gemini", "gemini-1.5-flash"))  # Cloud backup
        else:
            chain.append(("ollama", "llama3.1"))  # Local backup

        # EXECUTE CHAIN
        errors = []
        for provider, model in chain:
            # Key Resolution
            current_key = None
            if key_ring and provider in key_ring:
                current_key = key_ring[provider]
            if not current_key:
                current_key = self._get_api_key(provider)
            if not current_key and provider == "gemini":
                current_key = api_key

            # Global shared keys fallback
            if not current_key and provider != "ollama":
                try:
                    with open("global_config/shared_keys.json", "r") as f:
                        current_key = json.load(f).get(provider)
                except Exception:
                    pass

            if not current_key and provider != "ollama":
                errors.append(f"{provider}: Missing Key")
                continue

            # Hive Mind Injection?
            if hive_mode and not image_input:
                self.system_instruction += prompts.HIVE_INSTRUCTION

            res = None
            if provider == "gemini":
                res = self.query_gemini(
                    prompt, history, current_key, model, image_input, stream
                )
            elif provider == "ollama":
                res = self.query_ollama(prompt, history, model, stream, image_input)
            elif provider == "openai":
                res = self.query_openai(prompt, history, current_key, model)
            elif provider == "anthropic":
                res = self.query_anthropic(prompt, history, current_key, model)
            elif provider == "groq":
                res = self.query_groq(prompt, history, current_key, model)
            elif provider == "openrouter":
                res = self.query_openrouter(prompt, history, current_key, model)
            elif provider == "cerebras":
                res = self.query_cerebras(prompt, history, current_key, model)

            if res and not (isinstance(res, str) and "Error" in res):
                return res

            if res:
                errors.append(res)

        return f"CRITICAL FAILURE: {errors}"
