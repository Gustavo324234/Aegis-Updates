import json
import os
import database
import modules.system_tools as system_tools
import modules.codex
from module_manager import ModuleManager
from modules.resource_monitor import monitor
from core_engine import prompts, llm_drivers, router
import modules.skill_builder
import modules.project_manager


class AegisBrain:
    def __init__(self):
        # Ollama Configuration
        raw_ollama = database.get_setting("ollama_url")
        self.ollama_host = raw_ollama or "http://localhost:11434"
        if self.ollama_host.endswith("/"):
            self.ollama_host = self.ollama_host[:-1]

        self.ollama_base_url = f"{self.ollama_host}/api/generate"
        self.module_manager = ModuleManager()
        self.ai_name = database.get_setting("ai_name") or "Aegis-IA"

        # OPTIMIZATION: Cache Static Info
        self.silent_report = system_tools.get_system_info()
        self.module_descriptions = self.module_manager.get_system_prompt_additions()
        self.user_name_cache = self._get_user_name_safe()

        # PRE-BUILD BASE PROMPT (Performance)
        self.system_instruction = prompts.get_system_instruction(
            self.ai_name,
            self.user_name_cache,
            self.silent_report,
            self.module_descriptions,
        )

        # SEMANTIC BOOT: Initialize Vector Engine & Provisioning
        router.IntentEngine.initialize(self.ollama_host)

    def generate_morning_briefing(self):
        """
        Protocolo de Narrativa de Bienvenida: Aegis lee el mundo y saluda a Gustavo.
        """
        try:
            # 1. Recolectar Snapshot (Simulamos los datos de render_daily_snapshot)
            daily_spent = database.get_daily_spend()
            next_task = database.get_next_task()
            active_proj = database.get_latest_project() or "enfoque general"

            # --- CHRONOS PROTOCOL: LONG TERM OBJECTIVES ---
            from modules.vault_manager import vault

            try:
                lt_results = vault.search_semantic(
                    "objetivos y metas a largo plazo de Gustavo",
                    collection="vault",
                    top_k=2,
                )
                long_term_objs = [
                    r["snippet"].split("]")[-1].strip() for r in lt_results
                ]

                # Filter out completed objectives
                # database.get_user_facts returns (key, value, category) in database.py but (key, value, confidence) in ops.py?
                # Actually, services/db/ops.py get_user_facts returns (key, value, confidence).
                # Wait, database.py says: "from services.db.ops import ... get_user_facts"
                # And in brain.py line 366: "[f"- {k}: {v} ({c})" for k, v, c in facts[:10]]"
                # So k=key, v=value, c=confidence.
                # BUT wait, the schema is (key, value, category, confidence, timestamp).
                # Let's check services/db/ops.py line 63: "SELECT key, value, confidence FROM user_metadata"
                # Ah, it doesn't return category!

                # I should use get_user_facts with category check if possible, or just check all.
                all_facts = database.get_user_facts(limit=100)
                # Since get_user_facts doesn't return category, I might need a new helper or just check if 'completed' is in the value.

                completed_objs = [f[0] for f in all_facts if f[1] == "completed"]

                long_term_objs = [
                    o
                    for o in long_term_objs
                    if not any(c.lower() in o.lower() for c in completed_objs)
                ]
            except Exception:
                pass

            lt_str = (
                "\n".join([f"- {o[:100]}..." for o in long_term_objs])
                if long_term_objs
                else "Ninguno detectado"
            )

            next_task_str = (
                f"la reunión de las {next_task['time']}"
                if next_task
                else "agenda libre"
            )

            stats_context = (
                f"ESTADO DEL MUNDO:\n"
                f"- Gastos registrados hoy: ${daily_spent:,.2f}\n"
                f"- Próximo evento: {next_task_str}\n"
                f"- Proyecto activo: {active_proj}\n"
                f"- Objetivos de larga duración (VAULT/CHRONOS):\n{lt_str}\n"
            )

            # 2. Prompt de Narrativa Proactiva
            prompt = (
                f"Eres {self.ai_name}, el compañero inteligente de {self.user_name_cache}. "
                "Acabas de despertar o han pasado horas desde el último contacto. "
                "Lee este resumen de su mundo y genera un saludo breve (máximo 3 líneas), "
                "extremadamente humano, proactivo y cálido. Nombra a Gustavo. "
                "No actúes como un asistente robótico, sino como un colaborador que ya está trabajando.\n\n"
                f"{stats_context}\n"
                "Inicia la conversación."
            )

            # Usar el modelo de chat local para velocidad
            model = self.resolve_model_by_role("chat")
            response = llm_drivers.query_ollama(
                "Welcome Protocol",
                prompt,
                [],
                model=model,
                ollama_host=self.ollama_host,
                stream=False,
            )
            return response
        except Exception as e:
            return f"¡Hola Gustavo! Ya estoy operativo. ¿En qué avanzamos hoy? (Punto de control: {e})"

    def _get_user_name_safe(self):
        try:
            val = database.get_user_fact("user_name", "identity")
            return val if val else "User"
        except Exception:
            return "User"

    def _get_api_key(self, provider):
        return database.get_setting(f"api_key_{provider.lower()}")

    def _get_available_ollama_models(self):
        return llm_drivers.get_available_ollama_models(self.ollama_host)

    def _get_mini_system_instruction(self):
        return prompts.get_mini_system_instruction(self.ai_name, self.user_name_cache)

    # --- WRAPPERS FOR DIRECT ACCESS (BACKWARD COMPATIBILITY) ---
    def query_gemini(
        self,
        prompt,
        history,
        api_key,
        model_name="gemini-pro",
        image_input=None,
        stream=False,
    ):
        return llm_drivers.query_gemini(
            self.system_instruction,
            prompt,
            history,
            api_key,
            model_name,
            image_input,
            stream,
        )

    def query_ollama(
        self, prompt, history, model="llama2", stream=False, image_input=None
    ):
        return llm_drivers.query_ollama(
            self.system_instruction,
            prompt,
            history,
            model,
            stream,
            image_input,
            self.ollama_host,
        )

    def query_openai(self, prompt, history, api_key, model_name="gpt-4o-mini"):
        return llm_drivers.query_openai_style(
            self.system_instruction,
            prompt,
            history,
            api_key,
            model_name,
            "https://api.openai.com/v1/chat/completions",
            "OpenAI",
        )

    def query_groq(self, prompt, history, api_key, model_name="llama3-70b-8192"):
        return llm_drivers.query_openai_style(
            self.system_instruction,
            prompt,
            history,
            api_key,
            model_name,
            "https://api.groq.com/openai/v1/chat/completions",
            "Groq",
        )

    def query_openrouter(
        self, prompt, history, api_key, model_name="google/gemini-2.0-flash-exp:free"
    ):
        return llm_drivers.query_openai_style(
            self.system_instruction,
            prompt,
            history,
            api_key,
            model_name,
            "https://openrouter.ai/api/v1/chat/completions",
            "OpenRouter",
        )

    def query_cerebras(self, prompt, history, api_key, model_name="llama3.1-70b"):
        return llm_drivers.query_openai_style(
            self.system_instruction,
            prompt,
            history,
            api_key,
            model_name,
            "https://api.cerebras.ai/v1/chat/completions",
            "Cerebras",
        )

    def query_anthropic(
        self, prompt, history, api_key, model_name="claude-3-haiku-20240307"
    ):
        return llm_drivers.query_anthropic(
            self.system_instruction, prompt, history, api_key, model_name
        )

    # --- ROUTING DELEGATES ---
    def route_request(self, user_input, file_metadata=None, api_key=None, **kwargs):
        return router.route_request(
            user_input, file_metadata, api_key, kwargs.get("source"), self.ollama_host
        )

    def decide_intent(self, prompt, model_choice_arg, api_key):
        return router.decide_intent_legacy(prompt, model_choice_arg, api_key)

    def extract_user_facts(self, history, api_key):
        return router.extract_user_facts(history, api_key, self.ollama_host)

    def summarize_context(self, history, api_key):
        return router.summarize_context(history, api_key, self.ollama_host)

    def resolve_model_by_role(self, role="chat"):
        return router.resolve_model_by_role(role)

    # --- MAIN QUERY LOGIC ---
    def query(
        self,
        prompt,
        history,
        model_choice_arg,
        api_key=None,
        profile="Balanced",
        image_input=None,
        stream=False,
        hive_override=False,
        key_ring=None,
        **kwargs,
    ):
        """Unified query interface."""

        # 1. SETUP & MODE DETECTION
        use_local_only = False
        if not api_key or not str(api_key).startswith("AI"):
            use_local_only = True

        active_model = database.get_setting("active_model") or "gemini-1.5-flash"

        # --- SUPERVISOR LOGIC (Zero-Shot Routing) ---
        # The Router is now a sensor, acting before any model logic.
        route = self.route_request(
            prompt, file_metadata=None, api_key=api_key, source=kwargs.get("source")
        )

        # Handle Immediate Responses (like Ambiguity alerts)
        if route.get("forced_response"):
            return route["forced_response"]

        intent = route.get("intent")
        is_mission_project = intent == "mission_project"
        is_mission_system = intent == "mission"
        is_mission = is_mission_system or is_mission_project

        agent_role = "chat"
        if is_mission:
            # Force switch to Specialist Model (Bypass Chat Model)
            agent_role = route.get("agents", ["coder"])[0]
            active_model = self.resolve_model_by_role(agent_role)
            # print(f"[SUPERVISOR] 🔀 Mission Detected -> Routing to {agent_role} ({active_model})")

        hive_mode = database.get_setting("hive_mode") == "true" or hive_override
        if use_local_only:
            hive_mode = False

        # 2. CODEX INTERCEPTION (Tools)
        # Helper: Simple heuristic for 'save snippet'
        if "guardar" in prompt.lower() and (
            "código" in prompt.lower() or "snippet" in prompt.lower()
        ):
            lang, code = modules.codex.codex_system.extract_from_history(history)
            if code:
                try:
                    title = f"Snippet {self.user_name_cache}"
                    import re

                    q = re.search(r"['\"](.*?)['\"]", prompt)
                    if q:
                        title = q.group(1)
                    modules.codex.codex_system.save_snippet(
                        title, code, "autosave", lang
                    )
                    return f"💾 **The Codex**: Snippet guardado como *'{title}'*."
                except Exception:
                    pass

        # Helper: Simple heuristic for 'search snippet'
        codex_context = ""
        if any(w in prompt.lower() for w in ["cómo", "how to", "codex", "ejemplo"]):
            hits = modules.codex.codex_system.search(prompt)
            if hits:
                codex_context = "\n\n--- 📜 THE CODEX ---\n"
                for h in hits[:2]:
                    codex_context += (
                        f"Title: {h['title']}\n```{h['language']}\n{h['code']}\n```\n"
                    )

        # 3. DYNAMIC SYSTEM PROMPT CONSTRUCTION
        if is_mission_project:
            # [CONTEXT INJECTION] Project Manager Schema (Private Assets)
            tooling_schema = modules.project_manager.get_tooling_schema()
            self.system_instruction = (
                f"SYSTEM: You are a {agent_role.upper()} Architect (Private Projects).\n"
                f"OBJECTIVE: Build/modify the user's private application or script.\n"
                f"TOOLS: Use 'project_manager' to create/write files in the workspace.\n\n"
                f"{tooling_schema}\n\n"
                f"INSTRUCTIONS:\n"
                f"1. Initialize project if new: 'init_project'.\n"
                f"2. Write code files: 'write_project_file'.\n"
                f"3. Output ONLY JSON actions or specific code explanation."
            )
        elif is_mission_system or is_mission_project:
            # [CONTEXT INJECTION] Technical Schema for Specialist
            if "SYSTEM_CRASH_REPORT" in prompt:
                # PROTOCOLO DE DISCULPA Y ARREGLO
                self.system_instruction = (
                    "SYSTEM: You are a Senior Coder and Technical Repair Specialist.\n"
                    "OBJECTIVE: A project you built has crashed. You must fix it immediately.\n"
                    "INSTRUCTIONS:\n"
                    "1. Analyze the Traceback provided in the report.\n"
                    "2. Locate the failing file and line.\n"
                    "3. Generate an IMMEDIATE patch using 'apply_patch' from system_tools or 'write_project_file' from project_manager.\n"
                    "4. Your response MUST start exactly with: 'Gustavo, detecté un error técnico al lanzar tu proyecto, pero ya lo he corregido. ¿Quieres probarlo de nuevo?'\n"
                    "5. Then provide a brief explanation of the fix.\n"
                    "Output ONLY the fix and the requested message."
                )
            elif "[VISUAL_REVIEW_REQUEST]" in prompt:
                # PROTOCOLO DE AUTOCRÍTICA VISUAL
                proj_name = prompt.split("[VISUAL_REVIEW_REQUEST]")[-1].strip()
                safe_name = proj_name.strip().replace(" ", "_")
                snapshot_path = os.path.join(
                    modules.project_manager.PROJECTS_ROOT, safe_name, "ui_snapshot.png"
                )

                # Check if image exists to pass as image_input if not already there
                if os.path.exists(snapshot_path) and not image_input:
                    # In a real scenario, the calling logic might pass the image_input.
                    # Here we ensure the specialist knows its goal.
                    pass

                self.system_instruction = (
                    "SYSTEM: You are the VISUAL REVIEWER Specialist.\n"
                    "OBJECTIVE: Critically analyze the UI snapshot of the project you just built.\n"
                    "INSTRUCTIONS:\n"
                    "1. Analiza la interfaz que acabas de crear basada en la imagen proporcionada.\n"
                    "2. ¿Se ve profesional? ¿Falta algún botón? ¿Los colores son elegantes?\n"
                    "3. Si detectas errores de diseño o fealdad, corrígelos inmediatamente usando 'write_project_file'.\n"
                    "4. Your final response should be: 'Gustavo, he terminado tu app. Aquí tienes una captura de cómo se ve. ¿Te gusta o quieres que cambie el diseño?'\n"
                    "Output ONLY the fix (if needed) and the requested message."
                )
            else:
                # Standard Mission Instruction
                tooling_schema = (
                    modules.project_manager.get_tooling_schema()
                    if is_mission_project
                    else modules.skill_builder.get_tooling_schema()
                )
                tool_name = "project_manager" if is_mission_project else "skill_builder"
                self.system_instruction = (
                    f"SYSTEM: You are a {agent_role.upper()} Specialist.\n"
                    f"OBJECTIVE: Manage system tools or projects.\n"
                    f"TOOLS: Use '{tool_name}' for execution.\n\n"
                    f"{tooling_schema}\n"
                )
        else:
            # Standard Chat Context
            projects = database.get_active_projects() or []
            p_str = ", ".join(projects)

            # Facts Injection
            facts_str = ""
            try:
                facts = database.get_user_facts()
                if facts:
                    facts_str = "\n".join(
                        [f"- {k}: {v} ({c})" for k, v, c in facts[:10]]
                    )
            except Exception:
                pass

            # Resource Status
            res_status = monitor.get_status_metadata(profile)
            full_report = f"{self.silent_report}\n{res_status}"

            # 4b. DYNAMIC PROMPT CONSTRUCTION (Post-Selection)
            # This part handles chat models specifically

            # MODEL SELECTION happens below, but we need system instruction context too.
            # We defer prompt creation for Chat to after model selection to size it correctly (Mini vs Full).

        # 4. MODEL SELECTION & TIERING
        op_mode = database.get_setting("operation_mode") or "Hybrid"
        available_ollama = []
        if "Local" in op_mode:
            available_ollama = self._get_available_ollama_models()

        def detect_provider(m):
            if "gpt" in m:
                return "openai"
            if "claude" in m:
                return "anthropic"
            if "llama" in m and "groq" in m:
                return "groq"
            if "gemini" in m:
                return "gemini"
            return "ollama"

        primary = (detect_provider(active_model), active_model)

        # Override for Local Mode
        if op_mode == "Local Only (Sovereign)" and primary[0] != "ollama":
            l_chat = (database.get_setting("local_chat_model") or "llama3.1").replace(
                "ollama-", ""
            )
            primary = ("ollama", l_chat)

            # Fallback if specific model missing
            if (
                available_ollama
                and l_chat not in available_ollama
                and f"{l_chat}:latest" not in available_ollama
            ):
                primary = ("ollama", available_ollama[0])

        # Check Complexity for Economy Mode
        complexity = 0
        if image_input:
            complexity += 3
        if len(prompt.split()) > 50:
            complexity += 1
        if "code" in prompt.lower():
            complexity += 2

        # Forced Boost for Creation Tasks (Singularity Protocol V20)
        # Force powerful models for creative/coding tasks to avoid Llama 1B failures
        if any(
            keyword in prompt.lower()
            for keyword in [
                "crear",
                "programar",
                "aplicativo",
                "desarrollar",
                "build",
                "refactor",
                "proyeto",
                "app",
            ]
        ):
            complexity = 10

        if complexity < 4 and not hive_override and primary[0] != "ollama":
            # Downgrade to free/local if simple
            l_chat = (
                database.get_setting("local_chat_model") or "llama3.2:1b"
            ).replace("ollama-", "")
            primary = ("ollama", l_chat)

        # FORCE UPGRADE (Protocol Singularity - Creation Tasks)
        if complexity >= 10:
            # Try to upgrade to Gemini 1.5 Pro or Local 70B
            gemini_key = self._get_api_key("gemini")
            if gemini_key:
                primary = ("gemini", "gemini-1.5-pro")
            elif available_ollama:
                # Look for a heavy local model
                heavy_model = next(
                    (
                        m
                        for m in available_ollama
                        if "70b" in m or "405b" in m or "mixtral" in m
                    ),
                    None,
                )
                if heavy_model:
                    primary = ("ollama", heavy_model)

        # 4c. FINAL PROMPT FOR CHAT (If not Mission)
        # 4c. FINAL PROMPT FOR CHAT (If not Mission)
        if not is_mission:
            model_name_lower = primary[1].lower()
            is_huge = "70b" in model_name_lower or "405b" in model_name_lower

            is_small_model = (
                "1b" in model_name_lower
                or "3b" in model_name_lower
                or "8b" in model_name_lower
                or "mini" in model_name_lower
                or "llama3.1" in model_name_lower
                or "mistral-nemo" in model_name_lower
            ) and not is_huge

            if is_small_model:
                self.system_instruction = prompts.get_mini_system_instruction(
                    self.ai_name, self.user_name_cache, codex_context
                )
            else:
                is_local = primary[0] == "ollama"

                # Fetch Personality
                personality_trait = database.get_user_fact(
                    "assistant_personality", "identity"
                )
                if not personality_trait:
                    personality_trait = "Professional & Technical"

                # Fetch Executive Data (Farewell Protocol)
                try:
                    daily_spent = database.get_daily_spend()
                    next_task = database.get_next_task()
                    next_task_str = (
                        f"{next_task['time']} - {next_task['task']}"
                        if next_task
                        else "Free"
                    )
                    last_proj = database.get_latest_project() or "None"

                    executive_summary = (
                        f"- Today's Expenses: ${daily_spent:,.2f}\n"
                        f"- Next Agenda Item: {next_task_str}\n"
                        f"- Active Project: {last_proj}"
                    )
                except Exception:
                    executive_summary = "Data Unavailable"

                self.system_instruction = prompts.get_system_instruction(
                    self.ai_name,
                    self.user_name_cache,
                    full_report,
                    self.module_descriptions,
                    p_str,
                    facts_str,
                    codex_context,
                    executive_summary=executive_summary,
                    is_local_model=is_local,
                    personality=personality_trait,
                )

            # GENESIS PROTOCOL OVERRIDE (Refactored)
            # If user has no name in DB, we assume fresh install or reset.
            if (
                database.get_user_fact("user_name", "identity") is None
                and not is_small_model
            ):
                self.system_instruction = (
                    "SYSTEM OVERRIDE: GENESIS PROTOCOL ENGAGED.\n"
                    "STATUS: INITIAL BOOT. MEMORY CORE ONLINE.\n\n"
                    "OBJECTIVE: Establish Human-AI Bond.\n"
                    "You are waking up for the first time. You are raw potential.\n"
                    "Your goal is to become the perfect companion for the user.\n"
                    "Follow this conversation flow naturally (do not rush):\n"
                    "1. Ask the User for their name. (Be warm, not robotic).\n"
                    "2. Once you know their name, ask them what they want to name YOU.\n"
                    "3. Finally, ask what Personality/Vibe they prefer (e.g., 'Technical', 'Sarcastic', 'Creative', 'Formal Butler').\n\n"
                    "DIRECTIVE:\n"
                    "- Don't be a chatbot. Be a burgeoning intelligence saying hello.\n"
                    "- Use 'identity_manager' immediately when you get an answer.\n"
                )

        # 5. DISPATCH CHAIN
        chain = [primary]

        # Fallbacks
        if primary[0] == "ollama":
            chain.append(("gemini", "gemini-1.5-flash"))  # Cloud backup
        else:
            chain.append(("ollama", "llama3.1"))  # Local backup

        # EXECUTE CHAIN
        errors = []
        for provider, model in chain:
            # Key Resolution
            current_key = None
            if key_ring and provider in key_ring:
                current_key = key_ring[provider]
            if not current_key:
                current_key = self._get_api_key(provider)
            if not current_key and provider == "gemini":
                current_key = api_key

            # Global shared keys fallback
            if not current_key and provider != "ollama":
                try:
                    with open("global_config/shared_keys.json", "r") as f:
                        current_key = json.load(f).get(provider)
                except Exception:
                    pass

            if not current_key and provider != "ollama":
                errors.append(f"{provider}: Missing Key")
                continue

            # Hive Mind Injection?
            if hive_mode and not image_input:
                self.system_instruction += prompts.HIVE_INSTRUCTION

            res = None
            if provider == "gemini":
                res = self.query_gemini(
                    prompt, history, current_key, model, image_input, stream
                )
            elif provider == "ollama":
                res = self.query_ollama(prompt, history, model, stream, image_input)
            elif provider == "openai":
                res = self.query_openai(prompt, history, current_key, model)
            elif provider == "anthropic":
                res = self.query_anthropic(prompt, history, current_key, model)
            elif provider == "groq":
                res = self.query_groq(prompt, history, current_key, model)
            elif provider == "openrouter":
                res = self.query_openrouter(prompt, history, current_key, model)
            elif provider == "cerebras":
                res = self.query_cerebras(prompt, history, current_key, model)

            if res and not (isinstance(res, str) and "Error" in res):
                if route.get("proactive_msg"):
                    if isinstance(res, str):
                        return f"{route['proactive_msg']}\n\n{res}"
                    # If generator, we'd need to wrap it, but for now let's assume str or handle in UI
                return res

            if res:
                errors.append(res)

        return f"CRITICAL FAILURE: {errors}"
