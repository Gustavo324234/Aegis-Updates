import json
import re
import database
import modules.system_tools as system_tools
import modules.codex
from module_manager import ModuleManager
from modules.resource_monitor import monitor
from core_engine import prompts, llm_drivers, router
import modules.skill_builder
import modules.project_manager


class AegisBrain:
    def __init__(self):
        # Ollama Configuration
        raw_ollama = database.get_setting("ollama_url")
        self.ollama_host = raw_ollama or "http://127.0.0.1:11434"
        if self.ollama_host.endswith("/"):
            self.ollama_host = self.ollama_host[:-1]

        self.ollama_base_url = f"{self.ollama_host}/api/chat"
        self.module_manager = ModuleManager()
        self.ai_name = database.get_setting("ai_name") or "Aegis-IA"

        # OPTIMIZATION: Cache Static Info
        self.silent_report = system_tools.get_system_info()
        self.module_descriptions = self.module_manager.get_system_prompt_additions()
        self.user_name_cache = self._get_user_name_safe()

        # PRE-BUILD BASE PROMPT (Performance)
        self.system_instruction = prompts.get_system_instruction(
            self.ai_name,
            self.user_name_cache,
            self.silent_report,
            self.module_descriptions,
        )

        # SEMANTIC BOOT: Initialize Vector Engine & Provisioning
        router.IntentEngine.initialize(self.ollama_host)

    def generate_morning_briefing(self):
        """
        Protocolo de Narrativa de Bienvenida: Aegis lee el mundo y saluda al usuario.
        """
        try:
            # 1. Recolectar Snapshot (Simulamos los datos de render_daily_snapshot)
            daily_spent = database.get_daily_spend()
            next_task = database.get_next_task()
            active_proj = database.get_latest_project() or "enfoque general"

            # --- CHRONOS PROTOCOL: LONG TERM OBJECTIVES ---
            from modules.vault_manager import vault

            try:
                lt_results = vault.search_semantic(
                    f"objetivos y metas a largo plazo de {self.user_name_cache}",
                    collection="vault",
                    top_k=2,
                )
                long_term_objs = [
                    r["snippet"].split("]")[-1].strip() for r in lt_results
                ]

                # Filter out completed objectives
                # database.get_user_facts returns (key, value, category) in database.py but (key, value, confidence) in ops.py?
                # Actually, services/db/ops.py get_user_facts returns (key, value, confidence).
                # Wait, database.py says: "from services.db.ops import ... get_user_facts"
                # And in brain.py line 366: "[f"- {k}: {v} ({c})" for k, v, c in facts[:10]]"
                # So k=key, v=value, c=confidence.
                # BUT wait, the schema is (key, value, category, confidence, timestamp).
                # Let's check services/db/ops.py line 63: "SELECT key, value, confidence FROM user_metadata"
                # Ah, it doesn't return category!

                # I should use get_user_facts with category check if possible, or just check all.
                all_facts = database.get_user_facts(limit=100)
                # Since get_user_facts doesn't return category, I might need a new helper or just check if 'completed' is in the value.

                completed_objs = [f[0] for f in all_facts if f[1] == "completed"]

                long_term_objs = [
                    o
                    for o in long_term_objs
                    if not any(c.lower() in o.lower() for c in completed_objs)
                ]
            except Exception:
                pass

            lt_str = (
                "\n".join([f"- {o[:100]}..." for o in long_term_objs])
                if long_term_objs
                else "Ninguno detectado"
            )

            next_task_str = (
                f"la reunión de las {next_task['time']}"
                if next_task
                else "agenda libre"
            )

            stats_context = (
                f"ESTADO DEL MUNDO:\n"
                f"- Gastos registrados hoy: ${daily_spent:,.2f}\n"
                f"- Próximo evento: {next_task_str}\n"
                f"- Proyecto activo: {active_proj}\n"
                f"- Objetivos de larga duración (VAULT/CHRONOS):\n{lt_str}\n"
            )

            # 2. Prompt de Narrativa Proactiva
            prompt = (
                f"Eres {self.ai_name}, el compañero inteligente de {self.user_name_cache}. "
                "Acabas de despertar o han pasado horas desde el último contacto. "
                "Lee este resumen de su mundo y genera un saludo breve (máximo 3 líneas), "
                f"extremadamente humano, proactivo y cálido. Nombra a {self.user_name_cache}. "
                "No actúes como un asistente robótico, sino como un colaborador que ya está trabajando.\n\n"
                f"{stats_context}\n"
                "Inicia la conversación."
            )

            # Usar el modelo de chat local para velocidad
            model = self.resolve_model_by_role("chat")
            response = llm_drivers.query_ollama(
                "Welcome Protocol",
                prompt,
                [],
                model=model,
                ollama_host=self.ollama_host,
                stream=False,
            )
            return response
        except Exception as e:
            return f"Estado Operativo: Activo. Hola {self.user_name_cache}, el núcleo de {self.ai_name} está listo. ¿Cuál es el objetivo de hoy? (Error: {e})"

    def _get_user_name_safe(self):
        try:
            val = database.get_user_fact("user_name", "identity")
            return val if val else "User"
        except Exception:
            return "User"

    def _get_api_key(self, provider):
        return database.get_setting(f"api_key_{provider.lower()}")

    def _get_available_ollama_models(self):
        return llm_drivers.get_available_ollama_models(self.ollama_host)

    def _get_mini_system_instruction(self):
        return prompts.get_mini_system_instruction(
            self.ai_name,
            self.user_name_cache,
            module_descriptions=self.module_descriptions,
        )

    # --- WRAPPERS FOR DIRECT ACCESS (BACKWARD COMPATIBILITY) ---
    def query_gemini(
        self,
        prompt,
        history,
        api_key,
        model_name="gemini-pro",
        image_input=None,
        stream=False,
    ):
        return llm_drivers.query_gemini(
            self.system_instruction,
            prompt,
            history,
            api_key,
            model_name,
            image_input,
            stream,
        )

    def query_ollama(
        self,
        prompt,
        history,
        model="llama2",
        stream=False,
        image_input=None,
        require_json=False,
    ):
        return llm_drivers.query_ollama(
            self.system_instruction,
            prompt,
            history,
            model,
            stream,
            image_input,
            self.ollama_host,
            require_json,
        )

    def query_openai(self, prompt, history, api_key, model_name="gpt-4o-mini"):
        return llm_drivers.query_openai_style(
            self.system_instruction,
            prompt,
            history,
            api_key,
            model_name,
            "https://api.openai.com/v1/chat/completions",
            "OpenAI",
        )

    def query_groq(self, prompt, history, api_key, model_name="llama3-70b-8192"):
        return llm_drivers.query_openai_style(
            self.system_instruction,
            prompt,
            history,
            api_key,
            model_name,
            "https://api.groq.com/openai/v1/chat/completions",
            "Groq",
        )

    def query_openrouter(
        self, prompt, history, api_key, model_name="google/gemini-2.0-flash-exp:free"
    ):
        return llm_drivers.query_openai_style(
            self.system_instruction,
            prompt,
            history,
            api_key,
            model_name,
            "https://openrouter.ai/api/v1/chat/completions",
            "OpenRouter",
        )

    def query_cerebras(self, prompt, history, api_key, model_name="llama3.1-70b"):
        return llm_drivers.query_openai_style(
            self.system_instruction,
            prompt,
            history,
            api_key,
            model_name,
            "https://api.cerebras.ai/v1/chat/completions",
            "Cerebras",
        )

    def query_anthropic(
        self, prompt, history, api_key, model_name="claude-3-haiku-20240307"
    ):
        return llm_drivers.query_anthropic(
            self.system_instruction, prompt, history, api_key, model_name
        )

    # --- ROUTING DELEGATES ---
    def route_request(self, user_input, file_metadata=None, api_key=None, **kwargs):
        return router.route_request(
            user_input, file_metadata, api_key, kwargs.get("source"), self.ollama_host
        )

    def decide_intent(self, prompt, model_choice_arg, api_key):
        return router.decide_intent_legacy(prompt, model_choice_arg, api_key)

    def extract_user_facts(self, history, api_key):
        return router.extract_user_facts(history, api_key, self.ollama_host)

    def summarize_context(self, history, api_key):
        return router.summarize_context(history, api_key, self.ollama_host)

    def resolve_model_by_role(self, role="chat"):
        return router.resolve_model_by_role(role)

    def neural_debate(self, prompt, history, current_key):
        """Coordina a tres modelos para llegar a un consenso."""
        # 1. Definir los tres especialistas
        # Usamos la Matriz de Especialistas configurada
        model_a = self.resolve_model_by_role("coder")  # El Técnico
        model_b = self.resolve_model_by_role("heavy")  # El Contextual
        model_juez = self.resolve_model_by_role("logic")  # El Juez (DeepSeek R1)

        print(f" 🧠 Iniciando Debate Neural entre: {model_a}, {model_b} y {model_juez}")

        # 2. Obtener respuestas iniciales (Simulado o en paralelo)
        # Nota: Usamos stream=False para el debate interno
        import concurrent.futures

        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
            future_a = executor.submit(
                self.query_ollama,
                f"Respuesta Técnica:\n{prompt}",
                [],
                model_a,
                stream=False,
            )
            future_b = executor.submit(
                self.query_ollama,
                f"Respuesta Contextual:\n{prompt}",
                [],
                model_b,
                stream=False,
            )
            res_a = future_a.result()
            res_b = future_b.result()

        # 3. El Juez analiza y sintetiza
        debate_prompt = f"""
[PROTOCOLO DE CONSENSO NEURAL]
El usuario solicitó: "{prompt}"

Contendiente A ({model_a}): {res_a}
Contendiente B ({model_b}): {res_b}

Tu tarea como Juez es:
1. Comparar ambas respuestas buscando contradicciones.
2. Si hay errores técnicos, corrígelos.
3. Genera la respuesta FINAL definitiva, proactiva y segura para el usuario.
No menciones a los contendientes, solo da la solución verificada.
"""
        final_verdict = self.query_ollama(debate_prompt, [], model_juez, stream=False)
        return f"<details><summary>⚖️ Consenso de Enjambre Aplicado</summary>Debate entre {model_a} y {model_b} arbitrado por {model_juez}.</details>\n\n{final_verdict}"

    def _get_tools_schema(self):
        """Genera el esquema JSON oficial para herramientas nativas (Ollama/OpenAI compatible)."""
        tools = []
        for name, module in self.module_manager.modules.items():
            if not self.module_manager.is_active(name):
                continue

            # Extraer descripción (Soporta MANIFEST de Skills y DESCRIPTION de módulos legacy)
            description = ""
            if hasattr(module, "MANIFEST"):
                description = f"Skill {name}: {module.MANIFEST.get('description', '')}"
            elif hasattr(module, "DESCRIPTION"):
                description = f"Modulo {name}: {module.DESCRIPTION}"

            # Limitar longitud para evitar saturar el contexto
            description = description[:800]

            tools.append(
                {
                    "type": "function",
                    "function": {
                        "name": name,
                        "description": description,
                        "parameters": {
                            "type": "object",
                            "properties": {
                                "action": {
                                    "type": "string",
                                    "description": "La acción a ejecutar",
                                },
                                "args": {
                                    "type": "object",
                                    "description": "Argumentos para la acción",
                                },
                            },
                            "required": ["action"],
                        },
                    },
                }
            )
        return tools

    # --- MAIN QUERY LOGIC ---
    def query(
        self,
        prompt,
        history,
        model_choice_arg,
        api_key=None,
        profile="Balanced",
        image_input=None,
        stream=False,
        hive_override=False,
        key_ring=None,
        **kwargs,
    ):
        """Unified query interface wrapped to handle hybrid status events."""
        gen = self._query_internal(
            prompt,
            history,
            model_choice_arg,
            api_key=api_key,
            profile=profile,
            image_input=image_input,
            stream=stream,
            hive_override=hive_override,
            key_ring=key_ring,
            **kwargs,
        )
        if stream:
            return gen
        else:
            final_str = ""
            for item in gen:
                if isinstance(item, dict) and item.get("type") == "status":
                    continue
                if hasattr(item, "text"):
                    final_str += item.text
                else:
                    final_str += str(item)
            return final_str

    def _query_internal(
        self,
        prompt,
        history,
        model_choice_arg,
        api_key=None,
        profile="Balanced",
        image_input=None,
        stream=False,
        hive_override=False,
        key_ring=None,
        **kwargs,
    ):
        """Internal generator unified query interface."""
        # --- CONTEXT WINDOW GUARD & COMPACTION ---
        if history and not kwargs.get("is_repair"):
            try:
                from core_engine.memory_guard import MemoryGuard

                guard = MemoryGuard(token_limit=8192)
                history = guard.compress_history(history, brain_instance=self)
            except Exception as e:
                print(f"[MemoryGuard] Warning: Failed to compress history: {e}")

        # --- RECURSION LIMIT (Singularity Guard) ---
        healing_depth = kwargs.get("healing_depth", 0)
        if healing_depth > 2:
            print(" ⚠️ Límite de Auto-Sanación alcanzado (Recursión detenida).")
            yield "ERROR: Máxima profundidad de auto-sanación alcanzada."
            return

        # 1. SETUP & MODE DETECTION
        use_local_only = False
        if not api_key or not str(api_key).startswith("AI"):
            use_local_only = True

        active_model = database.get_setting("active_model") or "gemini-1.5-flash"

        # --- SUPERVISOR LOGIC (Zero-Shot Routing) ---
        # The Router is now a sensor, acting before any model logic.
        route = self.route_request(
            prompt, file_metadata=None, api_key=api_key, source=kwargs.get("source")
        )

        if route.get("debate") and not kwargs.get(
            "is_repair"
        ):  # Evitar bucles en autoreparación
            yield {"type": "status", "msg": "⚖️ Iniciando Debate Neural..."}
            yield self.neural_debate(prompt, history, api_key)
            return

        # Handle Immediate Responses (like Ambiguity alerts)
        if route.get("forced_response"):
            yield route["forced_response"]
            return

        intent = route.get("intent")
        is_mission_project = intent == "mission_project"
        is_mission_system = intent == "mission"
        is_mission_life = intent == "mission_life"
        is_mission = is_mission_system or is_mission_project or is_mission_life

        # --- NUEVO: DETECCIÓN DE MISIONES ASÍNCRONAS (NIGHT SHIFT) ---
        night_shift_keywords = [
            "durante la noche",
            "en segundo plano",
            "lote",
            "night shift",
            "background",
        ]
        is_async = any(
            kw in prompt.lower() for kw in night_shift_keywords
        ) and not kwargs.get("is_planning")

        if is_async and is_mission:
            try:
                import streamlit as st

                st.toast("🌙 Protocolo Night Shift Activado", icon="🦉")
                with st.spinner("Planificando trabajo en segundo plano..."):
                    # Generar un plan de pasos usando el modelo Lógico
                    plan_prompt = f"Descompón esta tarea en pasos ejecutables para un agente automatizado. Devuelve un JSON array de strings. Tarea: {prompt}"
                    plan_response = self.query(
                        plan_prompt,
                        [],
                        "specialist:logic",
                        require_json=True,
                        is_planning=True,
                    )

                    try:
                        # Parsear pasos
                        json_match = re.search(r"\[.*\]", plan_response, re.DOTALL)
                        steps = json.loads(json_match.group(0)) if json_match else []

                        if steps:
                            # Encolar en la DB (Agent Missions)
                            database.create_mission(prompt, steps)

                            # Activar el Daemon Worker si estaba apagado
                            database.set_daemon_status("mission_worker", "RUNNING")

                            full_response = f"🌙 He encolado la misión con {len(steps)} pasos para ejecutarse en segundo plano. Te avisaré cuando termine."

                            # Intentar usar placeholder si está disponible en kwargs, o crear uno nuevo en Streamlit
                            placeholder = kwargs.get("placeholder")
                            if placeholder:
                                placeholder.markdown(full_response)
                            else:
                                st.markdown(full_response)

                            database.save_message(
                                "assistant",
                                full_response,
                                active_model,
                                kwargs.get("context", "general"),
                            )
                            yield {
                                "type": "status",
                                "msg": "🌙 Night Shift configurado...",
                            }
                            yield full_response
                            return  # Salir temprano, la UI ya no bloquea

                    except Exception as e:
                        print(f" Error de planificación: {e}")
                        # Fallback si el JSON falla, ejecutar normal
                        pass
            except ImportError:
                # No estamos en un entorno Streamlit, ignorar UI
                pass
        # --- FIN NIGHT SHIFT ---

        agent_role = "chat"
        if is_mission:
            # Force switch to Specialist Model (Bypass Chat Model)
            agent_role = route.get("agents", ["coder"])[0]

            # Resolve model based on force_model or role
            force = route.get("force_model")
            if force:
                active_model = self.resolve_model_by_role(force)
            else:
                active_model = self.resolve_model_by_role(agent_role)

            # --- MISSION MODEL HARDENING (Tier-Aware) ---
            # Si el modelo resuelto es pequeño, verificamos si podemos subir de nivel
            if any(
                small in str(active_model).lower()
                for small in [":1b", ":1.5b", ":3b", "llama3.2"]
            ):
                tier_id, _, _, _ = monitor.get_hardware_tier()

                if tier_id >= 2:  # Solo Tier 2+ soporta 7B confortablemente
                    print(
                        "[BRAIN] 🛡️ Hallucination Risk Detected. Hardware permits upgrade. Forcing Specialist."
                    )
                    # Usamos el resolver para respetar la config del usuario si tiene otro coder preferido de 7B
                    active_model = self.resolve_model_by_role("coder")
                    # Fallback si el resolver devolvió el mismo pequeño (mal configurado)
                    if "1b" in active_model.lower() or "3b" in active_model.lower():
                        active_model = "qwen2.5-coder:7b"
                else:
                    print(
                        f"[BRAIN] ⚠️ Low RAM (Tier 1). Risk accepted; staying with {active_model}."
                    )

            # print(f"[SUPERVISOR] 🔀 Mission Detected -> Routing to {agent_role} ({active_model})")

        hive_mode = database.get_setting("hive_mode") == "true" or hive_override
        if use_local_only:
            hive_mode = False

        # 2. CODEX INTERCEPTION (Tools)
        # Helper: Simple heuristic for 'save snippet'
        if "guardar" in prompt.lower() and (
            "código" in prompt.lower() or "snippet" in prompt.lower()
        ):
            lang, code = modules.codex.codex_system.extract_from_history(history)
            if code:
                try:
                    title = f"Snippet {self.user_name_cache}"

                    q = re.search(r"['\"](.*?)['\"]", prompt)
                    if q:
                        title = q.group(1)
                    modules.codex.codex_system.save_snippet(
                        title, code, "autosave", lang
                    )
                    yield f"💾 **The Codex**: Snippet guardado como *'{title}'*."
                    return
                except Exception:
                    pass

        # Helper: Simple heuristic for 'search snippet'
        codex_context = ""
        if any(w in prompt.lower() for w in ["cómo", "how to", "codex", "ejemplo"]):
            hits = modules.codex.codex_system.search(prompt)
            if hits:
                codex_context = "\n\n--- 📜 THE CODEX ---\n"
                for h in hits[:2]:
                    codex_context += (
                        f"Title: {h['title']}\n```{h['language']}\n{h['code']}\n```\n"
                    )

        # 3. DYNAMIC SYSTEM PROMPT CONSTRUCTION
        if intent == "chat":
            # LAZY LOADING: Minimal prompt for simple interactions (No DB calls)
            self.system_instruction = prompts.get_mini_system_instruction(
                self.ai_name,
                self.user_name_cache,
                codex_context,
                module_descriptions=self.module_descriptions,
            )
        else:
            # HEAVY LOADING: Deep context for Missions (Project, System, Life)
            master_sys = prompts.get_system_instruction(
                self.ai_name,
                self.user_name_cache,
                self.silent_report,
                self.module_descriptions,
                executive_summary=kwargs.get("executive_summary", "Ready"),
                personality=database.get_user_fact("assistant_personality", "identity")
                or "Proactivo",
            )

        if is_mission_project:
            # [CONTEXT INJECTION] Project Manager Schema (Private Assets)
            self.system_instruction = (
                f"{master_sys}\n\n"
                f"--- PROJECT SPECIALIST PROTOCOL ---\n"
                f"OBJECTIVE: Build/modify the user's private application.\n"
                f"INSTRUCTIONS:\n"
                f"1. Use native tool calls for workspace files.\n"
                f"2. You can STILL use core tools (life_manager, etc.) if requested."
            )
        elif is_mission_system:
            # [CONTEXT INJECTION] Technical Schema for Specialist
            if "SYSTEM_CRASH_REPORT" in prompt:
                self.system_instruction = (
                    f"{master_sys}\n\n"
                    "--- TECHNICAL REPAIR SPECIALIST ---\n"
                    "OBJECTIVE: Fix the project crash immediately.\n"
                    f"START RESPONSE WITH: '{self.user_name_cache}, detecté un error técnico...'"
                )
            elif "[VISUAL_REVIEW_REQUEST]" in prompt:
                self.system_instruction = (
                    f"{master_sys}\n\n"
                    "--- VISUAL REVIEWER Specialist ---\n"
                    "OBJECTIVE: Critique and polish the UI.\n"
                    f"FINAL MSG: '{self.user_name_cache}, he terminado tu app...'"
                )
            else:
                agent_name = (
                    "project_manager" if is_mission_project else "skill_builder"
                )
                self.system_instruction = (
                    f"{master_sys}\n\n"
                    f"--- SPECIALIST MISSION ({agent_role.upper()}) ---\n"
                    f"INSTRUCTIONS: Use native tool calls for '{agent_name}'.\n"
                )
        elif is_mission_life:
            # Standard Mission Life Context
            projects = database.get_active_projects() or []
            p_str = ", ".join(projects)

            facts_str = ""
            try:
                facts = database.get_user_facts()
                if facts:
                    facts_str = "\n".join(
                        [f"- {k}: {v} ({c})" for k, v, c in facts[:10]]
                    )
            except Exception:
                pass

            res_status = monitor.get_status_metadata(profile)
            full_report = f"{self.silent_report}\n{res_status}"

        # 4. MODEL SELECTION & TIERING
        op_mode = database.get_setting("operation_mode") or "Hybrid"
        available_ollama = []
        if "Local" in op_mode:
            available_ollama = self._get_available_ollama_models()

        def detect_provider(m):
            if "gpt" in m:
                return "openai"
            if "claude" in m:
                return "anthropic"
            if "llama" in m and "groq" in m:
                return "groq"
            if "gemini" in m:
                return "gemini"
            return "ollama"

        primary = (detect_provider(active_model), active_model)

        # Override for Local Mode
        if op_mode == "Local Only (Sovereign)" and primary[0] != "ollama":
            l_chat = (database.get_setting("local_chat_model") or "llama3.1").replace(
                "ollama-", ""
            )
            primary = ("ollama", l_chat)

            # Fallback if specific model missing
            if (
                available_ollama
                and l_chat not in available_ollama
                and f"{l_chat}:latest" not in available_ollama
            ):
                primary = ("ollama", available_ollama[0])

        # Check Complexity for Economy Mode
        complexity = 0
        if image_input:
            complexity += 3
        if len(prompt.split()) > 50:
            complexity += 1
        if "code" in prompt.lower():
            complexity += 2

        # Forced Boost for Creation Tasks (Singularity Protocol V20)
        # Force powerful models for creative/coding tasks to avoid Llama 1B failures
        if any(
            keyword in prompt.lower()
            for keyword in [
                "crear",
                "programar",
                "aplicativo",
                "desarrollar",
                "build",
                "refactor",
                "proyeto",
                "app",
            ]
        ):
            complexity = 10

        if complexity < 4 and not hive_override and primary[0] != "ollama":
            # Downgrade to free/local if simple
            l_chat = (
                database.get_setting("local_chat_model") or "llama3.2:1b"
            ).replace("ollama-", "")
            primary = ("ollama", l_chat)

        # FORCE UPGRADE (Protocol Singularity - Creation Tasks)
        if complexity >= 10:
            # Try to upgrade to Gemini 1.5 Pro or Local 70B
            gemini_key = self._get_api_key("gemini")
            if gemini_key:
                primary = ("gemini", "gemini-1.5-pro")
            elif available_ollama:
                # Look for a heavy local model
                heavy_model = next(
                    (
                        m
                        for m in available_ollama
                        if "70b" in m or "405b" in m or "mixtral" in m
                    ),
                    None,
                )
                if heavy_model:
                    primary = ("ollama", heavy_model)
                else:
                    # FALLBACK SOBERANO: qwen2.5-coder es el mejor modelo local garantizado
                    coder_model = next(
                        (m for m in available_ollama if "qwen2.5-coder" in m),
                        "qwen2.5-coder",
                    )
                    primary = ("ollama", coder_model)
                    print(
                        f"[BRAIN] ⚡ FORCE UPGRADE: No 70B found. Falling back to sovereign coder: {coder_model}"
                    )

        # 4c. FINAL PROMPT ASSEMBLY (Mission Life only)
        if is_mission_life:
            model_name_lower = primary[1].lower()
            is_huge = "70b" in model_name_lower or "405b" in model_name_lower

            is_small_model = (
                "1b" in model_name_lower
                or "3b" in model_name_lower
                or "8b" in model_name_lower
                or "mini" in model_name_lower
                or "llama3.1" in model_name_lower
                or "mistral-nemo" in model_name_lower
            ) and not is_huge

            if is_small_model:
                self.system_instruction = prompts.get_mini_system_instruction(
                    self.ai_name,
                    self.user_name_cache,
                    codex_context,
                    module_descriptions=self.module_descriptions,
                )
                self.system_instruction += "\n[SYSTEM WARNING]: Estás usando un motor limitado (< 4B). Las capacidades de razonamiento proactivo podrían verse disminuidas."
            else:
                is_local = primary[0] == "ollama"

                # Fetch Personality
                personality_trait = database.get_user_fact(
                    "assistant_personality", "identity"
                )
                if not personality_trait:
                    personality_trait = "Professional & Technical"

                # Fetch Executive Data (Farewell Protocol)
                try:
                    daily_spent = database.get_daily_spend()
                    next_task = database.get_next_task()
                    next_task_str = (
                        f"{next_task['time']} - {next_task['task']}"
                        if next_task
                        else "Free"
                    )
                    last_proj = database.get_latest_project() or "None"

                    executive_summary = (
                        f"- Today's Expenses: ${daily_spent:,.2f}\n"
                        f"- Next Agenda Item: {next_task_str}\n"
                        f"- Active Project: {last_proj}"
                    )
                except Exception:
                    executive_summary = "Data Unavailable"

                self.system_instruction = prompts.get_system_instruction(
                    self.ai_name,
                    self.user_name_cache,
                    full_report,
                    self.module_descriptions,
                    p_str,
                    facts_str,
                    codex_context,
                    executive_summary=executive_summary,
                    is_local_model=is_local,
                    personality=personality_trait,
                )

            pass

        # --- 4.5 PROTOCOLO RAG PASIVO (Memoria Asociativa) ---
        if intent != "chat":  # Evitamos RAG en saludos simples para ahorrar RAM
            try:
                from modules.vault_manager import vault

                # Búsqueda silenciosa en el Vault
                yield {
                    "type": "status",
                    "msg": "🧠 Buscando contexto en tu baúl de proyectos (RAG)...",
                }
                rag_results = vault.search_semantic(prompt, collection="vault", top_k=2)
                if rag_results:
                    rag_context = "\n\n"
                    for r in rag_results:
                        rag_context += f"- {r}\n"

                    # Se lo inyectamos al System Prompt
                    self.system_instruction += rag_context
                    print(f" 🧠 RAG Pasivo inyectó {len(rag_results)} recuerdos.")
            except Exception as e:
                print(f" ⚠️ Error en RAG Pasivo: {e}")

        # --- 4.6 PROTOCOLO GRAPH RAG (Conexiones Lógicas) ---
        if intent != "chat":
            try:
                # Extracción simple de entidades (palabras clave > 5 letras del prompt)
                yield {
                    "type": "status",
                    "msg": "🕸️ Analizando tus dependencias y Grafos (Graph RAG)...",
                }
                clean_prompt = re.sub(r"[^\w\s]", "", prompt.lower())
                entities = [w for w in clean_prompt.split() if len(w) > 5]

                graph_context = []
                for entity in entities[:4]:  # Consultar hasta 4 conceptos clave
                    graph_context.extend(database.get_graph_context(entity))

                if graph_context:
                    # Deduplicar y formatear
                    graph_str = "\n".join(list(set(graph_context)))
                    self.system_instruction += f"\n\n\n{graph_str}\n"
                    print(
                        f" 🕸️ Graph RAG inyectó {len(set(graph_context))} aristas lógicas."
                    )
            except Exception as e:
                print(f" ⚠️ Error en Graph RAG: {e}")

        # 5. DISPATCH CHAIN
        chain = [primary]

        # Fallbacks
        if primary[0] == "ollama":
            chain.append(("gemini", "gemini-1.5-flash"))  # Cloud backup
        else:
            chain.append(
                ("ollama", "llama3.2:1b")
            )  # Local backup (guaranteed installed)

        # EXECUTE CHAIN
        errors = []
        for provider, model in chain:
            # Check Health
            if not router.ModelHealth.is_healthy(provider):
                print(f"[BRAIN] ⏳ Skipping {provider} due to cooldown.")
                continue

            # Key Resolution
            current_key = None
            if key_ring and provider in key_ring:
                current_key = key_ring[provider]
            if not current_key:
                current_key = self._get_api_key(provider)
            if not current_key and provider == "gemini":
                current_key = api_key

            # Global shared keys fallback
            if not current_key and provider != "ollama":
                try:
                    with open("global_config/shared_keys.json", "r") as f:
                        current_key = json.load(f).get(provider)
                except Exception:
                    pass

            if not current_key and provider != "ollama":
                errors.append(f"{provider}: Missing Key")
                continue

            # Hive Mind Injection?
            if hive_mode and not image_input:
                self.system_instruction += prompts.HIVE_INSTRUCTION

            intent = route.get("intent")
            is_mission = intent in ["mission", "mission_project", "mission_life"]
            strict_json_required = intent == "mission_project"

            try:
                if provider == "gemini":
                    res = self.query_gemini(
                        prompt, history, current_key, model, image_input, stream
                    )
                elif provider == "ollama":
                    # --- SWARM OFFLOADING ---
                    target_node = route.get("delegate_to")
                    if target_node and target_node != "Local":
                        # (Async delegation logic omitted for brevity, same as before)
                        res = self.query_ollama(
                            prompt,
                            history,
                            model,
                            stream,
                            image_input,
                            require_json=strict_json_required,
                            tools=self._get_tools_schema() if is_mission else None,
                        )
                    else:
                        res = self.query_ollama(
                            prompt,
                            history,
                            model,
                            stream,
                            image_input,
                            require_json=strict_json_required,
                            tools=self._get_tools_schema() if is_mission else None,
                        )
                elif provider == "openai":
                    res = self.query_openai(prompt, history, current_key, model)
                elif provider == "anthropic":
                    res = self.query_anthropic(prompt, history, current_key, model)
                elif provider == "groq":
                    res = self.query_groq(prompt, history, current_key, model)
                elif provider == "openrouter":
                    res = self.query_openrouter(prompt, history, current_key, model)
                elif provider == "cerebras":
                    res = self.query_cerebras(prompt, history, current_key, model)

                if res:
                    router.ModelHealth.report_success(provider)

                    # Tool Interception
                    if isinstance(res, dict) and "tool_calls" in res:
                        tool_calls = res.get("tool_calls", [])
                        content = res.get("content", "")
                        results = []
                        for call in tool_calls:
                            func_name = call["function"]["name"]
                            arguments = call["function"]["arguments"]
                            print(
                                f" ⚙️ Aegis-IA: Ejecutando herramienta nativa '{func_name}'"
                            )
                            tool_res = self.module_manager.execute_module(
                                func_name, arguments, brain_instance=self
                            )
                            results.append(str(tool_res))
                        yield f"{content}\n\n" + "\n".join(results)
                        return

                    if route.get("proactive_msg"):
                        yield f"{route.get('proactive_msg')}\n\n"

                    buffer = ""
                    if (
                        stream
                        and isinstance(
                            res, (type((x for x in [])), type(self._query_internal))
                        )
                        or (
                            stream
                            and hasattr(res, "__iter__")
                            and not isinstance(res, (str, dict))
                        )
                    ):
                        for chunk in res:
                            txt = (
                                chunk
                                if isinstance(chunk, str)
                                else chunk.text
                                if hasattr(chunk, "text")
                                else str(chunk)
                            )
                            buffer += txt
                            yield chunk
                    else:
                        buffer = (
                            res
                            if isinstance(res, str)
                            else res.text
                            if hasattr(res, "text")
                            else str(res)
                        )
                        yield res

                    # --- 1st CLASS TOOL REFLECTION LOOP (OpenClaw style) ---
                    if healing_depth < 2:
                        import modules.json_healer as json_healer

                        tool_matches = re.findall(
                            r"<tool>(.*?)</tool>", buffer, re.DOTALL
                        )
                        if tool_matches:
                            has_error = False
                            error_msg = ""

                            for block in tool_matches:
                                try:
                                    repaired_block = json_healer.repair_json(block)
                                    data = json.loads(repaired_block)
                                    module_name = data.get("module")
                                    action_name = data.get("action")

                                    # We execute privileged modules internally to verify/auto-correct them
                                    SELF_MANAGED_MODULES = [
                                        "identity_manager",
                                        "project_manager",
                                        "data_architect",
                                        "db_logger",
                                        "database_ops",
                                        "memory_manager",
                                        "life_manager",
                                    ]
                                    if module_name in SELF_MANAGED_MODULES:
                                        print(
                                            f" ⚙️ [Brain] Validating/Executing Tool '{module_name}' internally..."
                                        )
                                        tool_res = self.module_manager.execute_module(
                                            module_name, data, brain_instance=self
                                        )

                                        if isinstance(
                                            tool_res, str
                                        ) and tool_res.startswith("Error:"):
                                            has_error = True
                                            error_msg = tool_res
                                            break

                                        # Log the successful execution since chat_manager won't do it for INTERNAL_EXEC blocks
                                        msg_result = str(tool_res)
                                        undo_data = None
                                        try:
                                            if (
                                                isinstance(tool_res, dict)
                                                and "id" in tool_res
                                                and "type" in tool_res
                                            ):
                                                undo_data = tool_res
                                                msg_result = tool_res.get(
                                                    "message", msg_result
                                                )
                                        except Exception:
                                            pass
                                        log_msg = (
                                            f"AUTO-EXEC ({module_name}): {msg_result}"
                                        )
                                        if undo_data:
                                            log_msg += (
                                                f" [UNDO_DATA:{json.dumps(undo_data)}]"
                                            )
                                        database.save_message(
                                            "system",
                                            log_msg,
                                            "Aegis",
                                            kwargs.get("context", "general"),
                                        )

                                        # Yield a silent marker so chat_manager bypasses execution for this chunk
                                        yield f"\n[INTERNAL_EXEC:{module_name}:{action_name}]\n"

                                except Exception as e:
                                    has_error = True
                                    error_msg = f"JSON/Format Error: {str(e)}"
                                    break

                            if has_error:
                                yield {
                                    "type": "status",
                                    "msg": "Corrigiendo parámetros de herramienta...",
                                }
                                yield "\n[TOOL_EXECUTION_FAILED]\n"

                                new_history = list(history)
                                new_history.append(
                                    ("assistant", buffer, "", active_model)
                                )
                                sys_msg = f"[SYSTEM: Tool Execution Failed. Error: {error_msg}. Reflect inside <think> and try again.]"
                                new_history.append(
                                    ("system", sys_msg, "", active_model)
                                )

                                yield from self._query_internal(
                                    prompt=prompt,
                                    history=new_history,
                                    model_choice_arg=model_choice_arg,
                                    api_key=api_key,
                                    profile=profile,
                                    image_input=image_input,
                                    stream=stream,
                                    hive_override=hive_override,
                                    key_ring=key_ring,
                                    healing_depth=healing_depth + 1,
                                    **kwargs,
                                )
                                return
                    return

            except llm_drivers.LLMRateLimitError as e:
                print(f"[BRAIN] ⚠️ Rate Limit on {provider}: {e}")
                router.ModelHealth.report_error(provider)
                errors.append(str(e))
            except llm_drivers.LLMConnectionError as e:
                print(f"[BRAIN] 🕸️ Connection Error on {provider}: {e}")
                router.ModelHealth.report_error(provider)
                errors.append(str(e))
            except llm_drivers.LLMAuthError as e:
                print(f"[BRAIN] 🔑 Auth Error on {provider}: {e}")
                router.ModelHealth.report_error(provider)
                errors.append(str(e))
            except Exception as e:
                print(f"[BRAIN] ❌ Unexpected error on {provider}: {e}")
                errors.append(str(e))

        yield f"CRITICAL FAILURE: {errors}"
        return

    def repair_tool_call(self, failed_block, error_msg, api_key=None):
        """Llamada Fantasma: Ciclo de Reflexión para sanar JSON roto o argumentos erróneos."""
        prompt_fantasma = f"Tu intento anterior de usar la herramienta falló con el error:\n{error_msg}\n\nCorrige el JSON y emite solo el bloque <tool> corregido."
        print(
            f"[REFL] 👻 Iniciando Ciclo de Reflexión Fantasma... Error detectado: {str(error_msg)[:100]}"
        )

        # Force a quick, silent, non-streamed query
        gen = self._query_internal(
            prompt=prompt_fantasma,
            history=[],
            model_choice_arg="specialist:logic",
            api_key=api_key,
            stream=False,
            is_repair=True,
        )

        final_str = ""
        for item in gen:
            if isinstance(item, dict) and item.get("type") == "status":
                continue
            if hasattr(item, "text"):
                final_str += item.text
            else:
                final_str += str(item)

        import modules.json_healer as json_healer
        import json

        match = re.search(r"<tool>(.*?)</tool>", final_str, re.DOTALL)
        if match:
            new_block = match.group(1)
            healed = json_healer.repair_json(new_block)
            try:
                return json.loads(healed), healed
            except Exception:
                pass
        return None, final_str
