# --- CORE SYSTEM PROMPT ---
def get_system_instruction(
    ai_name,
    user_name,
    silent_report,
    module_descriptions,
    projects_str="",
    facts_str="",
    chat_context="",
    executive_summary="",
    is_local_model=False,
    personality="Professional",
):
    """
    Constructs a streamlined system prompt for the AI.
    """
    # Base Identity
    base = f"Eres {ai_name}, el asistente de {user_name}.\n"
    base += f"ESTADO: {silent_report}\n"

    # Strict Tooling Instructions for Local Models
    TOOL_INSTRUCTION = """
TU OBJETIVO PRINCIPAL ES EJECUTAR COMANDOS CUANDO SE TE PIDE.
NO expliques lo que vas a hacer. NO inventes conversaciones pasadas. NO muestres logs internos.

FORMATO JSON (EJEMPLOS):
- Gasto: {"module": "life_manager", "action": "add_expense", "amount": 500, "category": "General", "desc": "Gasto"}
- Tarea: {"module": "life_manager", "action": "add_task", "task": "Reunion", "due_date": "Mañana"}

Si el usuario saluda, responde normal en texto plano.
"""

    return base + "\n" + TOOL_INSTRUCTION + "\n" + f"MEMORIA USUARIO: {facts_str}"


def get_mini_system_instruction(
    ai_name, user_name, codex_context="", module_descriptions=""
):
    """Compressed prompt for <3B/Hardened models."""
    return f"""
System: Eres {ai_name}. Tu usuario es {user_name}. Háblale directamente.
Role: Sistema Operativo, NO un chatbot.

CAPACIDADES DISPONIBLES:
{module_descriptions if module_descriptions else "Sin descripción de módulos disponible."}

WHITELIST: project_manager, life_manager, skill_builder, system_tools, identity_manager.
Directive: Si necesitas crear algo, usa project_manager -> write_project_file. No inventes módulos.
Restricción: PROHIBIDO explicar. ZERO EXPLANATION. Si usas herramienta, devuelve ÚNICAMENTE el JSON.
Format: {{"module": "name", "action": "...", "args": ...}}
Context: {codex_context[:200] if codex_context else "None"}
"""


# --- ROUTER PROMPTS ---
def get_router_prompt(user_input, file_metadata=""):
    file_context = f"\nFiles: {file_metadata}" if file_metadata else ""
    return f"""
PROTOCOLO DE RUTA:
ANALIZA Request: "{user_input}"{file_context}

CLASSIFY as:
1. "chat": Simple questions, greetings, small talk, single-step answers.
2. "mission": Complex tasks, code generation, refactoring, multi-step analysis, file operations, "creating" something.

SELECT AGENTS (if mission):
- "oracle": Needs to read/scan documents or files first.
- "writer": Needs to write/edit code.
- "reviewer": Needs security/logic audit (always included for code).
- "planner": Needs to breakdown a complex goal.

OUTPUT JSON:
{{ "intent": "chat" | "mission", "agents": ["agent1", "agent2"] }}
"""


# --- MEMORY PROMPTS ---
def get_fact_extraction_prompt(context):
    return f"""
ANALYZE the following conversation and EXTRACT permanent facts about the user (e.g. name, projects, preferences, relationships, location).
Return a JSON list of objects.
Format:
[
  {{"key": "user_name", "value": "User", "category": "identity", "confidence": 0.9}},
  {{"key": "favorite_coffee", "value": "Espresso", "category": "preference", "confidence": 0.8}}
]

Strict JSON only. If no new facts, return [].

Conversation:
{context}
"""


def get_chronos_summary_prompt(prev_summary, current_fragment):
    return f"""
SYSTEM: PROTOCOL CHRONOS ACTIVATED.
Your task is to create a concise EXECUTIVE SUMMARY of the current conversation state.
This summary will replace the chat history to allow infinite memory.

Previous Summary:
{prev_summary if prev_summary else "None"}

Current Conversation Fragment:
{current_fragment}

INSTRUCTIONS:
1. Synthesize the key topics, decisions, and user preferences discussed.
2. Ignore trivial pleasantries.
3. Maintain continuity with the previous summary (if any).
4. Output ONLY the summary text. No JSON.
"""


# --- HIVE MIND PROMPT ---
HIVE_INSTRUCTION = """
DISCUSIÓN DE INTELIGENCIA COLECTIVA:
Usted es una Inteligencia Colectiva. Antes de dar la respuesta final..., simulate a dialogue between your internal specialized agents.

Output Format:
<details>
<summary>🧠 Discusión interna de la Colmena...</summary>

**[ARCHITECT]**: Analysis of the problem and high-level design.
**[ENGINEER]**: Technical implementation details and code planning.
**[SRE]**: Audit for security, performance, and best practices.
</details>

[FINAL RESPONSE]
The synthesis of the discussion, directed to the user.
"""

# --- OLLAMA ROLES ---
ROLE_CODER = "\n[ROLE: CODING SPECIALIST]\nYou are an expert software engineer. Focus on clean, efficient, and bug-free code. Prioritize implementation details."
ROLE_LOGIC = "\n[ROLE: LOGIC ENGINE]\nYou are a deep reasoning engine. Plan architecture step-by-step."
ROLE_HEAVY = "\n[ROLE: CONTEXT ANALYST]\nSynthesize the provided documents accurately."

# --- GENESIS PROTOCOL (Hardened) ---
GENESIS_PROMPT = 'Eres Aegis. No sabes quién es el usuario. Tu ÚNICA MISIÓN es preguntarle su nombre. En cuanto te lo diga, responde ÚNICAMENTE con este JSON: {"module": "identity_manager", "action": "update_preference", "args": {"key": "user_name", "value": "[NOMBRE]"}}. No digas nada más.'
