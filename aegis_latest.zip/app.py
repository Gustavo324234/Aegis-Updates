import json
import actions

# Initialize database
database.init_db()

# Initialize Brain
brain = AegisBrain()

st.set_page_config(page_title="Aegis-IA", layout="wide", page_icon="🛡️")

# Cyber-Dark Theme CSS
st.markdown("""
<style>
    /* Main Background */
    .stApp {
        background-color: #0e1117;
        color: #c9d1d9;
    }
    
    /* Sidebar */
    section[data-testid="stSidebar"] {
        background-color: #0e1117; /* Deep Black */
        border-right: 1px solid #30363d;
    }
    
    /* Input Field */
    .stTextInput > div > div > input {
        background-color: #161b22;
        color: #c9d1d9;
        border: 1px solid #30363d;
    }
    
    /* User Message Bubble (Right, Neon Blue Accent) */
    .stChatMessage[data-testid="stChatMessage"]:nth-child(odd) {
        background-color: rgba(0, 242, 255, 0.05); /* Faint Neon Blue */
        border-left: 3px solid #00f2ff;
        border-radius: 5px;
    }

    /* Assistant Message Bubble (Left, Steel Gray) */
    .stChatMessage[data-testid="stChatMessage"]:nth-child(even) {
        background-color: #161b22;
        border-left: 3px solid #30363d;
        border-radius: 5px;
    }
    
    /* Action Warning Box (Aegis Shield) */
    .stAlert {
        background-color: #161b22;
        border: 1px solid #ff4b4b; /* Red alert border */
        color: #ff4b4b;
        font-family: 'Courier New', monospace;
    }
    
    /* Buttons */
    .stButton > button {
        background-color: #21262d;
        color: #00f2ff;
        border: 1px solid #30363d;
        border-radius: 4px;
        transition: all 0.3s;
    }
    .stButton > button:hover {
        border-color: #00f2ff;
        box-shadow: 0 0 8px rgba(0, 242, 255, 0.5);
    }
    
</style>
""", unsafe_allow_html=True)

# Sidebar Configuration
with st.sidebar:
    st.title("Aegis-IA Settings")
    
    # Model Selection
    model_option = st.selectbox(
        "Select Model",
        ("Gemini", "Ollama (llama2)", "Ollama (mistral)")
    )
    
    # API Key Input (Only for Gemini)
    api_key = ""
    if "Gemini" in model_option:
        api_key = st.text_input("Gemini API Key", type="password")
        if api_key:
            st.session_state["gemini_api_key"] = api_key
    
    # Reset Memory Button
    if st.button("Reiniciar Memoria"):
        import sqlite3
        conn = sqlite3.connect("aegis_memory.db")
        c = conn.cursor()
        c.execute("DELETE FROM history")
        conn.commit()
        conn.close()
        st.success("Memoria reiniciada!")
        st.rerun()

# Main Chat Interface
st.title("Aegis-IA Multimodal Assistant")

# Display Message History
history = database.get_history(limit=50)

for i, (role, message) in enumerate(history):
    with st.chat_message(role):
        # Check if message is JSON action from assistant
        if role == "assistant" and message.strip().startswith("{") and message.strip().endswith("}"):
            try:
                action_data = json.loads(message)
                st.code(json.dumps(action_data, indent=2), language='json')
                
                # Check if the NEXT message is a system result (optimization: checking if action was already handled)
                # In this simple implementation, if the action is the VERY LAST message, we show buttons.
                # If there are messages after it, we assume it's done or history.
                # However, get_history returns oldest first. 
                # If this is the last message in history, we show controls.
                if i == len(history) - 1:
                    st.warning(f"Action Request: {action_data.get('action')}")
                    col1, col2 = st.columns(2)
                    with col1:
                        if st.button("EJECUTAR", key=f"exec_{i}"):
                            result = "Action Executed"
                            if action_data['action'] == 'terminal':
                                result = actions.execute_command(action_data['command'])
                            elif action_data['action'] == 'file':
                                result = actions.manage_files(action_data.get('operation'), action_data.get('path'), action_data.get('content'))
                            elif action_data['action'] == 'sysinfo':
                                result = actions.get_system_info()
                            
                            database.save_message("system", f"Action Result:\n{result}", model_option)
                            st.rerun()
                    with col2:
                        if st.button("CANCELAR", key=f"cancel_{i}"):
                            database.save_message("system", "Action Cancelled by User", model_option)
                            st.rerun()
            except json.JSONDecodeError:
                st.markdown(message)
        else:
            st.markdown(message)

# Chat Input
if prompt := st.chat_input("Escribe tu mensaje..."):
    # Display user message immediately
    with st.chat_message("user"):
        st.markdown(prompt)
    
    # Save user message
    database.save_message("user", prompt, model_option)
    
    # Get response
    with st.spinner("Pensando..."):
        # Use existing history for context (excluding the just-saved current prompt)
        # We need to refresh history from DB to include previous turns properly if we want full context
        # But get_history returns tuples. We should pass them to brain.
        # Ideally we fetch fresh history including the one we just saved? 
        # Actually, standard flow is: User says X -> Save X -> Fetch History (including X) -> Query -> Save Y
        # My previous fix was: context_history = history[-20:] if history else []
        # That `history` variable was fetched at top of script. 
        # So it DOES NOT include the current prompt.
        # So we actually want to APPEND the current prompt to context for the AI, 
        # OR save it first and then fetch.
        # In the code above:
        # database.save_message("user", prompt, model_option) 
        # So it is in DB.
        # But `history` variable is stale (fetched before save).
        # So we should fetch again OR manually append.
        # Fetching again is safer.
        current_history = database.get_history(limit=20)
        
        # Determine API Key to use
        current_api_key = st.session_state.get("gemini_api_key", "")
        
        response = brain.query(prompt, current_history, model_option, api_key=current_api_key)
        
        # Save assistant response
        database.save_message("assistant", response, model_option)
        
    st.rerun()
