import asyncio
import websockets
import json
import os
import time
import sys

import logging
import platform
import uuid
import threading
import tkinter as tk
from tkinter import simpledialog, messagebox
from typing import Dict, Any
from cryptography.fernet import Fernet
import requests
import hashlib
import hmac
import zipfile
import shutil
import io
import base64
import psutil

# --- Aegis Core Imports ---
try:
    import database
except ImportError:
    database = None

# --- GUI Dependencies ---
try:
    import pystray
    from PIL import Image, ImageDraw
except ImportError:
    print("CRITICAL: pystray and Pillow are required. Run 'pip install pystray Pillow'")
    sys.exit(1)

# --- Configuration & Constants ---
CONFIG_FILE = "aegis_limb_config.json"
DEFAULT_GATEWAY_URL = os.getenv("AEGIS_GATEWAY_URL", "ws://localhost:8000/ws")
DEFAULT_WORKSPACE_ROOT = os.getenv("AEGIS_WORKSPACE_ROOT", os.getcwd())

# --- Logging Setup ---
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - [AegisLimb] - %(levelname)s - %(message)s",
    handlers=[logging.FileHandler("aegis_limb.log"), logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger("AegisLimb")


# --- Global State for Tray ---
class AppState:
    running = True
    status = "Disconnected"  # Disconnected, Connecting, Connected, Error
    node_id = "Unknown"
    gateway_url = DEFAULT_GATEWAY_URL
    icon = None  # Holds the pystray icon instance


state = AppState()


# --- Security Module ---
class SecurityModule:
    def __init__(self, key: str):
        try:
            key_bytes = key.encode() if isinstance(key, str) else key
            self.cipher = Fernet(key_bytes)
        except Exception as e:
            logger.critical(f"Failed to initialize encryption key: {e}")
            state.status = "Error"

    def decrypt(self, encrypted_token: str) -> Dict[str, Any]:
        try:
            token_bytes = (
                encrypted_token.encode()
                if isinstance(encrypted_token, str)
                else encrypted_token
            )
            decrypted_data = self.cipher.decrypt(token_bytes)
            return json.loads(decrypted_data.decode("utf-8"))
        except Exception as e:
            logger.error(f"Decryption failed: {e}")
            raise

    def encrypt(self, data: Dict[str, Any]) -> str:
        try:
            json_str = json.dumps(data)
            encrypted_bytes = self.cipher.encrypt(json_str.encode("utf-8"))
            return encrypted_bytes.decode("utf-8")
        except Exception as e:
            logger.error(f"Encryption failed: {e}")
            raise


# --- Command Handler ---
class CommandHandler:
    def __init__(self, workspace_root: str, api_keys: Dict[str, str] = None):
        self.workspace_root = os.path.abspath(workspace_root)
        self.api_keys = api_keys or {}

    def _resolve_path(self, path: str) -> str:
        folder = os.path.abspath(self.workspace_root)
        if os.path.isabs(path):
            target = os.path.abspath(path)
        else:
            target = os.path.abspath(os.path.join(folder, path))

        try:
            if os.path.commonpath([folder, target]) != folder:
                raise ValueError(
                    f"Security Alert: Path '{path}' attempts to escape workspace root '{folder}'."
                )
        except ValueError:
            raise ValueError("Security Alert: Path Escape Attempt.")
        return target

    async def execute(self, cmd_data: Dict[str, Any]) -> Dict[str, Any]:
        cmd_type = cmd_data.get("cmd") or cmd_data.get("type")
        args = cmd_data.get("args", {})
        if not args:
            args = {
                k: v
                for k, v in cmd_data.items()
                if k not in ["cmd", "type", "id", "reply_to"]
            }

        try:
            if cmd_type == "terminal_cmd":
                return await self.terminal_cmd(args)
            elif cmd_type == "file_ops":
                return await self.file_ops(args)
            elif cmd_type == "write_to_workspace":
                return await self.write_to_workspace(args)
            elif cmd_type == "index_remote_workspace":
                return await self.index_remote_workspace(args)
            elif cmd_type == "sync_entire_project":
                return await self.sync_entire_project(args)
            elif cmd_data.get("module") == "project_manager":
                # Neural Swarm: Remote project execution
                return await self.project_action(cmd_data)
            elif "soul_sync" in cmd_data:
                # Circular backup (already handled in gateway for Hub, but Limb might get one too)
                return {"status": "success", "message": "Soul Sync data received"}
            return {"status": "error", "message": f"Unknown Command Type: {cmd_type}"}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    async def project_action(self, cmd_data):
        """Executes project_manager actions on the Satellite."""
        action = cmd_data.get("action")
        proj_name = cmd_data.get("project_name") or cmd_data.get("name")
        filename = cmd_data.get("filename")
        content = cmd_data.get("content")

        # Base path for projects on satellite: workspace/projects/
        projects_base = os.path.join(self.workspace_root, "workspace", "projects")
        proj_dir = os.path.join(projects_base, proj_name.strip().replace(" ", "_"))

        if action == "init_project":
            await asyncio.to_thread(os.makedirs, proj_dir, exist_ok=True)
            return {
                "status": "success",
                "message": f"Project {proj_name} initialized at {proj_dir}",
            }

        elif action == "write_project_file":
            full_path = os.path.join(proj_dir, filename)

            async def write():
                os.makedirs(os.path.dirname(full_path), exist_ok=True)
                with open(full_path, "w", encoding="utf-8") as f:
                    f.write(content or "")

            await asyncio.to_thread(write)
            return {
                "status": "success",
                "message": f"Written {filename} to {proj_name}",
            }

        elif action == "execute_project":
            main_file = os.path.join(proj_dir, "app.py")
            if not os.path.exists(main_file):
                # Look for index.html if it's a web project
                if os.path.exists(os.path.join(proj_dir, "index.html")):
                    return {
                        "status": "success",
                        "message": "Static project ready. Access via host.",
                    }
                return {"status": "error", "message": "app.py not found"}

            # Execute app.py
            return await self.terminal_cmd({"command": f"python {main_file}"})

        return {"status": "error", "message": f"Unknown action: {action}"}

    async def terminal_cmd(self, args):
        command = args.get("command")
        if not command:
            return {"status": "error", "message": "No command"}

        proc = await asyncio.create_subprocess_shell(
            command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=self.workspace_root,
        )
        stdout, stderr = await proc.communicate()
        return {
            "status": "success",
            "stdout": stdout.decode(errors="replace").strip(),
            "stderr": stderr.decode(errors="replace").strip(),
        }

    async def file_ops(self, args):
        op = args.get("operation")
        path = args.get("path")
        content = args.get("content")
        full_path = self._resolve_path(path)

        if op == "read":
            if not os.path.exists(full_path):
                return {"status": "error", "message": "File not found"}

            async def read():
                with open(full_path, "r", encoding="utf-8") as f:
                    return f.read()

            return {"status": "success", "data": await asyncio.to_thread(read)}
        elif op == "write":

            async def write():
                os.makedirs(os.path.dirname(full_path) or ".", exist_ok=True)
                with open(full_path, "w", encoding="utf-8") as f:
                    f.write(content or "")

            await asyncio.to_thread(write)
            return {"status": "success", "message": f"Written to {full_path}"}
        elif op == "list":
            if os.path.exists(full_path) and os.path.isdir(full_path):
                return {
                    "status": "success",
                    "files": await asyncio.to_thread(os.listdir, full_path),
                }
            return {"status": "error", "message": "Dir not found"}
        return {"status": "error", "message": "Unknown Op"}

    async def write_to_workspace(self, args):
        return await self.file_ops(
            {
                "operation": "write",
                "path": args.get("filename") or args.get("path"),
                "content": args.get("content"),
            }
        )

    async def index_remote_workspace(self, args):
        file_map = []
        ignore_dirs = {
            ".git",
            "__pycache__",
            "node_modules",
            "venv",
            ".env",
            ".idea",
            ".vscode",
        }
        ignore_ext = {".pyc", ".exe", ".dll", ".so", ".bin"}

        for root, dirs, files in os.walk(self.workspace_root):
            dirs[:] = [d for d in dirs if d not in ignore_dirs]
            for file in files:
                if any(file.endswith(ext) for ext in ignore_ext):
                    continue
                full_path = os.path.join(root, file)
                rel_path = os.path.relpath(full_path, self.workspace_root)
                file_map.append(
                    {
                        "path": rel_path.replace("\\", "/"),
                        "size": os.path.getsize(full_path),
                        "type": "file",
                    }
                )
        return {"status": "success", "file_map": file_map}

    async def sync_entire_project(self, args):
        """
        Receives a Base64 encoded ZIP, verifies checksum, creates a snapshot,
        and securely unpacks it to the target directory.
        """
        payload_b64 = args.get("payload")
        target_subdir = args.get("target_subdir", "")  # Relative to workspace_root
        checksum_provided = args.get("checksum")

        if not payload_b64:
            return {"status": "error", "message": "No payload provided"}

        # 1. Resolve Target Path
        try:
            full_target_path = self._resolve_path(target_subdir)
        except ValueError as e:
            return {"status": "error", "message": str(e)}

        # 2. Decode and Verify Integrity
        try:
            zip_data = base64.b64decode(payload_b64)
        except Exception:
            return {"status": "error", "message": "Invalid Base64 payload"}

        if checksum_provided:
            md5_calculated = hashlib.md5(zip_data).hexdigest()
            # Support both straight MD5 and whatever format sender uses
            if md5_calculated != checksum_provided:
                return {
                    "status": "error",
                    "message": f"Integrity Check Failed. Recv: {md5_calculated} != Exp: {checksum_provided}",
                }

        # 3. Create Snapshot (Backup)
        timestamp = int(time.time())
        backup_dir = os.path.join(self.workspace_root, ".aegis_backups")
        os.makedirs(backup_dir, exist_ok=True)

        # We backup the specific target folder if it exists
        if os.path.exists(full_target_path) and os.path.isdir(full_target_path):
            # If target is root, we might want to be careful not to backup the backup folder if it's inside
            snap_name = (
                f"snap_{timestamp}_{os.path.basename(full_target_path) or 'root'}.zip"
            )
            snap_path = os.path.join(backup_dir, snap_name)

            # Run zip in thread to avoid blocking
            def make_backup():
                shutil.make_archive(
                    snap_path.replace(".zip", ""), "zip", full_target_path
                )

            await asyncio.to_thread(make_backup)
            logger.info(f"Snapshot created at {snap_path}")

        # 4. Secure Decompression (Zip Slip Protection)
        try:

            def extract_zip():
                os.makedirs(full_target_path, exist_ok=True)
                with zipfile.ZipFile(io.BytesIO(zip_data)) as zf:
                    for member in zf.namelist():
                        # Security Check: Zip Slip
                        member_path = os.path.join(full_target_path, member)
                        # Normalize path resolves '..'
                        abs_member_path = os.path.abspath(member_path)
                        if not abs_member_path.startswith(
                            os.path.abspath(full_target_path)
                        ):
                            raise ValueError(
                                f"Zip Slip Alert: {member} attempts to escape target path"
                            )

                        zf.extract(member, full_target_path)

            await asyncio.to_thread(extract_zip)

            # 5. Register in Local Database
            if database:
                try:
                    proj_name = args.get(
                        "project_name", os.path.basename(target_subdir)
                    )
                    database.add_user_fact(
                        proj_name, full_target_path, "project_active"
                    )
                    logger.info(f"Project '{proj_name}' registered in local database.")
                except Exception as db_err:
                    logger.error(f"Failed to register project: {db_err}")

            return {
                "status": "success",
                "message": "Project Synced Successfully",
                "details": f"Extracted {len(zip_data)} bytes to {target_subdir}",
            }

        except ValueError as ve:
            return {"status": "error", "message": str(ve)}
        except Exception as e:
            return {"status": "error", "message": f"Extraction Failed: {e}"}


# --- Main Client ---
class AegisLimbClient:
    def __init__(self):
        self.config = self.load_config()
        state.node_id = self.config.get("node_id")
        state.gateway_url = self.config.get("gateway_url", DEFAULT_GATEWAY_URL)

        self.ws_url = f"{state.gateway_url}/{state.node_id}"
        self.security = SecurityModule(self.config.get("secret_key"))
        self.handler = CommandHandler(
            self.config.get("workspace_root", DEFAULT_WORKSPACE_ROOT)
        )

    def load_config(self) -> Dict[str, Any]:
        config = {}
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE, "r") as f:
                    config = json.load(f)
            except Exception:
                pass

        updated = False
        if "node_id" not in config:
            config["node_id"] = f"limb_{uuid.uuid4().hex[:8]}"
            updated = True
        if "secret_key" not in config:
            config["secret_key"] = Fernet.generate_key().decode()
            updated = True
        if "gateway_url" not in config:
            config["gateway_url"] = DEFAULT_GATEWAY_URL
            updated = True
        if "workspace_root" not in config:
            config["workspace_root"] = DEFAULT_WORKSPACE_ROOT
            updated = True

        if updated:
            with open(CONFIG_FILE, "w") as f:
                json.dump(config, f, indent=4)
        return config

    def save_pairing_code(self, code):
        self.config["pairing_code_cache"] = code
        with open(CONFIG_FILE, "w") as f:
            json.dump(self.config, f, indent=4)

    def register_with_gateway(self):
        state.status = "Connecting"
        update_tray_icon()

        code = self.config.get("pairing_code_cache")
        # Generate HWID Signature
        hwid = str(uuid.getnode())
        sig = None
        if code:
            try:
                sig = hmac.new(code.encode(), hwid.encode(), hashlib.sha256).hexdigest()
            except Exception:
                pass

        payload = {
            "node_id": state.node_id,
            "public_key": "limbv1",  # Placeholder
            "fernet_key": self.config.get("secret_key"),
            "pairing_code": code,
            "contribution_mode": self.config.get("contribution_mode", False),
            "client_type": "desktop",
            "hwid": hwid,
            "hwid_signature": sig,
        }

        attempt_urls = [
            state.gateway_url,
            DEFAULT_GATEWAY_URL,
            "ws://localhost:8000/ws",
        ]
        attempt_urls = list(dict.fromkeys(attempt_urls))

        while state.running:
            for url in attempt_urls:
                try:
                    http_url = (
                        url.replace("ws://", "http://")
                        .replace("wss://", "https://")
                        .replace("/ws", "")
                    )
                    resp = requests.post(
                        f"{http_url}/register", json=payload, timeout=5
                    )

                    if resp.status_code == 200:
                        logger.info(f"✅ Registered with {http_url}")
                        if self.config.get("gateway_url") != url:
                            self.config["gateway_url"] = url
                            with open(CONFIG_FILE, "w") as f:
                                json.dump(self.config, f, indent=4)
                        return True
                    elif resp.status_code == 403:
                        state.status = "Pairing Needed"
                        update_tray_icon()
                        # Request UI popup
                        request_pairing_ui(self)
                        # Reload from config in case UI updated it
                        payload["pairing_code"] = self.config.get("pairing_code_cache")
                    else:
                        logger.error(f"Registration Error: {resp.text}")
                except Exception as e:
                    logger.error(f"Connection Error: {e}")

            time.sleep(5)
        return False

    async def run(self):
        if not self.register_with_gateway():
            return

        self.ws_url = f"{state.gateway_url}/{state.node_id}"
        backoff = 1

        while state.running:
            try:
                state.status = "Connecting"
                update_tray_icon()
                async with websockets.connect(self.ws_url) as websocket:
                    state.status = "Connected"
                    update_tray_icon()
                    logger.info("✅ Connected via WebSocket!")
                    backoff = 1

                    while state.running:
                        try:
                            message = await websocket.recv()
                            await self.handle_message(websocket, message)
                        except websockets.ConnectionClosed:
                            state.status = "Disconnected"
                            update_tray_icon()
                            break
                        except Exception:
                            break
            except Exception as e:
                logger.error(f"Connection Failed: {e}")
                state.status = "Error"
                update_tray_icon()

            if state.running:
                # Add background heartbeat task if not already running
                if not hasattr(self, "heartbeat_task") or self.heartbeat_task.done():
                    self.heartbeat_task = asyncio.create_task(
                        self.heartbeat_loop(websocket)
                    )

                # Add background soul sync task (Respaldo Circular)
                if not hasattr(self, "soul_task") or self.soul_task.done():
                    self.soul_task = asyncio.create_task(self.soul_sync_loop(websocket))

                await asyncio.sleep(backoff)
                backoff = min(backoff * 1.5, 30)

    async def soul_sync_loop(self, websocket):
        """Periodically sends the local 'Soul' (DB + Config) to the Hub."""
        logger.info("🌀 Soul Sync Loop Started")
        while state.running:
            try:
                if state.status == "Connected":
                    import tarfile
                    import io
                    import base64

                    soul_buffer = io.BytesIO()
                    with tarfile.open(fileobj=soul_buffer, mode="w:gz") as tar:
                        # Add database if exists
                        if os.path.exists("aegis_memory.db"):
                            tar.add("aegis_memory.db", arcname="aegis_memory.db")
                        # Add config
                        if os.path.exists(CONFIG_FILE):
                            tar.add(CONFIG_FILE, arcname=CONFIG_FILE)

                    soul_bytes = soul_buffer.getvalue()
                    soul_b64 = base64.b64encode(soul_bytes).decode("utf-8")

                    # 2. Encrypt and Send
                    payload = {"soul_sync": soul_b64}
                    encrypted_res = self.security.encrypt(
                        {"result": payload, "id": f"soul_{int(time.time())}"}
                    )

                    outbound = {
                        "target": "hub_vault",
                        "msg": {
                            "encrypted_data": encrypted_res,
                            "sender": state.node_id,
                        },
                    }
                    await websocket.send(json.dumps(outbound))
                    logger.info(f"📤 Soul backup sent to Hub ({len(soul_bytes)} bytes)")
            except Exception as e:
                logger.error(f"Soul Sync Error: {e}")

            # Every 2 hours
            await asyncio.sleep(7200)

    async def heartbeat_loop(self, websocket):
        """Sends periodic system metrics to the Hub."""
        logger.info("💓 Heartbeat Loop Started")
        while state.running:
            try:
                if state.status == "Connected":
                    # Calculate Compute Score
                    mem = psutil.virtual_memory()
                    cpu_count = psutil.cpu_count() or 1
                    ram_total_gb = mem.total / (1024**3)

                    # GPU Check (Simplified for Limb)
                    gpu_factor = 0
                    try:
                        import subprocess

                        subprocess.check_output(
                            ["nvidia-smi"], stderr=subprocess.STDOUT
                        )
                        gpu_factor = 500
                    except Exception:
                        pass

                    compute_score = (cpu_count * 100) + (ram_total_gb * 50) + gpu_factor

                    heartbeat_msg = {
                        "type": "heartbeat",
                        "node_id": state.node_id,
                        "compute_score": round(compute_score, 2),
                        "timestamp": time.time(),
                    }

                    await websocket.send(json.dumps(heartbeat_msg))
                    logger.debug(f"Sent heartbeat: {compute_score}")
            except Exception as e:
                logger.error(f"Heartbeat Error: {e}")

            await asyncio.sleep(30)  # Every 30 seconds

    async def handle_message(self, websocket, raw_msg):
        try:
            envelope = json.loads(raw_msg)
            is_ping = envelope.get("type") == "ping"  # Keep-alive
            if is_ping:
                return

            encrypted_token = envelope.get("encrypted_data")
            if not encrypted_token:
                return

            command_data = self.security.decrypt(encrypted_token)
            result = await self.handler.execute(command_data)

            # Notifications
            cmd_type = command_data.get("type") or command_data.get("cmd")
            if cmd_type == "write_to_workspace" and result.get("status") == "success":
                filename = command_data.get("filename") or "File"
                show_notification("New File Received", filename)

            # Response
            response_payload = {"result": result, "cmd_id": command_data.get("id")}
            encrypted_response = self.security.encrypt(response_payload)

            reply_to = command_data.get("reply_to")
            if reply_to and websocket:
                outbound = {
                    "target": reply_to,
                    "msg": {
                        "encrypted_data": encrypted_response,
                        "sender": state.node_id,
                    },
                }
                await websocket.send(json.dumps(outbound))

        except Exception as e:
            logger.error(f"Msg Handle Error: {e}")


# --- GUI / Tray Utils ---


def create_image(color):
    # Generate a simple colored square icon
    width = 64
    height = 64
    image = Image.new("RGB", (width, height), color)
    dc = ImageDraw.Draw(image)
    dc.rectangle((0, 0, width, height), fill=color)
    dc.rectangle((0, 0, width, height), outline="white", width=3)
    return image


def update_tray_icon():
    if not state.icon:
        return

    color_map = {
        "Connected": "green",
        "Connecting": "yellow",
        "Disconnected": "gray",
        "Error": "red",
        "Pairing Needed": "orange",
    }
    color = color_map.get(state.status, "gray")

    # Update Icon Image
    state.icon.icon = create_image(color)
    # Update Tooltip (Title)
    state.icon.title = f"Aegis Satellite: {state.status}"


def show_notification(title, msg):
    if state.icon:
        state.icon.notify(msg, title)


def on_exit(icon, item):
    state.running = False
    icon.stop()
    sys.exit(0)


def show_id(icon, item):
    root = tk.Tk()
    root.withdraw()
    messagebox.showinfo("Node ID", f"Node ID:\n{state.node_id}")
    root.destroy()


pairing_requested_event = threading.Event()
client_instance = None


def request_pairing_ui(client):
    global client_instance
    client_instance = client
    pairing_requested_event.set()
    # Block until user inputs code? No, we wait for UI thread.
    # We will poll config for updated code in the loop.
    # Just setting event signals UI thread to show popup.
    while pairing_requested_event.is_set():
        time.sleep(1)


def pairing_popup_logic():
    # Only run this on Main Thread
    if pairing_requested_event.is_set():
        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        code = simpledialog.askstring(
            "Aegis Pairing", "Enter Pairing Code from Hub:", parent=root
        )
        root.destroy()

        if code and client_instance:
            client_instance.save_pairing_code(code)

        pairing_requested_event.clear()


def run_tray():
    menu = pystray.Menu(
        pystray.MenuItem("Status: " + state.status, lambda i, it: None, enabled=False),
        pystray.MenuItem("Node ID", show_id),
        pystray.MenuItem("Exit", on_exit),
    )

    state.icon = pystray.Icon(
        "AegisSatellite", create_image("gray"), "Aegis Satellite", menu
    )

    # Custom loop to handle threading checks
    def setup(icon):
        icon.visible = True
        while state.running:
            pairing_popup_logic()
            time.sleep(0.5)

    state.icon.run(setup)


# --- Entry Point ---
if __name__ == "__main__":
    if platform.system() == "Windows":
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

    # Start Client in Background Thread
    def run_client_thread():
        client = AegisLimbClient()
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            loop.run_until_complete(client.run())
        except Exception as e:
            logger.error(f"Client Thread Crash: {e}")

    t = threading.Thread(target=run_client_thread, daemon=True)
    t.start()

    # Run Tray on Main Thread (GUI Requirement)
    run_tray()
