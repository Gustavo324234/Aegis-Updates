import asyncio
import websockets
import json
import os
import time
try:
    from plyer import notification
except ImportError:
    notification = None
import requests
import sys
import subprocess
import logging
import platform
import uuid
from typing import Optional, Dict, Any
from cryptography.fernet import Fernet

# --- Configuration & Constants ---
CONFIG_FILE = "aegis_limb_config.json"
DEFAULT_GATEWAY_URL = os.getenv("AEGIS_GATEWAY_URL", "ws://localhost:8000/ws")
DEFAULT_WORKSPACE_ROOT = os.getenv("AEGIS_WORKSPACE_ROOT", os.getcwd())

# --- Logging Setup ---
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - [AegisLimb] - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("aegis_limb.log"),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger("AegisLimb")

# --- Security Module ---
class SecurityModule:
    def __init__(self, key: str):
        try:
            # Ensure key is bytes
            key_bytes = key.encode() if isinstance(key, str) else key
            self.cipher = Fernet(key_bytes)
            logger.info("Security Module initialized successfully.")
        except Exception as e:
            logger.critical(f"Failed to initialize encryption key: {e}")
            sys.exit(1)

    def decrypt(self, encrypted_token: str) -> Dict[str, Any]:
        """Decrypts a Fernet token into a dictionary."""
        try:
            # Token usually comes as a string, Fernet needs bytes
            token_bytes = encrypted_token.encode() if isinstance(encrypted_token, str) else encrypted_token
            decrypted_data = self.cipher.decrypt(token_bytes)
            return json.loads(decrypted_data.decode('utf-8'))
        except Exception as e:
            logger.error(f"Decryption failed: {e}")
            raise

    def encrypt(self, data: Dict[str, Any]) -> str:
        """Encrypts a dictionary into a Fernet string token."""
        try:
            json_str = json.dumps(data)
            encrypted_bytes = self.cipher.encrypt(json_str.encode('utf-8'))
            return encrypted_bytes.decode('utf-8')
        except Exception as e:
            logger.error(f"Encryption failed: {e}")
            raise

# --- Command Handler ---
class CommandHandler:
    def __init__(self, workspace_root: str, api_keys: Dict[str, str] = None):
        self.workspace_root = os.path.abspath(workspace_root)
        self.api_keys = api_keys or {}
        logger.info(f"Command Handler initialized. Workspace Root: {self.workspace_root}")

    def _resolve_path(self, path: str) -> str:
        """Safely resolves path relative to workspace root with fallback."""
        folder = os.path.abspath(self.workspace_root)
        # Force relative handling or absolute check
        if os.path.isabs(path):
             # Ensure absolute path is inside workspace
             target = os.path.abspath(path)
        else:
             target = os.path.abspath(os.path.join(folder, path))
        
        try:
            if os.path.commonpath([folder, target]) != folder:
                raise ValueError(f"Security Alert: Path '{path}' attempts to escape workspace root '{folder}'.")
        except ValueError:
             raise ValueError(f"Security Alert: Path '{path}' attempts to escape workspace root (Drive Mismatch).")
             
        return target

    async def execute(self, cmd_data: Dict[str, Any]) -> Dict[str, Any]:
        cmd_type = cmd_data.get("cmd") or cmd_data.get("type")
        args = cmd_data.get("args", {})
        
        # Merge top-level args if not nested (fallback for varying formats)
        if not args:
            args = {k: v for k, v in cmd_data.items() if k not in ["cmd", "type", "id", "reply_to"]}

        logger.info(f"Executing command: {cmd_type}")

        try:
            if cmd_type == "terminal_cmd":
                return await self.terminal_cmd(args)
            elif cmd_type == "file_ops":
                return await self.file_ops(args)
            elif cmd_type == "write_to_workspace":
                return await self.write_to_workspace(args)
            elif cmd_type == "index_remote_workspace":
                return await self.index_remote_workspace(args)
            elif cmd_type == "delegate_task":
                return await self.delegate_task(args)
            else:
                return {"status": "error", "message": f"Unknown command: {cmd_type}"}
        except Exception as e:
            logger.error(f"Command execution error: {e}")
            return {"status": "error", "message": str(e)}

    async def terminal_cmd(self, args: Dict[str, Any]) -> Dict[str, Any]:
        command = args.get("command")
        if not command:
            return {"status": "error", "message": "No command provided"}

        logger.info(f"Running shell command: {command}")
        
        # Use asyncio subprocess
        proc = await asyncio.create_subprocess_shell(
            command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=self.workspace_root
        )
        
        stdout, stderr = await proc.communicate()
        
        return {
            "status": "success",
            "stdout": stdout.decode(errors='replace').strip(),
            "stderr": stderr.decode(errors='replace').strip(),
            "returncode": proc.returncode
        }

    async def file_ops(self, args: Dict[str, Any]) -> Dict[str, Any]:
        operation = args.get("operation")
        path = args.get("path")
        content = args.get("content")
        
        if not operation or not path:
            return {"status": "error", "message": "Missing operation or path"}

        full_path = self._resolve_path(path)

        try:
            if operation == "read":
                if not os.path.exists(full_path):
                    return {"status": "error", "message": "File not found"}
                async def read():
                    with open(full_path, 'r', encoding='utf-8') as f:
                        return f.read()
                data = await asyncio.to_thread(read)
                return {"status": "success", "data": data}

            elif operation == "write":
                async def write():
                    os.makedirs(os.path.dirname(full_path) or '.', exist_ok=True)
                    with open(full_path, 'w', encoding='utf-8') as f:
                        f.write(content or "")
                await asyncio.to_thread(write)
                return {"status": "success", "message": f"Written to {full_path}"}

            elif operation == "delete":
                if os.path.exists(full_path):
                    await asyncio.to_thread(os.remove, full_path)
                    return {"status": "success", "message": f"Deleted {full_path}"}
                return {"status": "error", "message": "File not found"}
            
            elif operation == "list":
                 if os.path.exists(full_path) and os.path.isdir(full_path):
                     files = await asyncio.to_thread(os.listdir, full_path)
                     return {"status": "success", "files": files}
                 return {"status": "error", "message": "Directory not found"}

            else:
                return {"status": "error", "message": f"Unknown file operation: {operation}"}

        except Exception as e:
            return {"status": "error", "message": str(e)}

    async def index_remote_workspace(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Scans workspace and returns simplified file map."""
        file_map = []
        ignore_dirs = {'.git', '__pycache__', 'node_modules', 'venv', '.env', '.idea', '.vscode'}
        ignore_ext = {'.pyc', '.exe', '.dll', '.so', '.bin'}
        
        try:
            for root, dirs, files in os.walk(self.workspace_root):
                # Modify dirs in-place to skip ignored
                dirs[:] = [d for d in dirs if d not in ignore_dirs]
                
                for file in files:
                    if any(file.endswith(ext) for ext in ignore_ext): continue
                    
                    full_path = os.path.join(root, file)
                    rel_path = os.path.relpath(full_path, self.workspace_root)
                    size = os.path.getsize(full_path)
                    
                    # Basic structure for LLM consumption
                    file_map.append({
                        "path": rel_path.replace("\\", "/"), 
                        "size": size,
                        "type": "file"
                    })
            return {"status": "success", "file_map": file_map}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    async def write_to_workspace(self, args: Dict[str, Any]) -> Dict[str, Any]:
        # Alias for file_ops write, but specific to workspace tasks
        # Can handle 'filename' or 'path'
        path = args.get("filename") or args.get("path")
        content = args.get("content")
        
        if not path:
             return {"status": "error", "message": "Filename required for write_to_workspace"}
             
        return await self.file_ops({
            "operation": "write",
            "path": path,
            "content": content
        })



    # --- SWARM DELEGATION ---
    async def delegate_task(self, args: Dict[str, Any]) -> Dict[str, Any]:
        task_type = args.get("task_type")
        payload = args.get("payload", {})
        
        logger.info(f"Received delegated task: {task_type}")
        
        try:
            if task_type == "index_folder":
                return await self._task_index_folder(payload)
            elif task_type == "process_pdf":
                return await self._task_process_pdf(payload)
            elif task_type == "generate_embeddings":
                return await self._task_generate_embeddings(payload)
            elif task_type == "analyze_file":
                return await self._task_analyze_file(payload)
            else:
                return {"status": "error", "message": f"Unknown task: {task_type}"}
        except Exception as e:
            return {"status": "error", "message": f"Task Failed: {str(e)}"}

    async def _task_index_folder(self, payload):
        path = payload.get("path", ".")
        full_path = self._resolve_path(path)
        if not os.path.exists(full_path): return {"status": "error", "message": "Path not found"}
        
        # Simple recursive list
        file_list = []
        for root, dirs, files in os.walk(full_path):
             for f in files:
                 file_list.append(os.path.join(root, f))
        return {"status": "success", "files": file_list[:1000], "count": len(file_list)} # Limit return size

    async def _task_process_pdf(self, payload):
        start_time = time.time()
        path = payload.get("path")
        full_path = self._resolve_path(path)
        
        if not os.path.exists(full_path): return {"status": "error", "message": "PDF not found"}
        
        try:
            import pypdf
        except ImportError:
            return {"status": "error", "message": "pypdf not installed on Satellite. Run pip install pypdf."}
            
        text_content = ""
        try:
            with open(full_path, 'rb') as f:
                reader = pypdf.PdfReader(f)
                for page in reader.pages:
                    text_content += page.extract_text() + "\n"
            
            processing_time = time.time() - start_time
            return {"status": "success", "text_preview": text_content[:500], "full_length": len(text_content), "time": processing_time}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    async def _task_generate_embeddings(self, payload):
        text = payload.get("text")
        if not text: return {"status": "error", "message": "No text provided"}
        
        try:
            from sentence_transformers import SentenceTransformer
            # Load model (this will be slow on first run)
            logger.info("Loading Embedding Model...")
            model = SentenceTransformer('all-MiniLM-L6-v2') 
            embeddings = model.encode(text)
            
            return {"status": "success", "vector_length": len(embeddings), "vector": embeddings.tolist()}
        except ImportError:
             return {"status": "error", "message": "sentence-transformers not installed"}
        except Exception as e:
             return {"status": "error", "message": str(e)}

    # --- LOCAL INTELLIGENCE ---
    async def _call_llm(self, prompt: str, provider: str = "groq", model: str = None) -> str:
        key = self.api_keys.get(provider)
        
        if not key:
            return f"Error: No API Key found for '{provider}' in aegis_limb_config.json. Add it under 'api_keys'."

        if provider == "groq":
            try:
                # Use standard Requests to Groq (OpenAI compatible)
                url = "https://api.groq.com/openai/v1/chat/completions"
                headers = {
                    "Authorization": f"Bearer {key}",
                    "Content-Type": "application/json"
                }
                data = {
                    "model": model or "llama3-70b-8192", 
                    "messages": [{"role": "user", "content": prompt}],
                    "temperature": 0.7,
                    "max_tokens": 1024
                }
                
                logger.info(f"Calling Groq Local Intelligence (Model: {data['model']})...")
                resp = await asyncio.to_thread(requests.post, url, json=data, headers=headers)
                
                if resp.status_code == 200:
                    return resp.json()["choices"][0]["message"]["content"]
                else:
                    return f"Groq Error {resp.status_code}: {resp.text}"
            except Exception as e:
                return f"Groq Request Failed: {e}"
        
        # Add other providers here if needed (e.g. Gemini)
        return f"Provider '{provider}' not implemented locally."

    async def _task_analyze_file(self, payload):
        path = payload.get("path")
        prompt_instruction = payload.get("instruction", "Summarize this file shortly.")
        provider = payload.get("provider", "groq")
        model = payload.get("model") # Optional override
        
        full_path = self._resolve_path(path)
        if not os.path.exists(full_path): 
            return {"status": "error", "message": "File not found"}
        
        try:
            # Read content
            with open(full_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            # Truncate content if too large (Approx 25k chars ~ 6k tokens)
            if len(content) > 25000:
                content = content[:25000] + "\n...[Truncated for Speed]"
            
            final_prompt = f"{prompt_instruction}\n\n--- FILE CONTENT ---\n{content}"
            
            start_t = time.time()
            summary = await self._call_llm(final_prompt, provider, model)
            duration = time.time() - start_t
            
            return {
                "status": "success", 
                "summary": summary, 
                "provider": provider,
                "duration": duration
            }
        except Exception as e:
            return {"status": "error", "message": str(e)}

# --- Main Client ---
class AegisLimbClient:
    def __init__(self):
        self.config = self.load_config()
        self.node_id = self.config.get("node_id")
        self.gateway_url = self.config.get("gateway_url", DEFAULT_GATEWAY_URL)
        self.ws_url = f"{self.gateway_url}/{self.node_id}"
        
        # Initialize Security
        self.security = SecurityModule(self.config.get("secret_key"))
        
        # Initialize Command Handler
        workspace_path = self.config.get("workspace_root", DEFAULT_WORKSPACE_ROOT)
        api_keys = self.config.get("api_keys", {})
        self.handler = CommandHandler(workspace_path, api_keys)
        
        self.running = True

    def load_config(self) -> Dict[str, Any]:
        """Loads config, ensuring mandatory identity fields exist."""
        config = {}
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE, 'r') as f:
                    config = json.load(f)
            except Exception:
                logger.warning("Config file corrupt. Re-creating.")

        # Check for mandatory fields
        updated = False
        
        if "node_id" not in config:
            config["node_id"] = f"limb_{uuid.uuid4().hex[:8]}"
            updated = True
            
        if "secret_key" not in config:
            config["secret_key"] = Fernet.generate_key().decode()
            updated = True
            
        if "gateway_url" not in config:
            config["gateway_url"] = DEFAULT_GATEWAY_URL
            updated = True

        # Defaults for optional fields
        if "workspace_root" not in config:
            config["workspace_root"] = DEFAULT_WORKSPACE_ROOT
            updated = True
        if "auto_open" not in config:
            config["auto_open"] = False
            updated = True
        if "contribution_mode" not in config:
            config["contribution_mode"] = False
            updated = True
        if "api_keys" not in config:
            config["api_keys"] = {}
            updated = True

        if updated:
            with open(CONFIG_FILE, 'w') as f:
                json.dump(config, f, indent=4)
            
            # Log new identity details
            if updated and "node_id" in config:
                logger.warning(f"IDENTITY UPDATED/CREATED. Node ID: {config['node_id']}")
                logger.warning(f"GATEWAY URL: {config['gateway_url']}")

        return config

    def register_with_gateway(self):
        """Registers via HTTP to exchange keys secure-ish."""
        
        print(f"\n🔵 AEGIS SATELLITE INTERFACE [{self.node_id}]")
        print("Connecting to Nexus...")
        
        # Try to register
        payload = {
            "node_id": self.node_id,
            "public_key": "limbv1", # Placeholder
            "fernet_key": self.config.get("secret_key"),
            "pairing_code": self.config.get("pairing_code_cache"),
            "contribution_mode": self.config.get("contribution_mode", False)
        }
        
        # Simple loop for pairing
        attempt_urls = [self.gateway_url, DEFAULT_GATEWAY_URL, "ws://localhost:8000/ws"]
        # De-duplicate
        attempt_urls = list(dict.fromkeys(attempt_urls))
        
        while True:
            for url in attempt_urls:
                try:
                    # Update current target for this attempt
                    self.gateway_url = url
                    
                    # Convert ws:// to http://
                    http_url = self.gateway_url.replace("ws://", "http://").replace("wss://", "https://").replace("/ws", "")
                    logger.info(f"Attempting registration with {http_url}...")
                    
                    resp = requests.post(f"{http_url}/register", json=payload, timeout=5)
                
                    if resp.status_code == 200:
                        logger.info(f"✅ Registration Successful with {http_url}. Keys Exchanged.")
                        
                        # Persist the successful Gateway URL if it changed
                        if self.config.get("gateway_url") != self.gateway_url:
                            self.config["gateway_url"] = self.gateway_url
                            with open(CONFIG_FILE, 'w') as f:
                                json.dump(self.config, f, indent=4)
                            logger.info(f"Configuration updated with Gateway URL: {self.gateway_url}")
                            
                        return True
                    elif resp.status_code == 403:
                        # Pairing Code Required
                        print("\n⚠️  PAIRING REQUIRED")
                        print("Please generate a Pairing Code on Aegis Hub (Network Mesh Panel).")
                        try:
                            code = input("Enter Pairing Code: ").strip()
                            payload["pairing_code"] = code
                        except EOFError:
                            # Handle non-interactive environments
                            logger.error("Cannot read input in non-interactive mode.")
                            time.sleep(5)
                    else:
                        logger.error(f"Registration Error from {url}: {resp.text}")
                        
                except Exception as e:
                    logger.error(f"Connection Error with {url}: {e}")
            
            logger.warning("All connection attempts failed. Retrying in 5s...")
            time.sleep(5)

    async def run(self):
        logger.info(f"Starting Aegis Limb Client {self.node_id}...")
        
        # 1. Register / Pair
        # This might update self.gateway_url
        if self.register_with_gateway():
             self.ws_url = f"{self.gateway_url}/{self.node_id}"
             logger.info(f"Gateway Locked: {self.gateway_url}")
        else:
             logger.warning("Registration loop exited without success.")
             return
        
        backoff = 1
        
        while self.running:
            try:
                # 2. Connect WebSockets
                logger.info(f"Connecting to Gateway: {self.ws_url}")
                async with websockets.connect(self.ws_url) as websocket:
                    logger.info("✅ Connected via WebSocket!")
                    backoff = 1 # Reset on successful connection
                    
                    # Connection Loop
                    while self.running:
                        try:
                            message = await websocket.recv()
                            await self.handle_message(websocket, message)
                        except websockets.ConnectionClosed:
                            logger.warning("Connection lost.")
                            break # Break inner loop to trigger reconnect
                        except Exception as e:
                            logger.error(f"Error in msg loop: {e}")
                            break
                            
            except (OSError, asyncio.TimeoutError, websockets.InvalidURI, websockets.InvalidHandshake) as e:
                 logger.error(f"Connection Failed: {e}")
            except Exception as e:
                 logger.error(f"Unexpected Connection Error: {e}")

            if self.running:
                logger.warning(f"Reconnecting in {backoff}s...")
                await asyncio.sleep(backoff)
                # Strategy: 1s -> 5s -> 30s cap
                if backoff == 1:
                    backoff = 5
                else:
                    backoff = 30

    async def check_queue_loop(self):
        """Periodically checks for missed offline messages."""
        logger.info("Starting Queue Worker...")
        while self.running:
            try:
                # Poll every 60s or so
                await asyncio.sleep(60)
                
                # Check Queue via HTTP
                http_url = self.gateway_url.replace("ws://", "http://").replace("wss://", "https://").replace("/ws", "")
                url = f"{http_url}/check_queue/{self.node_id}"
                
                resp = await asyncio.to_thread(requests.get, url, timeout=10)
                if resp.status_code == 200:
                    data = resp.json()
                    status = data.get("status")
                    
                    if status == "success":
                        encrypted_bundle = data.get("encrypted_bundle")
                        if encrypted_bundle:
                            try:
                                # 1. Decrypt Bundle
                                bundle_json = self.security.cipher.decrypt(encrypted_bundle.encode()).decode()
                                bundle = json.loads(bundle_json)
                                messages = bundle.get("messages", [])
                                
                                logger.info(f"📥 Retrieved {len(messages)} offline messages.")
                                
                                # 2. Process each
                                for msg_content in messages:
                                    # msg_content is likely stringified JSON (envelope)
                                    # We can reuse handle_message if we mock the logic, 
                                    # but handle_message expects websocket for replying.
                                    # For queue, replies might be tricky. For now, we just execute.
                                    # We can pass None as websocket, provided handle_message checks it.
                                    if isinstance(msg_content, str):
                                        await self.handle_message(None, msg_content)
                                    elif isinstance(msg_content, dict):
                                         # If it's already dict
                                         await self.handle_message(None, json.dumps(msg_content))
                                         
                            except Exception as e:
                                logger.error(f"Failed to process message bundle: {e}")
                                
                    elif status == "empty":
                        pass
                    else:
                        logger.warning(f"Check Queue Status: {status}")
                        
            except Exception as e:
                # Don't spam logs if offline
                # logger.debug(f"Queue Check Failed: {e}")
                pass

    async def handle_message(self, websocket, raw_msg: str):
        # The gateway sends {"target": ..., "msg": ...} OR just the msg content depending on implementation.
        # Based on local nexus_gateway.py, it sends 'message_str' which is json.dumps(payload.content).
        
        try:
            # 1. Parse JSON
            try:
                envelope = json.loads(raw_msg)
            except json.JSONDecodeError:
                # Could be raw string? unlikely.
                logger.warning(f"Received non-JSON message: {raw_msg[:50]}...")
                return

            # 2. Extract Encrypted Token
            # We expect {"encrypted_data": "..."} inside the message
            encrypted_token = envelope.get("encrypted_data")
            
            if not encrypted_token:
                # Might be a plaintext control message from gateway
                if "status" in envelope:
                    logger.info(f"Gateway Status: {envelope}")
                    return
                logger.warning("Received message with no encrypted_data")
                return

            # 3. Decrypt
            command_data = self.security.decrypt(encrypted_token)
            
            # 4. Execute
            result = await self.handler.execute(command_data)

            # --- UX: Notifications & Auto-Open ---
            cmd_type = command_data.get("type") or command_data.get("cmd")
            if cmd_type == "write_to_workspace" and isinstance(result, dict) and result.get("status") == "success":
                filename = command_data.get("filename") or command_data.get("path") or "unknown_file"
                # Resolve full path safely
                try:
                    full_path = os.path.abspath(os.path.join(self.handler.workspace_root, filename))
                except:
                    full_path = filename
                
                # 1. Notify
                if notification:
                    try:
                        notification.notify(
                            title="🛡️ Aegis: New Task",
                            message=f"Received: {filename}",
                            app_name="Aegis Limb",
                            timeout=5
                        )
                    except Exception: pass
                else: 
                     print(f"\n[🔔 NOTIFICATION] New File: {filename}")

                # 2. Auto-Open
                if self.config.get("auto_open"):
                     try:
                         if platform.system() == 'Windows':
                             os.startfile(full_path)
                         elif platform.system() == 'Darwin':
                             subprocess.call(('open', full_path))
                         else:
                             subprocess.call(('xdg-open', full_path))
                         logger.info(f"Auto-opened: {full_path}")
                     except Exception as e:
                         logger.error(f"Auto-open failed: {e}")
            
            # 5. Send Response (if needed/requested)
            # Response Packet
            response_payload = {
                "result": result,
                "cmd_id": command_data.get("id")
            }
            
            # Encrypt Response
            encrypted_response = self.security.encrypt(response_payload)
            
            # Send back
            # If the command had a 'reply_to' field, we target that node.
            # Otherwise we just send it to the gateway (which might not know where to send it).
            reply_to = command_data.get("reply_to")
            
            if reply_to and websocket:
                outbound = {
                    "target": reply_to,
                    "msg": {
                        "encrypted_data": encrypted_response,
                        "sender": self.node_id
                    }
                }
                await websocket.send(json.dumps(outbound))
                logger.info(f"Sent encrypted response to {reply_to}")
            elif reply_to and not websocket:
                 logger.warning(f"Cannot reply to {reply_to} (Offline/Queue Mode). Response dropped.")
            else:
                logger.info("Command executed. No 'reply_to' specified, silent completion.")

        except Exception as e:
            logger.error(f"Message handling error: {e}")

if __name__ == "__main__":
    if platform.system() == 'Windows':
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

    client = AegisLimbClient()
    try:
        # Run Client + Queue Worker
        loop = asyncio.new_event_loop() 
        asyncio.set_event_loop(loop)
        
        async def main_wrapper():
             # Run both valid tasks
             await asyncio.gather(
                 client.run(),
                 client.check_queue_loop()
             )
        
        loop.run_until_complete(main_wrapper())
        
    except KeyboardInterrupt:
        logger.info("Stopped by user.")
