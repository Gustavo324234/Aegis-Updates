import os
import sys
# Mock genai to avoid import errors if not configured, though core handles it gracefully
sys.modules['google.generativeai'] = type('MockGenAI', (object,), {'configure': lambda **kwargs: None, 'GenerativeModel': lambda *args: None})

# Adjust path to find modules
sys.path.append(os.getcwd())

from core import AegisBrain
import database

print("--- 🧪 INICIANDO TEST DE LOGS DEL GATEWAY ---")

# Initialize Brain
brain = AegisBrain()

# Mock settings for the test
# We want to force Local Only or Hybrid to see the discovery log
database.update_setting("operation_mode", "Local Only (Sovereign)")
database.update_setting("active_model", "ollama-nonexistent-model") # To trigger invalid model logic
database.update_setting("local_chat_model", "llama3.1") # Default fallback

# Mock history
history = [("user", "Hola, ¿cómo estás?")]

# Run a Query
print("\n--- 🚀 EJECUTANDO QUERY SIMULADA ---")
# We use a dummy prompt that shouldn't actually call LLM if we don't want to wait, 
# but core.py will try to connect. 
# We just want to see the PRE-FLIGHT logs.
# We'll use a very short timeout or just let it fail naturally if ollama isn't up, 
# but the logs BEFORE the call are what matters.

try:
    # This might fail if Ollama isn't actually running on localhost:11434, but logs will show before that.
    brain.query("Hola Aegis, prueba de logs.", history, "ollama-llama3")
except Exception as e:
    print(f"\n[TEST END] La llamada terminó (posiblemente por timeout/conexión), pero arriba deberías ver los logs.")

print("\n--- ✅ FIN DEL TEST ---")
