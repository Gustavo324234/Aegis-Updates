import sys
import os

# Add root to path so imports work
root_dir = os.path.dirname(os.path.abspath(__file__))
if root_dir not in sys.path:
    sys.path.insert(0, root_dir)

print("Checking imports...")

try:
    print("Checking modules/vault_manager.py...")
    import modules.vault_manager

    print("SUCCESS: modules.vault_manager imported without syntax error.")
except SyntaxError as e:
    print(f"FAILURE: SyntaxError in vault_manager: {e}")
except Exception as e:
    print(f"WARNING: Other error in vault_manager: {e}")

try:
    print("Checking core.py...")
    import core

    print("SUCCESS: core imported without syntax error.")
except SyntaxError as e:
    print(f"FAILURE: SyntaxError in core: {e}")
except Exception as e:
    print(f"WARNING: Other error in core: {e}")

try:
    print("Checking database.py...")
    import database

    print("SUCCESS: database imported without syntax error.")
except SyntaxError as e:
    print(f"FAILURE: SyntaxError in database: {e}")
except Exception as e:
    print(f"WARNING: Other error in database: {e}")

print("Verification complete.")
