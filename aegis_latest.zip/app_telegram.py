import logging
import asyncio
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    ApplicationBuilder,
    ContextTypes,
    CommandHandler,
    MessageHandler,
    filters,
    CallbackQueryHandler,
)
from core import AegisBrain
import database
import json
import os

# CONFIGURATION
TOKEN = os.getenv("TELEGRAM_TOKEN", "YOUR_TELEGRAM_TOKEN_HERE")
AUTHORIZED_CHAT_ID = int(
    os.getenv("TELEGRAM_CHAT_ID", "123456789")
)  # Replace with your ID

# Initialize Brain
brain = AegisBrain()
database.init_db()

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO
)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_chat.id != AUTHORIZED_CHAT_ID:
        await update.message.reply_text("⛔ ACCESS DENIED.")
        return
    await update.message.reply_text("🛡️ Aegis-IA Online. Systems Operational.")


async def send_push_notification(message):
    """Proactive Push Notification to Authorized User."""
    bot = ApplicationBuilder().token(TOKEN).build().bot
    try:
        await bot.send_message(
            chat_id=AUTHORIZED_CHAT_ID,
            text=f"🔔 *Aegis Alert:*\n{message}",
            parse_mode="Markdown",
        )
    except Exception as e:
        print(f"[!] Push Failed: {e}")


def trigger_push(message):
    """Sync wrapper for async push (call from other modules)."""
    try:
        asyncio.run(send_push_notification(message))
    except Exception as e:
        # If loop is already running (e.g. inside main app), this might fail.
        # Ideally, main app loop handles it. For now, best effort.
        print(f"Trigger Push Error: {e}")


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_chat.id != AUTHORIZED_CHAT_ID:
        return

    user_msg = update.message.text
    chat_id = update.effective_chat.id

    # Save User Message to DB (so it shows on Web too)
    # Telegram usually defaults to 'general' or a specific 'Telegram' context if desired.
    # For unity with Web V3, let's use 'general' by default, or maybe track per-user context if we wanted.
    # To keep it simple and consistent with V3 Web default:
    thread_tag = "general"
    database.save_message("user", user_msg, "Telegram", thread_tag)

    # Get History (Shared with Web)
    history = database.get_history(limit=20, thread_tag=thread_tag)

    await context.bot.send_chat_action(chat_id=chat_id, action="typing")

    # Process with Brain
    response = brain.query(user_msg, history, "Ollama (mistral)")

    # Save Assistant Response
    database.save_message("assistant", response, "Telegram", thread_tag)

    # Check if response is JSON Action
    if response.strip().startswith("{") and response.strip().endswith("}"):
        try:
            action_data = json.loads(response)
            module_name = action_data.get("module", "system_tools")

            # Create Inline Keyboard for Decision
            keyboard = [
                [
                    InlineKeyboardButton(
                        "EXECUTE", callback_data=f"exec|{module_name}"
                    ),
                    InlineKeyboardButton("DENY", callback_data="deny"),
                ]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)

            # Store action data in context.user_data to retrieve on callback
            context.user_data["pending_action"] = action_data

            await update.message.reply_text(
                f"⚠️ *Action Request:*\n`{json.dumps(action_data, indent=2)}`",
                parse_mode="MarkdownV2",
                reply_markup=reply_markup,
            )
        except Exception:
            await update.message.reply_text(response)
    else:
        await update.message.reply_text(response)


async def button_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if query.message.chat.id != AUTHORIZED_CHAT_ID:
        return

    data = query.data
    thread_tag = "general"  # Default for telegram responses

    if data.startswith("exec"):
        action_data = context.user_data.get("pending_action")
        if action_data:
            module_name = data.split("|")[1]
            result = brain.module_manager.execute_module(module_name, action_data)

            # Save system result
            database.save_message(
                "system", f"Module Result:\n{result}", "Telegram", thread_tag
            )

            await query.edit_message_text(text=f"✅ Executed. Result:\n{result}")
        else:
            await query.edit_message_text(text="❌ Error: Action data executed.")

    elif data == "deny":
        database.save_message("system", "Action Denied by User", "Telegram", thread_tag)
        await query.edit_message_text(text="🚫 Action Denied.")


if __name__ == "__main__":
    application = ApplicationBuilder().token(TOKEN).build()

    application.add_handler(CommandHandler("start", start))
    application.add_handler(
        MessageHandler(filters.TEXT & (~filters.COMMAND), handle_message)
    )
    application.add_handler(CallbackQueryHandler(button_callback))

    print("Aegis-IA Telegram Bridge Running...")
    application.run_polling()
