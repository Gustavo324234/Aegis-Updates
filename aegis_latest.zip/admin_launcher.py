import streamlit as st
import psutil
import subprocess
import os
import sys
import time
import json
import shutil
import socket
from datetime import datetime

# --- CONFIGURATION (SRE ISOLATION) ---
st.set_page_config(
    page_title="Aegis Admin Launcher v2.0",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="collapsed"
)

# --- STYLE CHEAT SHEET (Hades V2 Minimal) ---
st.markdown("""
    <style>
    /* Dark Theme */
    .stApp { background-color: #0e1117; color: #FAFAFA; }
    
    /* Typography */
    h1, h2, h3 { color: #00e5ff !important; font-family: 'Consolas', 'Courier New', monospace; }
    div[data-testid="stCaptionContainer"] { color: #888; }
    
    /* Tables */
    div[data-testid="column"] { border-right: 1px solid #333; }
    
    /* Buttons */
    .stButton>button { 
        color: #00e5ff; 
        border: 1px solid #00e5ff; 
        background-color: #1a1c24; 
        transition: all 0.2s;
    }
    .stButton>button:hover { 
        background-color: #00e5ff; 
        color: #000000; 
        box-shadow: 0 0 8px #00e5ff;
    }
    
    /* Emergency Zone */
    .emergency-text { color: #ff4b4b; font-weight: bold; }
    </style>
""", unsafe_allow_html=True)

# --- SRE UTILITIES ---

def get_aegis_processes():
    """
    Scans system for Aegis (app_web.py) processes using psutil.
    ISOLATION: Does NOT import any Aegis modules. Rely purely on OS signatures.
    """
    instances = []
    try:
        # Iterate over all processes
        for proc in psutil.process_iter(['pid', 'name', 'cmdline', 'memory_info', 'create_time']):
            try:
                # Safe access to process info
                pinfo = proc.info
                cmd = pinfo.get('cmdline', [])
                
                # Identification: Check if it's running streamlit AND app_web.py
                if cmd and len(cmd) > 1:
                    # Convert to string for easy searching
                    cmd_str = " ".join(cmd).lower()
                    if 'streamlit' in cmd_str and 'app_web.py' in cmd_str:
                        
                        # Extract Port
                        port = "8501" # Default Streamlit Port
                        if "--server.port" in cmd:
                            idx = cmd.index("--server.port")
                            if idx + 1 < len(cmd):
                                port = cmd[idx+1]
                                
                        # Metrics in MB
                        mem_mb = pinfo['memory_info'].rss / (1024 * 1024)
                        
                        # Uptime
                        created = datetime.fromtimestamp(pinfo['create_time'])
                        uptime = created.strftime('%H:%M:%S')
                        
                        instances.append({
                            "PID": pinfo['pid'],
                            "PORT": port,
                            "RAM_MB": round(mem_mb, 2),
                            "STATUS": "ONLINE",
                            "UPTIME": uptime
                        })
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue
    except Exception as e:
        st.error(f"SRE Monitor Error: {e}")
        
    return instances

def kill_process(pid):
    """Terminates a specific PID gracefully, then forcefully."""
    try:
        p = psutil.Process(pid)
        p.terminate()
        try:
            p.wait(timeout=2)
        except psutil.TimeoutExpired:
            p.kill()
        return True, "Terminated"
    except Exception as e:
        return False, str(e)

def emergency_kill_all():
    """
    SRE PROTOCOL: EMERGENCY SHUTDOWN.
    Kills all processes matching 'app_web.py'.
    """
    killed_count = 0
    errors = []
    
    # 1. Surgical Kill via Psutil
    targets = get_aegis_processes()
    for inst in targets:
        try:
            p = psutil.Process(inst['PID'])
            p.terminate()
            killed_count += 1
        except Exception as e:
            errors.append(f"PID {inst['PID']}: {e}")
    
    return killed_count, errors

def launch_instance(port, user_path=None):
    """Launches app_web.py via subprocess detached."""
    try:
        # Locate target safely
        target = os.path.abspath("app_web.py")
        if not os.path.exists(target):
            return False, "Critical: 'app_web.py' not found in CWD."
            
        env = os.environ.copy()
        if user_path:
            env['AEGIS_USER_ROOT'] = user_path
            
        cmd = [
            sys.executable, "-m", "streamlit", "run", target,
            "--server.port", str(port),
            "--server.address", "0.0.0.0",
            "--server.headless", "true",
            "--browser.gatherUsageStats", "false"
        ]
        
        # Launch detached
        if os.name == 'nt':
            # Windows specific flag for new console window
            subprocess.Popen(cmd, env=env, creationflags=subprocess.CREATE_NEW_CONSOLE)
        else:
            # POSIX: Start new session
            subprocess.Popen(cmd, env=env, start_new_session=True)
            
        return True, f"Launched Node on Port {port}"
    except Exception as e:
        return False, str(e)

def create_user_structure(username, port):
    """
    Creates the filesystem structure for a new User/Tenant.
    ISOLATION: Uses standard lib 'json' & 'os', no DB import.
    """
    try:
        base_dir = os.path.join("users", username)
        
        # 1. Create Directories
        dirs = [
            os.path.join(base_dir, "vault"),
            os.path.join(base_dir, "config"),
            os.path.join(base_dir, "skills"),
            os.path.join(base_dir, "logs")
        ]
        
        for d in dirs:
            os.makedirs(d, exist_ok=True)
            
        # 2. Default Config
        config_path = os.path.join(base_dir, "config", "settings.json")
        default_config = {
            "username": username,
            "port": port,
            "created_at": datetime.now().isoformat(),
            "active_plugins": ["core", "web_sentinel"],
            "theme": "hades_dark"
        }
        
        if not os.path.exists(config_path):
            with open(config_path, "w", encoding="utf-8") as f:
                json.dump(default_config, f, indent=4)
                
        return True, base_dir
    except Exception as e:
        return False, str(e)

def execute_git_pull():
    """Performs a hard reset and pull from origin."""
    log = []
    try:
        # 1. Reset
        res1 = subprocess.run(["git", "reset", "--hard"], capture_output=True, text=True)
        log.append(f"$ git reset --hard\n{res1.stdout}\n{res1.stderr}")
        
        # 2. Pull
        res2 = subprocess.run(["git", "pull"], capture_output=True, text=True)
        log.append(f"$ git pull\n{res2.stdout}\n{res2.stderr}")
        
        # 3. Pip Install
        if os.path.exists("requirements.txt"):
             res3 = subprocess.run([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"], capture_output=True, text=True)
             log.append(f"$ pip install -r requirements.txt\n{res3.stdout}\n{res3.stderr}")
        
        return "\n".join(log)
    except Exception as e:
        return f"Git Ops Failed: {e}"

# --- INTERFACE ---

st.title("🛡️ Aegis Admin Launcher v2.0")
st.caption("SRE Console | Isolation: Enabled | Zero-Trust")

tab_monitor, tab_users, tab_system = st.tabs(["📡 Monitor", "👥 Gestión de Usuarios", "⚙️ Sistema"])

# ==========================
# TAB 1: MONITOR (Original)
# ==========================
with tab_monitor:
    st.subheader("Active Instances")
    if st.button("🔄 Refresh Status", key="refresh_monitor"):
        st.rerun()

    instances = get_aegis_processes()

    if not instances:
        st.info("System Cold. No active instances detected.")
    else:
        # Minimalist Table Header
        cols = st.columns([1, 1, 2, 2, 2])
        cols[0].markdown("**PID**")
        cols[1].markdown("**PORT**")
        cols[2].markdown("**RAM**")
        cols[3].markdown("**UPTIME**")
        cols[4].markdown("**CONTROL**")
        
        # Rows
        for inst in instances:
            c1, c2, c3, c4, c5 = st.columns([1, 1, 2, 2, 2])
            c1.markdown(f"`{inst['PID']}`")
            c2.markdown(f"**:{inst['PORT']}**")
            
            # Color code RAM
            mem = inst['RAM_MB']
            color = "green" if mem < 500 else "orange" if mem < 1000 else "red"
            c3.markdown(f":{color}[{mem} MB]")
            
            c4.markdown(inst['UPTIME'])
            
            if c5.button("⛔ Kill", key=f"k_{inst['PID']}"):
                ok, msg = kill_process(inst['PID'])
                if ok:
                    st.toast(f"Terminated PID {inst['PID']}")
                    time.sleep(1)
                    st.rerun()
                else:
                    st.error(msg)
        
        # Footer Metrics
        st.markdown("---")
        c_tot1, c_tot2 = st.columns(2)
        c_tot1.metric("Total Nodes", len(instances))
        c_tot2.metric("Total Load (MB)", f"{sum(i['RAM_MB'] for i in instances):.1f}")

    st.divider()

    # DAMAGE CONTROL (Emergency)
    with st.expander("⚠️ DAMAGE CONTROL (Emergency Zone)"):
        st.markdown("### Emergency Shutdown Protocol")
        st.markdown("Use this ONLY if instances are zombie/unresponsive. This will force-kill ALL processes matching `app_web.py`.")
        
        col_em1, col_em2 = st.columns([1, 3])
        with col_em1:
            if st.button("☢️ EXECUTE ORDER 66", type="primary"):
                n, errs = emergency_kill_all()
                if n > 0:
                    st.success(f"Protocol Executed: {n} processes terminated.")
                else:
                    st.warning("No targets found.")
                
                if errs:
                    st.error(f"Errors: {errs}")
                
                time.sleep(2)
                st.rerun()

# ==========================
# TAB 2: GESTIÓN DE USUARIOS
# ==========================
with tab_users:
    st.subheader("🏭 User Factory")
    st.markdown("Deploy isolated workspaces for each tenant/user.")
    
    with st.form("new_user_form"):
        col_u1, col_u2 = st.columns(2)
        with col_u1:
            username = st.text_input("Username (Unique ID)", placeholder="admin_01")
        with col_u2:
            assigned_port = st.number_input("Assign Port", min_value=8501, max_value=9999, value=8501)
            
        submitted = st.form_submit_button("Deploy User Workspace & Launch")
        
        if submitted:
            if not username:
                st.error("Username is required.")
            else:
                # 1. Create Filesystem
                ok_fs, path_or_err = create_user_structure(username, assigned_port)
                
                if ok_fs:
                    st.success(f"✅ Workspace Created: {path_or_err}")
                    
                    # 2. Launch Instance
                    ok_launch, msg_launch = launch_instance(assigned_port, user_path=path_or_err)
                    if ok_launch:
                        st.success(f"🚀 {msg_launch}")
                        st.balloons()
                        time.sleep(2)
                        st.rerun()
                    else:
                        st.error(f"Launch Failed: {msg_launch}")
                else:
                    st.error(f"Filesystem Error: {path_or_err}")

    st.divider()
    st.markdown("### 📂 Existing Users")
    # Quick scan of users dir
    if os.path.exists("users"):
        users = [d for d in os.listdir("users") if os.path.isdir(os.path.join("users", d))]
        if users:
            st.code("\n".join(users), language="text")
        else:
            st.info("No user workspaces found.")

# ==========================
# TAB 3: SISTEMA / GIT OPS
# ==========================
with tab_system:
    st.subheader("⚙️ System Operations")
    
    col_sys1, col_sys2 = st.columns(2)
    
    with col_sys1:
        st.markdown("#### 🔄 Update Mechanism (Git Ops)")
        st.info("This will discard local changes and pull the latest version from remote repository.")
        
        if st.button("Force Update (Git Pull)", type="primary"):
            with st.spinner("Executing Git Operations..."):
                output = execute_git_pull()
                st.code(output, language="bash")
                if "Already up to date." in output:
                    st.success("System is up to date.")
                else:
                    st.success("Update process finished. Please restart if core files changed.")
                    
    with col_sys2:
        st.markdown("#### 💻 Host Stats")
        # Simple Host Metrics
        cpu = psutil.cpu_percent()
        ram = psutil.virtual_memory() # Available GB
        
        st.metric("Host CPU", f"{cpu}%")
        st.metric("Host RAM Free", f"{ram.available / (1024**3):.1f} GB")
        st.metric("Python Version", sys.version.split()[0])
