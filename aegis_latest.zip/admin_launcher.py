import streamlit as st
import sqlite3
import hashlib
import os
import subprocess
import time
import socket
import logging
import psutil
from datetime import datetime

# --- CONFIG ---
ADMIN_DB = "users.db"
START_PORT = 8501
MAX_PORT = 8550
GLOBAL_CONFIG_DIR = "global_config"

# --- SYSTEM INIT (DEEP CLEAN PROTOCOL) ---
REQUIRED_DIRS = [
    "users",
    "vault",
    "backups", 
    "quarantine",
    "config",
    GLOBAL_CONFIG_DIR
]
for d in REQUIRED_DIRS:
    if not os.path.exists(d):
        try:
            os.makedirs(d)
        except Exception as e:
            # Streamlit might interfere with print, but logging works
            logging.warning(f"Failed to create init dir {d}: {e}")

# --- LOGGING ---
logging.basicConfig(filename='hypervisor.log', level=logging.INFO, 
                    format='%(asctime)s - %(message)s')

# --- DATABASE ---
def init_admin_db():
    conn = sqlite3.connect(ADMIN_DB)
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE,
            password_hash TEXT,
            assigned_port INTEGER UNIQUE,
            ram_limit_mb INTEGER DEFAULT 512,
            status TEXT DEFAULT 'stopped',
            pid INTEGER DEFAULT 0,
            last_login TEXT
        )
    ''')
    # Default Admin
    try:
        c.execute("INSERT INTO users (username, password_hash, assigned_port) VALUES (?, ?, ?)", 
                  ("admin", hashlib.sha256("admin".encode()).hexdigest(), 8501))
    except sqlite3.IntegrityError:
        pass
        
    conn.commit()
    conn.close()

def get_user(username):
    conn = sqlite3.connect(ADMIN_DB)
    # Return dict
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE username = ?", (username,))
    row = c.fetchone()
    conn.close()
    return dict(row) if row else None

def verify_user(username, password):
    user = get_user(username)
    if user:
        ph = hashlib.sha256(password.encode()).hexdigest()
        if ph == user['password_hash']:
            return user
    return None

def create_user(username, password, port=None):
    conn = sqlite3.connect(ADMIN_DB)
    c = conn.cursor()
    if not port:
        # Find next available port
        c.execute("SELECT MAX(assigned_port) FROM users")
        last_port = c.fetchone()[0]
        port = (last_port or START_PORT) + 1
    
    ph = hashlib.sha256(password.encode()).hexdigest()
    try:
        c.execute("INSERT INTO users (username, password_hash, assigned_port) VALUES (?, ?, ?)",
                  (username, ph, port))
        conn.commit()
        return True, f"User {username} created on Port {port}"
    except Exception as e:
        return False, str(e)
    finally:
        conn.close()

def update_user_status(username, status, pid=0):
    conn = sqlite3.connect(ADMIN_DB)
    c = conn.cursor()
    c.execute("UPDATE users SET status = ?, pid = ?, last_login = ? WHERE username = ?",
              (status, pid, datetime.now().isoformat(), username))
    conn.commit()
    conn.close()

# --- HYPERVISOR LOGIC ---
def is_port_in_use(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(('localhost', port)) == 0

def kill_process(pid):
    try:
        if pid <= 0: return
        p = psutil.Process(pid)
        p.terminate()
        p.wait(3)
        return True
    except:
        return False

def launch_instance(username):
    user = get_user(username)
    if not user: return False, "User not found"
    
    port = user['assigned_port']
    user_root = f"users/{username}"
    
    # Check if already running
    if is_port_in_use(port):
        # Already running?
        # Update db just in case
        update_user_status(username, 'running', user['pid'])
        return True, f"Instance already active on Port {port}"
        
    # Prepare Environment
    env = os.environ.copy()
    env["AEGIS_USER_ROOT"] = user_root
    env["STREAMLIT_SERVER_PORT"] = str(port)
    env["STREAMLIT_SERVER_HEADLESS"] = "true"
    env["AEGIS_RAM_LIMIT_MB"] = str(user.get("ram_limit_mb", 512))
    
    # Launch
    import sys
    cmd = [
        sys.executable, "-m", "streamlit", "run", "app_web.py",
        "--server.port", str(port),
        "--server.headless", "true",
        "--browser.serverAddress", "localhost"
    ]
    
    try:
        # Use CREATE_NEW_CONSOLE to detach properly on Windows or nohup on Linux
        # On Windows, we want it detached. 
        # Using subprocess.Popen
        
        # Ensure directory exists before launch (handled by database.py but safe to do here)
        os.makedirs(user_root, exist_ok=True)
        
        proc = subprocess.Popen(cmd, env=env, cwd=os.getcwd(), 
                                creationflags=subprocess.CREATE_NEW_CONSOLE if os.name == 'nt' else 0)
        
        update_user_status(username, "running", proc.pid)
        logging.info(f"Launched instance for {username} on port {port} (PID: {proc.pid})")
        
        # Wait a bit for startup
        time.sleep(3)
        return True, f"Instance launched on Port {port}"
        
    except Exception as e:
        logging.error(f"Launch failed for {username}: {e}")
        return False, str(e)

def stop_instance(username):
    user = get_user(username)
    if not user: return
    
    # Kill by PID
    if user['pid']:
        kill_process(user['pid'])
    
    # Kill by Port (Safety Net)
    # (Optional: implementation specific)
    
    update_user_status(username, "stopped", 0)
    return f"Instance {username} stopped."

# --- UI ---
st.set_page_config(page_title="Aegis Hypervisor", layout="centered", page_icon="🛡️")

init_admin_db()

st.title("🛡️ Aegis Hypervisor")
st.caption("Multi-Tenancy Access Portal")

if 'hv_user' not in st.session_state:
    st.session_state.hv_user = None

# VIEW: LOGIN
if not st.session_state.hv_user:
    with st.form("login_form"):
        u = st.text_input("Username")
        p = st.text_input("Password", type="password")
        if st.form_submit_button("Access"):
            user = verify_user(u, p)
            if user:
                st.session_state.hv_user = user
                st.rerun()
            else:
                st.error("Invalid credentials")
else:
    # VIEW: DASHBOARD
    user = st.session_state.hv_user
    st.success(f"Welcome, {user['username']}")
    
    # Admin Panel
    if user['username'] == 'admin':
        with st.expander("Admin Console", expanded=True):
            st.subheader("Manage Users")
            
            # Create User
            c1, c2, c3 = st.columns([2,2,1])
            with c1: new_u = st.text_input("New User")
            with c2: new_p = st.text_input("New Pass", type="password")
            with c3: 
                if st.button("Create"):
                    ok, msg = create_user(new_u, new_p)
                    if ok: st.success(msg)
                    else: st.error(msg)
            
            st.divider()
            
            # List Instances
            conn = sqlite3.connect(ADMIN_DB)
            conn.row_factory = sqlite3.Row
            users = conn.execute("SELECT * FROM users").fetchall()
            conn.close()
            
            for u in users:
                c1, c2, c3, c4 = st.columns([1, 1, 1, 2])
                c1.write(f"**{u['username']}**")
                c2.write(f"Port: {u['assigned_port']}")
                
                status_color = "green" if u['status'] == 'running' else "red"
                c3.markdown(f":{status_color}[{u['status'].upper()}]")
                
                with c4:
                    metrics_text = ""
                    if u['status'] == 'running' and u['pid']:
                        try:
                            # Monitor Real-time
                            p = psutil.Process(u['pid'])
                            try:
                                mem = p.memory_info().rss / (1024 * 1024)
                                cpu = p.cpu_percent(interval=None) # First call is 0, calls are too infrequent? No, interval=None returns since last call.
                                # Store for display
                                limit = u.get("ram_limit_mb", 512)
                                color = "red" if mem > limit else "green"
                                metrics_text = f"CPU: {cpu:.1f}% | RAM: :{color}[{mem:.1f}MB] / {limit}MB"
                            except Exception:
                                metrics_text = "Metrics N/A"
                                
                            # Check hibernate state from DB or just assume running?
                            # DB status is correct.
                        except psutil.NoSuchProcess:
                            # Process died outside of our control
                            update_user_status(u['username'], "crashed", 0)
                            st.rerun()

                    if metrics_text:
                        st.caption(metrics_text)

                    if u['status'] != 'running':
                        if st.button(f"Start", key=f"start_{u['username']}"):
                             ok, msg = launch_instance(u['username'])
                             if ok: st.rerun()
                    else:
                        if st.button(f"Stop", key=f"stop_{u['username']}"):
                             stop_instance(u['username'])
                             st.rerun()
                        st.markdown(f"[Open](http://localhost:{u['assigned_port']})")

    # User Panel (Self)
    st.divider()
    st.subheader("My Instance")
    
    # Refresh user data
    me = get_user(user['username'])
    
    st.info(f"Assigned Port: {me['assigned_port']}")
    
    if me['status'] == 'running':
        st.success("Instance is RUNNING.")
        st.markdown(f"### [👉 CLICK TO ENTER AEGIS](http://localhost:{me['assigned_port']})")
        
        if st.button("Stop My Instance"):
            stop_instance(me['username'])
            st.rerun()
    else:
        st.warning("Instance is STOPPED.")
        if st.button("🚀 Launch Aegis"):
            with st.spinner("Provisioning resources..."):
                ok, msg = launch_instance(me['username'])
                if ok: 
                    st.success("Launched!")
                    time.sleep(1)
                    st.rerun()
                else:
                    st.error(msg)

    if st.button("Log Out"):
        st.session_state.hv_user = None
        st.rerun()
