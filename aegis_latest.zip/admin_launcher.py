import streamlit as st
import psutil
import subprocess
import os
import sys
import time
import socket
import logging
from datetime import datetime

# --- CONFIGURATION ---
st.set_page_config(
    page_title="Aegis Hypervisor",
    page_icon="🧊",
    layout="wide",
    initial_sidebar_state="collapsed"
)

# Custom CSS for Hades V2 Aesthetics
st.markdown("""
    <style>
    /* Dark Mode Core */
    .stApp {
        background-color: #0e1117;
        color: #e0e0e0;
    }
    
    /* Headers */
    h1, h2, h3 {
        color: #00e5ff !important;
        font-family: 'Segoe UI', sans-serif;
    }
    
    /* Metrics */
    div[data-testid="metric-container"] {
        background-color: #1a1c24;
        border-radius: 10px;
        padding: 15px;
        border: 1px solid #333;
        box-shadow: 0 4px 6px rgba(0,0,0,0.3);
    }
    
    /* Buttons */
    .stButton > button {
        background-color: #262730;
        color: #00e5ff;
        border: 1px solid #00e5ff;
        border-radius: 5px;
        transition: all 0.3s;
    }
    .stButton > button:hover {
        background-color: #00e5ff;
        color: #000;
        box-shadow: 0 0 10px #00e5ff;
    }
    
    /* Status Indicators */
    .status-online { color: #00ff00; font-weight: bold; }
    .status-offline { color: #ff0000; font-weight: bold; }
    
    </style>
""", unsafe_allow_html=True)

# Logger Setup
logging.basicConfig(filename="hypervisor.log", level=logging.INFO, format='%(asctime)s - %(message)s')
logger = logging.getLogger("Hypervisor")

# --- UTILITY FUNCTIONS ---

def get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return "127.0.0.1"

def find_aegis_processes():
    """Scans for active Streamlit processes running app_web.py."""
    instances = []
    
    # Iterate with safe capture
    for proc in psutil.process_iter(['pid', 'name', 'cmdline', 'create_time', 'memory_info']):
        try:
            # Safe Attribute Access
            info = proc.info # Cache
            cmd = info.get('cmdline', [])
            
            if cmd and len(cmd) > 1 and ('streamlit' in cmd[0] or 'streamlit' in cmd[1]):
                # Check target file app_web.py
                is_target = False
                for arg in cmd:
                    if 'app_web.py' in arg:
                        is_target = True
                        break
                
                if is_target:
                    # Extract Port
                    port_val = "8501" # Default
                    try:
                        for i, arg in enumerate(cmd):
                            if arg == "--server.port" and i+1 < len(cmd):
                                port_val = cmd[i+1]
                    except: pass
                    
                    # Extract Memory
                    try:
                        mem_mb = info['memory_info'].rss / (1024 * 1024)
                    except:
                        mem_mb = 0.0
                    
                    # Extract Uptime
                    try:
                         uptime_str = datetime.fromtimestamp(info['create_time']).strftime("%H:%M:%S")
                    except:
                         uptime_str = "Unknown"

                    instances.append({
                        "pid": info['pid'],
                        "port": port_val,
                        "uptime": uptime_str,
                        "memory": f"{mem_mb:.1f} MB",
                        "status": "RUNNING"
                    })
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            continue
        except Exception as e:
            # Log specific iteration error but continue
            logging.error(f"Process scan error: {e}")
            
    return instances

def launch_instance(port, user_root_dir, ram_limit_mb):
    """Launches a new Aegis instance."""
    app_path = os.path.abspath("app_web.py")
    
    # Prepare Env
    env = os.environ.copy()
    if user_root_dir:
        env['AEGIS_USER_ROOT'] = user_root_dir
    env['AEGIS_RAM_LIMIT_MB'] = str(ram_limit_mb)
    
    # Command Construction
    # Use list format for subprocess (safer)
    cmd = [
        sys.executable, "-m", "streamlit", "run", app_path,
        "--server.port", str(port),
        "--server.address", "0.0.0.0",
        "--server.headless", "true",
        "--browser.gatherUsageStats", "false"
    ]
    
    try:
        # Launch detached
        if os.name == 'nt':
            creationflags = subprocess.CREATE_NEW_CONSOLE
        else:
            creationflags = 0
            
        subprocess.Popen(cmd, env=env, cwd=os.getcwd(), creationflags=creationflags)
        
        logger.info(f"Launched instance on port {port}")
        return True
    except Exception as e:
        logger.error(f"Launch failed: {e}")
        st.error(f"Launch failed: {e}")
        return False

def kill_instance(pid):
    try:
        p = psutil.Process(pid)
        p.terminate()
        return True
    except:
        return False

# --- UI LAYOUT ---

st.title("🧊  AEGIS HYPERVISOR")
st.markdown(f"**Host Node:** {socket.gethostname()} | **IP:** {get_local_ip()}")
st.divider()

# 1. System Vitality
col1, col2, col3, col4 = st.columns(4)
cpu = psutil.cpu_percent()
ram = psutil.virtual_memory()

col1.metric("CPU Load", f"{cpu}%", delta_color="inverse")
col2.metric("RAM Usage", f"{ram.percent}%", f"{ram.available/(1024**3):.1f} GB free")
col3.metric("Uptime", "Since Boot") # Placeholder
col4.metric("Active Instances", len(find_aegis_processes()))

st.divider()

# 2. Instance Manager
st.subheader("🚀  Instance Fleet")

# Refresh button
if st.button("🔄 Refresh Status"):
    st.rerun()

instances = find_aegis_processes()

if instances:
    # Table Header
    cols = st.columns([1, 2, 2, 2, 2, 2])
    cols[0].markdown("**PID**")
    cols[1].markdown("**Port**")
    cols[2].markdown("**Status**")
    cols[3].markdown("**Uptime**")
    cols[4].markdown("**Memory**")
    cols[5].markdown("**Action**")
    
    for inst in instances:
        c1, c2, c3, c4, c5, c6 = st.columns([1, 2, 2, 2, 2, 2])
        c1.write(str(inst['pid']))
        c2.write(f"**:{inst['port']}**")
        c3.markdown(f"<span class='status-online'>● {inst['status']}</span>", unsafe_allow_html=True)
        c4.write(inst['uptime'])
        c5.write(inst['memory'])
        
        if c6.button("⛔ Kill", key=f"kill_{inst['pid']}"):
            if kill_instance(inst['pid']):
                st.success(f"Instance {inst['pid']} terminated.")
                time.sleep(1)
                st.rerun()
            else:
                st.error("Failed to terminate.")
else:
    st.info("No active Aegis instances detected.")

st.divider()

# 3. Launchpad
st.subheader("✨  Deploy New Instance")

with st.expander("Deployment Configuration", expanded=True):
    l_col1, l_col2, l_col3 = st.columns(3)
    
    with l_col1:
        target_port = st.number_input("Port", min_value=8000, max_value=9000, value=8501, step=1)
        
    with l_col2:
        # Multi-Tenancy Logic
        user_root = st.text_input("User Root Directory", value="users/admin", help="Isolated workspace path")
        
    with l_col3:
        ram_limit = st.select_slider("RAM Limit (MB)", options=[500, 1000, 2000, 4000, 8000], value=2000)

    if st.button("🚀  Launch Aegis Core"):
        if os.path.exists("app_web.py"):
            launch_instance(target_port, user_root, ram_limit)
            st.success(f"Command sent! Aegis should be available at http://{get_local_ip()}:{target_port}")
            time.sleep(2)
            st.rerun()
        else:
            st.error("Critical Error: 'app_web.py' not found in current directory.")

# Footer
st.markdown("---")
st.caption("Aegis Hypervisor v2.0 | Protocol Zero-Trust | Localhost Only")
