import streamlit as st
import psutil
import subprocess
import os
import sys
import time
import json
import shutil
import socket
import socket
from datetime import datetime
import hashlib
import requests
# Import database for admin auth persistence
try:
    import database
except ImportError:
    # Fallback if running from a different context, though unlikely given file structure
    sys.path.append(os.getcwd())
    import database



# --- CONFIGURATION (SRE ISOLATION) ---
st.set_page_config(
    page_title="Aegis Admin Launcher v3.1 (Orchestrator)",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="collapsed"
)

# --- PERSISTENCE LAYER ---
# Define persistent path based on environment or fallback
AEGIS_ROOT = os.getenv('AEGIS_USER_ROOT')
if not AEGIS_ROOT:
    # Try to find sibling Data Root (Standard Linux Install)
    sibling_data = os.path.abspath(os.path.join(os.getcwd(), '..', 'Aegis-Data'))
    if os.path.exists(sibling_data):
        AEGIS_ROOT = sibling_data
    else:
        AEGIS_ROOT = '.'

# Ensure root exists if we are going to use it
if AEGIS_ROOT != '.' and not os.path.exists(AEGIS_ROOT):
    try: os.makedirs(AEGIS_ROOT, exist_ok=True)
    except: pass

TENANT_REGISTRY_FILE = os.path.join(AEGIS_ROOT, "tenants_registry.json")

# Auto-Migration: Move local registry to persistent storage if needed
local_registry_path = "tenants_registry.json"
if os.path.exists(local_registry_path) and not os.path.exists(TENANT_REGISTRY_FILE):
    # Only move if the paths are actually different
    if os.path.abspath(local_registry_path) != os.path.abspath(TENANT_REGISTRY_FILE):
        try:
            shutil.move(local_registry_path, TENANT_REGISTRY_FILE)
            print(f"[MIGRATION] Moved legacy registry to {TENANT_REGISTRY_FILE}")
        except Exception as e:
            print(f"[MIGRATION ERROR] Failed to move registry: {e}")

# --- SECURITY GATEKEEPER ---
# --- SECURITY GATEKEEPER & ONBOARDING ---
if 'admin_auth' not in st.session_state:
    st.session_state.admin_auth = False

# Initialize DB for Admin Password Storage
if "db_init_done" not in st.session_state:
    database.init_db()
    st.session_state.db_init_done = True

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def check_admin_password(password):
    stored_hash = database.get_setting("admin_password_hash")
    if not stored_hash: return False
    return hash_password(password) == stored_hash

def admin_exists():
    return database.get_setting("admin_password_hash") is not None

# 1. CHECK IF ADMIN EXISTS (Onboarding)
if not admin_exists():
    st.markdown("## 🛡️ Configuración Inicial de Aegis Admin")
    st.warning("No se ha detectado un administrador. Por favor, configure su acceso.")
    
    with st.form("admin_setup_form"):
        new_pass = st.text_input("Cree una Contraseña de Administrador", type="password")
        confirm_pass = st.text_input("Confirme la Contraseña", type="password")
        submit_setup = st.form_submit_button("Establecer Admin")
        
        if submit_setup:
            if new_pass and new_pass == confirm_pass:
                # Strong password check could go here
                hashed = hash_password(new_pass)
                database.set_setting("admin_password_hash", hashed)
                st.success("¡Administrador Configurado! Por favor, inicie sesión.")
                time.sleep(1)
                st.rerun()
            else:
                st.error("Las contraseñas no coinciden o están vacías.")
    st.stop()

# 2. LOGIN SCREEN
if not st.session_state.admin_auth:
    st.markdown("## 🛡️ Aegis Orchestrator Access")
    
    # Task 2: Support for "Enter" key using st.form
    with st.form("admin_login_form"):
        pwd = st.text_input("Admin Credentials Warning: Authorized Personnel Only", type="password")
        submit_login = st.form_submit_button("Unlock Console")
        
        if submit_login:
            if check_admin_password(pwd):
                st.session_state.admin_auth = True
                st.rerun()
            else:
                st.error("ACCESS DENIED: Incident Logged.")
    st.stop() # HALT - Do not render rest of app

# --- STYLE CHEAT SHEET (Hades V2 Minimal) ---
st.markdown("""
    <style>
    /* Dark Theme */
    .stApp { background-color: #0e1117; color: #FAFAFA; }
    
    /* Typography */
    h1, h2, h3 { color: #00e5ff !important; font-family: 'Consolas', 'Courier New', monospace; }
    div[data-testid="stCaptionContainer"] { color: #888; }
    
    /* Tables */
    div[data-testid="column"] { border-right: 1px solid #333; }
    
    /* Buttons */
    .stButton>button { 
        color: #00e5ff; 
        border: 1px solid #00e5ff; 
        background-color: #1a1c24; 
        transition: all 0.2s;
    }
    .stButton>button:hover { 
        background-color: #00e5ff; 
        color: #000000; 
        box-shadow: 0 0 8px #00e5ff;
    }
    
    /* Emergency Zone */
    .emergency-text { color: #ff4b4b; font-weight: bold; }
    </style>
""", unsafe_allow_html=True)

# --- TENANT REGISTRY MANAGEMENT ---

def load_tenant_registry():
    """Loads the tenant registry from JSON."""
    if not os.path.exists(TENANT_REGISTRY_FILE):
        return {}
    try:
        with open(TENANT_REGISTRY_FILE, 'r') as f:
            return json.load(f)
    except json.JSONDecodeError:
        return {}

def save_tenant_registry(registry):
    """Saves the tenant registry to JSON."""
    with open(TENANT_REGISTRY_FILE, 'w') as f:
        json.dump(registry, f, indent=4)

def register_tenant(username, port):
    """Registers a new tenant or updates an existing one."""
    registry = load_tenant_registry()
    registry[username] = {
        "port": port,
        "status": "active",
        "created_at": datetime.now().isoformat(),
        "last_launched": datetime.now().isoformat()
    }
    save_tenant_registry(registry)

def get_tenant_path(username):
    """Returns the standardized path for a user's data root."""
    # This must align with installer symlink logic OR use absolute path in Data Dir
    # Ideally: AEGIS_ROOT/users/username
    return os.path.join(AEGIS_ROOT, "users", username)

    return os.path.join(AEGIS_ROOT, "users", username)

# --- NETWORK UTILITIES ---
def get_lan_ip():
    """Detects the real LAN IP address using a socket connection."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        # Doesn't need to be reachable
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"

def get_aegis_processes():
    """
    Scans system for Aegis (app_web.py) processes using psutil.
    ISOLATION: Does NOT import any Aegis modules. Rely purely on OS signatures.
    """
    instances = []
    try:
        # Iterate over all processes
        for proc in psutil.process_iter(['pid', 'name', 'cmdline', 'memory_info', 'create_time']):
            try:
                # Safe access to process info
                pinfo = proc.info
                cmd = pinfo.get('cmdline', [])
                
                # Identification: Check if it's running streamlit AND app_web.py
                # Exclude admin_launcher.py self-detection
                if cmd and len(cmd) > 1:
                    cmd_str = " ".join(cmd).lower()
                    if 'streamlit' in cmd_str and 'app_web.py' in cmd_str:
                        
                        # Extract Port
                        port = "8501" # Default Streamlit Port
                        if "--server.port" in cmd:
                            idx = cmd.index("--server.port")
                            if idx + 1 < len(cmd):
                                port = cmd[idx+1]
                                
                        # Metrics in MB
                        p_mem = pinfo.get('memory_info')
                        mem_mb = (p_mem.rss / (1024 * 1024)) if p_mem else 0
                        
                        # Uptime
                        created = datetime.fromtimestamp(pinfo['create_time'])
                        uptime = created.strftime('%H:%M:%S')

                        instances.append({
                            "PID": pinfo['pid'],
                            "PORT": int(port),
                            "RAM_MB": round(mem_mb, 2),
                            "STATUS": "ONLINE",
                            "UPTIME": uptime
                        })
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue
    except Exception as e:
        st.error(f"SRE Monitor Error: {e}")
        
    return instances

def get_gateway_status():
    """Checks if Nexus Gateway is running."""
    for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
        try:
            cmd = proc.info.get('cmdline', [])
            if cmd:
                cmd_str = " ".join(cmd).lower()
                if 'nexus_gateway.py' in cmd_str:
                    return True, proc.info['pid']
        except: continue
    return False, None

def kill_process(pid):
    """Terminates a specific PID gracefully, then forcefully."""
    try:
        p = psutil.Process(pid)
        p.terminate()
        try:
            p.wait(timeout=2)
        except psutil.TimeoutExpired:
            p.kill()
        return True, "Terminated"
    except Exception as e:
        return False, str(e)

def emergency_kill_all():
    """
    SRE PROTOCOL: EMERGENCY SHUTDOWN.
    Kills all processes matching 'app_web.py'.
    """
    killed_count = 0
    errors = []
    
    # 1. Surgical Kill via Psutil
    targets = get_aegis_processes()
    for inst in targets:
        try:
            p = psutil.Process(inst['PID'])
            p.terminate()
            killed_count += 1
        except Exception as e:
            errors.append(f"PID {inst['PID']}: {e}")
    
    return killed_count, errors

def launch_instance(port, user_path=None):
    """Launches app_web.py via subprocess detached."""
    try:
        # Locate target safely
        target = os.path.abspath("app_web.py")
        if not os.path.exists(target):
             # Fallback check for typical Linux install path if current dir was moved
             linux_target = os.path.expanduser("~/Aegis-IA/app_web.py")
             if os.path.exists(linux_target):
                 target = linux_target
             else:
                 return False, f"Critical: 'app_web.py' not found in {os.getcwd()} or {linux_target}."
            
        env = os.environ.copy()
        if user_path:
            # THIS IS CRITICAL FOR MULTI-TENANCY ISOLATION
            env['AEGIS_USER_ROOT'] = user_path
            
        cmd = [
            sys.executable, "-m", "streamlit", "run", target,
            "--server.port", str(port),
            "--server.address", "0.0.0.0",
            "--server.headless", "true",
            "--browser.gatherUsageStats", "false"
        ]
        
        # Launch detached
        if os.name == 'nt':
            # Windows specific flag for new console window
            subprocess.Popen(cmd, env=env, creationflags=subprocess.CREATE_NEW_CONSOLE)
        else:
            # POSIX: Redirect to log file for visibility
            log_dir = os.path.join(user_path, "logs") if user_path else os.path.join("users", "logs")
            os.makedirs(log_dir, exist_ok=True)
            log_file = os.path.join(log_dir, f"node_{port}.log")
            
            with open(log_file, "a") as f:
                subprocess.Popen(cmd, env=env, start_new_session=True, stdout=f, stderr=subprocess.STDOUT)
            
        return True, f"Launched Node on Port {port}"
    except Exception as e:
        return False, str(e)

def launch_gateway():
    """Launches Nexus Gateway in a new console."""
    try:
        target = os.path.abspath("modules/nexus_gateway.py")
        if not os.path.exists(target):
            return False, f"Gateway script not found at {target}"
            
        cmd = [sys.executable, target]
        
        env = os.environ.copy()
        # Ensure Python path includes root
        env['PYTHONPATH'] = os.getcwd()
        if AEGIS_ROOT:
             env['AEGIS_USER_ROOT'] = AEGIS_ROOT
        
        if os.name == 'nt':
            subprocess.Popen(cmd, env=env, creationflags=subprocess.CREATE_NEW_CONSOLE, cwd=os.getcwd())
        else:
            # POSIX: Log to file
            with open("gateway.log", "a") as f:
                subprocess.Popen(cmd, env=env, start_new_session=True, cwd=os.getcwd(), stdout=f, stderr=subprocess.STDOUT)
            
        return True, "Gateway Launched on Port 8000"
    except Exception as e:
        return False, str(e)

def create_user_structure(username, port):
    """
    Creates the filesystem structure for a new User/Tenant.
    ISOLATION: Uses standard lib 'json' & 'os', no DB import.
    """
    try:
        base_dir = get_tenant_path(username)
        # Ensure base exists
        os.makedirs(base_dir, exist_ok=True)
        
        # 1. Create Directories
        dirs = [
            os.path.join(base_dir, "vault"),
            os.path.join(base_dir, "config"),
            os.path.join(base_dir, "skills"),
            os.path.join(base_dir, "logs")
        ]
        
        for d in dirs:
            os.makedirs(d, exist_ok=True)
            
        # 2. Default Config
        config_path = os.path.join(base_dir, "config", "settings.json")
        default_config = {
            "username": username,
            "port": port,
            "created_at": datetime.now().isoformat(),
            "active_plugins": ["core", "web_sentinel"],
            "theme": "hades_dark"
        }
        
        if not os.path.exists(config_path):
            with open(config_path, "w", encoding="utf-8") as f:
                json.dump(default_config, f, indent=4)
                
        return True, base_dir
    except Exception as e:
        return False, str(e)

def recover_all_tenants():
    """
    Orchestrator Logic: Reads registry and relaunches all active tenants.
    Skips if port already busy.
    """
    registry = load_tenant_registry()
    active_procs = get_aegis_processes()
    busy_ports = [p['PORT'] for p in active_procs]
    
    results = []
    
    for username, data in registry.items():
        if data.get("status") != "active":
            continue
            
        port = data.get("port")
        
        if port in busy_ports:
            results.append(f"⚠️ {username}: Already running (Port {port})")
            continue
            
        # Re-hydrate
        user_path = get_tenant_path(username)
        ok, msg = launch_instance(port, user_path=user_path)
        
        if ok:
            results.append(f"✅ {username}: Launched on {port}")
            # Update last launched
            data['last_launched'] = datetime.now().isoformat()
        else:
            results.append(f"❌ {username}: Failed. {msg}")
            
    # Save back registry updates (timestamps)
    save_tenant_registry(registry)
    return results

# --- AUTO-HEAL ON STARTUP (HEADLESS MODE) ---
# Check if we were launched with --heal flag or environment var?
# Actually, streamlit runs continuously. Let's do a one-time check via session state.
if 'system_booted' not in st.session_state:
    st.session_state.system_booted = True
    # Optional: Auto-recover if no instances running?
    # This might be aggressive on reloads.
    # Logic: If registry exists but process table empty -> assume crash -> recover.
    # But streamlit reloads on code change, so be careful.
    # Let's keep manual button unless explicitly desired. 
    # USER REQUEST: "Auto-launch tenants on start".
    # Implementation: Check if instances running. If 0 and registry > 0, auto-heal.
    instances = get_aegis_processes()
    reg = load_tenant_registry()
    if len(instances) == 0 and len(reg) > 0:
         print("[AEGIS ORCHESTRATOR] 🟢 System Cold Boot detected. Treating network...")
         res = recover_all_tenants()
         print(f"[AEGIS ORCHESTRATOR] Auto-Heal Report: {res}")

# --- INTERFACE ---

st.title("🛡️ Aegis Admin Launcher v3.1 (Orchestrator)")
st.caption("SRE Console | Multi-Tenant Hub & Spoke | Zero-Trust")

tab_monitor, tab_users, tab_system = st.tabs(["📡 Monitor & Orchestration", "👥 User Factory", "⚙️ System Ops"])

# ==========================
# TAB 1: MONITOR & ORCHESTRATION
# ==========================
with tab_monitor:
    c_m1, c_m2 = st.columns([3, 1])
    with c_m1:
        st.subheader("Active Instances (Spokes)")
    with c_m2:
        if st.button("🔄 Refresh", key="refresh_monitor"):
            st.rerun()

    instances = get_aegis_processes()
    registry = load_tenant_registry()
    
    # Map PID/Port to Tenants for display
    # Lookup tenant by port
    port_to_tenant = {v['port']: k for k, v in registry.items()}

    if not instances:
        st.info("System Cold. No active instances detected.")
    else:
        # Minimalist Table Header
        cols = st.columns([1, 1, 3, 2, 2, 2])
        cols[0].markdown("**USER**")
        cols[1].markdown("**PORT**")
        cols[2].markdown("**NETWORK URL**")
        cols[3].markdown("**STATUS**")
        cols[4].markdown("**RAM**")
        cols[5].markdown("**CONTROL**")
        
        lan_ip = get_lan_ip()
        
        # Iterate over REGISTRY for persistence (Task 3)
        for username, data in registry.items():
            port = data.get('port')
            
            # Check if online (present in instances)
            instance_data = next((i for i in instances if i['PORT'] == port), None)
            is_online = instance_data is not None
            
            c1, c2, c3, c4, c5, c6 = st.columns([1, 1, 3, 2, 2, 2])
            
            c1.markdown(f"**{username}**")
            c2.markdown(f"`{port}`")
            
            # Task 3: Show Real IP URL
            url = f"http://{lan_ip}:{port}"
            c3.markdown(f"[{url}]({url})")
            
            if is_online:
                c4.success(f"ONLINE ({instance_data['UPTIME']})")
                
                # RAM
                mem = instance_data['RAM_MB']
                color = "green" if mem < 500 else "orange" if mem < 1000 else "red"
                c5.markdown(f":{color}[{mem} MB]")
                
                # Kill Button
                if c6.button("⛔ Kill", key=f"k_{username}"):
                    ok, msg = kill_process(instance_data['PID'])
                    if ok:
                        st.toast(f"Terminated {username}")
                        time.sleep(1)
                        st.rerun()
                    else:
                        st.error(msg)
            else:
                c4.error("OFFLINE")
                c5.markdown("-")
                # Launch Button? Or just leave it to Orchestrator controls.
                # Adding individual launch might be nice but not explicitly requested here.
                c6.caption("Inactive")
        
        # Footer Metrics
        st.markdown("---")
        c_tot1, c_tot2 = st.columns(2)
        c_tot1.metric("Registered Users", len(registry))
        c_tot2.metric("Active Load (MB)", f"{sum(i['RAM_MB'] for i in instances):.1f}")
    
    st.divider()
    
    # ORCHESTRATION CONTROLS
    st.markdown("### 🎼 Orchestration Controls")
    
    col_orc1, col_orc2 = st.columns(2)
    
    with col_orc1:
        st.markdown("**State Recovery**")
        st.caption("Relaunches all tenants marked as 'active' in registry if they are down.")
        if st.button("♻️ HEAL NETWORK (Levantar Todo)", type="primary"):
            with st.spinner("Orchestrating Recovery..."):
                results = recover_all_tenants()
                for r in results:
                    if "✅" in r: st.success(r)
                    elif "⚠️" in r: st.warning(r)
                    else: st.error(r)
                time.sleep(2)
                st.rerun()

    # GATEWAY CONTROL
    st.markdown("### 🕸️ Nexus Gateway (System Core)")
    gw_up, gw_pid = get_gateway_status()
    
    c_gw1, c_gw2, c_gw3 = st.columns([1, 2, 2])
    c_gw1.markdown("**Status**")
    if gw_up:
        c_gw2.success(f"ONLINE (PID: {gw_pid})")
        if c_gw3.button("⛔ Stop Gateway", key="stop_gw"):
            ok, msg = kill_process(gw_pid)
            if ok: st.success("Gateway Stopped"); time.sleep(1); st.rerun()
            else: st.error(msg)
    else:
        c_gw2.error("OFFLINE")
        if c_gw3.button("🚀 Launch Gateway", key="launch_gw"):
            ok, msg = launch_gateway()
            if ok: st.success(msg); time.sleep(2); st.rerun()
            else: st.error(msg)

    st.divider()

    # DAMAGE CONTROL (Emergency)
    with st.expander("⚠️ DAMAGE CONTROL (Emergency Zone)"):
        st.markdown("### Emergency Shutdown Protocol")
        st.markdown("Use this ONLY if instances are zombie/unresponsive. This will force-kill ALL processes matching `app_web.py`.")
        
        col_em1, col_em2 = st.columns([1, 3])
        with col_em1:
            if st.button("☢️ EXECUTE ORDER 66", type="primary"):
                n, errs = emergency_kill_all()
                if n > 0:
                    st.success(f"Protocol Executed: {n} processes terminated.")
                else:
                    st.warning("No targets found.")
                
                if errs:
                    st.error(f"Errors: {errs}")
                
                time.sleep(2)
                st.rerun()

# ==========================
# TAB 2: USER FACTORY
# ==========================
with tab_users:
    st.subheader("🏭 User Factory")
    st.markdown("Deploy isolated workspaces for each tenant/user.")
    
    registry = load_tenant_registry()
    
    # Calculate next likely port
    used_ports = [v['port'] for v in registry.values()]
    next_port = 8501
    while next_port in used_ports:
        next_port += 1
    
    with st.form("new_user_form"):
        col_u1, col_u2 = st.columns(2)
        with col_u1:
            username = st.text_input("Username (Unique ID)", placeholder="admin_01")
        with col_u2:
            assigned_port = st.number_input("Assign Port", min_value=8501, max_value=9999, value=next_port)
            
        submitted = st.form_submit_button("Deploy User Workspace & Launch")
        
        if submitted:
            if not username:
                st.error("Username is required.")
            elif username in registry:
                st.error(f"User '{username}' already exists in registry.")
            elif assigned_port in used_ports:
                st.error(f"Port {assigned_port} is already assigned to another user.")
            else:
                # 1. Create Filesystem
                ok_fs, path_or_err = create_user_structure(username, assigned_port)
                
                if ok_fs:
                    st.success(f"✅ Workspace Created: {path_or_err}")
                    
                    # 2. Register Tenant
                    register_tenant(username, assigned_port)
                    st.info(f"📝 Tenant Registered: {username} -> Port {assigned_port}")
                    
                    # 3. Launch Instance
                    ok_launch, msg_launch = launch_instance(assigned_port, user_path=path_or_err)
                    if ok_launch:
                        st.success(f"🚀 {msg_launch}")
                        
                        # Show Access Link
                        ip = get_lan_ip() # Use detected IP
                        link = f"http://{ip}:{assigned_port}"
                        st.markdown(f"### 🔗 Access Link: [{link}]({link})")
                        
                        st.balloons()
                        time.sleep(2)
                        st.rerun()
                    else:
                        st.error(f"Launch Failed: {msg_launch}")
                else:
                    st.error(f"Filesystem Error: {path_or_err}")

    st.divider()
    st.markdown("### 📂 Registered Tenants")
    if registry:
        st.json(registry)
    else:
        st.info("No tenants registered.")

# ==========================
# TAB 3: SISTEMA / PROVISIONING
# ==========================
with tab_system:
    st.subheader("⚙️ System Operations")
    
    st.markdown("#### 🔄 Remote Provisioning (Upgrade Pipeline)")
    
    # --- TASK 1: VERSION VERIFICATION ---
    local_ver_file = "version.json"
    REMOTE_VER_URL = "https://raw.githubusercontent.com/Gustavo324234/Aegis-Updates/main/version.json"
    
    current_ver = "Unknown"
    if os.path.exists(local_ver_file):
        try:
            with open(local_ver_file, 'r') as f:
                vdata = json.load(f)
                current_ver = vdata.get('version', '0.0.0')
        except: pass
        
    c_v1, c_v2 = st.columns([3, 1])
    c_v1.write(f"**Current System Version:** `{current_ver}`")
    
    if c_v2.button("🔍 Buscar Actualizaciones"):
        with st.spinner("Consulting Update Repository..."):
            try:
                resp = requests.get(REMOTE_VER_URL, timeout=5)
                if resp.status_code == 200:
                    remote_data = resp.json()
                    remote_ver = remote_data.get('version', '0.0.0')
                    
                    # Semver Check (Simple String Compare for now or split)
                    # Assuming format x.y.z
                    def is_newer(v1, v2):
                        try:
                            return [int(x) for x in v1.split('.')] < [int(x) for x in v2.split('.')]
                        except: return False
                        
                    if is_newer(current_ver, remote_ver):
                        st.session_state.update_available = remote_ver
                        st.session_state.changelog = remote_data.get('changelog', 'Minor Fixes')
                        st.success(f"✨ Nueva versión disponible: v{remote_ver}")
                    else:
                        st.session_state.update_available = None
                        st.info("✅ Sistema actualizado.")
                else:
                    st.error("Error connecting to repo.")
            except Exception as e:
                st.error(f"Network Error: {e}")
                
    # --- TASK 2 & 3: ROBUST UPDATE INSTALLATION ---
    if st.session_state.get("update_available"):
        st.markdown(f"### ✨ Update Available: v{st.session_state.update_available}")
        st.info(f"Changelog: {st.session_state.get('changelog')}")
        
        sudo_pass = st.text_input("Sudo Password (Required for Install)", type="password", key="upd_pass")
        
        # Two-Stage Flow
        c_up1, c_up2 = st.columns(2)
        
        # Button 1: Download & Install Code (No Restart if possible via command split, 
        # but user gave a combined command in Task 2. We will use the 'nohup' wrapper for safety).
        # We'll treat this as "Install Update"
        if c_up1.button("📥 Instalar Actualización (Archivos)", type="primary", disabled=not sudo_pass):
            st.toast("Iniciando Actualización en segundo plano...")
            
            # TASK 2: NON-BLOCKING COMMAND (Linux Nohup)
            # Command: sudo -S nohup bash -c "curl ... | bash" &
            # Note: We omit the '&& systemctl restart' here to satisfy Task 3 (Ask first)
            # Unless the script forces it. We assume script is passive.
            
            install_url = "https://raw.githubusercontent.com/Gustavo324234/Aegis-Updates/main/install_aegis.sh"
            # Safe nohup command
            cmd_str = f"nohup bash -c 'curl -sL {install_url} | bash' &"
            full_cmd = ["sudo", "-S", "bash", "-c", cmd_str]
            
            try:
                # Use subprocess to launch
                p = subprocess.Popen(
                    full_cmd, 
                    stdin=subprocess.PIPE, 
                    stdout=subprocess.PIPE, 
                    stderr=subprocess.PIPE, 
                    text=True
                )
                out, err = p.communicate(input=f"{sudo_pass}\n")
                
                # Check for immediate sudo errors (password wrong)
                if "incorrect password" in (err or "").lower():
                    st.error("Contraseña Incorrecta.")
                else:
                    st.success("✅ Proceso de instalación iniciado en segundo plano.")
                    st.session_state.update_ready_to_restart = True
                    # Log output for debug
                    if out or err:
                        with st.expander("Install Logs (Initial)"):
                            st.code(f"OUT: {out}\nERR: {err}")
                            
            except Exception as e:
                st.error(f"Execution Error: {e}")
        
        # TASK 3: RESTART NOTIFICATION
        if st.session_state.get("update_ready_to_restart"):
            st.warning("⚠️ Actualización aplicada (Archivos). El sistema requiere reinicio.")
            if c_up2.button("🔄 Reiniciar Servicio Ahora", type="primary"):
                # Run Restart Command
                # Use nohup to avoid killing the parent process improperly before command sends
                cmd_restart_str = "nohup systemctl restart aegis.service &"
                cmd_restart = ["sudo", "-S", "bash", "-c", cmd_restart_str]
                
                try:
                    p = subprocess.Popen(cmd_restart, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                    p.communicate(input=f"{sudo_pass}\n")
                    st.success("Reiniciando... La conexión se perderá.")
                    time.sleep(3)
                    st.rerun() # Will likely fail connection, which is expected
                except Exception as e:
                    st.error(f"Restart Failed: {e}")
                    
    # Log Viewer (Optional, kept from previous)
    with st.expander("Update Logs", expanded=False):
         st.markdown("Logs will appear here during synchronous operations.")
                    
    # Host Stats Sidebar
    st.divider()
    col_sys1, col_sys2, col_sys3 = st.columns(3)
    col_sys1.metric("HOST CPU", f"{psutil.cpu_percent()}%")
    ram = psutil.virtual_memory()
    col_sys2.metric("HOST RAM FREE", f"{ram.available / (1024**3):.1f} GB")
    col_sys3.metric("OS USER", os.getenv('USERNAME') or os.getenv('USER') or 'Unknown')
