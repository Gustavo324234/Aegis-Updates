import os
import sys
import sqlite3
import subprocess
import importlib.util


def check_dependencies():
    print("📦 Chequeando dependencias críticas...")
    required_packages = {
        "requests": "requests",
        "streamlit": "streamlit",
        "cryptography": "cryptography",
        "yaml": "pyyaml",
        "playwright": "playwright",
        "chromadb": "chromadb",
        "sentence_transformers": "sentence-transformers",
    }

    missing = []
    for module, pip_name in required_packages.items():
        if importlib.util.find_spec(module) is None:
            missing.append(pip_name)
            print(f"  ❌ Falla {module} (Instalar: pip install {pip_name})")
        else:
            print(f"  ✅ {module} en línea")

    if missing:
        print(
            f"\n⚠️ Faltan paquetes. Instálalos con:\npip install {' '.join(missing)}\n"
        )
    return len(missing) == 0


def check_database():
    print("\n🗄️ Chequeando base de datos (aegis_memory.db)...")
    db_path = "aegis_memory.db"

    # Try to initialize if missing
    if not os.path.exists(db_path):
        print("  ⚠️ Base de datos no encontrada. Intentando crear esquemas...")
        try:
            import services.db.schema as schema

            schema.init_db()
            print("  ✅ Base de datos inicializada correctamente.")
        except Exception as e:
            print(f"  ❌ Falla inicializando DB: {e}")
            return False

    try:
        conn = sqlite3.connect(db_path)
        c = conn.cursor()

        # Check critical new tables from OpenClaw/Singularity refactors
        critical_tables = ["agent_missions", "knowledge_graph", "daemons"]

        missing_tables = []
        for table in critical_tables:
            c.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table,)
            )
            if not c.fetchone():
                missing_tables.append(table)

        if missing_tables:
            print(
                f"  ⚠️ Faltan tablas ({', '.join(missing_tables)}). Intentando forzar esquema..."
            )
            try:
                import services.db.schema as schema

                schema.init_db()
                print("  ✅ Esquemas actualizados.")
            except ImportError:
                print("  ❌ No se encontró services.db.schema para actualizar.")
        else:
            print("  ✅ Estructuras relacionales (RAG/Missions) intactas.")

        conn.close()
        return True
    except Exception as e:
        print(f"  ❌ Error de base de datos: {e}")
        return False


def check_docker():
    print("\n🐳 Chequeando motor de Sandboxing (Docker)...")
    try:
        res = subprocess.run(
            ["docker", "info"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        if res.returncode == 0:
            print("  ✅ Docker en línea. Sandboxing determinista activado.")
            return True
        else:
            print(
                "  ⚠️ Docker no está corriendo o hay permisos insuficientes. Aegis usará Fallback (Ejecución Local)."
            )
            return False
    except FileNotFoundError:
        print(
            "  ⚠️ Comando 'docker' no encontrado. Aegis usará Fallback (Ejecución Local insegura)."
        )
        return False


def check_security():
    print("\n🛡️ Chequeando protocolos de seguridad (Secret Sniffer)...")
    try:
        import modules.project_manager

        if hasattr(modules.project_manager, "_scan_for_secrets"):
            print(
                "  ✅ Interceptor de Credenciales activo (Hardcoded Secrets bloqueados)."
            )
            return True
        else:
            print(
                "  ⚠️ No se encontró el Interceptor de Credenciales en project_manager."
            )
            return False
    except ImportError:
        print("  ⚠️ No se encontró el Interceptor de Credenciales en project_manager.")
        return False


def check_directories():
    print("\n📂 Chequeando estructuras de directorios...")
    dirs = ["workspace", "skills/external", "vault", "config"]
    all_ok = True
    for d in dirs:
        if not os.path.exists(d):
            try:
                os.makedirs(d)
                print(f"  ✅ Creado directorio {d}")
            except OSError as e:
                print(f"  ❌ Falla creando {d}: {e}")
                all_ok = False
        else:
            print(f"  ✅ Directorio {d} listo.")
    return all_ok


def check_citadel_status():
    print("\n🏰 Chequeando estado del Protocolo Ciudadela (MFA & Túnel)...")
    ngrok_installed = importlib.util.find_spec("pyngrok") is not None
    mfa_configured = False

    try:
        from modules.auth_vault import auth

        if "mfa_secret" in auth.config:
            mfa_configured = True
    except Exception:
        pass

    if ngrok_installed and not mfa_configured:
        print(
            "  ⚠️ RIESGO DE SEGURIDAD: Tienes el túnel local (pyngrok) instalado pero el MFA está desactivado."
        )
        print(
            "  ❌ Configura Citadel (Doble Factor) antes de abrir puertos a Internet."
        )
        return False
    elif mfa_configured:
        print("  ✅ Protocolo Ciudadela activo. MFA Protegiendo el perímetro.")
        return True
    else:
        print("  ✅ Protocolo Ciudadela offline (Ejecución local segura).")
        return True


def check_exposed_ports():
    print("\n🔒 Chequeando Hardening de Red Búnker...")
    import psutil

    exposed = []
    try:
        for conn in psutil.net_connections(kind="inet"):
            if conn.status == "LISTEN":
                ip, port = conn.laddr
                if ip == "0.0.0.0" and port in [8000, 8501, 8502]:
                    exposed.append(port)
    except (psutil.AccessDenied, Exception) as e:
        print(f"  ⚠️ No se pudo escanear puertos (requiere sudo): {e}")
        return True

    if exposed:
        print(f"  ❌ RIESGO: Puertos críticos expuestos a 0.0.0.0: {exposed}")
        print("     Aegis debe correr en 127.0.0.1 (Bunker Mode).")
        return False
    else:
        print("  ✅ Red sellada. Sin puertos expuestos accidentalmente.")
        return True


def print_banner(docker_ready):
    banner = """
    █████╗ ███████╗ ██████╗ ██╗███████╗
   ██╔══██╗██╔════╝██╔════╝ ██║██╔════╝
   ███████║█████╗  ██║  ███╗██║███████╗
   ██╔══██║██╔══╝  ██║   ██║██║╚════██║
   ██║  ██║███████╗╚██████╔╝██║███████║
   ╚═╝  ╚═╝╚══════╝ ╚═════╝ ╚═╝╚══════╝
      S I N G U L A R I T Y   O N L I N E
"""
    # Cyan color
    print(f"\033[96m{banner}\033[0m")

    print("-" * 50)
    print("STATUS DEL SISTEMA:")
    print("✅ RAG Híbrido & Graph RAG: Activo")
    print("✅ Synapse Protocol (Markdown Skills): Cargado")
    print("✅ Announce Flow & Subagentes asíncronos: Activo")
    if getattr(sys, "_sec_ok", False):
        print("✅ Secret Sniffer (Zero-Trust): Activo")

    if docker_ready:
        print("✅ Docker Sandbox (TDD / Ejecución Segura): Activo")
    else:
        print("⚠️ Docker Sandbox (Ejecución Local Activa)")
    print("-" * 50)


def main():
    print("\n--- INICIANDO DIAGNÓSTICO DEL SISTEMA AEGIS ---")

    deps_ok = check_dependencies()
    db_ok = check_database()
    docker_ready = check_docker()
    sec_ok = check_security()
    dirs_ok = check_directories()
    citadel_ok = check_citadel_status()
    net_ok = check_exposed_ports()

    # Pass sec_ok flag to banner using sys
    sys._sec_ok = sec_ok

    print("\n" + "=" * 50)
    if deps_ok and db_ok and dirs_ok and citadel_ok and net_ok:
        print_banner(docker_ready)
        print("\n🚀 El Sistema AEGIS ha asimilado las mejoras existosas y está listo.")
        print("\nPara iniciar, ejecuta:")
        print("  \033[92mstreamlit run app_web.py\033[0m")
        print("\nPara leer tus capacidades dinámicas generadas:")
        print("  \033[93mcat CAPABILITIES.md\033[0m")
    else:
        print(
            "❌ Se han detectado errores críticos. Por favor revisa los mensajes anteriores y asegúrate de instalar las dependencias o permisos."
        )


if __name__ == "__main__":
    main()
