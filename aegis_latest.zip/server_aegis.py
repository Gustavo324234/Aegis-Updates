import os
import warnings
import json
import logging
import asyncio
import shutil
import psutil
import sys
import subprocess
import socket
import requests
from typing import Dict, Any
from datetime import datetime

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware

import database
from core_engine.brain import AegisBrain
from modules.daemon_manager import DaemonManager
from module_manager import ModuleManager
from modules.auth_vault import auth
from modules.resource_monitor import monitor
from modules.vault_manager import vault

warnings.filterwarnings("ignore", category=FutureWarning)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("AegisServer")

# --- TENANT CONFIG ---
AEGIS_ROOT = os.getenv("AEGIS_USER_ROOT", ".")
TENANT_REGISTRY_FILE = os.path.join(AEGIS_ROOT, "tenants_registry.json")


def load_tenant_registry():
    if not os.path.exists(TENANT_REGISTRY_FILE):
        return {}
    try:
        with open(TENANT_REGISTRY_FILE, "r") as f:
            return json.load(f)
    except Exception:
        return {}


def save_tenant_registry(registry):
    with open(TENANT_REGISTRY_FILE, "w") as f:
        json.dump(registry, f, indent=4)


def get_tenant_path(username):
    return os.path.normpath(os.path.join(AEGIS_ROOT, "users", username))


app = FastAPI(
    title="Aegis-IA Headless Server", description="Decoupled backend for Aegis-IA"
)


app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- INITIALIZATION ---
# We use global handles to be initialized on startup
brain = None
daemon_manager = None
module_manager = None


@app.on_event("startup")
async def startup_event():
    global brain, daemon_manager, module_manager
    logger.info("Starting Aegis Core Initialization...")

    # 1. Init DB
    database.init_db()

    # 2. Init Brain (Heavy: loads embeddings if not Cloud Only)
    brain = AegisBrain()

    # 3. Init Daemon Manager
    daemon_manager = DaemonManager()

    if os.getenv("AEGIS_NO_DAEMONS") != "true":
        logger.info("Starting System Daemons (Master Mode)...")
        daemon_manager.start()
    else:
        logger.info("Running in Tenant Mode (Daemons Disabled)")

    # 4. Init Module Manager
    module_manager = ModuleManager()

    logger.info("Aegis-IA Headless Server is READY.")


@app.on_event("shutdown")
async def shutdown_event():
    global daemon_manager
    if daemon_manager:
        logger.info("Shutting down Daemon Manager...")
        daemon_manager.stop()


SELF_MANAGED_MODULES = [
    "identity_manager",
    "project_manager",
    "data_architect",
    "db_logger",
    "database_ops",
    "memory_manager",
    "life_manager",
]


# --- CONNECTION MANAGER ---
class ConnectionManager:
    def __init__(self):
        self.active_connections: Dict[str, WebSocket] = {}

    async def connect(self, session_id: str, websocket: WebSocket):
        await websocket.accept()
        self.active_connections[session_id] = websocket
        logger.info(f"Session {session_id} connected.")

    def disconnect(self, session_id: str):
        if session_id in self.active_connections:
            del self.active_connections[session_id]
            logger.info(f"Session {session_id} disconnected.")

    async def send_message(self, session_id: str, message: dict):
        if session_id in self.active_connections:
            try:
                await self.active_connections[session_id].send_text(json.dumps(message))
            except Exception as e:
                logger.error(f"Error sending message to {session_id}: {e}")


manager = ConnectionManager()


# --- ASYNC TOOL EXECUTION ---
async def execute_tool_async(
    session_id: str,
    job_id: int,
    tool_name: str,
    tool_args: Any,
    internal_queue: asyncio.Queue = None,
):
    """Executes a tool in the background and notifies via WS."""
    try:
        # Update DB state to Executing
        database.update_action_status(job_id, "Executing")
        await manager.send_message(
            session_id,
            {"type": "status", "msg": f"⚙️ Executing {tool_name} (Job {job_id})..."},
        )

        loop = asyncio.get_running_loop()

        def stream_callback(line, stream_type="stdout"):
            asyncio.run_coroutine_threadsafe(
                manager.send_message(
                    session_id,
                    {
                        "type": "terminal_output",
                        "job_id": job_id,
                        "line": line,
                        "stream": stream_type,
                    },
                ),
                loop,
            )

        result = await loop.run_in_executor(
            None,
            lambda: module_manager.execute_module(
                tool_name, tool_args, stream_callback=stream_callback
            ),
        )

        # Mark as Completed
        database.update_action_status(job_id, "Completed")

        # Notify Client
        await manager.send_message(
            session_id,
            {
                "type": "tool_result",
                "job_id": job_id,
                "tool_name": tool_name,
                "result": result,
            },
        )

        # Check if result indicates failure (for healing)
        if isinstance(result, str) and (
            result.startswith("Error:") or "failed" in result.lower()
        ):
            if internal_queue:
                healing_prompt = f"[SRE_INTERNAL_REPORT: El comando anterior ({tool_name}) falló con:\n{result}\nCorrígelo antes de presentarlo al Arquitecto]"
                await internal_queue.put(
                    {"type": "prompt", "prompt": healing_prompt, "is_healing": True}
                )

        logger.info(f"Tool {tool_name} completed for session {session_id}")
    except Exception as e:
        logger.error(f"Error executing tool {tool_name}: {e}")
        database.update_action_status(job_id, "Failed")
        error_msg = str(e)
        await manager.send_message(
            session_id,
            {
                "type": "tool_error",
                "job_id": job_id,
                "tool_name": tool_name,
                "error": error_msg,
            },
        )
        if internal_queue:
            healing_prompt = f"[SRE_INTERNAL_REPORT: El comando anterior ({tool_name}) falló con error de sistema:\n{error_msg}\nCorrígelo antes de presentarlo al Arquitecto]"
            await internal_queue.put(
                {"type": "prompt", "prompt": healing_prompt, "is_healing": True}
            )


# --- WEBSOCKET ENDPOINT ---
@app.websocket("/ws/chat/{session_id}")
async def websocket_chat(websocket: WebSocket, session_id: str):
    await manager.connect(session_id, websocket)

    # 1. Re-send pending actions from DB (Persistent State)
    pending_actions = database.get_pending_actions(session_id)
    if pending_actions:
        logger.info(
            f"Resending {len(pending_actions)} pending actions for {session_id}"
        )
        for action in pending_actions:
            job_id, tool_name, tool_args, status, created_at = action
            await manager.send_message(
                session_id,
                {
                    "type": "tool_call",
                    "job_id": job_id,
                    "tool": tool_name,
                    "args": json.loads(tool_args)
                    if isinstance(tool_args, str)
                    else tool_args,
                    "status": status,
                    "created_at": created_at,
                },
            )

    try:
        internal_queue = asyncio.Queue()

        # Listener for WebSocket
        async def listen_ws():
            try:
                while True:
                    data = await websocket.receive_text()
                    await internal_queue.put(json.loads(data))
            except WebSocketDisconnect:
                await internal_queue.put({"type": "disconnect"})
            except Exception as e:
                logger.error(f"WS Listen Error: {e}")
                await internal_queue.put({"type": "disconnect"})

        asyncio.create_task(listen_ws())

        while True:
            # Wait for event (from WS or Internal Queue)
            payload = await internal_queue.get()
            msg_type = payload.get("type", "prompt")

            if msg_type == "disconnect":
                break

            if msg_type == "authorize_action":
                job_id = payload.get("job_id")
                # Retrieve action from DB
                action = database.get_action_by_id(job_id)
                if action:
                    job_id, tool_name, tool_args, status, created_at = action
                    if status == "Pending":
                        asyncio.create_task(
                            execute_tool_async(
                                session_id,
                                job_id,
                                tool_name,
                                json.loads(tool_args)
                                if isinstance(tool_args, str)
                                else tool_args,
                                internal_queue=internal_queue,
                            )
                        )
                continue

            # --- Extracción del Payload ---
            prompt = payload.get("prompt", "")
            image_input = payload.get("image")  # Base64 string para visión
            uploaded_files = payload.get("files", [])  # Array de {name, base64, type}
            is_healing = payload.get("is_healing", False)

            if not prompt and not image_input and not uploaded_files:
                continue

            # --- Lógica de Procesamiento de Archivos (RAG) ---
            if uploaded_files:
                import base64

                # Definir y asegurar directorio temporal de RAG
                rag_dir = os.path.join(database.USER_ROOT, "tmp", "session_rag")
                os.makedirs(rag_dir, exist_ok=True)

                indexed_names = []
                for f_obj in uploaded_files:
                    fname = f_obj.get("name")
                    b64_data = f_obj.get("base64", "")
                    if not fname or not b64_data:
                        continue

                    # Limpiar prefijo base64 si existe
                    if "," in b64_data:
                        b64_data = b64_data.split(",")[1]

                    try:
                        # Decodificar y guardar físicamente
                        file_bytes = base64.b64decode(b64_data)
                        file_path = os.path.join(rag_dir, fname)
                        with open(file_path, "wb") as f:
                            f.write(file_bytes)

                        # Iniciar indexación asíncrona en el Vault
                        vault.async_index_file(fname, collection="session_rag")
                        indexed_names.append(fname)
                    except Exception as e:
                        logger.error(f"Error procesando {fname} para RAG: {e}")

                # Inyectar metadatos al prompt para conocimiento de la IA
                if indexed_names:
                    prompt += f"\n[SYSTEM: Documentos cargados en la memoria RAG: {', '.join(indexed_names)}]"
                    await manager.send_message(
                        session_id,
                        {
                            "type": "status",
                            "msg": f"📂 {len(indexed_names)} documentos indexados en RAG.",
                        },
                    )

            if is_healing:
                await manager.send_message(
                    session_id,
                    {"type": "status", "msg": "🔧 Autocorrigiendo lógica interna..."},
                )
            elif image_input:
                await manager.send_message(
                    session_id,
                    {"type": "status", "msg": "👁️ Imagen recibida. Analizando..."},
                )

            # 1. GUARDAR MENSAJE DEL USUARIO EN BD (Incluyendo metadatos RAG)
            if prompt and not is_healing:
                database.save_message("user", prompt, "User", "general")

            # 2. OBTENER HISTORIAL ACTUALIZADO
            history = database.get_history(limit=50, thread_tag="general")

            active_model = (
                database.get_setting("active_model") or "gemini-2.0-flash"
            ).strip()

            generator = brain.query(
                prompt,
                history,
                active_model,
                stream=True,
                image_input=image_input,
            )

            loop = asyncio.get_running_loop()

            def get_next_chunk():
                try:
                    return next(generator)
                except StopIteration:
                    return None
                except Exception as e:
                    logger.error(f"Generator error: {e}")
                    return None

            full_response = ""  # Buffer para guardar la respuesta de la IA

            while True:
                chunk = await loop.run_in_executor(None, get_next_chunk)
                if chunk is None:
                    break

                if isinstance(chunk, dict):
                    chunk_type = chunk.get("type")
                    if chunk_type == "text":
                        full_response += chunk.get("content", "")
                        await manager.send_message(session_id, chunk)
                    elif chunk_type == "tool_call":
                        # Acumular la llamada a la herramienta en el buffer para que quede en el historial
                        tool_json = json.dumps(
                            {
                                "module": chunk.get("tool"),
                                "action": chunk.get("args", {}).get("action"),
                                "args": chunk.get("args", {}).get("args", {}),
                            }
                        )
                        full_response += f"\n<tool>{tool_json}</tool>\n"

                        # (Mantén el código original que encola la acción en la base de datos y la ejecuta...)
                        tool_name = chunk.get("tool")
                        tool_args = chunk.get("args", {})
                        job_id = database.enqueue_action(
                            session_id, tool_name, tool_args
                        )
                        chunk["job_id"] = job_id
                        await manager.send_message(session_id, chunk)

                        if tool_name in SELF_MANAGED_MODULES and tool_name not in [
                            "system_tools",
                            "file_writer",
                        ]:
                            asyncio.create_task(
                                execute_tool_async(
                                    session_id,
                                    job_id,
                                    tool_name,
                                    tool_args,
                                    internal_queue=internal_queue,
                                )
                            )
                    else:
                        await manager.send_message(session_id, chunk)
                else:
                    full_response += str(chunk)
                    await manager.send_message(
                        session_id, {"type": "text", "content": str(chunk)}
                    )

            # 3. GUARDAR LA RESPUESTA DE LA IA EN LA BD
            if full_response.strip():
                database.save_message(
                    "assistant", full_response, active_model, "general"
                )

            await manager.send_message(session_id, {"type": "done"})

    except WebSocketDisconnect:
        manager.disconnect(session_id)
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
        manager.disconnect(session_id)


@app.get("/api/graph")
def get_graph():
    """Endpoint para el visualizador KnowledgeMap.jsx"""
    triples = database.get_all_triples(limit=200)
    return {"triples": triples}


@app.get("/api/system/status")
def get_system_status():
    """Returns the current state of the system."""
    setup_complete = database.get_setting("setup_complete") == "true"
    health = monitor.check_health()
    metrics = monitor.get_metrics()
    tier_id, tier_name, _, _ = monitor.get_hardware_tier()

    # Check MCP Bridge status (Port 7000)
    mcp_active = False
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.5)
            mcp_active = s.connect_ex(("127.0.0.1", 7000)) == 0
    except Exception:
        pass

    return {
        "setup_complete": setup_complete,
        "authenticated": True,  # Placeholder until JWT
        "health": health,
        "metrics": metrics,
        "hardware_tier": {"id": tier_id, "name": tier_name},
        "mcp_bridge": {
            "active": mcp_active,
            "url": f"http://{socket.gethostname()}:7000/mcp/sse",
            "port": 7000,
        },
    }


@app.get("/api/chat/history")
def get_chat_history(limit: int = 50, thread_tag: str = "general"):
    # Obtiene los mensajes ordenados cronológicamente
    history = database.get_history(limit=limit, thread_tag=thread_tag)
    formatted_history = []
    for role, msg, ts, model in history:
        formatted_history.append(
            {
                "id": f"{ts}_{hash(msg)}",
                "role": role,
                "content": msg,
                "timestamp": ts,
                "model": model,
            }
        )
    return formatted_history


@app.post("/api/auth/setup")
async def setup_system(payload: Dict[str, Any]):
    """Genesis Sequence: Initial configuration."""
    master_pass = payload.get("master_password")
    if not master_pass or len(master_pass) < 4:
        return {"status": "error", "message": "Password too short"}

    try:
        auth.set_master_password(master_pass)
        auth.set_session_key(master_pass)  # Cache for current session
        database.set_setting("setup_complete", "true")
        database.set_setting(
            "operation_mode", payload.get("mode", "Local Only (Sovereign)")
        )

        # Add Gemini Key if provided
        gemini_key = payload.get("gemini_key")
        if gemini_key:
            # We need the encryption key which is derived from master pass
            enc_key = auth.derive_key(master_pass)
            enc = auth.encrypt_content(gemini_key, enc_key)
            database.add_api_key("gemini", enc)

        return {"status": "success", "message": "Genesis completed"}
    except Exception as e:
        logger.error(f"Setup fail: {e}")
        return {"status": "error", "message": str(e)}


@app.post("/api/auth/login")
async def login(payload: Dict[str, Any]):
    """Verify master password."""
    password = payload.get("password")
    if auth.verify_password(password):
        auth.set_session_key(password)  # Cache for current session
        # In a real app we'd return a JWT or set a cookie
        # For this prototype, we'll assume the client holds the session
        return {"status": "success", "message": "Vault Unlocked"}
    return {"status": "error", "message": "Access Denied"}


@app.get("/api/system/ollama/check")
async def check_ollama():
    """Verifies local Ollama connection and returns basic stats."""
    ollama_url = database.get_setting("ollama_url") or "http://127.0.0.1:11434"
    if ollama_url.endswith("/"):
        ollama_url = ollama_url[:-1]

    try:
        res = requests.get(f"{ollama_url}/api/tags", timeout=2)
        if res.status_code == 200:
            models = res.json().get("models", [])
            return {
                "status": "online",
                "models": [m["name"] for m in models],
                "version": res.headers.get("X-Ollama-Version", "Unknown"),
            }
        return {"status": "offline", "message": f"Ollama returned {res.status_code}"}
    except Exception as e:
        return {"status": "offline", "message": str(e)}


@app.get("/api/settings")
def get_settings():
    """Fetch all known settings."""
    keys = [
        "ai_name",
        "operation_mode",
        "ollama_url",
        "local_chat_model",
        "local_coder_model",
        "local_logic_model",
        "local_heavy_model",
        "local_vision_model",
        "mfa_enabled",
        "theme",
    ]
    results = {}
    for k in keys:
        results[k] = database.get_setting(k)
    return results


@app.post("/api/settings")
async def update_settings(payload: Dict[str, Any]):
    """Update system settings."""
    for key, value in payload.items():
        database.set_setting(key, str(value))
    return {"status": "success"}


@app.get("/api/daemons")
def list_daemons():
    return daemon_manager.list_daemons()


@app.post("/api/daemons/{name}/toggle")
async def toggle_daemon(name: str):
    daemons = daemon_manager.list_daemons()
    target = next((d for d in daemons if d["name"] == name), None)
    if not target:
        return {"status": "error", "message": "Daemon not found"}

    if target["status"] == "RUNNING":
        daemon_manager.stop_daemon(name)
    else:
        daemon_manager.start_daemon(name)
    return {"status": "success"}


@app.get("/api/nodes")
def list_nodes():
    return database.get_all_nodes()


@app.get("/api/tenants")
def get_tenants():
    registry = load_tenant_registry()

    def is_port_open(port):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.5)
            return s.connect_ex(("127.0.0.1", port)) == 0

    results = []
    for user, data in registry.items():
        port = data["port"]
        results.append(
            {
                "username": user,
                "port": port,
                "status": "online" if is_port_open(port) else "offline",
                "created_at": data.get("created_at"),
            }
        )
    return results


def stop_process_on_port(port):
    """Finds and terminates the process listening on a specific port."""
    stopped = False
    for proc in psutil.process_iter(["pid", "name"]):
        try:
            # We check connections for each process
            try:
                conns = proc.connections(kind="inet")
            except (psutil.AccessDenied, psutil.NoSuchProcess):
                continue

            for conn in conns:
                if conn.laddr.port == port:
                    print(
                        f"[Nexus] Found process {proc.pid} ({proc.name()}) on port {port}. Terminating..."
                    )

                    # Terminate children first (common in uvicorn/multiprocessing)
                    children = proc.children(recursive=True)
                    for child in children:
                        try:
                            child.terminate()
                        except Exception:
                            pass

                    proc.terminate()
                    gone, alive = psutil.wait_procs([proc] + children, timeout=3)
                    for p in alive:
                        print(f"[Nexus] Process {p.pid} still alive, killing...")
                        try:
                            p.kill()
                        except Exception:
                            pass
                    stopped = True
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.Error):
            continue
    return stopped


@app.post("/api/tenants/{username}/stop")
async def stop_tenant_endpoint(username: str):
    registry = load_tenant_registry()
    if username not in registry:
        return {"status": "error", "message": "User not found"}

    port = registry[username]["port"]
    if stop_process_on_port(port):
        return {"status": "success", "message": f"Tenant {username} stopped"}
    return {"status": "error", "message": f"No active process found on port {port}"}


@app.post("/api/tenants/{username}/start")
async def start_tenant_endpoint(username: str):
    registry = load_tenant_registry()
    if username not in registry:
        return {"status": "error", "message": "User not found"}

    data = registry[username]
    port = data["port"]
    mode = data.get("mode", "reactor")

    # Reuse the logic from deploy_tenant but without creating folders
    try:
        base_dir = get_tenant_path(username)
        env = os.environ.copy()
        env["AEGIS_USER_ROOT"] = base_dir
        env["AEGIS_NO_DAEMONS"] = "true"

        root_dir = os.path.dirname(os.path.abspath(__file__))
        if mode == "legacy":
            cmd = [
                sys.executable,
                "-m",
                "streamlit",
                "run",
                os.path.join(root_dir, "app_web.py"),
                "--server.port",
                str(port),
                "--server.headless",
                "true",
            ]
        else:
            cmd = [
                sys.executable,
                "-m",
                "uvicorn",
                "server_aegis:app",
                "--host",
                "0.0.0.0",
                "--port",
                str(port),
            ]

        subprocess.Popen(
            cmd,
            env=env,
            cwd=root_dir,
            creationflags=subprocess.CREATE_NEW_CONSOLE if os.name == "nt" else 0,
        )
        return {"status": "success", "message": f"Tenant {username} started on {port}"}
    except Exception as e:
        return {"status": "error", "message": str(e)}


@app.delete("/api/tenants/{username}")
async def delete_tenant_endpoint(username: str):
    registry = load_tenant_registry()
    if username not in registry:
        return {"status": "error", "message": "User not found"}

    port = registry[username]["port"]
    stop_process_on_port(port)

    # 1. Remove from registry
    del registry[username]
    save_tenant_registry(registry)

    # 2. Kill files
    try:
        base_dir = get_tenant_path(username)
        if os.path.exists(base_dir):
            import shutil

            shutil.rmtree(base_dir)
        return {"status": "success", "message": f"Tenant {username} completely purged"}
    except Exception as e:
        return {
            "status": "success",
            "message": f"Tenant removed from Nexus but files persist: {str(e)}",
        }


@app.get("/api/keys")
def list_api_keys():
    """Returns a list of registered API key services (names only for security)."""
    keys = database.get_api_keys()
    # keys is list of dicts: {"rowid": ..., "provider": ..., "api_key": ..., "priority": ...}
    return [{"service": k["provider"], "id": k["rowid"]} for k in keys]


@app.post("/api/keys")
async def add_api_key_endpoint(payload: Dict[str, Any]):
    """Adds an encrypted API key."""
    service = payload.get("service")
    key_value = payload.get("key")
    master_pass = payload.get("master_password")

    if not service or not key_value or not master_pass:
        return {"status": "error", "message": "Missing service, key or master_password"}

    try:
        # We need the encryption key derived from master pass
        enc_key = auth.derive_key(master_pass)
        enc = auth.encrypt_content(key_value, enc_key)
        database.add_api_key(service, enc)
        return {"status": "success", "message": f"API key for {service} saved."}
    except Exception as e:
        return {"status": "error", "message": str(e)}


@app.delete("/api/keys/{service}")
async def delete_api_key_endpoint(service: str):
    """Deletes an API key by service name."""
    # We can fetch keys and find the one with this service name
    keys = database.get_api_keys()
    for k in keys:
        if k["provider"].lower() == service.lower():
            database.delete_api_key(k["rowid"])
    return {"status": "success"}


@app.post("/api/tenants/deploy")
async def deploy_tenant(payload: Dict[str, Any]):
    username = payload.get("username")
    port = payload.get("port")
    mode = payload.get(
        "mode", "reactor"
    )  # 'reactor' (React/API) or 'legacy' (Streamlit)

    if not username or not port:
        return {"status": "error", "message": "Missing username or port"}

    registry = load_tenant_registry()
    if username in registry:
        return {"status": "error", "message": "User already exists"}

    try:
        # 1. Create Structure
        base_dir = get_tenant_path(username)
        for d in ["vault", "config", "skills", "logs"]:
            os.makedirs(os.path.join(base_dir, d), exist_ok=True)

        # 2. Register
        registry[username] = {
            "port": port,
            "mode": mode,
            "created_at": datetime.now().isoformat(),
        }
        save_tenant_registry(registry)

        # 3. Launch
        env = os.environ.copy()
        env["AEGIS_USER_ROOT"] = base_dir
        env["AEGIS_NO_DAEMONS"] = (
            "true"  # Avoid OOM by disabling daemons in sub-instances
        )

        # Determine root directory for child processes
        root_dir = os.path.dirname(os.path.abspath(__file__))

        if mode == "legacy":
            cmd = [
                sys.executable,
                "-m",
                "streamlit",
                "run",
                os.path.join(root_dir, "app_web.py"),
                "--server.port",
                str(port),
                "--server.headless",
                "true",
            ]
        else:
            cmd = [
                sys.executable,
                "-m",
                "uvicorn",
                "server_aegis:app",
                "--host",
                "0.0.0.0",
                "--port",
                str(port),
            ]

        subprocess.Popen(
            cmd,
            env=env,
            cwd=root_dir,
            creationflags=subprocess.CREATE_NEW_CONSOLE if os.name == "nt" else 0,
        )

        return {
            "status": "success",
            "message": f"Tenant {username} deployed on port {port}",
        }
    except Exception as e:
        return {"status": "error", "message": str(e)}


@app.get("/api/system/update/check")
async def check_updates():
    local_ver_file = "version.json"
    REMOTE_VER_URL = "https://raw.githubusercontent.com/Gustavo324234/Aegis-Updates/main/version.json"

    current_ver = "0.0.0"
    if os.path.exists(local_ver_file):
        try:
            with open(local_ver_file, "r") as f:
                current_ver = json.load(f).get("version", "0.0.0")
        except Exception:
            pass

    try:
        resp = requests.get(REMOTE_VER_URL, timeout=5)
        if resp.status_code == 200:
            remote_data = resp.json()
            remote_ver = remote_data.get("version", "0.0.0")

            # Simple check
            has_update = remote_ver > current_ver
            return {
                "current_version": current_ver,
                "remote_version": remote_ver,
                "update_available": has_update,
                "changelog": remote_data.get("changelog", ""),
            }
    except Exception as e:
        return {"error": str(e)}
    return {"current_version": current_ver, "update_available": False}


@app.post("/api/system/purge")
async def system_purge():
    # EMERGENCY DATA SANITIZATION
    try:
        # 1. Clear Database (We'll truncate tables instead of deleting file to avoid locking issues)
        database.clear_all_data()  # Need to implement this in database.py

        # 2. Clear Folders
        target_folders = ["vault", "workspace/projects", "backups"]
        for folder in target_folders:
            if os.path.exists(folder):
                for filename in os.listdir(folder):
                    file_path = os.path.join(folder, filename)
                    try:
                        if os.path.isfile(file_path):
                            os.unlink(file_path)
                        elif os.path.isdir(file_path):
                            shutil.rmtree(file_path)
                    except Exception:
                        pass

        # 3. Flush Ollama
        try:
            from modules.resource_monitor import monitor

            monitor.flush_ollama_cache()
        except Exception:
            pass

        return {"status": "success", "message": "System purged successfully"}
    except Exception as e:
        return {"status": "error", "message": str(e)}


# --- STATIC FILES (Frontend) ---
frontend_path = os.path.join(os.path.dirname(__file__), "ui_client", "dist")
if os.path.exists(frontend_path):
    app.mount("/", StaticFiles(directory=frontend_path, html=True), name="frontend")
else:

    @app.get("/")
    def read_root():
        return {"status": "Aegis Headless Server Running"}


# Removed duplicate startup event


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)
