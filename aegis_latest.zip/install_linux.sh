#!/bin/bash
set -e

# AEGIS-IA: The Forge Protocol Installer
# Wraps code-server installation and configuration

echo "=== 🛠️  INITIATING PROTOCOL 'THE FORGE' ==="
echo "[*] Target: Code-Server (VS Code Web Edition)"

# 1. Install Code-Server (Official Script)
if ! command -v code-server &> /dev/null; then
    echo "[+] Downloading and installing code-server..."
    curl -fsSL https://code-server.dev/install.sh | sh
else
    echo "[!] Code-server already installed. Updating..."
    # Re-run install script updates it
    curl -fsSL https://code-server.dev/install.sh | sh
fi

# 2. Enable Service for current user
echo "[+] Enabling systemd service..."
sudo systemctl enable --now code-server@$USER

# 3. Install AI Extension (Continue)
echo "[+] Installing 'Continue' AI extension..."
code-server --install-extension Continue.continue

# 4. Configuration Check
CONFIG_FILE="$HOME/.config/code-server/config.yaml"
if [ ! -f "$CONFIG_FILE" ]; then
    echo "[*] Generating default config..."
    mkdir -p $(dirname $CONFIG_FILE)
    echo "bind-addr: 127.0.0.1:8080" > $CONFIG_FILE
    echo "auth: password" >> $CONFIG_FILE
    echo "cert: false" >> $CONFIG_FILE
fi

# Get Password for display
PASSWORD=$(grep "password:" $CONFIG_FILE | cut -d' ' -f2)

echo ""
echo "=== ✅ THE FORGE DEPLOYED ==="
echo "URL: http://localhost:8080"
echo "Password: $PASSWORD"
echo "Aegis Bridge: Active"
echo ""
