# Aegis-IA 🛡️

**The Secure, Local Multimodal Assistant for Developers and Power Users.**

Aegis-IA is a powerful alternative to cloud-based assistants, designed with privacy and control as first principles. It offers persistent memory, system manipulation capabilities, and a dual-brain architecture (Google Gemini + Local Ollama).

## Key Features

- **🔒 Local & Secure**: Runs exclusively on `127.0.0.1`. No open ports to the internet.
- **🧠 Dual Brain**: 
  - **Gemini Pro**: For complex reasoning (API Key required).
  - **Ollama**: For completely offline, local inference (Llama 2, Mistral).
- **💾 Persistent Memory**: Remembers your conversations even after restarting, using a local SQLite database.
- **🛠️ System Actions ("Hands")**: Can execute terminal commands and manage files—but ONLY with your explicit approval.
- **🎨 Hades Interface**: A custom "Cyber-Dark" aesthetic designed for prolonged coding sessions.

## Installation

### Prerequisites
- Python 3.8+
- [Ollama](https://ollama.ai/) (optional, for local models)

### One-Click Setup

1. **Automatic Install**:
   Run the setup script to create a virtual environment and install dependencies.
   ```bash
   python setup.py
   ```

2. **Launch**:
   - **Windows**: Double-click `Aegis-IA.bat`.
   - **Linux/Mac**: Run `./Aegis-IA.sh`.

## Usage

1. **Select Model**: Choose between Gemini (requires key) or Ollama (offline).
2. **Chat**: Interact naturally. The AI remembers context.
3. **Commands**: Ask Aegis to "List files" or "Check System Status". 
   - A warning box will appear.
   - Click **EJECUTAR** to authorize the command.
   - Click **CANCELAR** to deny.

## System Awareness

Aegis-IA automatically detects your environment (OS, RAM, CPU) upon startup, allowing it to provide context-aware assistance without you needing to explain your setup.

---
*Built for the Tavo Ecosystem.*
