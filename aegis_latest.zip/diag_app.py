import os
import traceback

print("Current Dir:", os.getcwd())

try:
    print("Step 1: Importing database...")
    import database

    _ = database
    print("Database imported.")

    print("Step 2: Initializing DB...")
    database.init_db()
    print("DB Initialized.")

    print("Step 3.1: Importing ui.styles...")
    import ui.styles

    _ = ui.styles
    print("ui.styles imported.")

    print("Step 3.2: Importing ui.auth_manager...")
    import ui.auth_manager

    _ = ui.auth_manager
    print("ui.auth_manager imported.")

    print("Step 3.3: Importing ui.sidebar_manager...")
    import ui.sidebar_manager

    _ = ui.sidebar_manager
    print("ui.sidebar_manager imported.")

    print("Step 3.4: Importing ui.chat_manager...")
    import ui.chat_manager

    _ = ui.chat_manager
    print("ui.chat_manager imported.")

    print("All imports passed.")
except Exception:
    print("ERROR DETECTED:")
    traceback.print_exc()
