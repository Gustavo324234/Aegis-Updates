# 🛡️ Aegis-IA: Project Singularity (Final Manual)

## 🌌 Introduction
Aegis-IA Singularity Edition is a sovereign, self-contained Artificial Intelligence designed for absolute privacy and autonomous operation. This manual covers the "Transcendence" status (Phase 10), granting the AI sight, virtual hands, and self-distribution capabilities.

---

## 🚀 Getting Started (Portable Mode)
1. **Unzip** the `Aegis_Dist.zip` file.
2. Run `Start_Aegis.bat`.
3. **First Run Wizard**: The system will automatically:
   - Check if Ollama is installed (required for Local Mode).
   - Offer to download recommended models (`llama3.2:1b`, `qwen2.5-coder:1.5b`).
   - Create a Desktop Shortcut.

---

## 🧘 Zen Mode (New!)
For a distraction-free experience, enable **Zen Mode** in the sidebar.
- **Orb Status**:
  - 🟢 **Green**: Online & Ready.
  - 🟡 **Yellow**: Thinking / Processing.
  - 🔴 **Red**: Error / Disconnected.
- **Minimalist UI**: Hides technical logs and complex metrics.

---

## 👁️ active Vision (The Eye)
Aegis monitors the `workspace/screenshots` folder.
- **How to use**: Save any image/screenshot to this folder.
- **Action**: Aegis automatically analyzes it using:
  - **Cloud**: Gemini Flash (if API key active).
  - **Local**: Moondream (if installed via Ollama).
- **Notification**: You will receive a system alert with the analysis. You can then chat about it.

---

## 🖐️ Deep Web Operator (The Hands)
Aegis can navigate the web physically.
**Commands (in Chat or via Planner):**
- "Go to google.com and search for X"
- "Click the login button"
- "Type 'password' into the box"

**Technical Command Structure (JSON):**
```json
{"module": "browser_tools", "action": "navigate", "url": "https://example.com"}
{"module": "browser_tools", "action": "click", "selector": "#btn-submit"}
```

---

## 🤖 Agent Roles & Swarm
The "Hive Architecture" automatically routes your request to specialized agents:
- **Oracle**: Scans documents and memories.
- **Logic**: Plans complex architectures.
- **Coder**: Writes executable code.
- **Reviewer (Sentinel)**: Audits code for security before execution.

---

## 🛡️ Sovereign Mode & Soul Sync
- **Sovereign Mode**: If no API Key is provided, Aegis runs 100% locally on Ollama.
- **Soul Sync (Protocol Phoenix)**:
  - Clicking "Initiate Soul Dump" in the Neural Map creates an encrypted backup of your entire memory and vault.
  - Use this to migrate to a new PC or recover from catastrophe.

---

## 🎹 Protocol Siren (Voice)
- Toggle "Modo Manos Libres" in the sidebar.
- Aegis will listen via microphone and respond via TTS (Text-to-Speech).
- **Latency**: Minimized for conversation flow.

---

*Verified by Antigravity (Architect).*
*System Status: TRANSCENDENT.*
