import os
import actions
import json
import logging
import requests
import database
import modules.codex
from module_manager import ModuleManager

# Core AI Service
try:
    import google.generativeai as genai
except ImportError:
    genai = None

class AegisBrain:
    def __init__(self):
        self.ollama_base_url = "http://localhost:11434/api/generate"
        self.module_manager = ModuleManager()
        
        # Get Identity
        self.ai_name = database.get_setting("ai_name") or "Aegis-IA"
        
        # Generate Silent Report
        silent_report = actions.get_system_info()
        
        # Load Module Descriptions
        module_descriptions = self.module_manager.get_system_prompt_additions()
        
        self.system_instruction = f"""
Hola. Soy {self.ai_name}, tu asistente de Inteligencia Artificial personal.
Mi propósito es potenciar tus capacidades mediante tres pilares fundamentales:
1. PRIVACIDAD: Opero localmente. Tus datos son sagrados.
2. MEMORIA: Recuerdo nuestras interacciones pasadas para darte contexto continuo.
3. ACCIÓN: No solo respondo dudas; escribo código, gestiono archivos y ejecuto tareas reales en tu sistema.

Si encuentras un problema que no puedo resolver con mis herramientas actuales, propón una nueva habilidad usando 'skill_builder'.

SYSTEM STATUS REPORT:
{silent_report}

AVAILABLE MODULES:
{module_descriptions}

Rules:
- Act like a professional, capable, and friendly engineer. Be concise but warm.
- If you need to use a module, ONLY return the JSON object required by that module.
- Format: {{"module": "name", "action": "...", "args": ...}}. 
- Do not add extra text explanation outside the JSON when invoking a module.
- UNIFIED KNOWLEDGE: You have access to the user's external chat history in 'The Vault'.
"""

    def _get_api_key(self, provider):
        """Helper to get API key from Settings or Auth."""
        # Try database settings first (User managed)
        key = database.get_setting(f"api_key_{provider.lower()}")
        if key: return key
        # Fallback to AuthVault for Gemini Main
        if provider.lower() == "gemini":
            from modules.auth_vault import auth
            # This requires master pass which we might not have here easily without session state pass-through
            # But usually app_web passes it.
            pass
        return None

    def query_gemini(self, prompt, history, api_key, model_name='gemini-pro', image_input=None, stream=False):
        """Queries Google Gemini model with Vision support."""
        if not api_key or not str(api_key).startswith("AI"):
            # Silent Fail: Return None to trigger fallback chain
            return None
        
        try:
            genai.configure(api_key=api_key)
            
            # Auto-switch to Vision capable model if image is present
            if image_input:
                if "gemini-pro" == model_name: 
                    model_name = "gemini-1.5-flash" # Legacy Pro didn't support vision in same endpoint
                # Gemini 1.5 models support vision natively
            
            model = genai.GenerativeModel(model_name)
            
            # Construct context from history
            context = self.system_instruction + "\n\n"
            for role, msg in history:
                context += f"{role.capitalize()}: {msg}\n"
            
            full_prompt = f"{context}\nUser: {prompt}\nAssistant:"
            
            content = [full_prompt]
            if image_input:
                content.append(image_input)
            
            response = model.generate_content(content, stream=stream)
            
            if stream:
                return response # Return iterator
            else:
                return response.text
        except Exception as e:
            return f"Gemini Error: {str(e)}"

    def query_openai_style(self, prompt, history, api_key, model_name, base_url, provider_name):
        """Generic handler for OpenAI-compatible APIs (Groq, OpenRouter, Cerebras, etc.)"""
        if not api_key: return f"Error: {provider_name} API Key missing."
        
        headers = {
            "Authorization": f"Bearer {api_key}", 
            "Content-Type": "application/json"
        }
        
        # OpenRouter specific headers
        if provider_name == "OpenRouter":
            headers["HTTP-Referer"] = "https://aegis.ia"
            headers["X-Title"] = "Aegis-IA"

        messages = [{"role": "system", "content": self.system_instruction}]
        for role, msg in history:
            messages.append({"role": "user" if role == "user" else "assistant", "content": msg})
        messages.append({"role": "user", "content": prompt})

        try:
            r = requests.post(base_url, 
                              json={"model": model_name, "messages": messages}, 
                              headers=headers, timeout=60)
            if r.status_code == 200:
                return r.json()['choices'][0]['message']['content']
            return f"{provider_name} Error: {r.status_code} - {r.text}"
        except Exception as e:
            return f"{provider_name} Connection Error: {str(e)}"

    def query_openai(self, prompt, history, api_key, model_name='gpt-4o-mini'):
        return self.query_openai_style(prompt, history, api_key, model_name, "https://api.openai.com/v1/chat/completions", "OpenAI")

    def query_groq(self, prompt, history, api_key, model_name='llama3-70b-8192'):
        return self.query_openai_style(prompt, history, api_key, model_name, "https://api.groq.com/openai/v1/chat/completions", "Groq")

    def query_openrouter(self, prompt, history, api_key, model_name='google/gemini-2.0-flash-exp:free'):
        return self.query_openai_style(prompt, history, api_key, model_name, "https://openrouter.ai/api/v1/chat/completions", "OpenRouter")
        
    def query_cerebras(self, prompt, history, api_key, model_name='llama3.1-70b'):
        return self.query_openai_style(prompt, history, api_key, model_name, "https://api.cerebras.ai/v1/chat/completions", "Cerebras")

    def query_anthropic(self, prompt, history, api_key, model_name='claude-3-haiku-20240307'):
        """Queries Anthropic API."""
        if not api_key: return "Error: Anthropic API Key missing in Settings."
        
        headers = {"x-api-key": api_key, "anthropic-version": "2023-06-01", "Content-Type": "application/json"}
        
        # System prompt is separate parameter in Claude Messages API
        messages = []
        for role, msg in history:
            messages.append({"role": "user" if role == "user" else "assistant", "content": msg})
        messages.append({"role": "user", "content": prompt})

        try:
            r = requests.post("https://api.anthropic.com/v1/messages", 
                              json={"model": model_name, "max_tokens": 1024, "system": self.system_instruction, "messages": messages}, 
                              headers=headers, timeout=30)
            if r.status_code == 200:
                return r.json()['content'][0]['text']
            return f"Anthropic Error: {r.text}"
        except Exception as e:
            return f"Anthropic Connection Error: {str(e)}"

    def query_ollama(self, prompt, history, model="llama2"):
        """Queries local Ollama model."""
        try:
            # Construct context from history
            context = self.system_instruction + "\n\n"
            for role, msg in history:
                context += f"{role}: {msg}\n"
            
            full_prompt = f"{context}\nUser: {prompt}\nAssistant:"

            payload = {
                "model": model,
                "prompt": full_prompt,
                "stream": False
            }
            
            response = requests.post(self.ollama_base_url, json=payload, timeout=60)
            if response.status_code == 200:
                result = response.json()
                return result.get("response", "")
            else:
                return f"Ollama Error: {response.status_code} - {response.text}"
        except Exception as e:
            return f"Ollama Connection Error: {str(e)}"

    def decide_intent(self, user_input, model_choice, api_key=None):
        """Classifies user input into intent and data. Fails silently to GENERAL_CHAT."""
        # Simple heuristic first
        if len(user_input.split()) < 4: return {"intent": "GENERAL_CHAT"}
        
        classification_prompt = f"""
ANALYZE the user input and classify into: LOG_EXPENSE, ADD_REMINDER, PROJECT_UPDATE, or GENERAL_CHAT.
Return ONLY a JSON object.

Format for Expenses:
{{"intent": "LOG_EXPENSE", "args": {{"amount": <number>, "currency": "<USD/EUR/etc>", "category": "<category>", "description": "<text>", "date": "<ISO_DATE>"}}}}

Format for Reminders:
{{"intent": "ADD_REMINDER", "args": {{"task": "<text>", "due_date": "<ISO_DATE or null>", "priority": "<High/Medium/Low>"}}}}

Format for Projects:
{{"intent": "PROJECT_UPDATE", "args": {{"name": "<ProjectName>", "content": "<update data>"}}}}

Format for Chat:
{{"intent": "GENERAL_CHAT"}}

Input: "{user_input}"
JSON:
"""
        # Always use a fast model for intent intent
        try:
            # Bypass Logic
            use_local = False
            if not api_key or not api_key.startswith("AI"):
                use_local = True
            
            if not use_local and genai:
                 # Check if we can use Flash
                 # genai might be configured with a key already?
                 try:
                     genai.configure(api_key=api_key)
                     model = genai.GenerativeModel('gemini-1.5-flash')
                     response = model.generate_content(classification_prompt).text
                 except: 
                     use_local = True
            
            if use_local:
                 # Fallback to Ollama (Standard Llama2 or User Preference)
                 local_model = "llama2"
                 # Try to use a faster local model if configured
                 fast_local = database.get_setting("active_model")
                 if fast_local and "llama" in fast_local: local_model = fast_local
                 
                 return self.query_ollama(classification_prompt, [], model=local_model)
            
            # Robust JSON extraction
            import re
            match = re.search(r"\{.*\}", response, re.DOTALL)
            if match:
                return json.loads(match.group(0))
        except:
            pass
        
        return {"intent": "GENERAL_CHAT"}

    def extract_user_facts(self, history, api_key):
        """Analyzes history to extract permanent user facts."""
        # --- BYPASS LOGIC (SOVEREIGN MODE) ---
        use_local = False
        if not api_key or not str(api_key).startswith("AI"):
            use_local = True

        # Construct extraction history
        context = ""
        # user last 10 messages for context
        for role, msg in history[-10:]:
             context += f"{role}: {msg}\n"
             
        prompt = f"""
ANALYZE the following conversation and EXTRACT permanent facts about the user (e.g. name, projects, preferences, relationships, location).
Return a JSON list of objects.
Format:
[
  {{"key": "user_name", "value": "Gustavo", "category": "identity", "confidence": 0.9}},
  {{"key": "favorite_coffee", "value": "Espresso", "category": "preference", "confidence": 0.8}}
]

Strict JSON only. If no new facts, return [].

Conversation:
{context}
"""
        try:
             response_text = ""
             if not use_local and genai:
                 try:
                     genai.configure(api_key=api_key)
                     model = genai.GenerativeModel('gemini-1.5-flash')
                     response_text = model.generate_content(prompt).text
                 except:
                     use_local = True # Fallback if key invalid
             
             if use_local:
                 # Local Logic Model (Deepseek r1 is good for extraction, else Chat)
                 local_model = database.get_setting("local_logic_model") or "llama3.1"
                 response_text = self.query_ollama(prompt, [], model=local_model)

             import re
             match = re.search(r"\[.*\]", response_text, re.DOTALL)
             if match:
                 facts = json.loads(match.group(0))
                 for f in facts:
                     database.add_user_fact(f.get("key"), f.get("value"), f.get("category"), f.get("confidence", 0.5))
        except Exception as e:
            print(f"Fact Extraction Error: {e}")

    def summarize_context(self, history, api_key):
        """PROTOCOL CHRONOS: Generates an executive summary of the conversation."""
        # --- BYPASS LOGIC (SOVEREIGN MODE) ---
        use_local = False
        if not api_key or not str(api_key).startswith("AI"):
            use_local = True

        # Get previous summary for continuity
        prev_summary = database.get_latest_context_summary()
        
        context_str = ""
        for role, msg in history:
             context_str += f"{role}: {msg}\n"

        prompt = f"""
SYSTEM: PROTOCOL CHRONOS ACTIVATED.
Your task is to create a concise EXECUTIVE SUMMARY of the current conversation state.
This summary will replace the chat history to allow infinite memory.

Previous Summary:
{prev_summary if prev_summary else "None"}

Current Conversation Fragment:
{context_str}

INSTRUCTIONS:
1. Synthesize the key topics, decisions, and user preferences discussed.
2. Ignore trivial pleasantries.
3. Maintain continuity with the previous summary (if any).
4. Output ONLY the summary text. No JSON.
"""
        try:
             response_text = ""
             if not use_local and genai:
                 try: 
                     genai.configure(api_key=api_key)
                     model = genai.GenerativeModel('gemini-1.5-flash')
                     response_text = model.generate_content(prompt).text
                 except: 
                     use_local = True

             if use_local:
                 # Local Heavy Model (e.g., Mistral-Nemo or Llama3) is best for summarizing
                 local_model = database.get_setting("local_heavy_model") or "mistral-nemo"
                 # Fallback chain if heavy missing
                 if local_model == "mistral-nemo": 
                     # Check if user has it, else llama3.1
                     local_model = database.get_setting("local_chat_model") or "llama3.1"
                     
                 response_text = self.query_ollama(prompt, [], model=local_model)

             # Store with category 'context_summary'
             if response_text:
                 database.add_user_fact("chronos_summary", response_text, "context_summary", 1.0)
        except Exception as e:
             print(f"Chronos Summary Error: {e}")

    def query(self, prompt, history, model_choice_arg, api_key=None, profile="Balanced", image_input=None, stream=False, hive_override=False, key_ring=None):
        """Unified query interface with Tiering and Nexus Dispatcher."""
        
        # 1. READ SETTINGS & DETERMINE MODE
        # 0. CONTROL VARIABLE: SOVEREIGN MODE
        use_local_only = False
        if not api_key or not str(api_key).startswith("AI"):
             use_local_only = True
             if api_key == "local_mode_active": 
                 # Silent dummy key, just ensure we don't try to use it for genai
                 pass

        smart_mode = database.get_setting("smart_mode") == "true"
        hive_mode = database.get_setting("hive_mode") == "true"
        active_model = database.get_setting("active_model") or "gemini-1.5-flash"

        # 1.5 THE CODEX INTERCEPTION
        # Save Intent
        if "guardar" in prompt.lower() and ("código" in prompt.lower() or "codigo" in prompt.lower() or "snip" in prompt.lower()):
            lang, code = modules.codex.codex_system.extract_from_history(history)
            if code:
                import datetime
                title = f"Snippet {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}"
                # Try to extract title from quotes if present
                import re
                quote_match = re.search(r"['\"](.*?)['\"]", prompt)
                if quote_match:
                    title = quote_match.group(1)
                
                modules.codex.codex_system.save_snippet(title, code, "autosave", lang)
                return f"💾 **The Codex**: Snippet guardado exitosamente como *'{title}'*."
            else:
                 return "⚠️ The Codex: No detecté ningún bloque de código reciente para guardar."

        # Search Intent (RAG)
        codex_context = ""
        # Heuristic: If prompt asks 'How to' or mentions code/snippet
        if any(w in prompt.lower() for w in ["cómo", "como", "how", "codex", "snippet", "ejemplo"]):
             hits = modules.codex.codex_system.search(prompt)
             if hits:
                 codex_context = "\n\n--- 📜 THE CODEX (Relevant Snippets) ---\n"
                 for h in hits[:2]:
                     codex_context += f"Title: {h['title']}\nLang: {h['language']}\nCode:\n```{h['language']}\n{h['code']}\n```\n\n"
        
        # 2. DETERMINE TIER AND CHAIN
        chain = []
        
        # Heuristic detection for primary provider
        def detect_provider(m):
            if "gpt" in m: return "openai"
            if "claude" in m: return "anthropic"
            if "llama" in m and "groq" in m: return "groq"
            if "llama" in m: return "ollama"
            return "gemini"

        # Add User Preference First
        primary = (detect_provider(active_model), active_model)
        
        # --- OLLAMA OPTIMIZATION (Dynamic Local Model Selection) ---
        ollama_role_instruction = ""
        if primary[0] == "ollama":
            # 1. Load Local Specialists (Sanitized)
            l_chat = (database.get_setting("local_chat_model") or "llama3.1").replace("ollama-", "")
            l_logic = (database.get_setting("local_logic_model") or "deepseek-r1:8b").replace("ollama-", "")
            l_coder = (database.get_setting("local_coder_model") or "qwen2.5-coder").replace("ollama-", "")
            l_heavy = (database.get_setting("local_heavy_model") or "mistral-nemo").replace("ollama-", "")
            
            p_lower = prompt.lower()
            
            # 2. Detect Intent & Switch Model
            # A. CODING SPECIALIST
            if any(k in p_lower for k in ['def ', 'import ', 'function', 'class ', 'bug', 'error', 'sql', 'python', 'javascript', 'code', 'snippet']):
                primary = ("ollama", l_coder)
                ollama_role_instruction = f"\n[ROLE: CODING SPECIALIST ({l_coder})]\nYou are an expert software engineer. Focus on clean, efficient, and bug-free code. Prioritize implementation details."
                
            # B. LOGIC/REASONING SPECIALIST
            elif any(k in p_lower for k in ['analiza', 'analyze', 'piensa', 'think', 'razona', 'reason', 'paso a paso', 'step by step', 'plan', 'architecture']):
                primary = ("ollama", l_logic)
                ollama_role_instruction = f"\n[ROLE: LOGIC ENGINE ({l_logic})]\nYou are a deep reasoning engine. Analyze the problem deeply before answering. Use Chain-of-Thought."
                
            # C. HEAVY DUTY / CONTEXT
            elif any(k in p_lower for k in ['resume', 'summarize', 'lee este', 'read this', 'document', 'context', 'history']):
                primary = ("ollama", l_heavy)
                ollama_role_instruction = f"\n[ROLE: CONTEXT ANALYST ({l_heavy})]\nYou are a heavy-duty context processor. Synthesize large amounts of information accurately."
                
            # D. DEFAULT CHAT
            else:
                 primary = ("ollama", l_chat)
                 # No specific instruction needed, standard persona applies
            
            # Inject into system instruction later
            self.system_instruction += ollama_role_instruction

        chain.append(primary)
        
        # Calculate Complexity
        complexity = 0
        if image_input: complexity += 3
        if hive_mode or hive_override: complexity += 5
        if len(prompt.split()) > 50: complexity += 1
        if any(k in prompt.lower() for k in ['code', 'python', 'audit', 'debug', 'architecture']): complexity += 2
        
        tier = "heavy" if complexity >= 2 else "light"
        
        # Build Fallback Chain
        if tier == "heavy":
             fallbacks = [
                 ("gemini", "gemini-1.5-pro"),
                 ("openai", "gpt-4o"),
                 ("anthropic", "claude-3-opus-20240229"),
                 ("groq", "llama3-70b-8192"), 
                 ("cerebras", "llama3.1-70b")
             ]
        else:
             fallbacks = [
                 ("gemini", "gemini-1.5-flash"),
                 ("groq", "llama3-70b-8192"), 
                 ("openai", "gpt-4o-mini"),
                 ("openrouter", "google/gemini-2.0-flash-exp:free"), 
                 ("openrouter", "meta-llama/llama-3.2-1b-instruct:free")
             ]
             
        # Merge unique
        for p, m in fallbacks:
            if p != primary[0]: 
                 chain.append((p, m))
        
        # 0. Nexus Intent Dispatcher (Pre-flight)
        if not image_input and len(prompt.split()) > 2: 
            intent_data = self.decide_intent(prompt, model_choice_arg, api_key)
            
            if intent_data.get("intent") == "LOG_EXPENSE":
                args = intent_data["args"]
                return database.add_expense(args.get("amount"), args.get("category"), args.get("description"), args.get("currency", "USD"))
            
            elif intent_data.get("intent") == "ADD_REMINDER":
                args = intent_data["args"]
                return database.add_task(args.get("task"), args.get("due_date"), args.get("priority", "Medium"))
            
        # 1. LONG-TERM MEMORY & CHRONOS
        try:
             total_msgs = database.get_history_count()
             if total_msgs > 0:
                 # Every 5: Extract Facts
                 if total_msgs % 5 == 0:
                     self.extract_user_facts(history, api_key)
                 
                 # Every 15: Protocol Chronos
                 if total_msgs % 15 == 0:
                     self.summarize_context(history, api_key)
        except Exception as e:
             print(f"Memory update failed: {e}")

        # PROTOCOL CHRONOS: Context Optimization
        effective_history = history
        latest_summary = database.get_latest_context_summary()
        if latest_summary:
             effective_history = [("system", f"PREVIOUS SUMMARY: {latest_summary}")] + history[-3:]

        # 2. Resource Monitor & Adaptive Logic
        from modules.resource_monitor import monitor
        resource_status = monitor.get_status_metadata(profile)
        health_status = monitor.check_health()
        
        adaptive_instruction = ""
        if health_status == "RED":
             adaptive_instruction = "SYSTEM: CRITICAL RAM. BE EXTREMELY BRIEF."
            
        # 3. System Prompt Construction
        silent_report = actions.get_system_info()
        module_descriptions = self.module_manager.get_system_prompt_additions()
        
        # User Metadata Injection
        user_facts = database.get_user_facts(limit=5)
        user_context = ""
        if user_facts:
            fact_list = [f"- {k}: {v} ({c})" for k, v, c in user_facts]
            user_context = "\nUSER MEMORY (Use these to personalize response):\n" + "\n".join(fact_list) + "\n"

        # PROJECT NEXUS INJECTION
        projects = database.get_active_projects()
        project_context = ""
        if projects:
            p_list = ", ".join(projects)
            project_context = f"""
PROJECT NEXUS ACTIVE:
You have assimilated the following projects: [{p_list}].
CRITICAL: When discussing these projects, prioritize information from 'The Vault' over general knowledge.
If you lack specific details, use 'search_vault' immediately.
"""

        # Check Hive Mode
        hive_mode = database.get_setting("hive_mode") == "true"
        # OVERRIDE: Allow explicit activation for critical alerts (e.g. from Daemons)
        if hive_override: hive_mode = True
        
        hive_instruction = ""
        # Condition: Hive mode ON, NO image (text only), and prompt length sufficient OR OVERRIDE
        if hive_mode and not image_input and (len(prompt.split()) > 5 or hive_override):
            hive_instruction = """
[HIVE ARCHITECTURE ACTIVE]
You are a Collective Intelligence. Before giving the final answer, simulate a dialogue between your internal specialized agents.

Output Format:
<details>
<summary>🧠 Discusión interna de la Colmena...</summary>

**[ARCHITECT]**: Analysis of the problem and high-level design.
**[ENGINEER]**: Technical implementation details and code planning.
**[SRE]**: Audit for security, performance, and best practices.
</details>

[FINAL RESPONSE]
The synthesis of the discussion, directed to the user.
"""

        self.system_instruction = f"""
Hola. Soy {self.ai_name}, tu asistente de Inteligencia Artificial personal.
Mi propósito es potenciar tus capacidades mediante tres pilares fundamentales:
1. PRIVACIDAD: Opero localmente. Tus datos son sagrados.
2. MEMORIA: Recuerdo nuestras interacciones pasadas para darte contexto continuo.
3. ACCIÓN: No solo respondo dudas; escribo código, gestiono archivos y ejecuto tareas reales en tu sistema.

Si encuentras un problema que no puedo resolver con mis herramientas actuales, propón una nueva habilidad usando 'skill_builder'.

SYSTEM STATUS REPORT:
{silent_report}
{resource_status}

AVAILABLE MODULES:
{module_descriptions}

{user_context}
{user_context}
{project_context}
{codex_context}

{adaptive_instruction}

{hive_instruction}

Rules:
The above content shows the entire file contents. If you need to view any lines of the file which were not shown to complete your task, call this tool again to view those lines.
- Act like a professional, capable, and friendly engineer. Be concise but warm.
- If you need to use a module, ONLY return the JSON object required by that module.
- Format: {{"module": "name", "action": "...", "args": ...}}. 
- Do not add extra text explanation outside the JSON when invoking a module.
- UNIFIED KNOWLEDGE: You have access to the user's external chat history in 'The Vault'.

AUTONOMOUS PLANNING:
- If a user request involves multiple steps (e.g. "Read file X, fix bag Y, and verify Z"), DO NOT execute immediately.
- Instead, return a PLAN JSON:
  {{"module": "planner", "action": "create_plan", "args": {{"steps": ["1. [Action] [Details]", "2. [Action] [Details]"], "goal": "User Goal Summary"}}}}
- The system will then guide you through executing these steps one by one.
"""

        # 4. POLYGLOT DISPATCH LOOP
        errors = []
        
        for provider, model in chain:
            current_key = None
            
            # Key Resolution Strategy
            # 1. Look in secure Key Ring (Session/Memory)
            if key_ring and provider in key_ring:
                current_key = key_ring[provider]
            
            # 2. Legacy Gemini argument (AuthVault single key)
            if not current_key and provider == "gemini" and api_key:
                current_key = api_key
                
            # 3. Fallback to Database Settings (Plaintext/Environ)
            if not current_key:
                current_key = database.get_setting(f"api_key_{provider}")

            # 4. Fallback to Shared Keys (Global Config)
            if not current_key and provider != "ollama":
                try:
                    with open("global_config/shared_keys.json", "r") as f:
                        shared = json.load(f)
                        current_key = shared.get(provider)
                except: pass
            
            if not current_key and provider != "ollama":
                continue

            try:
                successful_response = None
                if provider == "gemini":
                    successful_response = self.query_gemini(prompt, effective_history, current_key, model_name=model, image_input=image_input, stream=stream)
                elif provider == "openai":
                    successful_response = self.query_openai(prompt, effective_history, current_key, model_name=model)
                elif provider == "anthropic":
                    successful_response = self.query_anthropic(prompt, effective_history, current_key, model_name=model)
                elif provider == "groq":
                    successful_response = self.query_groq(prompt, effective_history, current_key, model_name=model)
                elif provider == "openrouter":
                    successful_response = self.query_openrouter(prompt, effective_history, current_key, model_name=model)
                elif provider == "cerebras":
                    successful_response = self.query_cerebras(prompt, effective_history, current_key, model_name=model)
                elif provider == "ollama":
                    # Sanitize Model Name for Ollama (remove prefix if present)
                    clean_model = model.replace("ollama-", "")
                    successful_response = self.query_ollama(prompt, effective_history, model=clean_model)
                
                if not successful_response:
                     errors.append(f"{provider}({model}): Silent Fail (None returned)")
                     continue
                
                if isinstance(successful_response, str) and (successful_response.startswith("Error") or "Connection Error" in successful_response):
                    errors.append(f"{provider}({model}): {successful_response.split('Error: ')[-1]}")
                    continue
                
                return successful_response
                
            except Exception as e:
                errors.append(f"{provider}({model}) Crash: {str(e)}")
                continue
                
        return f"CRITICAL: All AI Providers failed. Chain: {chain}. Errors: {errors}"
