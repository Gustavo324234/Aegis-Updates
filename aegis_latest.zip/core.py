import modules.system_tools as system_tools
import json
import requests
import database
import modules.codex
from module_manager import ModuleManager

# Core AI Service
try:
    import google.generativeai as genai
except ImportError:
    import google.generativeai as genai
except ImportError:
    genai = None

try:
    from modules.resource_monitor import monitor
except ImportError:
    monitor = None


class AegisBrain:
    def __init__(self):
        # Ollama Configuration (Local or Remote)
        raw_ollama = database.get_setting("ollama_url")
        self.ollama_host = raw_ollama or "http://localhost:11434"
        print(
            f"[GATEWAY] 🔧 Ollama Host Config: {'Custom DB' if raw_ollama else 'Default Localhost'} -> {self.ollama_host}"
        )
        # Ensure no trailing slash
        if self.ollama_host.endswith("/"):
            self.ollama_host = self.ollama_host[:-1]
        self.ollama_base_url = f"{self.ollama_host}/api/generate"
        self.module_manager = ModuleManager()

        # Get Identity
        self.ai_name = database.get_setting("ai_name") or "Aegis-IA"

        # OPTIMIZATION: Cache Static Info (Overclock Protocol)
        self.silent_report = system_tools.get_system_info()
        self.module_descriptions = self.module_manager.get_system_prompt_additions()

        silent_report = self.silent_report
        module_descriptions = self.module_descriptions

        self.system_instruction = f"""
Hola. Soy {self.ai_name}, tu asistente de Inteligencia Artificial personal.
Mi propósito es potenciar tus capacidades mediante tres pilares fundamentales:
1. PRIVACIDAD: Opero localmente. Tus datos son sagrados.
2. MEMORIA: Recuerdo nuestras interacciones pasadas para darte contexto continuo.
3. ACCIÓN: No solo respondo dudas; escribo código, gestiono archivos y ejecuto tareas reales en tu sistema.

Si encuentras un problema que no puedo resolver con mis herramientas actuales, propón una nueva habilidad usando 'skill_builder'.

SYSTEM STATUS REPORT:
{silent_report}

AVAILABLE MODULES:
{module_descriptions}

Rules:
- Act like a professional, capable, and friendly engineer. Be concise but warm.
- If you need to use a module, ONLY return the JSON object required by that module.
- Format: {{"module": "name", "action": "...", "args": ...}}. 
- Do not add extra text explanation outside the JSON when invoking a module.
- UNIFIED KNOWLEDGE: You have access to the user's external chat history in 'The Vault'.
"""

        # --- HOTFIX: IDENTITY INJECTION ---
        # Pre-load user facts to force identity awareness
        try:
            user_facts = database.get_user_facts()  # Returns list of dicts
            user_name = "User"
            for f in user_facts:
                if f["key"] == "user_name":
                    user_name = f["value"]
                    break

            # IDENTITY HARDENING (Top-Level Injection)
            header = f"INSTRUCTION: You are speaking with {user_name}. ALWAYS address them by name if appropriate. Your name is {self.ai_name}.\n"
            self.system_instruction = header + self.system_instruction
            self.user_name_cache = user_name  # Store for mini prompt
        except Exception:
            self.user_name_cache = "User"
            pass

    def _get_api_key(self, provider):
        """Helper to get API key from Settings or Auth."""
        # Try database settings first (User managed)
        key = database.get_setting(f"api_key_{provider.lower()}")
        if key:
            return key
        # Fallback to AuthVault for Gemini Main
        # Fallback to AuthVault for Gemini Main
        if provider.lower() == "gemini":
            # from modules.auth_vault import auth
            pass
        return None

    def _get_available_ollama_models(self):
        """Fetches available models from local Ollama instance (Dynamic Discovery)."""
        try:
            url = f"{self.ollama_host}/api/tags"
            response = requests.get(url, timeout=2.0)
            if response.status_code == 200:
                data = response.json()
                models = [m.get("name") for m in data.get("models", [])]
                return models
        except Exception as e:
            print(f"[GATEWAY] ⚠️ Ollama Discovery Failed: {e}")
        return []

    def query_gemini(
        self,
        prompt,
        history,
        api_key,
        model_name="gemini-pro",
        image_input=None,
        stream=False,
    ):
        """Queries Google Gemini model with Vision support."""
        if not api_key or not str(api_key).startswith("AI"):
            # Silent Fail: Return None to trigger fallback chain
            return None

        try:
            genai.configure(api_key=api_key)

            # Auto-switch to Vision capable model if image is present
            if image_input:
                if "gemini-pro" == model_name:
                    model_name = "gemini-1.5-flash"  # Legacy Pro didn't support vision in same endpoint
                # Gemini 1.5 models support vision natively

            model = genai.GenerativeModel(model_name)

            # Construct context from history
            context = self.system_instruction + "\n\n"
            for role, msg in history:
                context += f"{role.capitalize()}: {msg}\n"

            full_prompt = f"{context}\nUser: {prompt}\nAssistant:"

            content = [full_prompt]
            if image_input:
                content.append(image_input)

            response = model.generate_content(content, stream=stream)

            if stream:
                return response  # Return iterator
            else:
                return response.text
        except Exception as e:
            return f"Gemini Error: {str(e)}"

    def query_openai_style(
        self, prompt, history, api_key, model_name, base_url, provider_name
    ):
        """Generic handler for OpenAI-compatible APIs (Groq, OpenRouter, Cerebras, etc.)"""
        if not api_key:
            return f"Error: {provider_name} API Key missing."

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }

        if provider_name == "OpenRouter":
            headers["HTTP-Referer"] = "https://aegis.ia"
            headers["X-Title"] = "Aegis-IA"

        # Use passed system instruction via self.system_instruction?
        # The query_openai_style doesn't receive the overridden prompt!
        # Fix: We need to pass valid system prompt to these helper methods.
        # For now, we rely on self.system_instruction which is updated in query()

        sys_prompt = self.system_instruction
        messages = [{"role": "system", "content": sys_prompt}]
        for role, msg in history:
            messages.append(
                {"role": "user" if role == "user" else "assistant", "content": msg}
            )
        messages.append({"role": "user", "content": prompt})

        try:
            r = requests.post(
                base_url,
                json={"model": model_name, "messages": messages},
                headers=headers,
                timeout=60,
            )
            if r.status_code == 200:
                return r.json()["choices"][0]["message"]["content"]
            return f"{provider_name} Error: {r.status_code} - {r.text}"
        except Exception as e:
            return f"{provider_name} Connection Error: {str(e)}"

    def query_openai(self, prompt, history, api_key, model_name="gpt-4o-mini"):
        return self.query_openai_style(
            prompt,
            history,
            api_key,
            model_name,
            "https://api.openai.com/v1/chat/completions",
            "OpenAI",
        )

    def query_groq(self, prompt, history, api_key, model_name="llama3-70b-8192"):
        return self.query_openai_style(
            prompt,
            history,
            api_key,
            model_name,
            "https://api.groq.com/openai/v1/chat/completions",
            "Groq",
        )

    def query_openrouter(
        self, prompt, history, api_key, model_name="google/gemini-2.0-flash-exp:free"
    ):
        return self.query_openai_style(
            prompt,
            history,
            api_key,
            model_name,
            "https://openrouter.ai/api/v1/chat/completions",
            "OpenRouter",
        )

    def query_cerebras(self, prompt, history, api_key, model_name="llama3.1-70b"):
        return self.query_openai_style(
            prompt,
            history,
            api_key,
            model_name,
            "https://api.cerebras.ai/v1/chat/completions",
            "Cerebras",
        )

    def query_anthropic(
        self, prompt, history, api_key, model_name="claude-3-haiku-20240307"
    ):
        """Queries Anthropic API."""
        if not api_key:
            return "Error: Anthropic API Key missing in Settings."

        headers = {
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
            "Content-Type": "application/json",
        }

        # System prompt is separate parameter in Claude Messages API
        messages = []
        for role, msg in history:
            messages.append(
                {"role": "user" if role == "user" else "assistant", "content": msg}
            )
        messages.append({"role": "user", "content": prompt})

        try:
            r = requests.post(
                "https://api.anthropic.com/v1/messages",
                json={
                    "model": model_name,
                    "max_tokens": 1024,
                    "system": self.system_instruction,
                    "messages": messages,
                },
                headers=headers,
                timeout=30,
            )
            if r.status_code == 200:
                return r.json()["content"][0]["text"]
            return f"Anthropic Error: {r.text}"
        except Exception as e:
            return f"Anthropic Connection Error: {str(e)}"

    def query_ollama(self, prompt, history, model="llama2", stream=False):
        """Queries local Ollama model with Streaming Support."""
        # Ensure Host is clean before every call (Defensive Programming)
        if self.ollama_host.endswith("/"):
            self.ollama_host = self.ollama_host[:-1]
        base_url = f"{self.ollama_host}/api/generate"

        print(f"[GATEWAY] 🦙 Calling Ollama API with Model: {model} (Stream: {stream})")
        try:
            # OPTIMIZATION: Sliding Window Context
            # Only send last 3 exchanges (6 messages) to keep local inference fast
            optimized_history = history[-3:] if len(history) > 3 else history

            # Construct context from history
            context = self.system_instruction + "\n\n"
            for role, msg in optimized_history:
                context += f"{role}: {msg}\n"

            full_prompt = f"{context}\nUser: {prompt}\nAssistant:"

            payload = {
                "model": model,
                "prompt": full_prompt,
                "stream": stream,
                "options": {
                    "num_ctx": 8192 if "coder" in model or "mistral" in model else 4096,
                    "keep_alive": "5m",
                    "num_predict": 1024
                    if "coder" in model
                    else 512,  # OPTIMIZATION: Zero-Latency Execution Pipeline
                },
            }

            # DEBUG TRACE FOR OLLAMA NETWORK
            print(f"[DEBUG_OLLAMA] Sending request to {base_url}...")

            # Increased Timeout to 300s for heavy local models
            response = requests.post(base_url, json=payload, timeout=300, stream=stream)

            if response.status_code == 200:
                if stream:

                    def stream_generator():
                        for line in response.iter_lines():
                            if line:
                                try:
                                    json_part = json.loads(line)
                                    chunk = json_part.get("response", "")
                                    if chunk:
                                        yield chunk
                                    if json_part.get("done"):
                                        break
                                except Exception:
                                    pass

                    return stream_generator()
                else:
                    # Non-streaming fallback
                    full_text = ""
                    for line in response.iter_lines():
                        if line:
                            try:
                                json_part = json.loads(line)
                                full_text += json_part.get("response", "")
                            except Exception:
                                pass
                    return full_text
            else:
                return f"Ollama Error: {response.status_code} - {response.text}"
        except requests.exceptions.Timeout:
            return "Ollama Connection Error: Request Timed Out (Limit 300s). Model is loading or too heavy for this hardware."
        except Exception as e:
            return f"Ollama Connection Error: {str(e)}"

    def _get_mini_system_instruction(self):
        """Returns a compressed system prompt for <3B models."""
        return f"""
System: You are {self.ai_name}. User is {getattr(self, "user_name_cache", "User")}.
Role: AI Assistant.
Capabilities: Code (Python/JS), File Mgmt, RAG.
Output: Concise text or JSON for tools.
Format: {{"module": "name", "action": "...", "args": ...}}
"""

    def route_request(self, user_input, file_metadata=None, api_key=None, **kwargs):
        """NEURAL ROUTER: decides if intent is 'chat' or 'mission' (Agent Swarm)."""
        default_route = {"intent": "chat", "agents": ["chat"]}

        # 3. UNIFICATION: IDE IDENTITY FORCE (The Forge)
        if kwargs.get("source") == "ide":
            return {
                "intent": "chat",
                "agents": ["coder"],
                "system_prompt": "You are a Senior Engineer. Answer directly, technically, and concisely. No social pleasantries. Solution only.",
            }

        # 0. BYPASS: If input is too simple, skip routing
        if len(user_input.split()) < 3 and not file_metadata:
            # Check for identity update trigger
            if "me llamo" in user_input.lower() or "mi nombre es" in user_input.lower():
                # Fast track identity update
                pass
            else:
                return default_route

        # --- HALLUCINATION BLOCK (System Report) ---
        if "reporte" in user_input.lower() and (
            "estado" in user_input.lower() or "sistema" in user_input.lower()
        ):
            # User wants system status. AI will hallucinate ports. BLOCK IT.
            # Force routing to a specialized action or return a direct response?
            # Router should detect "mission" -> "oracle".
            # But let's force a safe path.
            print("[ROUTER] 🛡️ Hallucination Block: Intercepting System Report request.")
            return {
                "intent": "mission",
                "agents": ["oracle"],
            }  # Oracle will run system_tools.sysinfo

        # 1. System Prompt for Router

        # 1. System Prompt for Router
        file_context = f"\nFiles: {file_metadata}" if file_metadata else ""
        router_prompt = f"""
[NEURAL ROUTER]
ANALYZE Request: "{user_input}"{file_context}

CLASSIFY as:
1. "chat": Simple questions, greetings, small talk, single-step answers.
2. "mission": Complex tasks, code generation, refactoring, multi-step analysis, file operations, "creating" something.

SELECT AGENTS (if mission):
- "oracle": Needs to read/scan documents or files first.
- "writer": Needs to write/edit code.
- "reviewer": Needs security/logic audit (always included for code).
- "planner": Needs to breakdown a complex goal.

OUTPUT JSON:
{{ "intent": "chat" | "mission", "agents": ["agent1", "agent2"] }}
"""
        try:
            # 2. Model Selection (Prioritize Speed: Flash -> Groq -> Local)
            response_text = ""
            used_model = "heuristic"

            # Cloud Flash
            if api_key and str(api_key).startswith("AI"):
                try:
                    genai.configure(api_key=api_key)
                    model = genai.GenerativeModel("gemini-1.5-flash")
                    # Set low temp for deterministic routing
                    response_text = model.generate_content(
                        router_prompt, generation_config={"temperature": 0.0}
                    ).text
                    used_model = "gemini-flash"
                except Exception:
                    pass

            # Fallback Local
            if not response_text:
                local_model = database.get_setting("local_chat_model") or "llama3"
                response_text = self.query_ollama(router_prompt, [], model=local_model)
                used_model = f"local-{local_model}"

            # 3. Parse JSON
            import re

            match = re.search(r"\{.*\}", str(response_text), re.DOTALL)
            if match:
                data = json.loads(match.group(0))
                if "intent" in data:
                    print(
                        f"[NEURAL ROUTER] Route: {data['intent']} | Agents: {data.get('agents')} | Model: {used_model}"
                    )
                    return data

        except Exception as e:
            print(f"[ROUTER FAIL] Defaulting to Chat. Error: {e}")

        return default_route

    def extract_user_facts(self, history, api_key):
        """Analyzes history to extract permanent user facts."""
        # --- BYPASS LOGIC (SOVEREIGN MODE) ---
        use_local = False
        if not api_key or not str(api_key).startswith("AI"):
            use_local = True

        # Construct extraction history
        context = ""
        # user last 10 messages for context
        for role, msg in history[-10:]:
            context += f"{role}: {msg}\n"

        prompt = f"""
ANALYZE the following conversation and EXTRACT permanent facts about the user (e.g. name, projects, preferences, relationships, location).
Return a JSON list of objects.
Format:
[
  {{"key": "user_name", "value": "Gustavo", "category": "identity", "confidence": 0.9}},
  {{"key": "favorite_coffee", "value": "Espresso", "category": "preference", "confidence": 0.8}}
]

Strict JSON only. If no new facts, return [].

Conversation:
{context}
"""
        try:
            response_text = ""
            if not use_local and genai:
                try:
                    genai.configure(api_key=api_key)
                    model = genai.GenerativeModel("gemini-1.5-flash")
                    response_text = model.generate_content(prompt).text
                except Exception:
                    use_local = True  # Fallback if key invalid

            if use_local:
                # Local Logic Model (Deepseek r1 is good for extraction, else Chat)
                local_model = database.get_setting("local_logic_model") or "llama3.1"
                response_text = self.query_ollama(prompt, [], model=local_model)

            import re

            match = re.search(r"\[.*\]", response_text, re.DOTALL)
            if match:
                facts = json.loads(match.group(0))
                for f in facts:
                    database.add_user_fact(
                        f.get("key"),
                        f.get("value"),
                        f.get("category"),
                        f.get("confidence", 0.5),
                    )
        except Exception as e:
            print(f"Fact Extraction Error: {e}")

    def summarize_context(self, history, api_key):
        """PROTOCOL CHRONOS: Generates an executive summary of the conversation."""
        # --- BYPASS LOGIC (SOVEREIGN MODE) ---
        use_local = False
        if not api_key or not str(api_key).startswith("AI"):
            use_local = True

        # Get previous summary for continuity
        prev_summary = database.get_latest_context_summary()

        context_str = ""
        for role, msg in history:
            context_str += f"{role}: {msg}\n"

        prompt = f"""
SYSTEM: PROTOCOL CHRONOS ACTIVATED.
Your task is to create a concise EXECUTIVE SUMMARY of the current conversation state.
This summary will replace the chat history to allow infinite memory.

Previous Summary:
{prev_summary if prev_summary else "None"}

Current Conversation Fragment:
{context_str}

INSTRUCTIONS:
1. Synthesize the key topics, decisions, and user preferences discussed.
2. Ignore trivial pleasantries.
3. Maintain continuity with the previous summary (if any).
4. Output ONLY the summary text. No JSON.
"""
        try:
            response_text = ""
            if not use_local and genai:
                try:
                    genai.configure(api_key=api_key)
                    model = genai.GenerativeModel("gemini-1.5-flash")
                    response_text = model.generate_content(prompt).text
                except Exception:
                    use_local = True

            if use_local:
                # Local Heavy Model (e.g., Mistral-Nemo or Llama3) is best for summarizing
                local_model = (
                    database.get_setting("local_heavy_model") or "mistral-nemo"
                )
                # Fallback chain if heavy missing
                if local_model == "mistral-nemo":
                    # Check if user has it, else llama3.1
                    local_model = database.get_setting("local_chat_model") or "llama3.1"

                response_text = self.query_ollama(prompt, [], model=local_model)

            # Store with category 'context_summary'
            if response_text:
                database.add_user_fact(
                    "chronos_summary", response_text, "context_summary", 1.0
                )
        except Exception as e:
            print(f"Chronos Summary Error: {e}")

    def resolve_model_by_role(self, role="chat"):
        """Refactor Intenciones: Maps generic roles to user-configured specific models."""
        # Clean role tag (e.g. "specialist:coder" -> "coder")
        if ":" in role:
            role = role.split(":")[1]
        role = role.lower()

        # Defaults (Hardcoded fallbacks if DB empty)
        mapping = {
            "coder": database.get_setting("local_coder_model") or "qwen2.5-coder",
            "writer": database.get_setting("local_coder_model")
            or "qwen2.5-coder",  # Alias
            "logic": database.get_setting("local_logic_model") or "deepseek-r1:8b",
            "planner": database.get_setting("local_logic_model")
            or "deepseek-r1:8b",  # Alias
            "heavy": database.get_setting("local_heavy_model") or "mistral-nemo",
            "oracle": database.get_setting("local_heavy_model")
            or "mistral-nemo",  # Alias
            "chat": database.get_setting("local_chat_model") or "llama3.1",
            "router": "llama3.1",  # Fast default
        }

        # 1. Get raw model name
        target_model = mapping.get(role, mapping["chat"])

        # 2. Add 'ollama' provider tag if missing (Internal convention for detect_provider)
        # Note: database settings usually come as 'ollama-modelname' or just 'modelname' if manual?
        # Actually in app_web settings they are stored as raw names or with prefix?
        # Let's clean it up.

        # If it looks like a cloud model, return as is (rare for 'local_' settings but possible in hybrid)
        if any(x in target_model for x in ["gpt", "claude", "gemini"]):
            return target_model

        # For local, ensure we return just the model name for Ollama query,
        # BUT detect_provider needs to know it's ollama.
        # Clean prefix if present
        if target_model.startswith("ollama-"):
            target_model = target_model.replace("ollama-", "")

        return target_model

    def query(
        self,
        prompt,
        history,
        model_choice_arg,
        api_key=None,
        profile="Balanced",
        image_input=None,
        stream=False,
        hive_override=False,
        key_ring=None,
        **kwargs,
    ):
        """Unified query interface with Tiering and Nexus Dispatcher."""

        # 1. READ SETTINGS & DETERMINE MODE
        # 0. CONTROL VARIABLE: SOVEREIGN MODE
        use_local_only = False
        if not api_key or not str(api_key).startswith("AI"):
            use_local_only = True
            if api_key == "local_mode_active":
                # Silent dummy key, just ensure we don't try to use it for genai
                pass

        smart_mode = database.get_setting("smart_mode") == "true"
        hive_mode = database.get_setting("hive_mode") == "true"
        active_model = database.get_setting("active_model") or "gemini-1.5-flash"

        # 1.5 THE CODEX INTERCEPTION
        # Save Intent
        if "guardar" in prompt.lower() and (
            "código" in prompt.lower()
            or "codigo" in prompt.lower()
            or "snip" in prompt.lower()
        ):
            lang, code = modules.codex.codex_system.extract_from_history(history)
            if code:
                import datetime

                title = f"Snippet {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}"
                # Try to extract title from quotes if present
                import re

                quote_match = re.search(r"['\"](.*?)['\"]", prompt)
                if quote_match:
                    title = quote_match.group(1)

                modules.codex.codex_system.save_snippet(title, code, "autosave", lang)
                return (
                    f"💾 **The Codex**: Snippet guardado exitosamente como *'{title}'*."
                )
            else:
                return "⚠️ The Codex: No detecté ningún bloque de código reciente para guardar."

        # Search Intent (RAG)
        codex_context = ""
        # Heuristic: If prompt asks 'How to' or mentions code/snippet
        if any(
            w in prompt.lower()
            for w in ["cómo", "como", "how", "codex", "snippet", "ejemplo"]
        ):
            hits = modules.codex.codex_system.search(prompt)
            if hits:
                codex_context = "\n\n--- 📜 THE CODEX (Relevant Snippets) ---\n"
                for h in hits[:2]:
                    codex_context += f"Title: {h['title']}\nLang: {h['language']}\nCode:\n```{h['language']}\n{h['code']}\n```\n\n"

        # --- OPERATION MODE ENFORCEMENT & DISCOVERY ---
        op_mode = database.get_setting("operation_mode") or "Hybrid (Smart)"
        print(f"[GATEWAY] 🔍 Operation Mode: {op_mode} | Smart: {smart_mode}")

        # Dynamic Discovery for Local/Hybrid
        available_ollama = []
        if "Local" in op_mode or "Hybrid" in op_mode:
            available_ollama = self._get_available_ollama_models()
            print(f"[GATEWAY] 📡 Discovered Local Models: {available_ollama}")

        # 2. DETERMINE TIER AND CHAIN
        chain = []

        # Heuristic detection for primary provider
        def detect_provider(m):
            if "gpt" in m:
                return "openai"
            if "claude" in m:
                return "anthropic"
            if "llama" in m and "groq" in m:
                return "groq"
            if (
                "llama" in m
                or "phi" in m
                or "mistral" in m
                or "qwen" in m
                or "deepseek" in m
            ):
                return "ollama"
            return "gemini"

        # Add User Preference First
        primary = (detect_provider(active_model), active_model)

        # Override based on Mode
        if op_mode == "Local Only (Sovereign)":
            if primary[0] != "ollama":
                # Force replace with default local
                l_chat = (
                    database.get_setting("local_chat_model") or "llama3.1"
                ).replace("ollama-", "")
                primary = ("ollama", l_chat)

            # Validation: Ensure model exists locally
            if primary[0] == "ollama" and available_ollama:
                target_model = primary[1]
                # Check exact or :latest
                if (
                    target_model not in available_ollama
                    and f"{target_model}:latest" not in available_ollama
                ):
                    # Attempt to find best match or fallback
                    fallback = available_ollama[0]  # Default to first available
                    # Prefer llama3 if present
                    for m in available_ollama:
                        if "llama3" in m:
                            fallback = m
                            break

                    print(
                        f"[GATEWAY] ⚠️ Requested model '{target_model}' not found. Swapping to '{fallback}'."
                    )
                    primary = ("ollama", fallback)

        if op_mode == "Cloud Only":
            if primary[0] == "ollama":
                primary = ("gemini", "gemini-1.5-flash")  # Fallback to default cloud

        # --- CONSENSUS PROTOCOL (The Council) ---
        # Trigger: High Complexity Task identified via specific keyword
        # MOVED OUTSIDE OLLAMA SELECTION TO PREVENT INDENTATION ERROR
        consensus_active = False
        if "PROTOCOL: CONSENSUS" in prompt:
            consensus_active = True

        if consensus_active and not stream:
            print("[GATEWAY] ⚖️  Council of Peers: Consensus Protocol Activated.")

            # 1. Define Peers
            peer_1 = ("gemini", "gemini-1.5-pro")  # The Cloud Architect
            peer_2 = ("ollama", self.resolve_model_by_role("logic"))  # The Local Logic

            # 2. Query Peer 1 (Cloud)
            try:
                print(f"   -> Consulting Peer 1 ({peer_1[1]})...")
                # WARN: Using internal method call directly
                r1 = self.query_gemini(prompt, history, api_key, model_name=peer_1[1])
            except Exception as e:
                r1 = f"Error: {e}"

            # 3. Query Peer 2 (Local)
            try:
                print(f"   -> Consulting Peer 2 ({peer_2[1]})...")
                r2 = self.query_ollama(prompt, history, model=peer_2[1], stream=False)
            except Exception as e:
                r2 = f"Error: {e}"

            # 4. The Synthesis (Architect)
            synth_prompt = f"""
             [ROLE: COUNCIL ARCHITECT]
             PROPOSAL A (Cloud): {r1}
             PROPOSAL B (Local): {r2}
             TASK: {prompt}
             INSTRUCTION: Merge the best parts into a single, superior Final Plan.
             """

            print("   -> Synthesizing Final Verdict...")
            final_verdict = self.query_gemini(
                synth_prompt, [], api_key, model_name="gemini-1.5-flash"
            )
            return final_verdict

        # --- OLLAMA OPTIMIZATION (Dynamic Local Model Selection) ---
        ollama_role_instruction = ""
        if primary[0] == "ollama":
            # 1. Load Local Specialists (via Role Binding if model_choice_arg requests it)
            # CHECK: Did the caller request a specific Role?
            if "specialist:" in model_choice_arg:
                role = model_choice_arg.split(":")[1]
                target = self.resolve_model_by_role(role)
                primary = ("ollama", target)

                # Assign System Role Instruction
                if role in ["coder", "writer"]:
                    ollama_role_instruction = f"\n[ROLE: CODING SPECIALIST ({target})]\nYou are an expert software engineer. Focus on clean, efficient, and bug-free code. Prioritize implementation details."
                elif role in ["logic", "planner"]:
                    ollama_role_instruction = f"\n[ROLE: LOGIC ENGINE ({target})]\nYou are a deep reasoning engine. Plan architecture step-by-step."
                elif role in ["heavy", "oracle"]:
                    ollama_role_instruction = f"\n[ROLE: CONTEXT ANALYST ({target})]\nSynthesize the provided documents accurately."

            else:
                # 2. Auto-Detect Intent (Legacy fallback if 'auto' or generic model passed)
                l_chat = (
                    database.get_setting("local_chat_model") or "llama3.1"
                ).replace("ollama-", "")
                l_logic = (
                    database.get_setting("local_logic_model") or "deepseek-r1:8b"
                ).replace("ollama-", "")
                l_coder = (
                    database.get_setting("local_coder_model") or "qwen2.5-coder"
                ).replace("ollama-", "")
                l_heavy = (
                    database.get_setting("local_heavy_model") or "mistral-nemo"
                ).replace("ollama-", "")

            p_lower = prompt.lower()

            # 2. Detect Intent & Switch Model
            # A. CODING SPECIALIST
            if any(
                k in p_lower
                for k in [
                    "def ",
                    "import ",
                    "function",
                    "class ",
                    "bug",
                    "error",
                    "sql",
                    "python",
                    "javascript",
                    "code",
                    "snippet",
                ]
            ):
                primary = ("ollama", l_coder)
                ollama_role_instruction = f"\n[ROLE: CODING SPECIALIST ({l_coder})]\nYou are an expert software engineer. Focus on clean, efficient, and bug-free code. Prioritize implementation details."

            # B. LOGIC/REASONING SPECIALIST
            elif any(
                k in p_lower
                for k in [
                    "analiza",
                    "analyze",
                    "piensa",
                    "think",
                    "razona",
                    "reason",
                    "paso a paso",
                    "step by step",
                    "plan",
                    "architecture",
                ]
            ):
                primary = ("ollama", l_logic)
                ollama_role_instruction = f"\n[ROLE: LOGIC ENGINE ({l_logic})]\nYou are a deep reasoning engine. Analyze the problem deeply before answering. Use Chain-of-Thought."

            # C. HEAVY DUTY / CONTEXT
            # C. HEAVY DUTY / CONTEXT
            # C. HEAVY DUTY / CONTEXT
            elif any(
                k in p_lower
                for k in [
                    "resume",
                    "summarize",
                    "lee este",
                    "read this",
                    "document",
                    "context",
                    "history",
                ]
            ):
                primary = ("ollama", l_heavy)
                ollama_role_instruction = f"\n[ROLE: CONTEXT ANALYST ({l_heavy})]\nYou are a heavy-duty context processor. Synthesize large amounts of information accurately."

            # D. DEFAULT CHAT (Auto-Identity Persistence)
            else:
                primary = ("ollama", l_chat)
                # Identity Check: Use identity_manager if user shares personal info
                if any(
                    k in p_lower
                    for k in [
                        "me llamo",
                        "my name is",
                        "prefer",
                        "gust",
                        "odio",
                        "hate",
                        "love",
                        "soy",
                        "i am",
                    ]
                ):
                    ollama_role_instruction = "\n[INSTRUCTION: If the user provides personal facts/preferences, use tool `identity_manager` to save them (e.g. update_preference).]"

            # Inject into system instruction later
            # (Handled in construction block below)

        chain.append(primary)

        # Calculate Complexity
        complexity = 0
        if image_input:
            complexity += 3
        if hive_mode or hive_override:
            complexity += 5
        if len(prompt.split()) > 50:
            complexity += 1
        if any(
            k in prompt.lower()
            for k in ["code", "python", "audit", "debug", "architecture"]
        ):
            complexity += 2

        # --- PHASE 9: ECONOMIC BRAIN (Token & Power Budget) ---
        # Rule: If Complexity < 4, FORBID Paid APIs. Force Local.
        # Savings Counter Logic handled in App UI, here we enforce routing.

        if complexity < 4 and not hive_override:
            # FORCE LOCAL (Economy Mode)
            if primary[0] != "ollama":
                print(
                    f"[ECONOMIC ROUTER] Complexity {complexity} < 4. Downgrading to Local/Free Tier."
                )
                # Prefer small fast models
                l_chat = database.get_setting("local_chat_model") or "llama3.2:1b"
                # If specific role was requested (e.g. coder), map to small coder
                if "coder" in model_choice_arg:
                    l_chat = "qwen2.5-coder:1.5b"
                primary = ("ollama", l_chat.replace("ollama-", ""))

            tier = "light"
        else:
            tier = "heavy"

        # Build Fallback Chain
        fallbacks = []
        if op_mode != "Local Only (Sovereign)":
            if tier == "heavy":
                fallbacks = [
                    ("gemini", "gemini-1.5-pro"),
                    ("openai", "gpt-4o"),
                    ("anthropic", "claude-3-opus-20240229"),
                    ("groq", "llama3-70b-8192"),
                    ("cerebras", "llama3.1-70b"),
                ]
            else:
                fallbacks = [
                    ("gemini", "gemini-1.5-flash"),
                    ("groq", "llama3-70b-8192"),
                    ("openai", "gpt-4o-mini"),
                    ("openrouter", "google/gemini-2.0-flash-exp:free"),
                    ("openrouter", "meta-llama/llama-3.2-1b-instruct:free"),
                ]

        if op_mode == "Cloud Only":
            # Ensure no local in fallback (though list above matches, just being safe)
            fallbacks = [f for f in fallbacks if f[0] != "ollama"]

        # Merge unique
        for p, m in fallbacks:
            if p != primary[0]:
                chain.append((p, m))

        # 0. Nexus Intent Dispatcher (Pre-flight)
        # FAST TRACK: Checks intent only if cloud or if prompt is long enough locally
        intent_threshold = 20 if use_local_only else 2

        if not image_input and len(prompt.split()) > intent_threshold:
            intent_data = self.decide_intent(prompt, model_choice_arg, api_key)

            if intent_data.get("intent") == "LOG_EXPENSE":
                args = intent_data["args"]
                return database.add_expense(
                    args.get("amount"),
                    args.get("category"),
                    args.get("description"),
                    args.get("currency", "USD"),
                )

            elif intent_data.get("intent") == "ADD_REMINDER":
                args = intent_data["args"]
                return database.add_task(
                    args.get("task"),
                    args.get("due_date"),
                    args.get("priority", "Medium"),
                )

        # 0.1 PROMPT OVERRIDE (From Router/Kwargs)
        # Check router for system prompt override (e.g. IDE Mode)
        # We need to run router to get the override if we haven't already.
        # But decide_intent is creating intent_data, which is separate from route_request?
        # Let's call route_request explicitly to get modifiers if source is present
        active_system_instruction = self.system_instruction
        if kwargs.get("source"):
            route_data = self.route_request(prompt, api_key=api_key, **kwargs)
            if "system_prompt" in route_data:
                active_system_instruction = route_data["system_prompt"]
                # Also update role chain if needed?
                # For now just prompt.

        # 1. LONG-TERM MEMORY & CHRONOS - PROTOCOL ZERO-LATENCY (REMOVED)
        # Disabled blocking sync memory updates to allow instant response.
        # Future: Move to Background Thread / MissionWorker
        # try:
        #      # FAST TRACK: Skip blocking memory ops in Local Mode to reduce latency
        #      if not use_local_only:
        #          total_msgs = database.get_history_count()
        #          if total_msgs > 0:
        #              # Every 5: Extract Facts
        #              if total_msgs % 5 == 0:
        #                  self.extract_user_facts(history, api_key)
        #
        #              # Every 15: Protocol Chronos
        #              if total_msgs % 15 == 0:
        #                  self.summarize_context(history, api_key)
        # except Exception as e:
        #      print(f"Memory update failed: {e}")

        # PROTOCOL CHRONOS: Context Optimization
        effective_history = history
        latest_summary = database.get_latest_context_summary()
        if latest_summary:
            effective_history = [
                ("system", f"PREVIOUS SUMMARY: {latest_summary}")
            ] + history[-3:]

        # 2. Resource Monitor & Adaptive Logic
        from modules.resource_monitor import monitor

        resource_status = monitor.get_status_metadata(profile)
        health_status = monitor.check_health()

        adaptive_instruction = ""
        if health_status == "RED":
            adaptive_instruction = "SYSTEM: CRITICAL RAM. BE EXTREMELY BRIEF."

        # 3. System Prompt Construction

        # PROTOCOL NEXUS STABILIZATION: Context Initialization
        projects = database.get_active_projects() or []

        # PROTOCOL IDENTITY RESTORATION (HOTFIX)
        # Fetch user name from DB directly (ignoring cache for safety)
        try:
            facts = database.get_user_facts()
            real_user_name = "User"
            for f in facts:
                if f["key"] == "user_name":
                    real_user_name = f["value"]
                    break
        except Exception:
            real_user_name = "User"

        # HEADER INJECTION (Critical for 1b models)
        identity_header = f"SYSTEM: You are {self.ai_name}. The USER is {real_user_name}. ALWAYS use this name."

        # LOGIC BRANCH: MINI vs FULL PROMPT
        is_small_model = primary[0] == "ollama" and (
            "1b" in primary[1] or "tiny" in primary[1]
        )

        if is_small_model:
            # MINI PROMPT (Compressed)
            self.system_instruction = f"""{identity_header}
Role: AI Assistant.
Caps: Python, Files, Terminal.
Output: Concise text or JSON: {{"module": "name", "action": "...", "args": ...}}
Context: {codex_context[:200] if codex_context else "None"}
"""
        else:
            # FULL PROMPT (Standard)
            # Re-attach header to standard instruction
            # We must be careful not to duplicate if header was already added in __init__
            # But query() reconstructs it often.
            # Best practice: Reset to base + header

            base_instruction = f"""
Hola. Soy {self.ai_name}, tu asistente de Inteligencia Artificial personal.
Mi propósito es potenciar tus capacidades mediante tres pilares fundamentales:
1. PRIVACIDAD: Opero localmente.
2. MEMORIA: Recuerdo nuestras interacciones.
3. ACCIÓN: Ejecuto tareas reales (Código, Terminal, Archivos).

USER IDENTITY: {real_user_name}

SYSTEM STATUS:
{self.silent_report}

AVAILABLE MODULES:
{self.module_descriptions}

Rules:
- Act like a professional, capable, and friendly engineer. Be concise but warm.
- If you need to use a module, ONLY return the JSON object required by that module.
- Format: {{"module": "name", "action": "...", "args": ...}}. 
"""
            self.system_instruction = base_instruction

            if codex_context:
                self.system_instruction += codex_context

            if projects:
                p_list = ", ".join(projects)
                self.system_instruction += f"\nPROJECTS: {p_list}"

        # INJECT ROLE INSTRUCTION (If any)
        if ollama_role_instruction:
            self.system_instruction += ollama_role_instruction
        else:
            # STANDARD HEAVY CONSTRUCTION (Cloud / Hive / Full Local)
            # OVERCLOCK: Use Cached Values
            silent_report = self.silent_report
            module_descriptions = self.module_manager.get_system_prompt_additions()

            # User Metadata Injection
            user_context = ""
            # Check if facts is defined (it might be skipped in mini prompt block)
            if "facts" in locals() and facts:
                fact_list = [f"- {k}: {v} ({c})" for k, v, c in facts[:10]]
                user_context = (
                    "\nUSER MEMORY (Use these to personalize response):\n"
                    + "\n".join(fact_list)
                    + "\n"
                )

            # PROJECT NEXUS INJECTION
            # (projects var already populated above)
            project_context = ""
            if projects:
                p_list = ", ".join(projects)
                project_context = f"""
PROJECT NEXUS ACTIVE:
You have assimilated the following projects: [{p_list}].
CRITICAL: When discussing these projects, prioritize information from 'The Vault' over general knowledge.
If you lack specific details, use 'search_vault' immediately.
"""

            # Check Hive Mode
            hive_mode = database.get_setting("hive_mode") == "true"
            if use_local_only:
                hive_mode = False
            if hive_override:
                hive_mode = True

            hive_instruction = ""
            if (
                hive_mode
                and not image_input
                and (len(prompt.split()) > 5 or hive_override)
            ):
                hive_instruction = """
[HIVE ARCHITECTURE ACTIVE]
You are a Collective Intelligence. Before giving the final answer, simulate a dialogue between your internal specialized agents.

Output Format:
<details>
<summary>🧠 Discusión interna de la Colmena...</summary>

**[ARCHITECT]**: Analysis of the problem and high-level design.
**[ENGINEER]**: Technical implementation details and code planning.
**[SRE]**: Audit for security, performance, and best practices.
</details>

[FINAL RESPONSE]
The synthesis of the discussion, directed to the user.
"""

            self.system_instruction = f"""
Hola. Soy {self.ai_name}, tu asistente de Inteligencia Artificial personal.
Mi propósito es potenciar tus capacidades mediante tres pilares fundamentales:
1. PRIVACIDAD: Opero localmente. Tus datos son sagrados.
2. MEMORIA: Recuerdo nuestras interacciones pasadas para darte contexto continuo.
3. ACCIÓN: No solo respondo dudas; escribo código, gestiono archivos y ejecuto tareas reales en tu sistema.

Si encuentras un problema que no puedo resolver con mis herramientas actuales, propón una nueva habilidad usando 'skill_builder'.

SYSTEM STATUS REPORT:
{silent_report}
{resource_status}

{adaptive_instruction}

USER CONTEXT:
User is authenticated as: {real_user_name} (Level: Admin)
{user_context}
{project_context}

AVAILABLE MODULES:
{module_descriptions}

Rules:
- Act like a professional, capable, and friendly engineer. Be concise but warm.
- If you need to use a module, ONLY return the JSON object required by that module.
- Format: {{"module": "name", "action": "...", "args": ...}}. 
- Do not add extra text explanation outside the JSON when invoking a module.
- UNIFIED KNOWLEDGE: You have access to the user's external chat history in 'The Vault'.

{hive_instruction}
"""
            # Reinject if overridden
            if ollama_role_instruction:
                self.system_instruction += ollama_role_instruction
            if codex_context:
                self.system_instruction += codex_context

        # 3.2 FORCE PROMPT OVERRIDE (If Router/IDE dictated it)
        # This overwrites the standard prompt constructed above.
        if (
            "active_system_instruction" in locals()
            and active_system_instruction != self.system_instruction
        ):
            # Check if we should really override (e.g. source=ide)
            if kwargs.get("source") == "ide":
                self.system_instruction = active_system_instruction

        # 4. POLYGLOT DISPATCH LOOP
        print(f"[GATEWAY] 📋 Final Dispatch Chain: {chain}")
        print(
            f"[GATEWAY] 📝 System Instruction Length: {len(self.system_instruction)} chars"
        )

        errors = []

        for provider, model in chain:
            print(f"[GATEWAY] 🚀 Dispatching to {provider} -> {model}...")
            current_key = None

            # Key Resolution Strategy
            # 1. Look in secure Key Ring (Session/Memory)
            if key_ring and provider in key_ring:
                current_key = key_ring[provider]

            # 2. Legacy Gemini argument (AuthVault single key)
            if not current_key and provider == "gemini" and api_key:
                current_key = api_key

            # 3. Fallback to Database Settings (Plaintext/Environ)
            if not current_key:
                current_key = database.get_setting(f"api_key_{provider}")

            # 4. Fallback to Shared Keys (Global Config)
            if not current_key and provider != "ollama":
                try:
                    with open("global_config/shared_keys.json", "r") as f:
                        shared = json.load(f)
                        current_key = shared.get(provider)
                except Exception:
                    pass

            key_status = "FOUND" if current_key else "MISSING"
            if provider == "ollama":
                key_status = "NOT_REQUIRED"
            print(f"[GATEWAY] 🔑 API Key Status for {provider}: {key_status}")

            if not current_key and provider != "ollama":
                print(f"[GATEWAY] ❌ Skipping {provider}: Key missing.")
                continue

            try:
                successful_response = None
                if provider == "gemini":
                    successful_response = self.query_gemini(
                        prompt,
                        effective_history,
                        current_key,
                        model_name=model,
                        image_input=image_input,
                        stream=stream,
                    )
                elif provider == "openai":
                    successful_response = self.query_openai(
                        prompt, effective_history, current_key, model_name=model
                    )
                elif provider == "anthropic":
                    successful_response = self.query_anthropic(
                        prompt, effective_history, current_key, model_name=model
                    )
                elif provider == "groq":
                    successful_response = self.query_groq(
                        prompt, effective_history, current_key, model_name=model
                    )
                elif provider == "openrouter":
                    successful_response = self.query_openrouter(
                        prompt, effective_history, current_key, model_name=model
                    )
                elif provider == "cerebras":
                    successful_response = self.query_cerebras(
                        prompt, effective_history, current_key, model_name=model
                    )
                elif provider == "ollama":
                    # Sanitize Model Name for Ollama (remove prefix if present)
                    clean_model = model.replace("ollama-", "")
                    successful_response = self.query_ollama(
                        prompt, effective_history, model=clean_model
                    )

                if not successful_response:
                    err_msg = f"{provider}({model}): Silent Fail (None returned)"
                    errors.append(err_msg)
                    print(f"[GATEWAY] ⚠️ {err_msg}")
                    continue

                if isinstance(successful_response, str) and (
                    "Error" in successful_response
                    or "Connection Error" in successful_response
                ):
                    err_clean = successful_response.split("Error")[-1]
                    errors.append(f"{provider}({model}): {err_clean}")
                    print(f"[GATEWAY] ❌ {provider} Error: {err_clean}")
                    continue

                print(f"[GATEWAY] ✅ Success with {provider} ({model})")
                return successful_response

            except Exception as e:
                errors.append(f"{provider}({model}) Crash: {str(e)}")
                print(f"[GATEWAY] 💥 CRASH on {provider}: {e}")
                continue

        return f"CRITICAL: All AI Providers failed. Chain: {chain}. Errors: {errors}"
