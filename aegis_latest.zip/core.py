from core_engine.brain import AegisBrain
# Facade for backward compatibility
# Existing imports in app_web.py rely on: from core import AegisBrain
# This file bridges the gap.

__all__ = ["AegisBrain"]
